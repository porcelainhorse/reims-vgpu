// RgfxSurfaceCaches: the IOSurfaces whose shared blocks have a device cache on the host
// (RGFX_SURFACE_PAGES_CACHED, where the device has RGFX_FEATURE_SURFACE_CACHE), and what a CPU
// lock of one does past waiting for the GPU's pending writes (RgfxSurfaceLocks.hpp).
//
// Such a surface's GPU copy is the host's device cache, in its GPU's own memory, and its pages
// hold the CPU's. The kext keeps them apart as a GPU of its own memory does:
//   - A CPU lock, of either mode, of a surface the GPU wrote since the pages last took the cache
//     has the host copy the cache into the pages (SURFACE_DOWNLOAD) and waits for the copy, once
//     the writes are done. One lock asks at a time; the others wait for its answer.
//   - A read-write CPU lock moves the surface's CPU generation, the count of its read-write
//     locks, which the kext writes into the block's header for the processes: each command
//     buffer that uses the surface names the generation it saw at its commit
//     (RGFX_OP_SURFACE_USE), and the host fills the cache from the pages before the first buffer
//     of a newer one. IOSurface calls the kext at every read-write lock of a surface whose device
//     cache exists, current or not (RgfxIOSurfaceKPI.hpp), so the count starts with the block.
//   - The block's last holder letting go posts its BLOCK_RELEASE, which the host answers once
//     the pages hold the cache: a lock waits for the answer, then the surface is no longer
//     cached. The kext holds the surface's device cache until then, so its locks still reach
//     the kext, and the surface's memory wired, so the host's copy lands in pages that are
//     still the surface's, past the holders' own wiring, which ends at their let-go: never
//     pages the guest has purged, paged out or given to another; a block that is not cached
//     lets its cache go with it (rgfxCacheLetGo, rgfxCacheReleased). A new block of the
//     surface in place, of any mode, waits for the answer too before it is made
//     (rgfxCacheNewBlockStep): nothing of it may use the pages before the host's copy.
//   - A release whose surface nothing but the kext holds (no client, no mach port or XPC object)
//     is flagged so (RGFX_BLOCK_RELEASE_UNHELD, rgfxCacheReleaseFlags): no process holds it to
//     read the pages, and the host drops the cache uncopied, but where the header's count of the
//     surface's clients is past 0 as it makes its copy, which a lock or a new block of the surface
//     met before the answer sets (rgfxCacheRetaken). The pages stay wired until the answer.
//   - The block's last holder letting go leaves it dormant (RgfxSurfaceBlocks.hpp), and the
//     surface cached, its memory wired and its device cache held: its locks go on as before, a
//     download among them, and its generation moves on. Its BLOCK_RELEASE, once the dormant
//     block is let go, has the host copy a cache the GPU wrote into the pages, and a lock waits
//     for the answer; then the surface is no longer cached.
//   - A dormant surface's device cache purged (op 5, as each client of the surface goes), or
//     the surface made empty (op 7), marks it to be let go (rgfxCachePurged,
//     rgfxCachePurgeable), and the kext's release thread lets its block go, the pages taking
//     what the GPU wrote; a surface made empty while held does not sleep at its last let-go.
//     A surface made volatile keeps its dormant block, the first of them to go under the caps
//     (RgfxSurfaceBlocks.hpp), as IOSurfaceRef.h lets a volatile surface's contents be
//     discarded; made nonvolatile again (op 6, or op 7), it is neither.
//   - A deferred block (RgfxSurfaceBlocks.hpp) has no pages until a lock needs them: the kext
//     holds its surface's memory retained, not wired. Its ask reads the surface's seed and its
//     pages' counts, resident and compressed or paged out, once its device cache and control
//     function are made (kRgfxCacheGating), and a lock goes on then as for any block: its seed
//     moves, and the ask names the pages. Found fresh (rgfxSurfaceHoldsOnlyResident, with no
//     resident page), a lock waits for the host's answer to the deferral (kRgfxCacheDeferring).
//     A surface whose pages the kernel cannot count so is never fresh.
//     Deferred, a read-write lock, or a read-only one of a surface the GPU wrote, attaches the
//     pages first (RGFX_SURFACE_PAGES_ATTACH), one lock at a time, the others waiting; then it
//     goes on as for any block, a download among it. A naming not answered OK is made again,
//     backing off, until the lock's wait ends (rgfxAttachRetryMs). A read-only lock of a
//     surface the GPU never wrote attaches nothing: a fresh page reads as zeros, as the cache
//     does. A dormant one is kept at a client's going (op 5) while other clients are left; its
//     release, where the GPU wrote it and the surface lives past the kext's own references,
//     attaches its pages first, so the release copies the cache into them
//     (rgfxCacheReleaseNext), naming them again as a lock does; else nothing reads them.
// A wait for the host's answers (a download's, another lock's download, attach or deferral, the
// block's release) has no deadline, as a new block's for the release (rgfxCacheNewBlockStep): the
// host answers each once its copy lands, after the buffers that used the cache, behind its other
// work, a pipeline's compile among it, and a lock that went on before it would read, or write,
// pages without the GPU's writes. The device's stop ends it, and so does the locking thread's
// abort. A naming the host refused is made again for a while from the first refusal
// (kRgfxAttachRetryWaitMs): each naming's answer is waited for in full, and the bound is on the
// refusals.
//
// A surface is named by its key, the device cache the kext made on it, as in RgfxSurfaceLocks.
// The caller holds one lock around every call. Header-only and free of the kernel's headers, so
// its native test (tests/surface_caches_test.cpp) builds it as the kext does.
//
// Our own code.
#ifndef RGFX_SURFACE_CACHES_HPP_
#define RGFX_SURFACE_CACHES_HPP_

#include <stdint.h>

#include "RgfxSurfaceBlocks.hpp"
#include "RgfxSurfaceRefill.hpp"

// Where a cached surface's block stands with its pages (RgfxSurfaceBlocks.hpp's deferred
// blocks).
enum RgfxCacheDeferral : uint32_t {
	// Its pages were named at its ask, as every block's not deferred.
	kRgfxCacheNotDeferred = 0,
	// Its ask reads the surface's seed and pages, to defer it or name them: a lock goes on as
	// for a block not deferred.
	kRgfxCacheGating,
	// The surface was fresh, and the host has not answered the deferral: a lock waits.
	kRgfxCacheDeferring,
	// Deferred: no pages named yet.
	kRgfxCacheDeferred,
	// A lock, or the release, is naming its pages: the others wait.
	kRgfxCacheAttaching,
	// Its pages were named after its ask: as a block not deferred.
	kRgfxCacheAttached,
	// Its attach was not answered in time: the host may yet take its pages, so they stay wired,
	// as an attached block's, until its release is answered OK, and a lock goes on as for one
	// attached, never naming them again.
	kRgfxCacheAttachLate,
};

// One cached surface.
struct RgfxCachedSurface {
	uint64_t key;
	// Its shared block's region offset, and its IOSurfaceID.
	uint64_t offset;
	uint32_t surfaceId;
	// The count of its read-write CPU locks: its CPU generation.
	uint64_t cpuGen;
	// How many GPU writes were named of it, and how many of them the pages hold: as many as
	// `writes` had when the last download was asked and answered.
	uint64_t writes;
	uint64_t copied;
	// A lock's download is asked and not yet answered.
	bool downloading;
	// The block's BLOCK_RELEASE is posted and not yet answered.
	bool releasing;
	// That release was posted RGFX_BLOCK_RELEASE_UNHELD: nothing but the kext held the surface
	// (rgfxCacheReleaseFlags). And a lock or a new block of the surface met it releasing, a
	// process holding the surface again (rgfxCacheRetaken).
	bool unheld;
	bool retaken;
	// The block is dormant (no client holds it).
	bool dormant;
	// The dormant block is to be let go, and why (a RgfxDormantCause); kRgfxCacheKept for none.
	uint32_t letGo;
	// The surface was made volatile, or empty, and not nonvolatile since.
	bool purgeable;
	bool emptied;
	// Where the kext writes `cpuGen` for the processes (the block's header, mapped), the
	// mapping, the surface's memory, held wired while the block lives, and the surface's
	// reference, which the table holds from the block's let-go until its release is answered,
	// opaque here.
	volatile uint64_t *genAt;
	void *map;
	void *wire;
	void *surface;
	// The wire of the pages its deferral carried (RgfxDeferCarry.hpp), prepared, opaque here: the
	// host may read them until the block's pages are named (rgfxCacheTakeCarried) or its release
	// is answered, so it is held until then, and handed out with `wire` where the entry goes.
	void *carried;
	// Where the kext writes the surface's clients for the processes (the header's
	// kRgfxSurfaceClientsOffset), and the surface, whose reference the block's entry holds, or
	// this table's `surface` after the let-go, while this entry lives: opaque here.
	volatile uint32_t *clientsAt;
	// Where the kext writes the generation's refill record for the processes (the header's
	// kRgfxSurfaceRefillOffset, RgfxSurfaceRefill.hpp), as it caches the block and at each
	// read-write lock.
	volatile uint64_t *refillAt;
	const void *object;
	// Its pages (RgfxCacheDeferral): `wire` holds the surface's memory retained but not prepared
	// while the block is deferred (rgfxCacheWired), and an attach prepares it. The block's
	// context, the bytes its holders map and the plane's bytes: what an attach's SURFACE_PAGES
	// names.
	RgfxCacheDeferral deferral;
	uint32_t context;
	uint64_t size;
	uint64_t length;
	// The block went, not released, while a lock or the release named its pages: the attach
	// lets the surface go once answered (rgfxCacheAttached), so the let-go waits for no host.
	bool forgotten;
	// That block, kept for good, took no wire of the pages of its own (its let-go read them
	// unnamed, before the attach began): the attach keeps its wiring of them for good where it
	// named them, as the host may map them through a block that never goes.
	bool keepWire;
};

// RgfxCachedSurface::letGo where nothing asks the dormant block to go.
constexpr uint32_t kRgfxCacheKept = ~0u;

struct RgfxCacheTable {
	RgfxCachedSurface *entries;
	uint32_t count;
	uint32_t capacity;
};

// The cached surface of key `key`, or null.
inline RgfxCachedSurface *rgfxCacheFind(RgfxCacheTable &t, uint64_t key)
{
	for (uint32_t i = 0; i < t.count; i++) {
		if (t.entries[i].key == key)
			return &t.entries[i];
	}
	return nullptr;
}

// The cached surface whose block is at `offset`, or null.
inline RgfxCachedSurface *rgfxCacheAtBlock(RgfxCacheTable &t, uint64_t offset)
{
	for (uint32_t i = 0; i < t.count; i++) {
		if (t.entries[i].offset == offset)
			return &t.entries[i];
	}
	return nullptr;
}

// The cached surface of IOSurfaceID `surfaceId` whose block is not going, or null.
inline RgfxCachedSurface *rgfxCacheOfSurface(RgfxCacheTable &t, uint32_t surfaceId)
{
	for (uint32_t i = 0; i < t.count; i++) {
		const RgfxCachedSurface &c = t.entries[i];
		if (c.surfaceId == surfaceId && !c.releasing && !c.forgotten)
			return &t.entries[i];
	}
	return nullptr;
}

// The table moves into `entries`, `capacity` of them, the caller's memory, its entries copied in
// order, where that is more than it holds: the array it held before is answered, for the caller
// to free. Else `entries` is, the table unchanged. No caller holds an entry across the lock's
// drops (a remove moves the last entry into its place, rgfxCacheRemove), so none is left over
// the old array.
inline RgfxCachedSurface *rgfxCacheGrow(RgfxCacheTable &t, RgfxCachedSurface *entries,
                                        uint32_t capacity)
{
	if (!entries || capacity <= t.capacity)
		return entries;
	for (uint32_t i = 0; i < t.count; i++)
		entries[i] = t.entries[i];
	for (uint32_t i = t.count; i < capacity; i++)
		entries[i] = RgfxCachedSurface{};
	RgfxCachedSurface *old = t.entries;
	t.entries = entries;
	t.capacity = capacity;
	return old;
}

// Adds the surface `key` (IOSurfaceID `surfaceId`), whose block at `offset` is cached, at CPU
// generation 0 and no write. Null where the table has no room or the key is there already.
inline RgfxCachedSurface *rgfxCacheAdd(RgfxCacheTable &t, uint64_t key, uint64_t offset,
                                       uint32_t surfaceId)
{
	if (t.count == t.capacity || rgfxCacheFind(t, key) != nullptr)
		return nullptr;
	RgfxCachedSurface &c = t.entries[t.count++];
	c = RgfxCachedSurface{};
	c.key = key;
	c.offset = offset;
	c.surfaceId = surfaceId;
	c.letGo = kRgfxCacheKept;
	return &c;
}

// Whether `c`'s `wire` is prepared: every block's but a deferred one's before its pages are
// named, whose memory is only retained, and which the caller then releases unprepared.
inline bool rgfxCacheWired(const RgfxCachedSurface &c)
{
	return c.deferral == kRgfxCacheNotDeferred || c.deferral == kRgfxCacheAttached ||
	       c.deferral == kRgfxCacheAttachLate;
}

// Whether the host may map a deferred block's pages: named, being named, or asked and not
// answered. Its holders wire none, so its block takes a wire of them as it goes, which it keeps
// until its release is answered OK.
inline bool rgfxCacheHostPages(const RgfxCachedSurface &c)
{
	return c.deferral == kRgfxCacheAttaching || c.deferral == kRgfxCacheAttached ||
	       c.deferral == kRgfxCacheAttachLate;
}

// Takes `c` out of the table: its mapping and its wired memory, which the caller lets go, in
// `*map` and `*wire`, and the wire of the pages its deferral carried in `*carried`, which the
// caller unwires. The kext gives `carried` at every call; a test of entries that carry none may
// leave it out.
inline void rgfxCacheRemove(RgfxCacheTable &t, RgfxCachedSurface *c, void **map, void **wire,
                            void **carried = nullptr)
{
	*map = c->map;
	*wire = c->wire;
	if (carried)
		*carried = c->carried;
	*c = t.entries[--t.count];
}

// The block of surface `key` goes: a cached one stays, its locks waiting, until the block's
// release is answered where `releasing`, else it is taken out (its mapping and wired memory in
// `*map` and `*wire`, for the caller to let go). True where the caller releases the device
// cache's reference and the surface's, `surface`, now; false where the table keeps both for the
// answer (rgfxCacheReleased), or, where an attach of a deferred block's pages is in flight, for
// that attach to let go once answered (rgfxCacheAttached): the let-go never waits for the host.
// `blockWired`: the block keeps a wire of the surface's pages of its own while it is in the
// table. Decided here, in the same hold as the attach's state: a block kept for good without
// one, whose attach is in flight, has the attach keep the pages wired (`keepWire`).
inline bool rgfxCacheLetGo(RgfxCacheTable &t, uint64_t key, bool releasing, void *surface,
                           void **map, void **wire, bool blockWired, void **carried = nullptr)
{
	*map = *wire = nullptr;
	if (carried)
		*carried = nullptr;
	RgfxCachedSurface *c = rgfxCacheFind(t, key);
	if (c == nullptr)
		return true;
	if (releasing || c->deferral == kRgfxCacheAttaching) {
		c->releasing = releasing;
		c->forgotten = !releasing;
		c->keepWire = !releasing && !blockWired;
		c->surface = surface;
		return false;
	}
	rgfxCacheRemove(t, c, map, wire, carried);
	return true;
}

// The surface of the cached block at `offset` whose BLOCK_RELEASE is posted and not yet
// answered, the reference the table holds until then (opaque here), and whether a buffer wrote
// its cache since its last copy (`*written`); null where no cached surface is releasing it.
inline void *rgfxCacheReleasingSurface(RgfxCacheTable &t, uint64_t offset, bool *written)
{
	RgfxCachedSurface *c = rgfxCacheAtBlock(t, offset);
	*written = c != nullptr && c->releasing && c->writes != c->copied;
	return c != nullptr && c->releasing ? c->surface : nullptr;
}

// The BLOCK_RELEASE of the block at `offset` was answered: the cached surface releasing it is
// taken out (its mapping, wired memory and surface's reference in `*map`, `*wire` and
// `*surface`), and its key, the device cache whose reference the caller releases now, before
// the surface's, returned; 0 where none was releasing it.
inline uint64_t rgfxCacheReleased(RgfxCacheTable &t, uint64_t offset, void **map, void **wire,
                                  void **surface, void **carried = nullptr)
{
	*map = *wire = *surface = nullptr;
	if (carried)
		*carried = nullptr;
	RgfxCachedSurface *c = rgfxCacheAtBlock(t, offset);
	if (c == nullptr || !c->releasing)
		return 0;
	const uint64_t key = c->key;
	*surface = c->surface;
	rgfxCacheRemove(t, c, map, wire, carried);
	return key;
}

// The block of surface `key` is dormant (`dormant`), or held again: false where the surface is
// not cached, made empty (it does not sleep), or is to be let go (it is held again by no ask).
// `*purgeable` where the surface is volatile.
inline bool rgfxCacheSleep(RgfxCacheTable &t, uint64_t key, bool dormant, bool *purgeable)
{
	*purgeable = false;
	RgfxCachedSurface *c = rgfxCacheFind(t, key);
	if (c == nullptr || (dormant && c->emptied) || (!dormant && c->letGo != kRgfxCacheKept))
		return false;
	c->dormant = dormant;
	*purgeable = c->purgeable;
	return true;
}

// The new states op 7 carries, as IOMemoryDescriptor numbers them (kIOMemoryPurgeable*):
// nonvolatile, and the two that may lose a surface's bytes, volatile and empty.
constexpr uint64_t kRgfxPurgeableNonVolatile = 2;
constexpr uint64_t kRgfxPurgeableVolatile = 3;
constexpr uint64_t kRgfxPurgeableEmpty = 4;

// Surface `key` has `clients` processes holding it now, as a block of it is cached or as one
// goes (op 5): written into its block's header for the processes, which keep a texture's view of
// a surface another process holds (the bundle's keep). A count below 0 is written as 0, and one
// past 32 bits as their most. True where the surface is cached and the count was written.
inline bool rgfxCacheNoteClients(RgfxCacheTable &t, uint64_t key, int64_t clients)
{
	RgfxCachedSurface *c = rgfxCacheFind(t, key);
	if (c == nullptr || c->clientsAt == nullptr)
		return false;
	const uint32_t n = clients < 0              ? 0u
	                   : clients > 0xffffffffll ? 0xffffffffu
	                                            : static_cast<uint32_t>(clients);
	__atomic_store_n(c->clientsAt, n, __ATOMIC_RELEASE);
	return true;
}

// Surface `key`'s device cache was purged (op 5), `clients` of the surface left: a dormant block
// of it is to be let go, but a deferred one whose pages are not named while a client is left,
// whose cache alone holds its bytes. True where one is, not asked to go before.
inline bool rgfxCachePurged(RgfxCacheTable &t, uint64_t key, int64_t clients = 0)
{
	RgfxCachedSurface *c = rgfxCacheFind(t, key);
	if (c == nullptr || !c->dormant || c->letGo != kRgfxCacheKept)
		return false;
	if (c->deferral == kRgfxCacheDeferred && clients > 0)
		return false;
	c->letGo = kRgfxDormantPurged;
	return true;
}

// Surface `key` was made `state` (op 7): volatile marks it, its dormant block the first to go
// under the caps; empty marks it, its dormant block to be let go now, a held one not to sleep;
// nonvolatile ends both; reading the state changes nothing. True where a dormant block of it is
// to be looked at again, on the release thread.
inline bool rgfxCachePurgeable(RgfxCacheTable &t, uint64_t key, uint64_t state)
{
	RgfxCachedSurface *c = rgfxCacheFind(t, key);
	if (c == nullptr)
		return false;
	if (state == kRgfxPurgeableNonVolatile) {
		c->purgeable = c->emptied = false;
	} else if (state == kRgfxPurgeableVolatile) {
		c->purgeable = true;
	} else if (state == kRgfxPurgeableEmpty) {
		c->emptied = true;
		if (c->dormant && c->letGo == kRgfxCacheKept)
			c->letGo = kRgfxDormantEmptied;
	} else {
		return false;
	}
	return c->dormant;
}

// The dormant block at `offset` of a cached surface is to be let go: its surface had no client
// left at its sleep. True where it is, not asked to go before.
inline bool rgfxCacheUnclaimed(RgfxCacheTable &t, uint64_t offset)
{
	RgfxCachedSurface *c = rgfxCacheAtBlock(t, offset);
	if (c == nullptr || !c->dormant || c->releasing || c->letGo != kRgfxCacheKept)
		return false;
	c->letGo = kRgfxDormantNoClients;
	return true;
}

// Surface `key` was made nonvolatile by op 6 (IOSurfaceDeviceCache::unpurge): as op 7 with
// nonvolatile.
inline bool rgfxCacheUnpurged(RgfxCacheTable &t, uint64_t key)
{
	return rgfxCachePurgeable(t, key, kRgfxPurgeableNonVolatile);
}

// The block at `offset` of a cached surface, where it is dormant and asked to go: why, else
// kRgfxCacheKept. `*purgeable` where its surface is volatile.
inline uint32_t rgfxCacheLetGoOf(RgfxCacheTable &t, uint64_t offset, bool *purgeable)
{
	RgfxCachedSurface *c = rgfxCacheAtBlock(t, offset);
	*purgeable = c != nullptr && c->purgeable;
	return c != nullptr && c->dormant && !c->releasing ? c->letGo : kRgfxCacheKept;
}

// A GPU write of surface `key` was named. False where it is not cached.
inline bool rgfxCacheNoteWrite(RgfxCacheTable &t, uint64_t key)
{
	RgfxCachedSurface *c = rgfxCacheFind(t, key);
	if (c == nullptr)
		return false;
	c->writes++;
	return true;
}

// A CPU lock, or a new block, of the cached surface `c` met its block releasing: a process holds
// the surface. Its release posted unheld (RGFX_BLOCK_RELEASE_UNHELD) has the header's count of
// its clients set past 0, so the host, looking at it as it makes its copy, copies the cache into
// the pages after all; one not yet posted is posted held. True where it was posted unheld, the
// first time.
inline bool rgfxCacheRetaken(RgfxCachedSurface &c)
{
	if (!c.releasing || c.retaken)
		return false;
	c.retaken = true;
	if (!c.unheld)
		return false;
	if (c.clientsAt != nullptr && __atomic_load_n(c.clientsAt, __ATOMIC_ACQUIRE) == 0)
		__atomic_store_n(c.clientsAt, 1u, __ATOMIC_RELEASE);
	return true;
}

// What a CPU lock of surface `key` does next, once no GPU write of it is pending.
enum RgfxCacheStep {
	// Nothing more: the pages hold every write, or the surface is not cached.
	kRgfxCacheGoOn,
	// Waits: another lock's download, or the block's release, is not yet answered.
	kRgfxCacheWait,
	// Asks the download of the block at `*offset` and waits for its answer, then calls
	// rgfxCacheDownloaded with `*mark`.
	kRgfxCacheDownload,
	// Names the deferred block's pages (RGFX_SURFACE_PAGES_ATTACH) and waits for the answer, then
	// calls rgfxCacheAttached.
	kRgfxCacheAttach,
};

// A lock, read-write where `readWrite`.
inline RgfxCacheStep rgfxCacheNext(RgfxCacheTable &t, uint64_t key, uint64_t *offset,
                                   uint64_t *mark, bool readWrite = false)
{
	RgfxCachedSurface *c = rgfxCacheFind(t, key);
	if (c == nullptr)
		return kRgfxCacheGoOn;
	if (c->releasing)
		rgfxCacheRetaken(*c);
	if (c->downloading || c->releasing || c->deferral == kRgfxCacheDeferring ||
	    c->deferral == kRgfxCacheAttaching)
		return kRgfxCacheWait;
	if (c->deferral == kRgfxCacheDeferred) {
		if (!readWrite && c->writes == c->copied)
			return kRgfxCacheGoOn;
		c->deferral = kRgfxCacheAttaching;
		*offset = c->offset;
		return kRgfxCacheAttach;
	}
	if (c->writes == c->copied)
		return kRgfxCacheGoOn;
	c->downloading = true;
	*offset = c->offset;
	*mark = c->writes;
	return kRgfxCacheDownload;
}

// The CPU locks that slept for a block's release's answer, a process taking the surface again
// after its block was let go, and the longest of those waits, in mach_absolute_time's units: the
// releases line's "lock waits on a release". The answer comes once the host's copy into the pages
// is made, behind the buffers of the context that used the cache.
struct RgfxReleaseLockWaits {
	uint64_t count;
	uint64_t most;
};

// A lock of surface `key` about to sleep at `now` (rgfxCacheNext's kRgfxCacheWait): where its
// block's release is unanswered, its wait for the release starts at `now`, kept in `*since`,
// unless it started already. `*since` is 0 until then.
inline void rgfxReleaseWaitSleeps(RgfxCacheTable &t, uint64_t key, uint64_t now, uint64_t *since)
{
	const RgfxCachedSurface *c = rgfxCacheFind(t, key);
	if (c != nullptr && c->releasing && *since == 0)
		*since = now != 0 ? now : 1;
}

// The lock went on at `now`, `since` where it slept for a release (rgfxReleaseWaitSleeps): one wait
// more, however it ended. Nothing where it slept for none.
inline void rgfxReleaseWaitEnds(RgfxReleaseLockWaits &w, uint64_t since, uint64_t now)
{
	if (since == 0)
		return;
	w.count++;
	const uint64_t waited = now > since ? now - since : 0;
	if (waited > w.most)
		w.most = waited;
}

// The download asked at `mark` was answered, OK where `ok`: the pages hold the writes named up to
// it. Writes named since are still to copy. A download not answered OK copies nothing.
inline void rgfxCacheDownloaded(RgfxCacheTable &t, uint64_t key, uint64_t mark, bool ok)
{
	RgfxCachedSurface *c = rgfxCacheFind(t, key);
	if (c == nullptr)
		return;
	c->downloading = false;
	if (ok && mark > c->copied)
		c->copied = mark;
}

// How long a lock, or the release, waits to name a deferred block's pages again after a naming
// not answered OK (kRgfxPagesNotNamed: the surface's memory not wired, its runs not taken or not
// written, or the host refusing them), `tries` namings made so far: from kRgfxAttachRetryFirstMs,
// doubling to kRgfxAttachRetryMostMs. A naming that fails for a moment (the guest short of wired
// memory, the host's views full) is made again within kRgfxAttachRetryWaitMs of the first
// refusal, and one that keeps failing costs a dozen namings in its 2 s. Each naming's answer is
// waited for in full (a SURFACE_PAGES waits with no deadline): the host answered these, and the
// bound is on its refusals. The lock goes on over pages that do not hold the cache's bytes only
// once that bound is past.
constexpr uint32_t kRgfxAttachRetryFirstMs = 10;
constexpr uint32_t kRgfxAttachRetryMostMs = 320;
constexpr uint32_t kRgfxAttachRetryWaitMs = 2000;

inline uint32_t rgfxAttachRetryMs(uint32_t tries)
{
	uint32_t ms = kRgfxAttachRetryFirstMs;
	for (uint32_t i = 1; i < tries && ms < kRgfxAttachRetryMostMs; i++)
		ms *= 2;
	return ms < kRgfxAttachRetryMostMs ? ms : kRgfxAttachRetryMostMs;
}

// The attach a lock or the release asked of surface `key` (kRgfxCacheAttach) ended as `naming`:
// its pages are the cache's from here on, or are still to name, or, not answered, may yet be the
// host's (kRgfxCacheAttachLate). Where its block went meanwhile (`forgotten`), the surface is
// taken out (its mapping, its memory, wired where rgfxPagesNamingWired, and the surface's
// reference in `*map`, `*wire` and `*surface`) and its key returned, the device cache whose
// reference the caller releases, then the surface's; else 0. A block that took a wire of its own
// as it went (rgfxCacheHostPages) holds the host's pages past the cache's; one kept for good that
// took none (`keepWire`) has the caller keep the memory's wiring for good where the naming wired
// it (`*keepWired`): neither unwired nor released, as the host may map the pages for good.
inline uint64_t rgfxCacheAttached(RgfxCacheTable &t, uint64_t key, RgfxPagesNaming naming,
                                  void **map, void **wire, void **surface,
                                  bool *keepWired = nullptr, void **carried = nullptr)
{
	*map = *wire = *surface = nullptr;
	if (keepWired)
		*keepWired = false;
	if (carried)
		*carried = nullptr;
	RgfxCachedSurface *c = rgfxCacheFind(t, key);
	if (c == nullptr || c->deferral != kRgfxCacheAttaching)
		return 0;
	c->deferral = naming == kRgfxPagesNamed       ? kRgfxCacheAttached
	              : naming == kRgfxPagesUnanswered ? kRgfxCacheAttachLate
	                                               : kRgfxCacheDeferred;
	if (!c->forgotten)
		return 0;
	if (keepWired)
		*keepWired = c->keepWire && rgfxPagesNamingWired(naming);
	*surface = c->surface;
	rgfxCacheRemove(t, c, map, wire, carried);
	return key;
}

// What the kernel counted of a surface's pages (rgfxSurfaceLocksPageCounts). `counted` only
// where the counts cover every place its bytes can be: memory the kernel allocated anonymous,
// so a page neither resident nor compressed nor paged out holds nothing, and counts of the
// compressed and paged-out pages (`swapped`) as well as the resident ones, over its whole
// mapping and nothing past it (rgfxRegionPageCounts).
struct RgfxSurfacePageCounts {
	bool counted;
	uint64_t resident;
	uint64_t swapped;
};

// One region of the kernel's map, as VM_REGION_EXTENDED_INFO describes it: where it starts, its
// size, its pages resident and its pages compressed or paged out (pages_swapped_out, which
// counts both: measured on 11.7.11 against each page's disposition), whether its memory is a
// pager's (`external`, a file's), and whether it has no memory to count (`empty`, SM_EMPTY: no
// object, a submap, or physically contiguous memory).
struct RgfxPageRegion {
	uint64_t start;
	uint64_t size;
	uint64_t resident;
	uint64_t swapped;
	bool external;
	bool empty;
};

// The counts of a surface mapped at [start, start + length), from the `count` regions a walk from
// `start` found, in order. Counted only where the regions tile the mapping exactly: the first
// starting at `start`, each the next where the previous ends, the last ending where the mapping
// does, none a pager's or empty. A region reaching past the mapping would count pages that are
// not the surface's, and a gap or a missing region pages that are not counted, so either refuses
// the count, which only ever refuses a deferral, never grants one.
inline RgfxSurfacePageCounts rgfxRegionPageCounts(const RgfxPageRegion *regions, uint32_t count,
                                                  uint64_t start, uint64_t length)
{
	const RgfxSurfacePageCounts uncounted = {false, ~0ull, ~0ull};
	if (count == 0 || length == 0 || start + length < start)
		return uncounted;
	RgfxSurfacePageCounts counts = {true, 0, 0};
	uint64_t at = start;
	for (uint32_t i = 0; i < count; i++) {
		const RgfxPageRegion &r = regions[i];
		if (r.start != at || r.size == 0 || r.size > start + length - at || r.external ||
		    r.empty)
			return uncounted;
		counts.resident += r.resident;
		counts.swapped += r.swapped;
		at += r.size;
	}
	return at == start + length ? counts : uncounted;
}

// Whether a surface's bytes can only be in its `resident` resident pages, as the read that
// found `seed` and `counts` saw it: under its read-only lock (`locked`), its seed 0 (no lock for
// writing yet), its pages counted, none compressed or paged out, and `resident` of them in
// memory. With `resident` 0 the surface is fresh, every page of it zeros: a page a writer that
// takes no lock dirtied reads as one resident, or, once compressed or paged out, as one swapped,
// either way not fresh. The read itself takes no lock, so a caller holding the surface's
// read-only lock may read again.
inline bool rgfxSurfaceHoldsOnlyResident(bool locked, uint32_t seed,
                                         const RgfxSurfacePageCounts &counts, uint64_t resident)
{
	return locked && seed == 0 && counts.counted && counts.swapped == 0 &&
	       counts.resident == resident;
}

// The wire of the pages surface `key`'s deferral carried, once its block's pages are named
// (kRgfxCacheAttached): the host reads its pages from then on, never the carried ones, so the
// caller unwires them. Null, the entry unchanged, for an entry whose pages are not named, or that
// carried none.
inline void *rgfxCacheTakeCarried(RgfxCacheTable &t, uint64_t key)
{
	RgfxCachedSurface *c = rgfxCacheFind(t, key);
	if (c == nullptr || c->deferral != kRgfxCacheAttached)
		return nullptr;
	void *carried = c->carried;
	c->carried = nullptr;
	return carried;
}

// The wire of the pages surface `key`'s deferral carried, where the host refused the deferral
// (kRgfxCacheDeferring, its pages named next as a stale surface's are): it made nothing, so
// nothing reads them, and the caller unwires them. Null, the entry unchanged, otherwise.
inline void *rgfxCacheRefusedCarried(RgfxCacheTable &t, uint64_t key)
{
	RgfxCachedSurface *c = rgfxCacheFind(t, key);
	if (c == nullptr || c->deferral != kRgfxCacheDeferring)
		return nullptr;
	void *carried = c->carried;
	c->carried = nullptr;
	return carried;
}

// The ask of surface `key`'s deferred block read the surface fresh: it asks the host to defer
// the block, and locks wait for the answer. False where the surface is not gating.
inline bool rgfxCacheGated(RgfxCacheTable &t, uint64_t key)
{
	RgfxCachedSurface *c = rgfxCacheFind(t, key);
	if (c == nullptr || c->deferral != kRgfxCacheGating)
		return false;
	c->deferral = kRgfxCacheDeferring;
	return true;
}

// The host answered the ask of surface `key`'s block: deferred where `deferred`, else its pages
// were named at the ask (its surface not fresh, or the deferral refused), `wire` prepared.
inline void rgfxCacheSettled(RgfxCacheTable &t, uint64_t key, bool deferred)
{
	RgfxCachedSurface *c = rgfxCacheFind(t, key);
	if (c != nullptr && (c->deferral == kRgfxCacheGating || c->deferral == kRgfxCacheDeferring))
		c->deferral = deferred ? kRgfxCacheDeferred : kRgfxCacheNotDeferred;
}

// The ask of surface `key`'s block, made for its deferral, names its pages instead, and the host
// answered that they lie in place (a host that answers which surfaces need a cache, where the
// deferral was refused or the surface read not fresh): the surface is not cached, so its entry
// goes, its mapping and its memory, retained and never prepared for the entry, in `*map` and
// `*wire` for the caller to let go. False, nothing changed, where the surface is not gating or
// deferring: an entry the host deferred, or named cached, stays.
inline bool rgfxCacheUngated(RgfxCacheTable &t, uint64_t key, void **map, void **wire,
                             void **carried = nullptr)
{
	*map = *wire = nullptr;
	if (carried)
		*carried = nullptr;
	RgfxCachedSurface *c = rgfxCacheFind(t, key);
	if (c == nullptr || (c->deferral != kRgfxCacheGating && c->deferral != kRgfxCacheDeferring))
		return false;
	rgfxCacheRemove(t, c, map, wire, carried);
	return true;
}

// Whether the asker's hold of a block whose ask named its pages after all (its surface not fresh,
// the deferral refused, or no device cache: deferSurfaceBlock), `naming` the outcome, wires
// them again for itself, the block cached where `cached`. The naming's own wiring
// (rgfxPagesNamingWired) is its cache's where named, which the settle leaves wired
// (rgfxCacheSettled, rgfxCacheWired), so the hold takes a second; else the hold takes the
// naming's, which nothing else would let go.
inline bool rgfxAskHoldWiresAgain(bool cached, RgfxPagesNaming naming)
{
	return cached && naming == kRgfxPagesNamed;
}

// The references of a surface the kext holds itself as its release thread looks at a deferred
// block's release: the table's, which the block's entry handed it at the let-go
// (rgfxCacheLetGo); the device cache's, the kext holding the cache, which IOSurface's
// IOSurfaceDeviceCache::init retains its surface for (IOSurface 393.5.8); and the release
// thread's own, taken to read the surface (rgfxCacheReleasingSurface). A surface retained past
// these lives on: a process's client, a mach port or an XPC object holds it, and may read it.
constexpr int32_t kRgfxSurfaceTableRef = 1;
constexpr int32_t kRgfxSurfaceDeviceCacheRef = 1;
constexpr int32_t kRgfxSurfaceReleaseRef = 1;
constexpr int32_t kRgfxSurfaceKextRefs =
    kRgfxSurfaceTableRef + kRgfxSurfaceDeviceCacheRef + kRgfxSurfaceReleaseRef;

// The flags of the BLOCK_RELEASE of the cached block at `offset`, its surface having `clients`
// clients and `retains` references (IOSurface's counts, read out of the lock as the release is
// posted), decided under the lock as rgfxCacheReleasePeek decides a deferred block's naming:
//   - RGFX_BLOCK_RELEASE_NO_CLIENT where the surface has no client, which the host only counts,
//     copying the cache into the pages all the same (a mach port or an XPC object holds a surface
//     with no client, and whoever looks it up from one reads its pages);
//   - RGFX_BLOCK_RELEASE_UNHELD where, besides, nothing but the kext holds it
//     (kRgfxSurfaceKextRefs) and no lock or new block of it met it releasing (`retaken`): no
//     process holds it to read its pages, so the host drops a cache the GPU wrote without copying
//     it into them, where the header's count of the surface's clients is still 0 at its copy.
//     The kext still holds the pages wired until the answer, which nothing but the host's own
//     copies wrote. The entry is marked `unheld`, so a process that takes the surface again
//     before the answer has its lock or its block mark the header (rgfxCacheRetaken). Only a
//     taking between the host's look at the header and the kext's let-go of the surface after
//     the answer, which needs a lookup by ID of a surface no process holds, reads the pages
//     without what the GPU last wrote, as a deferred block's unnamed release does
//     (rgfxCacheReleasePeek).
inline uint32_t rgfxCacheReleaseFlags(RgfxCacheTable &t, uint64_t offset, int32_t clients,
                                      int32_t retains)
{
	uint32_t flags = clients == 0 ? RGFX_BLOCK_RELEASE_NO_CLIENT : 0;
	RgfxCachedSurface *c = rgfxCacheAtBlock(t, offset);
	if (c == nullptr || !c->releasing)
		return flags;
	c->unheld = !c->retaken && clients <= 0 && retains <= kRgfxSurfaceKextRefs;
	return c->unheld ? flags | RGFX_BLOCK_RELEASE_UNHELD : flags;
}

// What the release of the cached block at `offset` does before its BLOCK_RELEASE goes, its
// surface having `clients` clients and `retains` references (IOSurface's counts, read out of
// the lock).
enum RgfxCacheReleaseStep {
	// Goes as it is: a block not deferred, or attached, whose release copies the cache into its
	// pages; or a deferred one the GPU never wrote, or that nothing but the kext holds, whose
	// pages nothing reads.
	kRgfxCacheReleaseAsIs,
	// Waits: a lock is naming its pages.
	kRgfxCacheReleaseWait,
	// Names its pages (kRgfxCacheAttach), so the release copies what the GPU wrote into them.
	kRgfxCacheReleaseAttach,
};

// What rgfxCacheReleaseNext would answer, with nothing changed: for the release thread, which
// hands a release that waits or names to the naming worker, and goes on with the next.
inline RgfxCacheReleaseStep rgfxCacheReleasePeek(RgfxCacheTable &t, uint64_t offset,
                                                 int32_t clients, int32_t retains)
{
	const RgfxCachedSurface *c = rgfxCacheAtBlock(t, offset);
	if (c == nullptr || !c->releasing)
		return kRgfxCacheReleaseAsIs;
	if (c->deferral == kRgfxCacheAttaching)
		return kRgfxCacheReleaseWait;
	if (c->deferral != kRgfxCacheDeferred || c->writes == c->copied ||
	    (clients <= 0 && retains <= kRgfxSurfaceKextRefs))
		return kRgfxCacheReleaseAsIs;
	return kRgfxCacheReleaseAttach;
}

inline RgfxCacheReleaseStep rgfxCacheReleaseNext(RgfxCacheTable &t, uint64_t offset,
                                                 int32_t clients, int32_t retains)
{
	const RgfxCacheReleaseStep step = rgfxCacheReleasePeek(t, offset, clients, retains);
	if (step == kRgfxCacheReleaseAttach)
		rgfxCacheAtBlock(t, offset)->deferral = kRgfxCacheAttaching;
	return step;
}

// Writes `c`'s refill record for its generation where it has a header (RgfxSurfaceRefill.hpp):
// `state` at the surface's unlock seed `unlockSeed` where `seeds` (IOSurface exports it), else
// settled.
inline void rgfxCacheNoteRefill(const RgfxCachedSurface &c, bool seeds, RgfxRefillState state,
                                uint32_t unlockSeed)
{
	if (c.refillAt == nullptr)
		return;
	const uint64_t word = seeds ? rgfxRefillWord(c.cpuGen, state, unlockSeed)
	                            : rgfxRefillWord(c.cpuGen, kRgfxRefillSettled, 0);
	__atomic_store_n(c.refillAt, word, __ATOMIC_RELEASE);
}

// The refill record of a block just cached, at generation 0: owed where a CPU holds the surface
// locked for writing as it is cached (its lock seed `lockSeed` past its unlock seed), that
// lock's op 2 come before the block was, so the first fill may be mid-write; else unsure, as a
// lock may be being taken.
inline void rgfxCacheNoteFirstRefill(const RgfxCachedSurface &c, bool seeds, uint32_t lockSeed,
                                     uint32_t unlockSeed)
{
	rgfxCacheNoteRefill(c, seeds, lockSeed != unlockSeed ? kRgfxRefillOwed : kRgfxRefillUnsure,
	                    unlockSeed);
}

// A read-write CPU lock of surface `key` goes on: its CPU generation moves, and its refill record
// is the new generation's (rgfxCacheNoteRefill), written before the caller writes the generation,
// so a holder that reads the generation reads its record. `unlockSeed` is the surface's unlock
// seed as the lock is taken, before IOSurface moves its lock seed. The new generation, or 0
// where the surface is not cached.
inline uint64_t rgfxCacheReadWriteLock(RgfxCacheTable &t, uint64_t key, bool seeds = false,
                                       uint32_t unlockSeed = 0)
{
	RgfxCachedSurface *c = rgfxCacheFind(t, key);
	if (c == nullptr)
		return 0;
	++c->cpuGen;
	rgfxCacheNoteRefill(*c, seeds, kRgfxRefillOwed, unlockSeed);
	return c->cpuGen;
}

// The BLOCK_RELEASE of the cached block at `offset` is to be posted: locks of its surface wait
// for its answer. False where no cached surface has that block.
inline bool rgfxCacheReleasing(RgfxCacheTable &t, uint64_t offset)
{
	RgfxCachedSurface *c = rgfxCacheAtBlock(t, offset);
	if (c == nullptr)
		return false;
	c->releasing = true;
	return true;
}

// Whether the pages of surface `object` (the IOSurface, opaque here) are still to take a
// write-back: a cached block of it went, its BLOCK_RELEASE posted and not yet answered OK, and the
// host copies its cache into the pages before it answers (rgfxCacheLetGo with `releasing`). A
// block of it kept for good, or one whose attach a let-go left in flight (`forgotten`), posts no
// release, and leaves none to take.
inline bool rgfxCacheWritingBack(RgfxCacheTable &t, const void *object)
{
	for (uint32_t i = 0; object != nullptr && i < t.count; i++) {
		if (t.entries[i].object == object && t.entries[i].releasing) {
			// A new block of it: a process holds the surface again (rgfxCacheRetaken).
			rgfxCacheRetaken(t.entries[i]);
			return true;
		}
	}
	return false;
}

// What an ask that would make a new block in place of a surface does where the surface's pages
// are still to take a write-back (`writingBack`). Nothing of the new block may come before that
// copy over the same pages: a cache filled from them before it reads older bytes, and the GPU's
// writes to them in place, or a new cache's download, are overwritten by it. So every such ask
// waits for it, cached, uncached or deferred, with no deadline: the host answers the release once
// the buffers that used the cache have finished and its copy is done, behind the host's other
// work, a pipeline's compile among it, however long that takes. A wait that ended without the
// answer (`gaveUp`: the device stopped, or the asking thread's process is ending) makes the
// block all the same, logged.
enum RgfxNewBlockStep : uint32_t {
	// No write-back is pending: the block is made.
	kRgfxNewBlockMake = 0,
	// The ask waits for the release's answer.
	kRgfxNewBlockWait,
	// The wait ended unanswered: the block is made all the same, logged.
	kRgfxNewBlockLate,
};

inline RgfxNewBlockStep rgfxCacheNewBlockStep(bool writingBack, bool gaveUp)
{
	if (!writingBack)
		return kRgfxNewBlockMake;
	return gaveUp ? kRgfxNewBlockLate : kRgfxNewBlockWait;
}

// The let-go of the block at `offset`, which named surface `key`'s device cache: as
// rgfxCacheLetGo, where the surface's cached entry is this block's own. Another block of the
// surface, a copy or one in place uncached, whose locks follow the surface by the same device
// cache, holds no entry, and leaves the cached block's as it is: released and unanswered, its
// memory stays wired for the host's copy into the pages; living, or with an attach in flight,
// its locks go on. True, nothing in `*map` and `*wire`, where the caller releases its own
// references of the cache and the surface now.
inline bool rgfxCacheBlockLetGo(RgfxCacheTable &t, uint64_t key, uint64_t offset, bool releasing,
                                void *surface, void **map, void **wire, bool blockWired,
                                void **carried = nullptr)
{
	*map = *wire = nullptr;
	if (carried)
		*carried = nullptr;
	const RgfxCachedSurface *c = rgfxCacheFind(t, key);
	if (c != nullptr && c->offset != offset)
		return true;
	return rgfxCacheLetGo(t, key, releasing, surface, map, wire, blockWired, carried);
}

// Whether a block's SURFACE_PAGES carries its surface's layout (RgfxSurfacePagesLayout, at
// RGFX_SURFACE_PAGES_LAYOUT_OFFSET), the one the bundle gave with its ask (`laidOut`): an ask
// whether the block needs a device cache (`ask`, on a device that answers it, `askCache`:
// SURFACE_CACHE_REFUSED) carries it, and so does a cached block's (`cached`, a deferred one's
// among them) on a device that asks nothing (SURFACE_CACHE alone), by which the host places the
// cache's first plane where its GPU's textures over the cache may start in place, answering it as
// with none. A cached block's on a device that answers asks carries none: its cache takes the
// layout its ask gave. Any other carries none.
inline bool rgfxPagesCarryLayout(bool laidOut, bool ask, bool cached, bool askCache)
{
	return laidOut && (ask || (cached && !askCache));
}

#endif // RGFX_SURFACE_CACHES_HPP_
