/*
 * RgfxAcceleratorUserClient: the connection the guest Metal bundle opens to the
 * RgfxAccelerator over OUR protocol (RgfxUserClientABI.hpp names the ids and selectors): the
 * doorbell, the process's context and its window.
 *   - The window (RgfxAcceleratorUserClientWindow.cpp): the range of the process where its part
 *     of the region lies, each byte at the window's base plus its region offset. The kext maps
 *     in only what is the client's: its blocks, the shared blocks of the surface planes it
 *     holds and the scanout it is granted, and nothing of the rings, the device page or another
 *     process's. The bundle's RgfxRegion and RgfxRingWriter write rings and resources there,
 *     in place in the device's memory. The device info comes from a selector.
 *   - externalMethod(kRgfxAccelMethodDoorbell): writes a ring id to RGFX_REG_DOORBELL
 *     so the host's consumer of that queue's submission ring wakes.
 *
 * This is deliberately NOT Apple's IOGPU submission / allocation user-client ABI. That
 * ABI (its types and selectors) is Apple-private and boot-gated — see the base-class
 * note in RgfxAccelerator.hpp — so it is neither modelled nor invented here.
 *
 * Our own code; it names only SDK-public IOKit classes.
 */

#ifndef RGFX_ACCELERATOR_USER_CLIENT_HPP_
#define RGFX_ACCELERATOR_USER_CLIENT_HPP_

#include <IOKit/IOUserClient.h>

#include "RgfxAccelerator.hpp"
#include "RgfxAskGate.hpp"
#include "RgfxQueueLimits.hpp"
#include "RgfxQueuePublish.hpp"

class IOBufferMemoryDescriptor;

class RgfxAcceleratorUserClient : public IOUserClient {
	OSDeclareDefaultStructors(RgfxAcceleratorUserClient);

public:
	// IOUserClient lifecycle.
	bool initWithTask(task_t owningTask, void *securityID, UInt32 type,
	                  OSDictionary *properties) override;
	bool start(IOService *provider) override;
	void stop(IOService *provider) override;
	IOReturn clientClose() override;
	IOReturn clientDied() override;
	void free() override;

	// Wakes the client's completion waiters (kRgfxAccelMethodWaitCompletions): a completion
	// ring of one of its queues holds records it has not taken. Any thread, and the vector's
	// filter at primary interrupt context (RgfxAccelerator::queueFilter): it takes only
	// completionSpin, with interrupts disabled, and neither blocks nor allocates.
	void wakeCompletions();

	// Maps nothing: the region reaches the process only through the window.
	IOReturn clientMemoryForType(UInt32 type, IOOptionBits *options,
	                             IOMemoryDescriptor **memory) override;

	// The window (RgfxAcceleratorUserClientWindow.cpp): maps the region's `length` bytes at
	// `offset` in at the window's base plus `offset`, a span of the client's own
	// (RgfxWindowSpans.hpp), before the process learns of it; unmapSpan maps the window's own
	// bytes back over the span, read-only, before the span can be anyone else's. Any thread; the
	// window's lock alone, which a caller may take under the accelerator's context or surface
	// lock. mapSpan fails, the op it serves with it, where the window is closed or the span is not
	// one; an unmapSpan that cannot map the window back closes the window. The span is mapped
	// write-back, or write-combined where `writeCombined` (the bytes the process only writes,
	// allocBlock's), from the region's descriptor for those spans
	// (RgfxAccelerator::copyWriteCombinedRegion), and write-back where that is missing.
	IOReturn mapSpan(UInt64 offset, UInt64 length, bool writeCombined = false);
	void unmapSpan(UInt64 offset, UInt64 length);

	// Whether the client's task is WindowServer (initWithTask): its blocks may take the reserve
	// no other process is given (RgfxBlockTable).
	bool isWindowServer() const { return windowServer; }

	// A shared event's port's calls (RgfxSharedEventUserClient), for the port's caller `caller`
	// in its context `ctx`: whether this client holds that context open for that task
	// (rgfxPortCallerHolds); and the export and the import, each an ask of this client's, so its
	// close waits for them, posted on the control ring and answered by the device: the export's
	// SHARED_EVENT_NAME of the caller's shared event `eventId` as `name`, its status in
	// `*status` and whether it was posted in `*posted`; the import's SHARED_EVENT_IMPORT of the
	// caller's new shared event `eventId` from `name`, its status and the event's value in
	// `*status` and `*value`, destroyed behind where the device did not answer in time. Each
	// names the caller's queue `listen`, which must be one of this client's.
	// kIOReturnBadArgument where the context is not this client's or is closing, or `listen` is no
	// queue of it; else postLifecycle's return.
	bool holdsContext(task_t caller, UInt64 ctx);
	IOReturn exportSharedEvent(UInt64 ctx, UInt64 eventId, UInt64 listen, UInt64 name,
	                           UInt32 *status, bool *posted);
	IOReturn importSharedEvent(UInt64 ctx, UInt64 eventId, UInt64 listen, UInt64 name,
	                           UInt32 *status, UInt64 *value);
	// IOConnectAddClient(this client's connection, port), which the bundle calls before it calls
	// on a port it was handed: kIOReturnSuccess where the port is a shared event's port of this
	// client's accelerator (rgfxPortIsShareOf), kIOReturnBadArgument where it is another user
	// client. The kernel looks the port up in the caller's space and sends it nothing, and
	// answers kIOReturnBadArgument itself for a port that is no IOKit connection, so a send right
	// of another process's own port is refused at once, where an IOKit call made on it kills the
	// caller (measured on the 5300M and the 630, oracle_events connect). Connects nothing.
	IOReturn connectClient(IOUserClient *client) override;

	// A diagnostic's (RgfxAcceleratorContexts.cpp, nameAgedClients): the IOSurface of ID
	// `surfaceId` as this client's process finds it (rgfxSurfaceLocksLookup), retained, or null.
	// Inside an ask (beginAsk), which the close waits out, so the process's task outlives the
	// lookup; null, `*asked` false, where the context is not open or its close has begun.
	OSObject *lookupSurfaceOfProcess(uint32_t surfaceId, bool *asked);

	// Dispatch our selectors (the doorbell).
	IOReturn externalMethod(uint32_t selector, IOExternalMethodArguments *arguments,
	                        IOExternalMethodDispatch *dispatch, OSObject *target,
	                        void *reference) override;

	// RGFX DIAG (Wall-2 trace; remove before merge): log the legacy dispatch paths.
	IOExternalMethod *getTargetAndMethodForIndex(IOService **targetP, UInt32 index) override;
	IOExternalTrap *getTargetAndTrapForIndex(IOService **targetP, UInt32 index) override;

private:
	static IOReturn doorbellMethod(OSObject *target, void *reference,
	                               IOExternalMethodArguments *arguments);

	// The process's context (RgfxAcceleratorUserClientContexts.cpp): its selectors, and its
	// release at the client's close or death (its queues, then the context, then its blocks).
	IOReturn contextMethod(uint32_t selector, IOExternalMethodArguments *arguments);
	// The IOGPU base's device calls on its type-5 client: its configuration and device info.
	IOReturn deviceMethod(uint32_t selector, IOExternalMethodArguments *arguments);
	IOReturn submitMethod(IOExternalMethodArguments *arguments);
	IOReturn submitBatchMethod(IOExternalMethodArguments *arguments);
	IOReturn takeAnswersMethod(IOExternalMethodArguments *arguments);
	IOReturn waitCompletionsMethod(IOExternalMethodArguments *arguments);
	void releaseContext();
	// An ask the close must not overtake begins (RgfxAskGate.hpp): false where the context is not
	// open or its close has begun, else `*ctx` is the context it asks for. endAsk ends one begun,
	// waking the close where it was the last. Under no lock; each takes listLock.
	bool beginAsk(UInt32 *ctx);
	void endAsk();
	// An ask begun, ended as it goes out of scope.
	struct Ask {
		RgfxAcceleratorUserClient *client;
		bool begun;
		~Ask()
		{
			if (begun)
				client->endAsk();
		}
	};
	// Makes the window at the context's open; closeWindow lets it go, every span in it with it,
	// at the release, before the context's blocks go.
	IOReturn openWindow();
	void closeWindow();
	// Binds a doorbell page of BAR 4 to the context and maps it into the task at the context's
	// open, where the bundle asks for it (kRgfxAccelMethodOpenContext's seventh output);
	// closeDoorbellPage unmaps it at the release, with the window, and then has it unbound and
	// given back (RgfxDoorbellPages.hpp).
	void openDoorbellPage();
	void closeDoorbellPage();
	IOReturn deviceInfoMethod(IOExternalMethodArguments *arguments);
	// Every CPU's PAT (kRgfxAccelMethodCpuPats), on x86-64.
	IOReturn cpuPatsMethod(IOExternalMethodArguments *arguments);
	// The Shared pool's blocks (kRgfxAccelMethodPoolTake, kRgfxAccelMethodPoolGive,
	// RgfxPoolBlocks.hpp): a take maps a block into the process and lists it, a give takes it off
	// the list and out of the process and gives it back; closePoolBlocks takes every one out of
	// the process at the release, before the CONTEXT_CLOSE that gives them back.
	IOReturn poolTakeMethod(IOExternalMethodArguments *arguments);
	IOReturn poolGiveMethod(IOExternalMethodArguments *arguments);
	void closePoolBlocks();
	// The context's Private blocks (kRgfxAccelMethodPrivateTake, kRgfxAccelMethodPrivateGive):
	// asks of the host alone, which knows each context's blocks and gives them back at its close.
	IOReturn privateTakeMethod(IOExternalMethodArguments *arguments);
	IOReturn privateGiveMethod(IOExternalMethodArguments *arguments);
	// The surfaces a command buffer writes (kRgfxAccelMethodSurfaceWrites), and whether a queue is
	// one of the client's open ones.
	IOReturn surfaceWritesMethod(IOExternalMethodArguments *arguments);
	bool ownsQueue(UInt64 queue);
	// Ends one of the client's command queues `objId` the way kRgfxAccelMethodQueueDestroy does
	// (stop watching its completion ring, drop it from queues[], post its destroy), under the
	// queue lock; false where `objId` is not one of the client's queues. QUEUE_DESTROY and a
	// queue's OBJECT_DESTROY posted through submit both go through it, so the kext never keeps
	// watching a queue the host has torn down.
	bool destroyQueueIfTracked(UInt64 objId);
	// Whether `objId` is one of the client's queues, listed or in the making, read under
	// listLock: destroyQueueIfTracked's first look.
	bool queueListed(UInt64 objId);
	// The submission ring headers the kext publishes the client's queues' buffers on
	// (RgfxQueuePublish.hpp): keepQueueHeader maps queue `objId`'s, whose ring lies at region
	// offset `ring` in the client's block at `block`, at its create; publishQueue publishes
	// `producer` on it with `flags` (SubmitBatch's), false where none is kept for the queue;
	// dropQueueHeaders lets go of the queue `key`'s, those in the block at `key`, or every one,
	// before what they lie in goes.
	enum QueueHeaderDrop { kDropQueue, kDropBlock, kDropAll };
	void keepQueueHeader(UInt64 objId, UInt64 block, UInt64 ring);
	bool publishQueue(UInt64 objId, UInt64 producer, UInt64 flags);
	void dropQueueHeaders(QueueHeaderDrop which, UInt64 key);

	// As many as the device watches for one process (RgfxQueueLimits.hpp).
	static const UInt32 kMaxQueues = kRgfxMaxQueuesPerClient;
	// The most bytes one kRgfxAccelMethodSurfaceWrites names: 1024 surfaces.
	static const UInt64 kMaxSurfaceWritesBytes = (3 + 2 * 1024) * sizeof(UInt64);
	// The context and the queues, changed under both locks: queueLock is held across what
	// changes them (a context's open and release, a queue's create and destroy), each of which
	// may wait for the device. listLock is held only to read or write these fields, so the
	// process's submits, its commits' surface writes and its completions' retires, which only read
	// them, never wait behind another thread's wait for the device.
	//
	// The asks a close must not overtake (a surface's block, a pages block, a block, a chunk of
	// resource ids, a queue, the scanout's grant) are counted under listLock (`asks`,
	// RgfxAskGate.hpp) and run beside each other, under no lock of the client's but a queue's
	// create, which takes queueLock among the queue creates and destroys for the queue list. The
	// close waits for those in flight before it takes queueLock, and none begins after.
	RgfxAskGate asks;
	bool hasContext;
	UInt32 context;
	// The context's run of units of GPU addresses (RgfxContextSlots.hpp): its first unit and
	// how many.
	UInt32 firstUnit;
	UInt32 units;
	UInt32 queueCount;
	UInt64 queues[kMaxQueues];
	// The queue a QUEUE_CREATE is making, its device's answer not yet in; 0 for none.
	UInt64 creatingQueue;
	// The queues' submission ring headers the kext publishes on, under listLock: the first 64
	// queues' kept at once; a queue made past them has its buffers published by the bundle.
	static const UInt32 kQueueHeaders = 64;
	RgfxQueueHeaders<IOMemoryMap, kQueueHeaders> queueHeaders;
	// Under listLock: the context's doorbell page (kRgfxNoDoorbellPage for none), its mapping in
	// the task and its address there (0 for none), which the kext's own publish rings at too.
	UInt32 doorbellPage;
	IOMemoryMap *doorbellMap;
	UInt64 doorbellAddress;
	// Under listLock: the context's Shared pool blocks, each mapped into the task
	// (RgfxPoolBlocks.hpp); the array grows as they do, and goes at the client's free.
	RgfxPoolBlockList poolBlocks;
	IOLock *queueLock;
	IOLock *listLock;

	// Under completionSpin, a spin lock every holder takes with interrupts disabled, as
	// wakeCompletions runs at primary interrupt context too: the count wakeCompletions raises,
	// which a waiter sleeps on, and whether the context is released (every waiter then returns).
	IOSimpleLock *completionSpin;
	UInt64 completionCount;
	bool completionsClosed;

	// Under windowLock: the window's memory and its mapping in the task, its base there and its
	// size, null and 0 while closed; how many spans were mapped in and taken back, and the time
	// it took, logged at the close.
	IOLock *windowLock;
	IOBufferMemoryDescriptor *windowMemory;
	IOMemoryMap *windowMap;
	UInt64 windowBase;
	UInt64 windowSize;
	UInt64 grants;
	UInt64 grantNs;
	UInt64 revokes;
	UInt64 revokeNs;

	task_t task;
	// Whether the task is WindowServer (initWithTask), whose blocks may take the reserve the
	// others are never given (RgfxBlockTable).
	bool windowServer;
	RgfxAccelerator *owner;
	// The type it was opened as: ours (kRgfxAccelUserClientType) or the IOGPU base's device
	// client (kRgfxIOGPUDeviceUserClientType); it decides which selectors it answers.
	UInt32 ucType;
};

#endif // RGFX_ACCELERATOR_USER_CLIENT_HPP_
