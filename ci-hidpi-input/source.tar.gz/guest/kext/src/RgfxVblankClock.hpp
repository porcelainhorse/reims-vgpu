// RgfxVblankClock: the display's refreshes in the guest's clock (ReimsGraphics). Header-only and
// free of the kernel's headers, so its native test (tests/vblank_clock_test.cpp) builds it as the
// kext does.
//
// The host stamps each VBLANK with the time of its refresh on its own monotonic clock, in
// nanoseconds; the guest's clock is taken in nanoseconds too (an x86-64 guest's mach_absolute_time
// counts them; the kext converts an arm64 guest's ticks to and from them). The two clocks
// differ by an offset, and each refresh maps to its host time + that offset: a refresh's time is
// when it happened, not when its interrupt was taken.
//
// Where the device has HOST_TIME, the kext reads the host's clock between two reads of its own at
// each VBLANK (reading): the offset lies within half that round trip of the reading's midpoint
// less the host's time, its bound. The clock maps by the reading of the least bound, a bound that
// widens by kAgePpm of the reading's age, so a newer reading takes over within a few refreshes and
// a drift of the clocks is followed. The offset is then the clocks' own, whatever the VBLANKs'
// delivery takes.
//
// Without it (a host built before HOST_TIME), the offset is inferred from the VBLANKs' delivery:
// a VBLANK's receipt shows the offset plus the event's delivery, and the clock keeps the least
// (receipt - host time) seen, the offset with the shortest delivery. That offset may rise by
// kDriftNs a refresh, so it follows the clocks if they drift apart (at most 0.24 ms a second at
// 120 Hz). It moves with the delivery: a quicker one pulls it down at once and slower ones let it
// creep back, so under load the mapped times wander (measured: Safari's 1080p60 playback put the
// display link's times 38 to 76 us rms off a straight line, against 0 idle).
//
// Either way no mapped time lies after its receipt, and a mapped time never goes back.
//
// Where the bundle stamps its command buffers with the guest's clock (GUEST_TIMES), the kext
// hands the host the held reading's offset (offsetAt) in ring 0's header after each reading, its
// bound widened by its age then, so the host maps those stamps to its own clock (design.md,
// "Guest times").
//
// A display pipe transaction completes at the host's answer, which the host gives in the refresh
// that showed its surface, right after that refresh's VBLANK, or, a host with no window, as it
// shows the surface: its time is the last refresh's at the answer's receipt (shownAt), the last
// VBLANK's where the answer comes within a period of that VBLANK's receipt, else the refresh of
// the VBLANK's grid a whole number of periods on (a VBLANK the ring had no room for, or one still
// to come), up to kOffPeriods periods on; past that the VBLANKs are off, and the time is the
// answer's own. The answers' times never go back, as the presents they complete are shown in
// order: an answer that would map before the last one takes the last one's time. Mapped to its
// own receipt instead, an answer a period after the last VBLANK's receipt came after the next
// refresh's time, and the next answer, mapped to that refresh, went back (measured on a macOS
// 14.6.1 arm64 guest with no host window: a frame info presentation time 6.3 ms back).
//
// Our own code.
#ifndef RGFX_VBLANK_CLOCK_HPP_
#define RGFX_VBLANK_CLOCK_HPP_

#include <stdint.h>

class RgfxVblankClock {
public:
	// A frame at 60 Hz, the period before two refreshes have been seen.
	static constexpr uint64_t kDefaultPeriodNs = 16666667;
	// The gaps taken as the period.
	static constexpr uint64_t kMinPeriodNs = 1000000;
	static constexpr uint64_t kMaxPeriodNs = 100000000;
	// How far the offset inferred from delivery may rise a refresh.
	static constexpr uint64_t kDriftNs = 2000;
	// How fast a held reading's bound widens with its age, in parts per million of it: 1 us in
	// 20 ms, so a newer reading takes over within a few refreshes from a held one a microsecond
	// tighter, and the offset follows the clocks' drift (measured on an x86-64 guest: 0.7 ppm
	// between its clock and the host's raw monotonic one, which NTP does not slew).
	static constexpr uint64_t kAgePpm = 50;
	// How many periods past the last VBLANK's receipt an answer still maps to a refresh of its
	// grid: VBLANKs that are on come a period apart.
	static constexpr uint64_t kOffPeriods = 4;

	// The host's clock from HOST_TIME's three reads, HI, LO and HI again: the second HI where LO
	// is below 2^31 (where LO wrapped between the HI reads, it did so before LO was read), else
	// the first.
	static uint64_t hostTime(uint32_t hi, uint32_t lo, uint32_t hiAgain)
	{
		return (static_cast<uint64_t>(lo < 0x80000000u ? hiAgain : hi) << 32) | lo;
	}

	// A reading of the host's clock (HOST_TIME): `hostNs` read between the guest's `before` and
	// `after`. It is held where its bound is no more than the held one's, widened by its age; a
	// reading of 0 (a device reset) is not taken.
	void reading(uint64_t before, uint64_t hostNs, uint64_t after)
	{
		if (!hostNs || after < before)
			return;
		uint64_t bound = (after - before) / 2;
		if (haveReading_ && before >= readingAt_ &&
		    bound > readingBound_ + (before - readingAt_) * kAgePpm / 1000000)
			return;
		haveReading_ = true;
		readingOffset_ = static_cast<int64_t>(before + bound - hostNs);
		readingBound_ = bound;
		readingAt_ = before;
	}

	// The VBLANK of refresh `count`, stamped `hostNs` by the host, taken at `receipt` (the
	// guest's clock): the refresh's time in the guest's clock, by the held reading's offset where
	// one came, else by the offset with the shortest delivery.
	uint64_t vblank(uint64_t count, uint64_t hostNs, uint64_t receipt)
	{
		int64_t sample = static_cast<int64_t>(receipt - hostNs);
		if (!have_ || sample < offset_ + static_cast<int64_t>(kDriftNs))
			offset_ = sample;
		else
			offset_ += static_cast<int64_t>(kDriftNs);
		int64_t offset = haveReading_ ? readingOffset_ : offset_;
		uint64_t time = hostNs + static_cast<uint64_t>(offset);
		if (time > receipt)
			time = receipt;
		if (have_ && time <= time_)
			time = time_ + 1;
		if (have_ && count > count_ && hostNs > hostNs_) {
			// A gap outside a display's rates (10 to 1000 Hz) is not taken.
			uint64_t gap = (hostNs - hostNs_) / (count - count_);
			if (gap >= kMinPeriodNs && gap <= kMaxPeriodNs)
				period_ = gap;
		}
		have_ = true;
		count_ = count;
		hostNs_ = hostNs;
		time_ = time;
		receipt_ = receipt;
		return time;
	}

	// The held reading's offset (the guest's clock less the host's) and its bound at the guest's
	// `now`, widened by kAgePpm of the reading's age: false, writing neither, before a reading
	// was held.
	bool offsetAt(uint64_t now, int64_t *offset, uint64_t *bound) const
	{
		if (!haveReading_)
			return false;
		*offset = readingOffset_;
		*bound = readingBound_ + (now > readingAt_ ? (now - readingAt_) * kAgePpm / 1000000 : 0);
		return true;
	}

	// A bound as ring 0's header holds it (RgfxRingHeader's guest_clock_bound_ns): at least 1 ns,
	// as 0 there says no reading is held, and at most what 32 bits hold.
	static uint32_t headerBound(uint64_t bound)
	{
		if (bound == 0)
			return 1;
		return bound > 0xffffffffull ? 0xffffffffu : static_cast<uint32_t>(bound);
	}

	// The last refresh's time (0 before any), and the next one's, a period after it.
	uint64_t last() const { return have_ ? time_ : 0; }
	uint64_t next() const { return have_ ? time_ + period_ : 0; }
	uint64_t period() const { return period_; }

	// The time of the refresh whose answer is taken at `now`: the last refresh's, where `now` is
	// within its period after that refresh's VBLANK was taken; the refresh a whole number of
	// periods after it, where `now` is that many periods after the receipt, up to kOffPeriods;
	// else `now` (no VBLANK came lately: the device's VBLANKs are off). Never before the last
	// answer's time: that, where it would be.
	uint64_t shownAt(uint64_t now)
	{
		uint64_t time = now;
		if (have_ && now >= receipt_ && now - receipt_ < kOffPeriods * period_)
			time = time_ + (now - receipt_) / period_ * period_;
		if (time < shown_)
			time = shown_;
		shown_ = time;
		return time;
	}

private:
	bool have_ = false;
	int64_t offset_ = 0;
	uint64_t count_ = 0;
	uint64_t hostNs_ = 0;
	uint64_t time_ = 0;
	uint64_t receipt_ = 0;
	uint64_t period_ = kDefaultPeriodNs;
	// The last answer's time (shownAt).
	uint64_t shown_ = 0;
	// The held reading of the host's clock: its offset, its bound and when it was taken.
	bool haveReading_ = false;
	int64_t readingOffset_ = 0;
	uint64_t readingBound_ = 0;
	uint64_t readingAt_ = 0;
};

#endif // RGFX_VBLANK_CLOCK_HPP_
