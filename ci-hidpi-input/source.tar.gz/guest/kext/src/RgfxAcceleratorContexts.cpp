/*
 * RgfxAccelerator's contexts: what each Metal process that opens our user client holds of the
 * device, and what the accelerator tells the device of it.
 *
 *   - A context number, handed out once from 1: the process's object ids are
 *     c << RGFX_CONTEXT_OBJ_ID_SHIFT and up, so no two processes' ids meet in the host's one
 *     handle table, and the host drops the process's at CONTEXT_CLOSE.
 *   - A run of units of the guest's GPU addresses (RgfxContextSlots.hpp), held until the close:
 *     the process's GPU addresses come from the run's range. Runs are handed out round-robin, so
 *     a run freed by one process is the last one the next process takes, and the last units
 *     free go to WindowServer alone.
 *   - Chunks of the texture resource ids, on demand, from one pool for the guest: every
 *     process's textures share the host device's one space of ids, which ends below
 *     RGFX_RESOURCE_ID_LIMIT, so ids are not split by context. Each chunk is posted to the device
 *     (RESOURCE_ID_SMALL_CHUNK, or RESOURCE_ID_CHUNK where the guest did not take
 *     RGFX_FEATURE_SMALL_ID_CHUNKS: RgfxIdChunks.hpp) before the process learns of it, and the
 *     client's are freed at its close, after its CONTEXT_CLOSE is answered.
 *   - Region blocks past RGFX_CONTEXT_ALLOCATIONS_OFFSET (rings, Shared buffers and heaps,
 *     surfaces), from a first-fit allocator over a table sorted by offset (RgfxBlockTable.hpp),
 *     each owned by the client that asked. A freed block is given out again once the device
 *     answers its BLOCK_RELEASE OK, which a thread call of the kext's own posts, so a free
 *     returns at once; the client's are freed after its close is answered, and kept from use
 *     for good where it is not.
 *   - The shared blocks of IOSurface planes (RgfxSurfaceBlocks.hpp): one block per plane asked
 *     for by every process that holds the surface (the bundle asks by each surface's plane 0, its
 *     block holding every plane), found by the plane's physical pages, which the kext wires in
 *     each asking process's task while it holds the block. The device learns of each
 *     holder (BLOCK_SHARE) before the process learns of the block, and of each but the last
 *     letting go (BLOCK_UNSHARE); the last frees the block as a client's free does. An unshare
 *     goes out of the lock, but before the block's release and before any ask holds the block
 *     again (RgfxBlockTable.hpp's `unshares`), so the device never ends a later hold with it,
 *     of the block or of the next block given its span. Where the
 *     device has RGFX_FEATURE_SURFACE_PAGES, a process may ask for a surface's block in place:
 *     the kext wires the surface's whole allocation, writes its runs into the block past the
 *     part the processes map, and hands them to the device (SURFACE_PAGES) before the first
 *     share. A block whose pages the device refuses goes again, and the process copies.
 *     Where the device also has RGFX_FEATURE_SURFACE_CACHE, an ask in place that names its
 *     surface and may have it cached makes a cached block (RgfxSurfaceCaches.hpp): the kext makes
 *     the surface's device cache first, then marks the block cached in its SURFACE_PAGES, and a
 *     cached block's release copies the host's cache into the pages (its locks waiting for it).
 *   - The completion rings of the clients' queues, watched: the device raises its one vector
 *     for a queue's completion as for the control ring's. The vector's filter calls
 *     queueFilter as the interrupt arrives, and the framebuffer's work loop then calls
 *     queueInterrupt; each wakes the client of each ring whose producer moved and holds
 *     records the client has not taken, the second skipping what the first woke for
 *     (RgfxQueueWakes.hpp). Each ring's header is mapped into the kernel at its queue's
 *     create; the work loop's scan takes only the watch table's lock, and the filter's only
 *     the table's spin lock.
 *   - The object lifecycle, on the framebuffer's control ring: creates and destroys, a
 *     QUEUE_CREATE answered once the host has the queue's ring pair (so the process writes it at
 *     once), and a CONTEXT_CLOSE answered once the host has dropped the context's objects.
 *
 * Our own code; it names only SDK-public IOKit calls.
 */

#include "RgfxAccelerator.hpp"
#include "RgfxAcceleratorUserClient.hpp"
#include "RgfxCloseTable.hpp"
#include "RgfxContextSlots.hpp"
#include "RgfxIOSurfaceKPI.hpp"
#include "ReimsGraphics.hpp"
#include "RgfxSurfaceBlocks.hpp"
#include "RgfxSurfaceCaches.hpp"
#include "RgfxLatency.hpp"
#include "RgfxBlockZero.hpp"
#include "RgfxPagesBlock.hpp"
#include "RgfxTopDown.hpp"
#include "RgfxIdChunks.hpp"
#include "RgfxTrace.hpp"
#include "RgfxReleaseTable.hpp"
#include "RgfxQueueWakes.hpp"

#include <IOKit/IOBufferMemoryDescriptor.h>
#include <IOKit/IOKitKeys.h>
#include <IOKit/IOLib.h>
#include <IOKit/IOMemoryDescriptor.h>
#include <IOKit/IOMultiMemoryDescriptor.h>
#include <kern/clock.h>
#include <kern/thread_call.h>
#include <libkern/libkern.h>
#include <sys/proc.h>
#include <sys/sysctl.h>
#if defined(__x86_64__)
#include <sys/systm.h>
#endif

namespace {
// The most blocks handed out at once, and WindowServer's reserve of them (RgfxBlockTable.hpp).
constexpr UInt32 kMaxBlocks = kRgfxMaxBlocks;
constexpr UInt64 kWindowServerReserveBytes = kRgfxWindowServerReserveBytes;
constexpr UInt32 kWindowServerReserveEntries = kRgfxWindowServerReserveEntries;
// The most command queues watched at once, over every client (RgfxQueueLimits.hpp).
constexpr UInt32 kMaxWatched = kRgfxMaxWatchedQueues;
// A ring header's fields (RgfxRingHeader).
constexpr UInt32 kRingProducer = 0x00;
constexpr UInt32 kRingCompletedSeqno = 0x08;
constexpr UInt32 kRingConsumer = 0x40;
// How long a CONTEXT_CLOSE waits for its answer before it is late. It keeps a deadline, as no
// answer of it is read wrong: a close not answered in time is parked (kCloseLate, parkClose),
// what the context held staying the device's until the answer, so the process's exit, or its
// client's close, goes on. A QUEUE_CREATE and a surface's SURFACE_PAGES wait for their answers
// with no deadline (kLifecycleUntilAnswered): the host answers each on the context's lane,
// behind whatever pipeline compiles were posted before them.
constexpr UInt32 kCloseAnswerMs = 10000;
// The most closes in flight, late ones included (RgfxCloseTable.hpp).
constexpr UInt32 kMaxCloses = 32;
// How long a BLOCK_RELEASE waits for its answer, which comes once the context's command buffers
// committed before it have finished, before it is logged as late. A late one stays in flight,
// its block, pages and surface the device's, until its answer.
constexpr UInt32 kReleaseAnswerMs = 10000;
// Every block is page-aligned and a whole number of pages, so a block can back a mapping.
constexpr UInt64 kPage = 0x1000;
// The guest's memory where hw.memsize gives none, for the dormant blocks' cap of bytes.
constexpr UInt64 kDormantMemoryUnknown = 2ull << 30;
// How often the dormant blocks' line is logged at most, a summary, once a minute
// (docs/conventions.md), and how long a new block waits for dormant blocks' releases to give the
// region room for it. That wait keeps its deadline: it is for room, not for an answer read, and a
// block that finds none is refused (kRgfxCopyRefusedRoom), its process making a copy instead.
constexpr UInt32 kDormantLogMs = 60000;
constexpr UInt32 kDormantRoomMs = 100;
// How many dormant blocks a new block that finds no room in the region lets go.
constexpr UInt32 kDormantRoomBlocks = 16;
// How often the releases' line is logged at most: a summary, once a minute.
constexpr UInt32 kReleaseLogMs = 60000;
// How often the zeroed blocks' line is logged at most (noteZeroing).
constexpr UInt32 kZeroLogMs = 30000;
// The most BLOCK_RELEASEs in flight at once (RgfxReleaseTable.hpp): 40 bytes each on ring 0,
// under a third of its 32 KiB.
constexpr UInt32 kMaxReleases = 256;
// The releases posted under one hold of the ring's lock, with one doorbell at most.
constexpr UInt32 kReleaseBatch = 16;

UInt64 alignUp(UInt64 value, UInt64 align)
{
	return (value + (align - 1)) & ~(align - 1);
}

#if defined(__x86_64__)
// The `length` bytes at `address` in `task`, the current task, faulted in from the last page down
// before a wire takes them, so that the pages the kernel gives them run in the guest's RAM's order
// (RgfxTopDown.hpp): one byte of each page read through the task's own mapping, until one is not
// readable. Nothing where `task` is not the current task.
//
// It faults in only pages the wire faults in anyway: a wire (prepare) takes every page of the
// range, faulting in each that is not resident, allocated and zero-filled or paged in; the read's
// fault does that for the page first, and the wire then finds it resident. A resident page is only
// read. No byte the process reads changes: nothing is written. Two cases do more than the wire
// alone, both rare and bounded:
// (i) a writable private range that is copy-on-write (a fork's), a page of which is in no object
//     yet: the read zero-fills the page in the object the range shares, and the wire, which writes,
//     copies it into the range's own: a page and a copy of its zeros more than the wire alone,
//     which zero-fills one page in the range's own;
// (ii) a range the wire refuses for a page it cannot take: the readable pages above that page are
//     faulted in, which the wire, from the first page up, does not reach before it refuses.
void faultTopDown(task_t task, UInt64 address, UInt64 length)
{
	if (task != current_task())
		return;
	rgfxTopDown(address, length, kPage, [](uint64_t at) {
		UInt8 byte = 0;
		return copyin(static_cast<user_addr_t>(at), &byte, 1) == 0;
	});
}

// The first `length` bytes of `memory`, faulted in from the last page down before a wire takes
// them, as faultTopDown faults a task's: through a read-only mapping of them in the kernel's map,
// made and let go of here, so that no process's map shows them. Nothing where every page of the
// memory is resident already, which a new mapping would fault in one by one for nothing, or where
// the memory is not mapped. Its pages are the memory's own, shared by every mapping of it, so the
// read's faults are the wire's, with no copy-on-write.
void faultTopDown(IOMemoryDescriptor *memory, UInt64 length)
{
	IOByteCount resident = 0, dirty = 0;
	if (length == 0 || (memory->getPageCounts(&resident, &dirty) == kIOReturnSuccess &&
	                    resident >= alignUp(memory->getLength(), kPage) / kPage))
		return;
	IOMemoryMap *map =
	    memory->createMappingInTask(kernel_task, 0, kIOMapAnywhere | kIOMapReadOnly, 0, length);
	if (!map)
		return;
	rgfxTopDown(map->getAddress(), length, kPage, [](uint64_t at) {
		(void)*reinterpret_cast<const volatile UInt8 *>(at);
		return true;
	});
	map->release();
}
#endif
} // namespace

// The device's contexts and blocks: one accelerator per device, one device per guest. Made at
// the first context's open (startContexts) and kept for the kernel's life.
namespace {
// One initialised object (it lands in __DATA,__data, a section the kext has already, so the
// image's layout before its code stays as the loader's sites were taken from).
struct ContextState {
	// Under contextLock: the units of GPU addresses held, the units a context holds (set at the
	// state's start, from the device's maxBufferLength), the next context number, and the
	// blocks handed out, sorted by offset.
	//
	// The lock order: IOSurface's own locks come before every lock of the kext's. IOSurface calls
	// the device caches' control function (RgfxAcceleratorLocks.cpp) holding locks of its own:
	// op 5 from a client's release (IOSurfaceRootUserClient::release_surface), under the lock
	// IOSurfaceRoot's lookupSurface takes; ops 6 and 7 from a purgeable change; ops 0 to 3 from a
	// CPU lock. The control function takes the locks' state.lock, which is taken after
	// contextLock where both are held, and never contextLock. So no thread holding contextLock or
	// state.lock calls into IOSurface: no lookup, no device cache made or its control function
	// set, no setCurrent, no CPU lock, and no release of a surface or a device cache, which may
	// free it inside IOSurface (letGo hands those to the release worker). The getters read under
	// them, IOSurface's getClientRetainCount, getLockSeed and getMemoryDescriptor, each load a
	// field and take no lock (read from IOSurface's x86_64 code in macOS 26.6's KDK). Seen on a
	// 12.7.6 boot, in a spindump: an ask holding contextLock in a lookup, and a client's release
	// holding the lock it waited for, its op 5 waiting for contextLock in wakeReleases, held
	// WindowServer for good.
	IOLock *contextLock;
	RgfxContextSlots slots;
	UInt32 contextUnits;
	UInt32 nextContext;
	RgfxBlockTable blockTable;
	// Under contextLock: the client holding each unit of RGFX_RESOURCE_ID_SMALL_CHUNK texture
	// resource ids, null where none does (RgfxIdChunks.hpp).
	const void *idChunkOwners[RGFX_RESOURCE_ID_SMALL_CHUNKS];
	// Under watchLock: the watched completion rings, and whether the framebuffer calls
	// queueInterrupt yet. Each change to the table (an entry added or taken out, its count) also
	// holds filterLock, a spin lock taken with interrupts disabled, which the vector's filter
	// takes at primary interrupt context (queueFilter) and which guards each entry's
	// filterProducer; the filter reads the table under it alone.
	IOLock *watchLock;
	IOSimpleLock *filterLock;
	RgfxWatchedRing *watched;
	UInt32 watchedCount;
	bool hooked;
	// The thread call that posts freed blocks' releases (releaseFreedBlocks).
	thread_call_t releaseCall;
	// The region again, a descriptor of its own that only write-combined spans are mapped from
	// (copyWriteCombinedRegion): null where it could not be made.
	IODeviceMemory *combinedRegion;
	// BAR 4's doorbell pages (RgfxDoorbellPages.hpp), where the kext took
	// RGFX_FEATURE_DOORBELL_PAGES and the BAR is mapped, set at the state's start and kept for
	// the kernel's life: the BAR's descriptor, which each process's page is mapped from, and its
	// mapping in the kernel, which the kext's own doorbell writes go through, null where there
	// are none; and under contextLock the pages held.
	IODeviceMemory *doorbells;
	IOMemoryMap *doorbellMap;
	volatile UInt8 *doorbellBase;
	RgfxDoorbellPages doorbellPages;
	// The kernel's own mappings of the blocks' range, one a cache mode (kZeroMapWriteBack,
	// kZeroMapWriteCombined), which zeroSpan writes a new block's zeros through: set at the
	// state's start and kept for the kernel's life, null where the kernel would not make one.
	IOMemoryMap *zeroMaps[2];
	// The Shared pool's range (poolMemory), a descriptor of its own that each block is mapped
	// into its process from, and its length: set once, at the first call that finds the pool,
	// and kept for the kernel's life; null and 0 until then, or where there is none.
	IODeviceMemory *pool;
	UInt64 poolLength;
};
ContextState state = {nullptr,
                      kRgfxContextSlotsEmpty,
                      1,
                      1,
                      {nullptr, 0, kMaxBlocks, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                      {},
                      nullptr,
                      nullptr,
                      nullptr,
                      0,
                      false,
                      nullptr,
                      nullptr,
                      nullptr,
                      nullptr,
                      nullptr,
                      {},
                      {nullptr, nullptr},
                      nullptr,
                      0};
IOLock *&contextLock = state.contextLock;
RgfxContextSlots &slots = state.slots;
UInt32 &contextUnits = state.contextUnits;
UInt32 &nextContext = state.nextContext;
RgfxBlockTable &blockTable = state.blockTable;
RgfxBlock *&blocks = state.blockTable.blocks;
UInt64 &blocksStart = state.blockTable.start;
UInt64 &blocksEnd = state.blockTable.end;
thread_call_t &releaseCall = state.releaseCall;
const void *(&idChunkOwners)[RGFX_RESOURCE_ID_SMALL_CHUNKS] = state.idChunkOwners;
IOLock *&watchLock = state.watchLock;
IOSimpleLock *&filterLock = state.filterLock;
RgfxWatchedRing *&watched = state.watched;
UInt32 &watchedCount = state.watchedCount;
bool &hooked = state.hooked;
// Whether the device uses surfaces' own pages in place (RGFX_FEATURE_SURFACE_PAGES), read from
// FEATURES_LO at the first context's open.
bool surfacePages = false;
#if RGFX_GUEST_ARM64
// Whether the kext took RGFX_FEATURE_PAGES_16K, read with surfacePages: every run of guest RAM it
// names to the device then ends at the end of a 16 KiB page (writeRuns, pagesBlock), and the
// length of each SURFACE_PAGES with it (postPages).
bool pages16k = false;
#endif
// Whether the device keeps cached surfaces' GPU copies in its own memory
// (RGFX_FEATURE_SURFACE_CACHE), or keeps them only of the surfaces it answers need one
// (RGFX_FEATURE_SURFACE_CACHE_REFUSED, taken), read with it.
bool surfaceCache = false;
// Whether the device answers, surface by surface, which surfaces need a device cache: a new
// cacheable block in place asks it (RGFX_SURFACE_PAGES_ASK_CACHE), and is cached only where it
// answers RGFX_STATUS_CACHE. Read with surfaceCache.
bool askCache = false;
// Whether the device's GPU form of every IOSurface is its device cache
// (RGFX_FEATURE_SURFACE_CACHE_EVERY, taken), read with surfaceCache, which it needs: every block in
// place is cached, and an ask in place that cannot be is refused before anything is posted
// (refuseInPlace); the tables of the surfaces' blocks, of a block's holders and of the cached
// surfaces grow rather than refuse; and each copy block made or held again, a surface's second
// copy beside its device cache, is counted (noteFallbackCopy).
bool cacheEvery = false;
// The bytes of the host GPU's memory deferred blocks' device caches may hold
// (RGFX_FEATURE_SURFACE_DEFERRED, or RGFX_FEATURE_SURFACE_DEFERRED_ASK where the device answers
// which surfaces need a cache, and their DEFERRED_BUDGET registers), read at the first context's
// open: 0, deferring none, where the device or the kext does not take the feature, or where the
// guest's IOSurfaces have a mapper device of their own (kSurfaceMapperService), which maps their
// pages for the host. Where the device answers which surfaces need a cache (askCache), a deferred
// block asks with its surface's layout, and is deferred only where the device answers that the
// block would need a cache whatever its pages (deferSurfaceBlock).
UInt64 deferredBudget = 0;
// Whether a deferral may carry the resident pages of its surface its asker lists
// (RGFX_FEATURE_SURFACE_DEFERRED_CARRY, taken, RgfxDeferCarry.hpp): a surface fresh but for them
// is deferred too. Read with deferredBudget, and false where it is 0.
bool deferCarries = false;
// The service of that mapper device, the paravirtualized GPU's.
const char *const kSurfaceMapperService = "IOSurfaceParavirtMapperService";
// Under contextLock: the shared blocks of surface planes, made at the first ask.
RgfxSurfaceTable surfaceTable = {nullptr, 0};
// Under contextLock: the pages blocks of writable memory being made (pagesBlock), each counted
// from before its pages are wired to its block's place in the table, or its failure
// (pagesBlockOver). A sole holder's block is refused while any is (soleHolderAlone).
UInt32 writableMakes = 0;
// The bytes of surface pages the dormant blocks hold at most, and of the dormant deferred blocks'
// caches where half deferredBudget is more (RgfxSurfaceBlocks.hpp): an eighth of the guest's
// memory, read at the first context's open.
UInt64 dormantMaxBytes = 0;
// What the dormant blocks did, under contextLock, logged once something changed and
// kDormantLogMs passed since the last line (noteDormant).
struct DormantStats {
	UInt64 slept;
	UInt64 revived;
	UInt64 letGo[kRgfxDormantCauses];
	// Let go as their surface's cache was purged (op 5, a client of the surface going) with a
	// cache the GPU wrote since its last copy: the host copies it into the pages, whether or not
	// a client of the surface is left as the release is posted (`unread`).
	UInt64 purgedWritten;
	// Let go past a cap, a table entry or the region's room, of a surface made volatile.
	UInt64 volatileFirst;
	// Let go for their age (kRgfxDormantAged) with a cache the GPU wrote since its last copy, whose
	// releases copied it into the pages one at a time (agePace).
	UInt64 agedWritten;
	// Blocks of cached surfaces released with no client of the surface left
	// (RGFX_BLOCK_RELEASE_NO_CLIENT), and of them those with GPU writes named that no lock's
	// download copied: the host copies the cache into the pages all the same where it holds a
	// write the pages do not (an early copy, or a device of the host, may have put it there).
	UInt64 unread;
	UInt64 unreadWritten;
	// Of them, those nothing but the kext held (RGFX_BLOCK_RELEASE_UNHELD), every one, which the
	// host counts too, the same set; and of those the ones with GPU writes named that no lock's
	// download copied, at least as many as the host drops uncopied: it drops a cache that holds
	// a write its pages do not, where no process took the surface again before its copy
	// (rgfxSurfaceCacheRetaken counts those).
	UInt64 unheld;
	UInt64 unheldWritten;
	// Blocks deferred (RgfxSurfaceBlocks.hpp), deferrals the host refused, and deferred blocks
	// released with their pages never named.
	UInt64 deferred;
	UInt64 deferredRefused;
	UInt64 deferredUnattached;
	// Asks that held a cached block in place found by their surface, no page of theirs wired
	// (rgfxSurfaceFindCached).
	UInt64 foundBySurface;
	UInt64 changes;
	UInt64 loggedChanges;
	// The surfaces left uncached for want of room (rgfxSurfaceCacheNoRoom) at the last line.
	UInt64 loggedNoRoom;
	UInt64 loggedAt;
	// Where the device caches every surface: the chunks the surface table grew by and the
	// blocks whose holds grew, under contextLock, and the sum of the fallback counts
	// (fallbackSum) at the last line.
	UInt64 tableChunks;
	UInt64 holdsGrown;
	UInt64 loggedFallback;
};
DormantStats dormantStats = {};

// What the releases took, under contextLock, logged once more were answered and kReleaseLogMs
// passed since the last line (noteReleases): from a block's free to its release's answer
// (`latency`), and from a dormant block's ask to go to the worker's reap of it (`reapWait`, while
// the worker is busy with releases); the releases kept, the ones late, the most in flight at
// once, and the new surface blocks that waited for the region's room and the ones that found
// none after.
struct ReleaseStats {
	RgfxLatency latency;
	RgfxLatency reapWait;
	UInt64 kept;
	// The releases not answered in kReleaseAnswerMs, each still waiting then.
	UInt64 late;
	UInt32 inFlightMost;
	UInt64 roomWaits;
	UInt64 roomWaitsFailed;
	// The new surface blocks that waited for their surface's write-back, and the ones that went
	// on with it still pending.
	UInt64 writeBackWaits;
	UInt64 writeBackLate;
	// Atomic, under no lock: when the first dormant block asked to go since the worker's last
	// run, set from the control function (wakeReleases), which takes no contextLock.
	UInt64 reapAskedAt;
	UInt64 loggedCount;
	UInt64 loggedAt;
};
ReleaseStats releaseStats = {};

// What zeroing new blocks took (RgfxBlockZero.hpp), under contextLock, logged once more were zeroed
// and kZeroLogMs passed since the last line (noteZeroing).
RgfxZeroStats zeroStats = {};

// Under contextLock: the references of device caches and surfaces let go of under it (letGo),
// which the release worker releases out of every lock of the kext's (releaseLetGo), in the order
// let go. The list holds them as they were given, retaining none; null and empty while none waits.
struct LetGoList {
	OSObject **refs;
	UInt32 count;
	UInt32 capacity;
};
LetGoList letGoList = {nullptr, 0, 0};
constexpr UInt32 kLetGoFirst = 16;

// Hands the caller's reference of `object`, a device cache or a surface, to the release worker,
// which releases it out of every lock of the kext's: a release here may free it inside IOSurface,
// which may wait for IOSurface's lock (ContextState's lock order). Under contextLock. One the list
// has no room for is kept for good, logged.
void letGo(OSObject *object)
{
	if (!object)
		return;
	if (letGoList.count == letGoList.capacity) {
		const UInt32 grown = letGoList.capacity ? 2 * letGoList.capacity : kLetGoFirst;
		auto *refs = static_cast<OSObject **>(IOMalloc(sizeof(OSObject *) * grown));
		if (!refs) {
			IOLog("RgfxAccelerator: no memory to let go of a %s out of the contexts' lock: it is "
			      "kept for good\n",
			      object->getMetaClass()->getClassName());
			return;
		}
		if (letGoList.count)
			bcopy(letGoList.refs, refs, sizeof(OSObject *) * letGoList.count);
		if (letGoList.refs)
			IOFree(letGoList.refs, sizeof(OSObject *) * letGoList.capacity);
		letGoList.refs = refs;
		letGoList.capacity = grown;
	}
	letGoList.refs[letGoList.count++] = object;
	thread_call_enter(releaseCall);
}

// Releases the references letGo was given, in its order, out of every lock of the kext's. On the
// release worker.
void releaseLetGo()
{
	IOLockLock(contextLock);
	const LetGoList list = letGoList;
	letGoList = {nullptr, 0, 0};
	IOLockUnlock(contextLock);
	for (UInt32 i = 0; i < list.count; i++)
		list.refs[i]->release();
	if (list.refs)
		IOFree(list.refs, sizeof(OSObject *) * list.capacity);
}

UInt64 nanosSince(UInt64 then, UInt64 now)
{
	UInt64 ns = 0;
	if (then && now > then)
		absolutetime_to_nanoseconds(now - then, &ns);
	return ns;
}

// The kept mappings' cache modes (ContextState::zeroMaps).
enum : UInt32 { kZeroMapWriteBack, kZeroMapWriteCombined, kZeroMapModes };

// The blocks' range mapped into the kernel once a cache mode, write-back from `region` and
// write-combined from its write-combined descriptor, for zeroSpan, at the state's start. A
// mapping made once costs a new block no mapping of its own: made and taken down for each span,
// the mappings took 93% of the zeroing's time over a boot, and its longest waits, 114 ms for a
// staging chunk and 19 ms for a surface header (rzboot2, a macOS 26.7.2 guest on a 780M host).
// It holds the kernel's address space and page tables, and no memory of the host's: no page of
// the region is touched until it is zeroed or used. Where the kernel will not make one, each
// span is mapped alone for its zeros, as before.
void keepZeroMaps(IODeviceMemory *region)
{
	const UInt64 length = blocksEnd > blocksStart ? blocksEnd - blocksStart : 0;
	for (UInt32 mode = 0; mode < kZeroMapModes; mode++) {
		const bool combined = mode == kZeroMapWriteCombined;
		IODeviceMemory *from = combined ? state.combinedRegion : region;
		if (!from || !length)
			continue;
		const IOOptionBits cache = combined ? kIOMapWriteCombineCache : kIOMapCopybackCache;
		const UInt64 made = mach_absolute_time();
		state.zeroMaps[mode] =
		    from->createMappingInTask(kernel_task, 0, kIOMapAnywhere | cache, blocksStart, length);
		const UInt64 ns = nanosSince(made, mach_absolute_time());
		if (state.zeroMaps[mode])
			IOLog("RgfxAccelerator: the blocks' range is kept mapped %s for their zeros: %llu MiB, "
			      "made in %llu us\n",
			      combined ? "write-combined" : "write-back", length >> 20, ns / 1000);
		else
			IOLog("RgfxAccelerator: the blocks' range was not kept mapped %s: each span is mapped "
			      "alone for its zeros\n",
			      combined ? "write-combined" : "write-back");
	}
}

// Zeros the span `s` of `region` (RgfxBlockZero.hpp) through a kernel mapping of the cache mode a
// window maps it with, as RgfxAcceleratorUserClient::mapSpan maps it: a write-combined span from
// the region's write-combined descriptor where there is one, else write-back from the region's
// own; through the mode's kept mapping (keepZeroMaps), else one made for the span. The
// write-combined stores are fenced (SFENCE), so they are in the region before any window maps the
// span. Adds the time a mapping of its own took, made and taken down, to `*mapNs`, and its
// stores' to `*storeNs`. False where the kernel would not map the span.
bool zeroSpan(IODeviceMemory *region, const RgfxZeroSpan &s, UInt64 *mapNs, UInt64 *storeNs)
{
	IODeviceMemory *combined = s.writeCombined ? state.combinedRegion : nullptr;
	IODeviceMemory *from = combined ? combined : region;
	if (!from)
		return false;
	IOMemoryMap *kept = state.zeroMaps[combined ? kZeroMapWriteCombined : kZeroMapWriteBack];
	if (kept && s.offset >= blocksStart && s.offset - blocksStart <= kept->getLength() &&
	    s.length <= kept->getLength() - (s.offset - blocksStart)) {
		const UInt64 start = mach_absolute_time();
		bzero(reinterpret_cast<void *>(kept->getVirtualAddress() + (s.offset - blocksStart)),
		      static_cast<size_t>(s.length));
#if defined(__x86_64__)
		if (combined)
			__builtin_ia32_sfence();
#endif
		*storeNs += nanosSince(start, mach_absolute_time());
		return true;
	}
	const IOOptionBits cache = combined ? kIOMapWriteCombineCache : kIOMapCopybackCache;
	const UInt64 made = mach_absolute_time();
	IOMemoryMap *map =
	    from->createMappingInTask(kernel_task, 0, kIOMapAnywhere | cache, s.offset, s.length);
	if (!map)
		return false;
	const UInt64 mapped = mach_absolute_time();
	bzero(reinterpret_cast<void *>(map->getVirtualAddress()), static_cast<size_t>(s.length));
#if defined(__x86_64__)
	if (combined)
		__builtin_ia32_sfence();
#endif
	const UInt64 stored = mach_absolute_time();
	map->release();
	*mapNs += nanosSince(made, mapped) + nanosSince(stored, mach_absolute_time());
	*storeNs += nanosSince(mapped, stored);
	return true;
}

UInt64 loadHeader64(const volatile UInt8 *header, UInt32 field)
{
	return __atomic_load_n(reinterpret_cast<const volatile UInt64 *>(header + field),
	                       __ATOMIC_ACQUIRE);
}

void queueInterruptHook(OSObject *target)
{
	if (RgfxAccelerator *accel = OSDynamicCast(RgfxAccelerator, target))
		accel->queueInterrupt();
}

// At primary interrupt context: the target is the accelerator whose watchQueue set the hook.
void queueFilterHook(OSObject *target)
{
	static_cast<RgfxAccelerator *>(target)->queueFilter();
}

bool reapDormant(bool aging = false);
void nameAgedClients(RgfxAccelerator *accel);
void noteDormant();
void noteReserve();
void noteReleases();
void noteZeroing();
void unwire(void *pages);
bool soleHolderAlone(IOMemoryDescriptor *md, UInt64 length);
bool releaseAnswered(OSObject *, UInt64 seqno, UInt32 status);

// The releases in flight (RgfxReleaseTable.hpp), made at the first context's open, under
// releaseLock, which the work loop takes to hand an answer over; and the timer that runs the
// worker once the oldest release waited kReleaseAnswerMs.
IOLock *releaseLock = nullptr;
RgfxReleaseTable releaseTable = {nullptr, 0, 0};
thread_call_t releaseTimer = nullptr;
// The thread call that names deferred blocks' pages before their releases (nameReleases).
thread_call_t namingCall = nullptr;
// The dormant blocks' age (kRgfxDormantAgeMs) in mach_absolute_time's units, set at the first
// context's open. Under contextLock: the timer that runs the release worker at the next dormant
// block's age, armed for `ageArmedAt` (0 where it waits for none, or its time passed: armAge), and
// the block let go for its age whose release copies its cache into its pages, by its offset, while
// its release is in flight (`agePace`, 0 while none is): the next such let-go waits for its answer
// (finishRelease), so the copies a close's dormant blocks owe come one after another, not as one
// burst beside the frames.
UInt64 dormantAge = 0;
thread_call_t ageTimer = nullptr;
UInt64 ageArmedAt = 0;
UInt64 agePace = 0;
// A diagnostic, under contextLock: the dormant blocks let go for their age with clients of their
// surfaces left, kAgedNamed a kDormantLogMs at most, each surface retained (the release worker's
// sample of them, ageDormant), whose processes the worker names (nameAgedClients).
struct AgedClient {
	OSObject *surface;
	uint32_t surfaceId;
	UInt64 bytes;
	bool deferred;
	bool written;
};
constexpr UInt32 kAgedNamed = 8;
AgedClient agedClients[kAgedNamed] = {};
UInt32 agedClientCount = 0;
UInt32 agedNamedCount = 0;
UInt64 agedNamedAt = 0;
bool releaseHooked = false;

// The closes in flight (RgfxCloseTable.hpp), under releaseLock: their answers come through the
// same hook as the releases'. Its entries' addresses are their late holdings' owners, so it is
// never moved.
RgfxCloseEntry closeEntries[kMaxCloses] = {};
RgfxCloseTable closeTable = {closeEntries, kMaxCloses};

// The framebuffer's work loop hands this worker's hook each COMPLETE no lifecycle waiter takes:
// named once, before the first release or close is posted.
void hookAnswers(RgfxAccelerator *accel)
{
	if (__atomic_load_n(&releaseHooked, __ATOMIC_ACQUIRE))
		return;
	if (ReimsGraphics *fb = accel->copyFramebuffer()) {
		fb->setReleaseAnswer(accel, &releaseAnswered);
		fb->release();
		__atomic_store_n(&releaseHooked, true, __ATOMIC_RELEASE);
	}
}

// The framebuffer's work loop hands each COMPLETE no lifecycle waiter takes here first: an
// answer to a release in flight is recorded, and the worker runs to retire it; an answer to a
// close wakes its waiting thread, or, late, runs the worker to let go of what it held.
bool releaseAnswered(OSObject *, UInt64 seqno, UInt32 status)
{
	IOLock *lock = __atomic_load_n(&releaseLock, __ATOMIC_ACQUIRE);
	if (!lock)
		return false;
	IOLockLock(lock);
	bool mine = rgfxReleaseAnswer(releaseTable, seqno, status);
	const bool close = !mine && rgfxCloseAnswer(closeTable, seqno, status);
	if (close)
		IOLockWakeup(lock, &closeTable, false);
	IOLockUnlock(lock);
	if (mine || close)
		thread_call_enter(releaseCall);
	return mine || close;
}

void releaseTimerFired(thread_call_param_t, thread_call_param_t)
{
	thread_call_enter(releaseCall);
}

// The age timer's call: the time it was armed for came, so the worker's run lets go of the
// blocks aged and arms it again (armAge), for the next.
void ageTimerFired(thread_call_param_t, thread_call_param_t)
{
	IOLockLock(contextLock);
	ageArmedAt = 0;
	IOLockUnlock(contextLock);
	thread_call_enter(releaseCall);
}

// A release done with: answered OK, the block goes out again; refused, or never posted, it is
// kept until a context close posts it again (rgfxBlockReleased). A release not answered in time
// never comes here before its answer (retireReleases).
void finishRelease(const RgfxReleaseEntry &e, bool answered)
{
	const bool ok = answered && e.status == RGFX_STATUS_OK;
	IOLockLock(contextLock);
	// Answered OK, a cached block's pages hold its cache: its surface's locks go on, and its
	// surface and the surface's wire are let go, before the block can be anyone else's. A kept
	// block's surface keeps them, its locks waiting, for the release posted again: the device
	// copies the cache into the pages at that release's answer. Only while the block is still
	// this release's, as it is until this answer (rgfxBlockFreeOwner keeps a releasing block past
	// its owner's close), and not another block's at its offset, whose own release holds its
	// surface. What it held goes out of the lock.
	RgfxReleasedSurface gone = {};
	if (ok && rgfxBlockReleasingAt(blockTable, e.offset, e.serial))
		rgfxSurfaceCacheReleased(e.offset, &gone);
	if (e.flags & RGFX_BLOCK_RELEASE_NO_CLIENT) {
		dormantStats.unread++;
		dormantStats.unreadWritten += e.written;
		dormantStats.changes++;
	}
	if (e.flags & RGFX_BLOCK_RELEASE_UNHELD) {
		dormantStats.unheld++;
		dormantStats.unheldWritten += e.written;
		dormantStats.changes++;
	}
	void *wired = nullptr;
	rgfxBlockReleased(blockTable, e.offset, e.serial, ok, &wired);
	rgfxLatencyAdd(releaseStats.latency, nanosSince(e.freedAt, mach_absolute_time()));
	releaseStats.kept += !ok;
	// The release of a block let go for its age that copies is done with, answered or not: the
	// next such let-go may go, on the worker's next run.
	const bool paced = agePace && agePace == e.offset;
	if (paced)
		agePace = 0;
	// A new block waiting for the region's room looks again.
	IOLockWakeup(contextLock, &surfaceTable, false);
	IOLockUnlock(contextLock);
	if (paced)
		thread_call_enter(releaseCall);
	// The device no longer maps an in-place block's pages once it has answered OK: unwire them,
	// and let go of its surface, out of the lock.
	rgfxSurfaceCacheLetGo(gone);
	unwire(wired);
	if (!ok)
		IOLog("RgfxAccelerator: context %u's block 0x%llx (0x%llx bytes) is kept: %s\n",
		      e.context, e.offset, e.size,
		      answered ? "the device refused its release" : "its release was not posted");
}

// Retires every release answered. One waiting past kReleaseAnswerMs is logged, once, and stays in
// flight: the device may still run a buffer over its block or copy its surface's cache into the
// surface's pages, so its block, its wired pages, its surface and the surface's wire stay the
// device's until the answer, which retires it as any other.
void retireReleases()
{
	uint64_t timeout = 0;
	nanoseconds_to_absolutetime(static_cast<uint64_t>(kReleaseAnswerMs) * 1000000ull, &timeout);
	for (;;) {
		RgfxReleaseEntry e;
		bool answered = false;
		IOLockLock(releaseLock);
		const bool any =
		    rgfxReleaseTakeDone(releaseTable, mach_absolute_time(), timeout, &e, &answered);
		IOLockUnlock(releaseLock);
		if (!any)
			return;
		if (answered) {
			finishRelease(e, true);
			continue;
		}
		IOLockLock(contextLock);
		releaseStats.late++;
		IOLockUnlock(contextLock);
		IOLog("RgfxAccelerator: context %u's block 0x%llx (0x%llx bytes): its release is not "
		      "answered after %u ms: the block, its pages and its surface stay the device's until "
		      "it is\n",
		      e.context, e.offset, e.size, kReleaseAnswerMs);
	}
}

// Lets go of what each late close answered held, its token's, as the closing thread lets go of a
// close answered in time (RgfxAcceleratorUserClient::releaseContext): answered OK, the device
// holds nothing of the context, so its resource-id chunks, its blocks (their wired pages
// unwired) and its holds of shared blocks go, its units are given back, and the releases it
// refused are posted again; refused, they are kept from use for good.
void retireCloses(RgfxAccelerator *accel)
{
	for (;;) {
		uint32_t at = 0;
		IOLockLock(releaseLock);
		const bool any = rgfxCloseTakeLate(closeTable, &at);
		const RgfxCloseEntry c = any ? closeTable.entries[at] : RgfxCloseEntry{};
		IOLockUnlock(releaseLock);
		if (!any)
			return;
		const void *token = rgfxCloseToken(closeTable, at);
		const bool ok = c.status == RGFX_STATUS_OK;
		if (ok) {
			accel->freeIdChunks(token);
			accel->freeBlocks(token);
			accel->dropSurfaceBlocks(token, true);
			IOLockLock(contextLock);
			rgfxContextSlotsGive(slots, c.firstUnit, c.units);
			IOLockUnlock(contextLock);
			accel->retryRefusedBlocks();
		} else {
			accel->keepIdChunks(token);
			accel->keepBlocks(token);
			accel->dropSurfaceBlocks(token, false);
		}
		IOLockLock(releaseLock);
		rgfxCloseRetired(closeTable, at);
		IOLockUnlock(releaseLock);
		IOLog("RgfxAccelerator: context %u's late close was answered (status %u): what it held is "
		      "%s\n",
		      c.context, c.status, ok ? "let go" : "kept from use for good");
	}
}

// The naming thread call (THREAD_CALL_OPTIONS_ONCE, one at a time): names the pages of each
// deferred block the release worker handed it (kRgfxReleaseNaming), one after another, waiting
// for the host's answer, or for a lock's naming in flight (rgfxSurfaceCacheReleaseAttach), and
// hands each back to the release worker to post (kRgfxReleaseNamed). The release worker goes on
// with the other releases meanwhile.
void nameReleases(thread_call_param_t accelerator, thread_call_param_t)
{
	RgfxAccelerator *accel = static_cast<RgfxAccelerator *>(accelerator);
	for (;;) {
		IOLockLock(releaseLock);
		const int32_t at = rgfxReleaseNextNaming(releaseTable);
		const UInt64 offset = at >= 0 ? releaseTable.entries[at].offset : 0;
		IOLockUnlock(releaseLock);
		if (at < 0)
			return;
		RgfxReleaseAttach attach = kRgfxReleaseAsIs;
		bool written = false;
		if (OSObject *surface = rgfxSurfaceCacheReleasingSurface(offset, &written)) {
			attach = rgfxSurfaceCacheReleaseAttach(accel, offset, surface, true);
			surface->release();
		}
		IOLockLock(releaseLock);
		rgfxReleaseNamed(releaseTable, static_cast<uint32_t>(at), attach);
		IOLockUnlock(releaseLock);
		thread_call_enter(releaseCall);
	}
}

// The release thread call, the guest's one (THREAD_CALL_OPTIONS_ONCE): lets go of the dormant
// blocks their surfaces asked to go, and of those aged (reapDormant), for which the age timer runs
// it; retires the releases answered; then posts each freed block's BLOCK_RELEASE on ring 0,
// kReleaseBatch at a time with one doorbell at most, as many as the release table holds, and
// returns without waiting for any answer. The work loop hands each answer to its entry, in whatever
// order the contexts' command buffers finish, and runs the worker again to retire it; so releases
// posted together wait for their contexts' drains at once, and a slow context holds back only its
// own blocks. A deferred block whose pages are named first goes to the naming worker
// (nameReleases), which waits for the host's answers, and is posted once named. Never on the
// freeing thread.
void releaseFreedBlocks(thread_call_param_t accelerator, thread_call_param_t)
{
	RgfxAccelerator *accel = static_cast<RgfxAccelerator *>(accelerator);
	IOLockLock(contextLock);
	if (const UInt64 asked = __atomic_exchange_n(&releaseStats.reapAskedAt, 0, __ATOMIC_RELAXED))
		rgfxLatencyAdd(releaseStats.reapWait, nanosSince(asked, mach_absolute_time()));
	reapDormant(true);
	IOLockUnlock(contextLock);
	releaseLetGo();
	// Before any release is posted, so the sample's own retains of surfaces are gone by then.
	nameAgedClients(accel);
	noteDormant();
	// The answers come through the framebuffer's work loop: name this worker's hook there
	// before the first release is posted.
	hookAnswers(accel);
	// The late closes answered let go of what they held, whose releases this run posts.
	retireCloses(accel);
	retireReleases();
	for (bool more = true; more;) {
		// A batch of freed blocks, each in an entry of its own, posted at once.
		RgfxBlockRelease batch[kReleaseBatch];
		UInt64 *seqnos[kReleaseBatch];
		int32_t at[kReleaseBatch];
		UInt32 n = 0;
		while (n < kReleaseBatch) {
			// A release whose block's pages the naming worker named goes first, its entry
			// holding its block; else a new entry, for the next freed block.
			IOLockLock(releaseLock);
			const int32_t named = rgfxReleaseTakeNamed(releaseTable);
			at[n] = named >= 0 ? named : rgfxReleaseReserve(releaseTable);
			RgfxBlock block = {};
			RgfxReleaseAttach attach = kRgfxReleaseAsIs;
			if (named >= 0) {
				const RgfxReleaseEntry &was = releaseTable.entries[named];
				block.offset = was.offset;
				block.serial = was.serial;
				block.size = was.size;
				block.context = was.context;
				block.freedAt = was.freedAt;
				attach = static_cast<RgfxReleaseAttach>(was.attach);
			}
			IOLockUnlock(releaseLock);
			// A full table: the answers that free its entries run the worker again.
			if (at[n] < 0) {
				more = false;
				break;
			}
			RgfxReleaseEntry &e = releaseTable.entries[at[n]];
			if (named < 0) {
				IOLockLock(contextLock);
				const bool any = rgfxBlockNextRelease(blockTable, &block);
				IOLockUnlock(contextLock);
				if (!any) {
					IOLockLock(releaseLock);
					rgfxReleaseUnposted(releaseTable, static_cast<uint32_t>(at[n]));
					IOLockUnlock(releaseLock);
					more = false;
					break;
				}
			}
			RgfxBlockRelease &release = batch[n];
			release = {};
			release.context = block.context;
			release.offset = block.offset;
			release.size = block.size;
			// A cached surface with no client left is flagged so (RGFX_BLOCK_RELEASE_NO_CLIENT),
			// which the host only counts: it copies the cache into the pages all the same, as a
			// mach port or an XPC object holds a surface with no client, and the process that
			// looks it up from one reads its pages. One that nothing but the kext holds besides
			// is flagged RGFX_BLOCK_RELEASE_UNHELD: no process can read its pages, and the host
			// drops a written cache uncopied (rgfxCacheReleaseFlags). Its counts are read here,
			// out of every lock, as at a block's sleep.
			// A deferred block's pages are named first, where the GPU wrote it and its surface
			// lives on, so the release copies the cache into them (rgfxCacheReleaseNext): by
			// the naming worker, whose waits for the host's answers this thread does not share.
			bool written = false;
			if (OSObject *surface = rgfxSurfaceCacheReleasingSurface(block.offset, &written)) {
				if (named < 0)
					attach = rgfxSurfaceCacheReleaseAttach(accel, block.offset, surface, false);
				if (attach == kRgfxReleaseNameFirst) {
					surface->release();
					IOLockLock(releaseLock);
					e.offset = block.offset;
					e.serial = block.serial;
					e.size = block.size;
					e.context = block.context;
					e.freedAt = block.freedAt;
					rgfxReleaseNaming(releaseTable, static_cast<uint32_t>(at[n]));
					IOLockUnlock(releaseLock);
					thread_call_enter(namingCall);
					continue;
				}
				// Pages the host may map now: the block holds them wired until its release is
				// answered OK, whatever becomes of its cache.
				IOMemoryDescriptor *hostPages = attach == kRgfxReleaseAttached
				                                    ? rgfxSurfaceCacheHostPages(nullptr, block.offset)
				                                    : nullptr;
				IOLockLock(contextLock);
				if (attach == kRgfxReleaseUnattached) {
					dormantStats.deferredUnattached++;
					dormantStats.changes++;
				}
				const bool held =
				    !hostPages || rgfxBlockSetWired(blockTable, block.offset, hostPages);
				IOLockUnlock(contextLock);
				if (!held)
					IOLog("RgfxAccelerator: the deferred block 0x%llx's pages stay wired for "
					      "good: its block is gone\n",
					      block.offset);
				release.flags = rgfxSurfaceCacheReleaseFlags(block.offset, surface);
				surface->release();
			}
			IOLockLock(releaseLock);
			e.offset = block.offset;
			e.serial = block.serial;
			e.size = block.size;
			e.context = block.context;
			e.freedAt = block.freedAt;
			e.flags = release.flags;
			e.written = written;
			IOLockUnlock(releaseLock);
			seqnos[n] = &e.seqno;
			n++;
		}
		if (!n)
			break;
		// Each post writes its entry's seqno before the message is published, so an answer that
		// comes before the entry is marked posted finds it.
		UInt32 posted = 0;
		ReimsGraphics *fb = accel->copyFramebuffer();
		if (fb) {
			fb->postReleases(batch, n, seqnos, &posted);
			fb->release();
		}
		RgfxReleaseEntry unposted[kReleaseBatch];
		IOLockLock(releaseLock);
		const uint64_t now = mach_absolute_time();
		for (UInt32 i = 0; i < n; i++) {
			if (i < posted) {
				rgfxReleasePosted(releaseTable, static_cast<uint32_t>(at[i]), now);
			} else {
				unposted[i] = releaseTable.entries[at[i]];
				rgfxReleaseUnposted(releaseTable, static_cast<uint32_t>(at[i]));
			}
		}
		const UInt32 inFlight = releaseTable.inFlight;
		IOLockUnlock(releaseLock);
		IOLockLock(contextLock);
		if (inFlight > releaseStats.inFlightMost)
			releaseStats.inFlightMost = inFlight;
		IOLockUnlock(contextLock);
		// Not on the ring: kept, as an unanswered release is.
		for (UInt32 i = posted; i < n; i++)
			finishRelease(unposted[i], false);
		if (posted < n)
			more = false;
	}
	// What was answered while this run posted, and a timer for the oldest still waiting.
	retireReleases();
	IOLockLock(releaseLock);
	const uint64_t oldest = rgfxReleaseOldest(releaseTable);
	IOLockUnlock(releaseLock);
	if (oldest) {
		uint64_t timeout = 0;
		nanoseconds_to_absolutetime(static_cast<uint64_t>(kReleaseAnswerMs) * 1000000ull,
		                            &timeout);
		thread_call_enter_delayed(releaseTimer, oldest + timeout);
	}
	noteReleases();
	noteZeroing();
}
} // namespace

bool RgfxAccelerator::startContexts()
{
	if (__atomic_load_n(&contextLock, __ATOMIC_ACQUIRE))
		return true;
	if (regionSize <= RGFX_CONTEXT_ALLOCATIONS_OFFSET + RGFX_CURSOR_SPAN) {
		IOLog("RgfxAccelerator: no contexts (region 0x%llx bytes)\n", regionSize);
		return false;
	}
	// The first opener makes the state; one that loses the race frees what it made.
	IOLock *lock = IOLockAlloc();
	IOLock *wlock = IOLockAlloc();
	IOSimpleLock *flock = IOSimpleLockAlloc();
	RgfxBlock *table = static_cast<RgfxBlock *>(IOMalloc(sizeof(RgfxBlock) * kMaxBlocks));
	RgfxWatchedRing *rings =
	    static_cast<RgfxWatchedRing *>(IOMalloc(sizeof(RgfxWatchedRing) * kMaxWatched));
	// The accelerator is the device's one, for the kernel's life, as the state is.
	// One release worker at a time: THREAD_CALL_OPTIONS_ONCE coalesces an enter made while it
	// runs into a single re-run after it returns, so a storm of frees cannot fan it out into a
	// thread per free (each of which blocks in postLifecycle for its answer, until the 'high'
	// group's 500-thread cap panics). It runs at kernel priority, below the framebuffer work
	// loop that delivers its answers, so the one worker never starves that loop.
	thread_call_t call = thread_call_allocate_with_options(
	    releaseFreedBlocks, this, THREAD_CALL_PRIORITY_KERNEL, THREAD_CALL_OPTIONS_ONCE);
	// One naming worker at a time, as the release worker, for the releases that name pages.
	thread_call_t naming = thread_call_allocate_with_options(
	    nameReleases, this, THREAD_CALL_PRIORITY_KERNEL, THREAD_CALL_OPTIONS_ONCE);
	// The releases in flight, and the timer for the oldest's answer.
	IOLock *rlock = IOLockAlloc();
	RgfxReleaseEntry *releases =
	    static_cast<RgfxReleaseEntry *>(IOMalloc(sizeof(RgfxReleaseEntry) * kMaxReleases));
	thread_call_t timer = thread_call_allocate(releaseTimerFired, nullptr);
	// The timer for the next dormant block's age, which runs the worker.
	thread_call_t aging = thread_call_allocate(ageTimerFired, nullptr);
	// The region's bytes again for the write-combined spans (copyWriteCombinedRegion), with no
	// effect on the region's own descriptor; a context goes on without it. None where the region's
	// write-combined mappings are not ordinary memory (RgfxRegionMapping.hpp): every span is then
	// mapped write-back.
	IODeviceMemory *combined =
	    kRgfxRegionWriteCombines && region
	        ? IODeviceMemory::withRange(region->getPhysicalSegment(0, nullptr, kIOMemoryMapperNone),
	                                    region->getLength())
	        : nullptr;
	RgfxBlock *expected = nullptr;
	if (lock && wlock && flock && table && rings && call && naming && rlock && releases && timer &&
	    aging &&
	    __atomic_compare_exchange_n(&blocks, &expected, table, false, __ATOMIC_ACQ_REL,
	                                __ATOMIC_ACQUIRE)) {
		bzero(table, sizeof(RgfxBlock) * kMaxBlocks);
		bzero(rings, sizeof(RgfxWatchedRing) * kMaxWatched);
		bzero(releases, sizeof(RgfxReleaseEntry) * kMaxReleases);
		watched = rings;
		filterLock = flock;
		watchLock = wlock;
		releaseCall = call;
		namingCall = naming;
		releaseTable = {releases, kMaxReleases, 0};
		releaseTimer = timer;
		ageTimer = aging;
		state.combinedRegion = combined;
		__atomic_store_n(&releaseLock, rlock, __ATOMIC_RELEASE);
		const UInt32 features = readRegister(RGFX_REG_FEATURES_LO);
		surfacePages = (features & RGFX_FEATURE_SURFACE_PAGES) != 0;
#if RGFX_GUEST_ARM64
		pages16k = (featureWord() & RGFX_FEATURE_PAGES_16K) != 0;
#endif
		// A host offers SURFACE_CACHE_REFUSED only where it offers no SURFACE_CACHE: its GPU
		// shares the CPU's memory.
		askCache = surfacePages && (features & RGFX_FEATURE_SURFACE_CACHE) == 0 &&
		           (featureWord() & RGFX_FEATURE_SURFACE_CACHE_REFUSED) != 0;
		surfaceCache = surfacePages && ((features & RGFX_FEATURE_SURFACE_CACHE) != 0 || askCache);
		cacheEvery = surfaceCache && (featureWord() & RGFX_FEATURE_SURFACE_CACHE_EVERY) != 0;
		rgfxSurfaceCacheSetGrows(cacheEvery);
		// Deferred blocks where the kext took the feature, its asking form where the device
		// answers which surfaces need a cache, and no mapper device maps the surfaces' pages.
		const uint64_t defers =
		    askCache ? RGFX_FEATURE_SURFACE_DEFERRED_ASK : RGFX_FEATURE_SURFACE_DEFERRED;
		if (surfaceCache && (featureWord() & defers)) {
			OSDictionary *matching = IOService::serviceMatching(kSurfaceMapperService);
			IOService *mapper = matching ? IOService::copyMatchingService(matching) : nullptr;
			OSSafeReleaseNULL(matching);
			if (!mapper) {
				deferredBudget =
				    (static_cast<UInt64>(readRegister(RGFX_REG_DEFERRED_BUDGET_HI)) << 32) |
				    readRegister(RGFX_REG_DEFERRED_BUDGET_LO);
				deferCarries = deferredBudget != 0 &&
				               (featureWord() & RGFX_FEATURE_SURFACE_DEFERRED_CARRY) != 0;
			} else
				IOLog("RgfxAccelerator: the guest's IOSurfaces have a mapper device (%s): no "
				      "block is deferred\n",
				      kSurfaceMapperService);
			OSSafeReleaseNULL(mapper);
		}
		blocksStart = RGFX_CONTEXT_ALLOCATIONS_OFFSET;
		blocksEnd = (regionSize - RGFX_CURSOR_SPAN) & ~(kPage - 1);
		// A reserve of no more than a quarter of the blocks' room, on a region too small for it.
		const UInt64 quarter = ((blocksEnd - blocksStart) / 4) & ~(kPage - 1);
		blockTable.reserveBytes =
		    kWindowServerReserveBytes < quarter ? kWindowServerReserveBytes : quarter;
		blockTable.reserveEntries = kWindowServerReserveEntries;
		uint64_t memory = 0;
		size_t length = sizeof(memory);
		if (sysctlbyname("hw.memsize", &memory, &length, nullptr, 0) != 0 || !memory)
			memory = kDormantMemoryUnknown;
		dormantMaxBytes = memory / 8;
		nanoseconds_to_absolutetime(static_cast<uint64_t>(kRgfxDormantAgeMs) * 1000000ull,
		                            &dormantAge);
		// A context's units hold twice the device's largest buffer (RgfxContextSlots.hpp).
		UInt64 maxBufferLength = 0;
		const void *info = nullptr;
		if (IOMemoryMap *map = mapDeviceInfo(sizeof(RgfxDeviceInfo), &info)) {
			const RgfxDeviceInfo *d = static_cast<const RgfxDeviceInfo *>(info);
			if (d->version == RGFX_DEVICE_INFO_VERSION)
				maxBufferLength = d->sizes[RGFX_DEVICE_INFO_MAX_BUFFER_LENGTH];
			map->release();
		}
		contextUnits = rgfxContextUnitsFor(maxBufferLength);
		// The doorbell pages, where the kext took them and BAR 4 is mapped: every context rings
		// through the kext's doorbell call otherwise, as before the pages.
		if (featureWord() & RGFX_FEATURE_DOORBELL_PAGES) {
			IODeviceMemory *bar = pci->getDeviceMemoryWithRegister(kIOPCIConfigBaseAddress4);
			IOMemoryMap *map = bar && bar->getLength() >= RGFX_DOORBELLS_SIZE
			                       ? pci->mapDeviceMemoryWithRegister(kIOPCIConfigBaseAddress4)
			                       : nullptr;
			if (map) {
				bar->retain();
				rgfxDoorbellPagesInit(state.doorbellPages);
				state.doorbells = bar;
				state.doorbellMap = map;
				state.doorbellBase = reinterpret_cast<volatile UInt8 *>(map->getVirtualAddress());
			} else
				IOLog("RgfxAccelerator: the device offers doorbell pages, but BAR 4 is %s: "
				      "every context rings through the kext\n",
				      !bar ? "not there" : bar->getLength() < RGFX_DOORBELLS_SIZE ? "too small"
				                                                                 : "not mapped");
		}
		keepZeroMaps(region);
		__atomic_store_n(&contextLock, lock, __ATOMIC_RELEASE);
		IOLog("RgfxAccelerator: blocks 0x%llx-0x%llx, %u contexts of %u GiB of GPU addresses "
		      "(maxBufferLength %llu MiB), surfaces %s, deferred blocks' budget %llu MiB; "
		      "WindowServer's reserve: %u of %u entries, %llu MiB\n",
		      blocksStart, blocksEnd, kRgfxContextUnits / contextUnits,
		      static_cast<UInt32>((contextUnits * RGFX_CONTEXT_VA_UNIT) >> 30),
		      maxBufferLength >> 20, surfacePages ? "in place" : "copied", deferredBudget >> 20,
		      blockTable.reserveEntries, kMaxBlocks, blockTable.reserveBytes >> 20);
		return true;
	}
	if (lock)
		IOLockFree(lock);
	if (wlock)
		IOLockFree(wlock);
	if (flock)
		IOSimpleLockFree(flock);
	if (table)
		IOFree(table, sizeof(RgfxBlock) * kMaxBlocks);
	if (rings)
		IOFree(rings, sizeof(RgfxWatchedRing) * kMaxWatched);
	if (call)
		thread_call_free(call);
	if (naming)
		thread_call_free(naming);
	if (rlock)
		IOLockFree(rlock);
	if (releases)
		IOFree(releases, sizeof(RgfxReleaseEntry) * kMaxReleases);
	if (timer)
		thread_call_free(timer);
	if (aging)
		thread_call_free(aging);
	OSSafeReleaseNULL(combined);
	// Another opener is making it: wait for it to publish.
	while (expected && !__atomic_load_n(&contextLock, __ATOMIC_ACQUIRE))
		IOSleep(1);
	return __atomic_load_n(&contextLock, __ATOMIC_ACQUIRE) != nullptr;
}

IODeviceMemory *RgfxAccelerator::copyWriteCombinedRegion() const
{
	// Set before contextLock is published, and kept for the kernel's life.
	IODeviceMemory *combined =
	    __atomic_load_n(&contextLock, __ATOMIC_ACQUIRE) ? state.combinedRegion : nullptr;
	if (combined)
		combined->retain();
	return combined;
}

// MARK: - The Shared pool

IODeviceMemory *RgfxAccelerator::poolMemory()
{
	IODeviceMemory *pool = __atomic_load_n(&state.pool, __ATOMIC_ACQUIRE);
	if (pool || !(featureWord() & RGFX_FEATURE_POOL))
		return pool;
	// The range reads the same for the device's life (POOL_BASE_LO).
	const UInt64 base = (static_cast<UInt64>(readRegister(RGFX_REG_POOL_BASE_HI)) << 32) |
	                    readRegister(RGFX_REG_POOL_BASE_LO);
	const UInt64 length = (static_cast<UInt64>(readRegister(RGFX_REG_POOL_LENGTH_HI)) << 32) |
	                      readRegister(RGFX_REG_POOL_LENGTH_LO);
	if (!base || !length || length % RGFX_POOL_BLOCK_ALIGN || base > UINT64_MAX - length)
		return nullptr;
	IODeviceMemory *made = IODeviceMemory::withRange(base, length);
	if (!made)
		return nullptr;
	// One descriptor for the kernel's life: another caller's, where it made one first.
	IODeviceMemory *expected = nullptr;
	if (!__atomic_compare_exchange_n(&state.pool, &expected, made, false, __ATOMIC_ACQ_REL,
	                                 __ATOMIC_ACQUIRE)) {
		made->release();
		return expected;
	}
	__atomic_store_n(&state.poolLength, length, __ATOMIC_RELEASE);
	IOLog("RgfxAccelerator: the Shared pool: 0x%llx bytes at 0x%llx\n", length, base);
	return made;
}

IOReturn RgfxAccelerator::takePoolBlock(UInt32 context, task_t task, UInt64 length,
                                        RgfxHeldPoolBlock *block, UInt64 *gpuAddress)
{
	*block = {};
	*gpuAddress = 0;
	IODeviceMemory *pool = poolMemory();
	if (!pool)
		return kIOReturnUnsupported;
	if (!rgfxPoolTakeLength(length))
		return kIOReturnBadArgument;
	RgfxPoolTake take = {};
	take.context = context;
	take.length = length;
	RgfxPoolBlock answer = {};
	UInt32 answered = 0;
	// The host answers each take of an open context, and the context's close waits for this ask
	// (RgfxAskGate.hpp): a take that waits for the host to add memory to the pool waits as long.
	IOReturn r = postLifecycle(RGFX_CMD_POOL_TAKE, &take, sizeof(take), RGFX_EVT_POOL_BLOCK,
	                           &answer, sizeof(answer), &answered, nullptr,
	                           ReimsGraphics::kLifecycleNoDeadline);
	if (r != kIOReturnSuccess)
		return r;
	if (!rgfxPoolAnswerWhole(answered)) {
		IOLog("RgfxAccelerator: context %u's pool take of 0x%llx bytes: an answer of %u bytes\n",
		      context, length, answered);
		return kIOReturnInternalError;
	}
	switch (answer.status) {
	case RGFX_STATUS_OK:
		break;
	case RGFX_STATUS_REFUSED:
		return kIOReturnNoMemory;
	case RGFX_STATUS_INVALID_ARGUMENT:
		return kIOReturnBadArgument;
	default:
		IOLog("RgfxAccelerator: context %u's pool take of 0x%llx bytes: status %u\n", context,
		      length, answer.status);
		return kIOReturnError;
	}
	const UInt64 poolLength = __atomic_load_n(&state.poolLength, __ATOMIC_ACQUIRE);
	if (!rgfxPoolAnswerFits(poolLength, length, answer.pool_offset, answer.length)) {
		IOLog("RgfxAccelerator: context %u's pool take of 0x%llx bytes: answered 0x%llx bytes at "
		      "0x%llx of a pool of 0x%llx bytes, which it does not map\n",
		      context, length, answer.length, answer.pool_offset, poolLength);
		return kIOReturnInternalError;
	}
	// The block's own range in the process, write-back as the device reads the pool. The kernel
	// maps no byte of it: the host zeroed it at the take.
	IOMemoryMap *map = pool->createMappingInTask(task, 0, kIOMapAnywhere | kIOMapCopybackCache,
	                                             answer.pool_offset, answer.length);
	if (!map) {
		IOLog("RgfxAccelerator: context %u's pool block of 0x%llx bytes at 0x%llx: the process "
		      "got no mapping of it, and it is given back\n",
		      context, answer.length, answer.pool_offset);
		givePoolBlock(context, answer.pool_offset, answer.length);
		return kIOReturnNoMemory;
	}
	*block = {answer.pool_offset, answer.length, map};
	// The host's GPU address for it, where the kext took RGFX_FEATURE_POOL_ADDRESSES: 0 otherwise,
	// as the host answers then.
	if (featureWord() & RGFX_FEATURE_POOL_ADDRESSES)
		*gpuAddress = answer.gpu_address;
	return kIOReturnSuccess;
}

IOReturn RgfxAccelerator::givePoolBlock(UInt32 context, UInt64 offset, UInt64 length)
{
	RgfxPoolGive give = {};
	give.context = context;
	give.pool_offset = offset;
	give.length = length;
	// Its COMPLETE no thread waits for: the host takes the block back once the context's command
	// buffers committed before it have finished.
	return postLifecycle(RGFX_CMD_POOL_GIVE, &give, sizeof(give), 0, nullptr, 0, nullptr, nullptr,
	                     0);
}

IOReturn RgfxAccelerator::takePrivateBlock(UInt32 context, UInt64 length, UInt64 *gpuAddress,
                                           UInt64 *blockLength)
{
	*gpuAddress = 0;
	*blockLength = 0;
	if (!(featureWord() & RGFX_FEATURE_PRIVATE_BLOCKS))
		return kIOReturnUnsupported;
	if (!rgfxPrivateTakeLength(length))
		return kIOReturnBadArgument;
	RgfxPrivateTake take = {};
	take.context = context;
	take.length = length;
	RgfxPrivateBlock answer = {};
	UInt32 answered = 0;
	// The host answers each take of an open context, and the context's close waits for this ask
	// (RgfxAskGate.hpp), as a pool take's: one whose block waits for device memory waits as long.
	IOReturn r = postLifecycle(RGFX_CMD_PRIVATE_TAKE, &take, sizeof(take),
	                           RGFX_EVT_PRIVATE_BLOCK, &answer, sizeof(answer), &answered,
	                           nullptr, ReimsGraphics::kLifecycleNoDeadline);
	if (r != kIOReturnSuccess)
		return r;
	if (answered < sizeof(answer)) {
		IOLog("RgfxAccelerator: context %u's Private take of 0x%llx bytes: an answer of %u "
		      "bytes\n",
		      context, length, answered);
		return kIOReturnInternalError;
	}
	switch (answer.status) {
	case RGFX_STATUS_OK:
		break;
	case RGFX_STATUS_REFUSED:
		return kIOReturnNoMemory;
	case RGFX_STATUS_INVALID_ARGUMENT:
		return kIOReturnBadArgument;
	default:
		IOLog("RgfxAccelerator: context %u's Private take of 0x%llx bytes: status %u\n", context,
		      length, answer.status);
		return kIOReturnError;
	}
	if (!rgfxPrivateAnswerFits(length, answer.gpu_address, answer.length)) {
		IOLog("RgfxAccelerator: context %u's Private take of 0x%llx bytes: answered 0x%llx bytes "
		      "at 0x%llx, which is no block for it: it is given back\n",
		      context, length, answer.length, answer.gpu_address);
		givePrivateBlock(context, answer.gpu_address, answer.length);
		return kIOReturnInternalError;
	}
	*gpuAddress = answer.gpu_address;
	*blockLength = answer.length;
	return kIOReturnSuccess;
}

IOReturn RgfxAccelerator::givePrivateBlock(UInt32 context, UInt64 gpuAddress, UInt64 length)
{
	if (!(featureWord() & RGFX_FEATURE_PRIVATE_BLOCKS))
		return kIOReturnUnsupported;
	RgfxPrivateGive give = {};
	give.context = context;
	give.gpu_address = gpuAddress;
	give.length = length;
	// Its COMPLETE no thread waits for: the host takes the block back once the context's command
	// buffers committed before it have finished, or refuses it, and the context's close gives
	// back any block it kept.
	return postLifecycle(RGFX_CMD_PRIVATE_GIVE, &give, sizeof(give), 0, nullptr, 0, nullptr,
	                     nullptr, 0);
}

// MARK: - Doorbell pages

UInt32 RgfxAccelerator::openDoorbellPage(UInt32 context, task_t task, IOMemoryMap **map)
{
	*map = nullptr;
	// Set before contextLock is published, and kept for the kernel's life.
	IOLock *lock = __atomic_load_n(&contextLock, __ATOMIC_ACQUIRE);
	if (!lock || !state.doorbells)
		return kRgfxNoDoorbellPage;
	UInt32 page = kRgfxNoDoorbellPage;
	IOLockLock(lock);
	const bool taken = rgfxDoorbellPageTake(state.doorbellPages, context, &page);
	const UInt32 held = rgfxDoorbellPagesHeld(state.doorbellPages);
	IOLockUnlock(lock);
	if (!taken) {
		if (rgfxDoorbellPageContext(context))
			IOLog("RgfxAccelerator: context %u: every doorbell page is held (%u): it rings "
			      "through the kext\n",
			      context, held);
		return kRgfxNoDoorbellPage;
	}
	// Bound before the process can write it: the device takes the write before it returns.
	writeRegister(RGFX_REG_DOORBELL_PAGE_BIND, rgfxDoorbellPageBind(page, context));
	*map = state.doorbells->createMappingInTask(task, 0, kIOMapAnywhere | kIOMapInhibitCache,
	                                            rgfxDoorbellPageOffset(page),
	                                            RGFX_DOORBELL_PAGE_SIZE);
	if (!*map) {
		IOLog("RgfxAccelerator: context %u: doorbell page %u not mapped: it rings through the "
		      "kext\n",
		      context, page);
		closeDoorbellPage(page);
		return kRgfxNoDoorbellPage;
	}
	return page;
}

void RgfxAccelerator::closeDoorbellPage(UInt32 page)
{
	IOLock *lock = __atomic_load_n(&contextLock, __ATOMIC_ACQUIRE);
	if (!lock || page >= RGFX_DOORBELL_PAGES)
		return;
	// Unbound before it is given back: from here the device wakes no ring at it, and drops what
	// an alias of the process's mapping kept past its release writes there.
	writeRegister(RGFX_REG_DOORBELL_PAGE_BIND, rgfxDoorbellPageBind(page, 0));
	IOLockLock(lock);
	rgfxDoorbellPageFree(state.doorbellPages, page);
	IOLockUnlock(lock);
}

void RgfxAccelerator::ringDoorbellPage(UInt32 page, UInt32 ringId)
{
	// A page is given out only where the pages are mapped, which they stay for the kernel's life.
	if (page >= RGFX_DOORBELL_PAGES || !state.doorbellBase)
		return;
	rgfxRegisterWriteBarrier();
	rgfxRegisterWrite32(state.doorbellBase + rgfxDoorbellPageOffset(page), ringId);
}

// MARK: - Contexts

IOReturn RgfxAccelerator::openContext(UInt32 *context, bool oldSpan, bool windowServer,
                                     UInt32 *first, UInt32 *units)
{
	if (!startContexts())
		return kIOReturnNotReady;
	// The context's messages reach the device only through the framebuffer's rings: none opens
	// before it has started, as none could post a message or its close. The accelerator registers
	// only once it has ("The bundle", RgfxAccelerator.cpp), so this answers only a framebuffer
	// that stopped since.
	if (!framebufferStarted()) {
		IOLog("RgfxAccelerator: no context opened: the framebuffer has not started\n");
		return kIOReturnNotReady;
	}
	IOLockLock(contextLock);
	const UInt32 want = oldSpan ? kRgfxContextOldSpanUnits : contextUnits;
	UInt32 at = 0;
	if (!rgfxContextSlotsTake(slots, want, windowServer, &at)) {
		const UInt32 free = slots.freeUnits;
		IOLockUnlock(contextLock);
		IOLog("RgfxAccelerator: every context slot is held (%u of %u units free, %u asked)\n",
		      free, kRgfxContextUnits, want);
		return kIOReturnNoResources;
	}
	*first = at;
	*units = want;
	*context = nextContext++;
	IOLockUnlock(contextLock);
	IOLog("RgfxAccelerator: context %u opened at unit %u (%u units)\n", *context, at, want);
	return kIOReturnSuccess;
}

RgfxAccelerator::CloseAnswer RgfxAccelerator::closeContext(UInt32 context, UInt32 first,
                                                           UInt32 units, int32_t *late)
{
	// The device ends the context's queues and drops its objects, and answers once the
	// context's command buffers have finished; the caller has closed its queues already, and
	// lets go of what the context held only once the close is answered OK.
	*late = -1;
	if (!startContexts())
		return kCloseRefused;
	// With no framebuffer started there is nothing to post the close through, and nothing of the
	// context to close: the context opened while one had started (openContext), and its stop
	// resets the device on the way out, which drops every context's objects with no answer owed
	// (design.md, "Reset"). What the context held is given back as an answered close gives it.
	if (!framebufferStarted()) {
		IOLockLock(contextLock);
		rgfxContextSlotsGive(slots, first, units);
		IOLockUnlock(contextLock);
		IOLog("RgfxAccelerator: context %u closed with no framebuffer started, which the device "
		      "holds nothing of (unit %u, %u units)\n",
		      context, first, units);
		return kCloseAnswered;
	}
	RgfxContextClose close = {};
	close.context = context;
	// The close's entry is the answer's to find, its seqno written before the device sees the
	// close; with every entry taken, the close waits as any lifecycle message does, and one not
	// answered then keeps what the context held for good.
	hookAnswers(this);
	IOLockLock(releaseLock);
	const int32_t at = rgfxCloseReserve(closeTable, context, first, units);
	IOLockUnlock(releaseLock);
	IOReturn r = kIOReturnNotReady;
	uint32_t status = RGFX_STATUS_OK;
	bool inTime = false;
	if (at < 0) {
		RgfxComplete answer = {};
		UInt32 length = 0;
		r = postLifecycle(RGFX_CMD_CONTEXT_CLOSE, &close, sizeof(close), RGFX_EVT_COMPLETE,
		                  &answer, sizeof(answer), &length, nullptr, kCloseAnswerMs);
		inTime = r == kIOReturnSuccess && length >= sizeof(answer);
		status = inTime ? answer.status : 0;
	} else {
		ReimsGraphics *fb = copyFramebuffer();
		if (fb) {
			r = fb->postAnswered(RGFX_CMD_CONTEXT_CLOSE, &close, sizeof(close),
			                     &closeTable.entries[at].seqno);
			fb->release();
		}
		uint64_t deadline = 0;
		clock_interval_to_deadline(kCloseAnswerMs, kMillisecondScale, &deadline);
		IOLockLock(releaseLock);
		if (r != kIOReturnSuccess) {
			rgfxCloseUnposted(closeTable, static_cast<uint32_t>(at));
		} else {
			while (!rgfxCloseAnswered(closeTable, static_cast<uint32_t>(at))) {
				if (IOLockSleepDeadline(releaseLock, &closeTable, deadline, THREAD_UNINT) ==
				    THREAD_TIMED_OUT)
					break;
			}
			inTime = rgfxCloseInTime(closeTable, static_cast<uint32_t>(at), &status);
		}
		IOLockUnlock(releaseLock);
		if (r == kIOReturnSuccess && !inTime) {
			*late = at;
			IOLog("RgfxAccelerator: context %u: its close is not answered after %u ms: what it "
			      "held, its %u GPU address units from %u among it, stays the device's until it "
			      "is\n",
			      context, kCloseAnswerMs, units, first);
			return kCloseLate;
		}
	}
	const bool closed = inTime && status == RGFX_STATUS_OK;
	if (!closed) {
		IOLog("RgfxAccelerator: context %u: the device did not answer its close (0x%x, "
		      "status %u): what it held, its %u GPU address units from %u among it, is kept "
		      "from use for good\n",
		      context, r, status, units, first);
		return kCloseRefused;
	}
	IOLockLock(contextLock);
	rgfxContextSlotsGive(slots, first, units);
	IOLockUnlock(contextLock);
	IOLog("RgfxAccelerator: context %u closed (unit %u, %u units)\n", context, first, units);
	return kCloseAnswered;
}

void RgfxAccelerator::parkClose(const void *client, int32_t late)
{
	if (late < 0 || static_cast<uint32_t>(late) >= kMaxCloses || !contextLock)
		return;
	const void *token = rgfxCloseToken(closeTable, static_cast<uint32_t>(late));
	IOLockLock(contextLock);
	const uint32_t ids =
	    rgfxIdChunksHand(idChunkOwners, RGFX_RESOURCE_ID_SMALL_CHUNKS, client, token);
	const uint32_t held = rgfxBlockHand(blockTable, client, token);
	const uint32_t holds = rgfxSurfaceHand(surfaceTable, client, token);
	IOLockUnlock(contextLock);
	IOLockLock(releaseLock);
	const bool answered = rgfxClosePark(closeTable, static_cast<uint32_t>(late));
	const uint32_t pending = rgfxCloseLateCount(closeTable);
	IOLockUnlock(releaseLock);
	IOLog("RgfxAccelerator: context %u's late close holds %u blocks, %u holds of shared blocks "
	      "and %u units of resource ids for its answer (%u closes late)\n",
	      closeTable.entries[late].context, held, holds, ids, pending);
	if (answered)
		thread_call_enter(releaseCall);
}

// MARK: - Resource ids

IOReturn RgfxAccelerator::takeIdChunk(const void *owner, UInt32 context, UInt64 *firstId,
                                     UInt64 *ids)
{
	if (!contextLock)
		return kIOReturnNotReady;
	// A chunk of the size the guest took: RGFX_RESOURCE_ID_SMALL_CHUNK ids where the device and
	// the kext carry RGFX_FEATURE_SMALL_ID_CHUNKS, else RGFX_RESOURCE_ID_CHUNK.
	const uint64_t features = featureWord();
	IOLockLock(contextLock);
	const RgfxIdGrant g = rgfxIdChunkGrant(idChunkOwners, features, owner);
	const UInt32 held = rgfxIdChunksHeld(idChunkOwners, RGFX_RESOURCE_ID_SMALL_CHUNKS);
	IOLockUnlock(contextLock);
	if (g.first < 0) {
		IOLog("RgfxAccelerator: context %u: every resource-id chunk is held\n", context);
		return kIOReturnNoResources;
	}
	IOLog("RgfxAccelerator: context %u: resource-id chunk %u of %u ids (%u of %u units held)\n",
	      context, g.chunk, g.units * RGFX_RESOURCE_ID_SMALL_CHUNK, held,
	      RGFX_RESOURCE_ID_SMALL_CHUNKS);
	// The device learns of the chunk before the process does, so the grant is on the control
	// ring before any create that names one of its ids.
	RgfxResourceIdChunk grant = {};
	grant.context = context;
	grant.chunk = g.chunk;
	IOReturn r = postLifecycle(g.type, &grant, sizeof(grant), 0, nullptr, 0, nullptr, nullptr, 0);
	if (r != kIOReturnSuccess) {
		IOLockLock(contextLock);
		rgfxIdChunkGive(idChunkOwners, static_cast<uint32_t>(g.first), g.units);
		IOLockUnlock(contextLock);
		return r;
	}
	*firstId = g.firstId;
	*ids = static_cast<UInt64>(g.units) * RGFX_RESOURCE_ID_SMALL_CHUNK;
	return kIOReturnSuccess;
}

void RgfxAccelerator::freeIdChunks(const void *owner)
{
	if (!contextLock)
		return;
	IOLockLock(contextLock);
	const UInt32 freed =
	    rgfxIdChunksHand(idChunkOwners, RGFX_RESOURCE_ID_SMALL_CHUNKS, owner, nullptr);
	IOLockUnlock(contextLock);
	if (freed)
		IOLog("RgfxAccelerator: %u units of resource ids freed\n", freed);
}

void RgfxAccelerator::keepIdChunks(const void *owner)
{
	if (!contextLock)
		return;
	IOLockLock(contextLock);
	const UInt32 kept =
	    rgfxIdChunksHand(idChunkOwners, RGFX_RESOURCE_ID_SMALL_CHUNKS, owner, rgfxBlockNoOwner());
	IOLockUnlock(contextLock);
	if (kept)
		IOLog("RgfxAccelerator: %u units of resource ids kept from use: their context's close "
		      "was refused\n",
		      kept);
}

// MARK: - Blocks

// A block is whole window pages, so the whole of it is a span a window maps.
static_assert(kRgfxBlockPage == kRgfxWindowPage, "a block is whole window pages");

IOReturn RgfxAccelerator::allocBlock(RgfxAcceleratorUserClient *owner, UInt32 context,
                                    UInt64 size, UInt64 align, UInt64 writeCombinedFrom,
                                    UInt64 *offset)
{
	if (!contextLock)
		return kIOReturnBadArgument;
	if (writeCombinedFrom < size && writeCombinedFrom % kRgfxBlockPage != 0)
		return kIOReturnBadArgument;
	const bool mayReserve = owner->isWindowServer();
	IOLockLock(contextLock);
	RgfxBlockPin pin = {};
	RgfxBlockResult r =
	    rgfxBlockAlloc(blockTable, owner, context, size, align, offset, &pin, mayReserve);
	IOLockUnlock(contextLock);
	if (r == kRgfxBlockOk && mayReserve)
		noteReserve();
	switch (r) {
	case kRgfxBlockOk: {
		const UInt64 bytes = rgfxBlockAlignUp(size, kRgfxBlockPage); // the block's, as allocated
		// The block is in the process's window, and the device learns of it, before the
		// process does: the grant is on the control ring before any message naming it, on that
		// ring or a queue's. The block is pinned until then, so no free overtakes either. Its
		// bytes from `writeCombinedFrom` are the ones the process only writes (a submission
		// ring's data, command buffers' bodies, a library's staging chunks), mapped
		// write-combined, the rest write-back: on x86-64 through the guest PAT's entry 2, which
		// xnu's pmap gives every page it does not manage (PCD) for any other ask, and which the
		// kext sets to write-back (RgfxPat.hpp). The process fences its stores before it
		// publishes them.
		// Each span is zeroed before the window maps it, in the mode the window maps it with:
		// the block's bytes are whatever its last holder, of any context, left in them
		// (RgfxBlockZero.hpp). A span the kernel would not map for the zeros fails the grant.
		RgfxZeroSpan spans[2];
		const uint32_t n = rgfxBlockZeroSpans(pin.offset, size, bytes, writeCombinedFrom,
		                                      state.combinedRegion != nullptr, spans);
		UInt64 mapNs = 0, storeNs = 0;
		const UInt64 zeroFrom = mach_absolute_time();
		bool zeroed = true;
		for (uint32_t i = 0; i < n && zeroed; i++)
			zeroed = zeroSpan(region, spans[i], &mapNs, &storeNs);
		const UInt64 zeroNs = nanosSince(zeroFrom, mach_absolute_time());
		IOReturn posted = zeroed ? kIOReturnSuccess : kIOReturnNoMemory;
		for (uint32_t i = 0; i < n && posted == kIOReturnSuccess; i++)
			posted = owner->mapSpan(spans[i].offset, spans[i].length, spans[i].writeCombined);
		if (posted == kIOReturnSuccess) {
			RgfxBlockGrant grant = {};
			grant.context = context;
			grant.offset = pin.offset;
			grant.size = bytes;
			posted = postLifecycle(RGFX_CMD_BLOCK_GRANT, &grant, sizeof(grant), 0, nullptr, 0,
			                       nullptr, nullptr, 0);
		}
		IOLockLock(contextLock);
		rgfxZeroNote(zeroStats, rgfxBlockZeroKind(size, writeCombinedFrom), bytes, zeroNs, mapNs,
		             storeNs, zeroed);
		if (posted == kIOReturnSuccess) {
			rgfxBlockUnpin(blockTable, pin);
		} else {
			// Out of the window again before the block goes back.
			owner->unmapSpan(pin.offset, bytes);
			rgfxBlockDrop(blockTable, pin);
		}
		IOLockUnlock(contextLock);
		noteZeroing();
		return posted;
	}
	case kRgfxBlockNoSpace:
		return kIOReturnNoSpace;
	case kRgfxBlockTableFull:
		return kIOReturnNoResources;
	default:
		return kIOReturnBadArgument;
	}
}

IOReturn RgfxAccelerator::freeBlock(RgfxAcceleratorUserClient *owner, UInt64 offset)
{
	if (!contextLock)
		return kIOReturnNotReady;
	IOLockLock(contextLock);
	// Out of the process's window before the block is freed, under the lock, so no other free
	// of it and no new grant of its span comes between.
	UInt64 size = 0;
	RgfxBlockResult r = rgfxBlockFreeable(blockTable, owner, offset, &size);
	if (r == kRgfxBlockOk) {
		// A pages block, the one kind of a client's own that holds wired pages, was never in
		// the window.
		const int64_t at = rgfxBlockIndex(blockTable, offset);
		if (at < 0 || !blockTable.blocks[at].wired)
			owner->unmapSpan(offset, rgfxWindowSpanLength(size));
		r = rgfxBlockFree(blockTable, owner, offset, mach_absolute_time());
	}
	IOLockUnlock(contextLock);
	if (r == kRgfxBlockBusy)
		return kIOReturnBusy;
	if (r != kRgfxBlockOk)
		return kIOReturnBadArgument;
	// The release goes from the thread call, after every message the client posted before
	// this free; the block is no one's to name meanwhile.
	thread_call_enter(releaseCall);
	return kIOReturnSuccess;
}

void RgfxAccelerator::freeBlocks(const void *owner)
{
	if (!contextLock)
		return;
	// The device holds nothing of the owner's now: its pages blocks' pages are unwired, out of
	// the lock, each taken from its block first so no release's answer unwires it again.
	for (;;) {
		IOLockLock(contextLock);
		void *wired = rgfxBlockTakeWired(blockTable, owner);
		IOLockUnlock(contextLock);
		if (!wired)
			break;
		unwire(wired);
	}
	IOLockLock(contextLock);
	UInt32 freed = rgfxBlockFreeOwner(blockTable, owner);
	IOLockUnlock(contextLock);
	if (freed)
		IOLog("RgfxAccelerator: %u blocks freed\n", freed);
}

void RgfxAccelerator::holdBlocks(const void *owner)
{
	if (!contextLock)
		return;
	IOLockLock(contextLock);
	rgfxBlockHand(blockTable, owner, owner);
	IOLockUnlock(contextLock);
}

void RgfxAccelerator::keepBlocks(const void *owner)
{
	if (!contextLock)
		return;
	IOLockLock(contextLock);
	UInt32 kept = rgfxBlockKeepOwner(blockTable, owner);
	IOLockUnlock(contextLock);
	if (kept)
		IOLog("RgfxAccelerator: %u blocks kept from use: their context's close was not "
		      "answered\n",
		      kept);
}

bool RgfxAccelerator::pinRange(const void *owner, UInt64 offset, UInt64 length, RgfxBlockPin *pin)
{
	if (!contextLock)
		return false;
	IOLockLock(contextLock);
	bool pinned = rgfxBlockPin(blockTable, owner, offset, length, pin);
	// Or a shared block of a surface plane the owner holds.
	RgfxSurfaceTable &table = surfaceTable;
	if (!pinned && table.entries && rgfxSurfaceHeldBy(table, owner, offset, length))
		pinned = rgfxBlockPinAny(blockTable, offset, length, pin);
	IOLockUnlock(contextLock);
	// Or a scanout span a surface of its process is drawn into (RgfxAcceleratorSurfaces.cpp):
	// no block holds it and nothing frees it, so its pin names no block (serial 0).
	if (!pinned && grantedRange(owner, offset, length)) {
		*pin = {offset, 0};
		pinned = true;
	}
	return pinned;
}

bool RgfxAccelerator::ownsBlock(const void *owner, UInt64 offset)
{
	if (!contextLock)
		return false;
	IOLockLock(contextLock);
	const int64_t at = rgfxBlockIndex(blockTable, offset);
	const bool owns = at >= 0 && blockTable.blocks[at].owner == owner &&
	                  blockTable.blocks[at].state == kRgfxBlockLive && !blockTable.blocks[at].wired;
	IOLockUnlock(contextLock);
	return owns;
}

void RgfxAccelerator::unpinBlock(const RgfxBlockPin &pin)
{
	if (!contextLock)
		return;
	IOLockLock(contextLock);
	rgfxBlockUnpin(blockTable, pin);
	IOLockUnlock(contextLock);
}

// MARK: - Shared blocks of surface planes

namespace {
// The most planes with a shared block at once, held or dormant, and the most bytes of one plane.
constexpr UInt32 kMaxSurfaceBlocks = kRgfxSurfaceMaxBlocks;
constexpr UInt64 kMaxPlaneBytes = 256ull << 20;

// The runs of the first `length` bytes of the prepared `md`, whose first byte lies `address`
// bytes into a page (IOMalloc'd, `*count` of them, the caller's to free with freeRuns), or null
// where they do not fit one run a page.
RgfxPageRun *walkRuns(IOMemoryDescriptor *md, UInt64 address, UInt64 length, UInt32 *count)
{
	// One run a page at most.
	UInt32 capacity = static_cast<UInt32>(((address & (kPage - 1)) + length + kPage - 1) / kPage);
	RgfxPageRun *all = static_cast<RgfxPageRun *>(IOMalloc(sizeof(RgfxPageRun) * capacity));
	UInt32 n = 0;
	bool fits = all != nullptr;
	for (UInt64 at = 0; fits && at < length;) {
		IOByteCount segment = 0;
		addr64_t phys = md->getPhysicalSegment(at, &segment, kIOMemoryMapperNone);
		if (!phys || !segment) {
			fits = false;
			break;
		}
		if (segment > length - at)
			segment = length - at;
		fits = rgfxSurfaceAppendRun(all, &n, capacity, phys, segment);
		at += segment;
	}
	RgfxPageRun *kept = fits && n ? static_cast<RgfxPageRun *>(IOMalloc(sizeof(RgfxPageRun) * n))
	                              : nullptr;
	if (kept)
		bcopy(all, kept, sizeof(RgfxPageRun) * n);
	if (all)
		IOFree(all, sizeof(RgfxPageRun) * capacity);
	*count = kept ? n : 0;
	return kept;
}

// The plane of `length` bytes at `address` in `task`, wired: its descriptor, prepared, and its
// pages' runs (`*runs`, IOMalloc'd, `*count` of them, the caller's to free with freeRuns), or
// null where the range is not mapped there or its runs do not fit.
IOMemoryDescriptor *wirePlane(task_t task, UInt64 address, UInt64 length, RgfxPageRun **runs,
                              UInt32 *count)
{
	IOMemoryDescriptor *md =
	    IOMemoryDescriptor::withAddressRange(address, length, kIODirectionOutIn, task);
	if (!md)
		return nullptr;
#if defined(__x86_64__)
	faultTopDown(task, address, length);
#endif
	if (md->prepare(kIODirectionOutIn) != kIOReturnSuccess) {
		md->release();
		return nullptr;
	}
	RgfxPageRun *kept = walkRuns(md, address, length, count);
	if (!kept) {
		md->complete(kIODirectionOutIn);
		md->release();
		return nullptr;
	}
	*runs = kept;
	return md;
}

void freeRuns(RgfxPageRun *runs, UInt32 count)
{
	if (runs)
		IOFree(runs, sizeof(RgfxPageRun) * count);
}

// The reasons a copy block was refused for so far, a bit each (rgfxCopyRefusalFirst).
uint32_t copyRefusalsLogged;

// The asking process gets no shared copy block of a plane of `length` bytes, block `size`, for
// `why`: logged the first time a reason refuses one, out of the contexts' lock. Answers `r`.
IOReturn refuseCopy(RgfxCopyRefusal why, UInt64 length, UInt64 size, IOReturn r)
{
	if (rgfxCopyRefusalFirst(&copyRefusalsLogged, why)) {
		char name[32] = {};
		proc_name(proc_selfpid(), name, sizeof(name));
		IOLog("RgfxAccelerator: %s[%d] gets no shared copy block of a plane of %llu bytes (block "
		      "%llu bytes, 0x%x): %s; it copies the surface in a block of its own, which no "
		      "other holder shares (the first refusal of this kind)\n",
		      name, proc_selfpid(), length, size, r, rgfxCopyRefusalName(why));
	}
	return r;
}

// Where the device caches every surface (cacheEvery): the asks in place refused, by why, and the
// copy blocks made and held again, each a surface's second copy beside its device cache, which
// its other holders' GPU work does not see but through the surface's pages. Atomic; the first of
// each reason, and the first copy block made, logged, and all on the dormancy line.
UInt64 inPlaceRefused[kRgfxCopyRefusals];
uint32_t inPlaceRefusalsLogged;
UInt64 fallbackCopiesMade;
UInt64 fallbackCopiesHeld;
uint32_t fallbackCopyLogged;

// The sum of the fallback counts, which moves wherever one does.
UInt64 fallbackSum()
{
	UInt64 sum = __atomic_load_n(&fallbackCopiesMade, __ATOMIC_RELAXED) +
	             __atomic_load_n(&fallbackCopiesHeld, __ATOMIC_RELAXED);
	for (UInt32 i = 0; i < kRgfxCopyRefusals; i++)
		sum += __atomic_load_n(&inPlaceRefused[i], __ATOMIC_RELAXED);
	return sum;
}

// The asking process gets no block in place of a surface of `length` bytes, block `size`, for
// `why`, where the device caches every surface: counted, logged the first time a reason refuses
// one, out of the contexts' lock. Its process then copies the surface. Answers `r`.
IOReturn refuseInPlace(RgfxCopyRefusal why, UInt64 length, UInt64 size, IOReturn r)
{
	__atomic_fetch_add(&inPlaceRefused[why], 1, __ATOMIC_RELAXED);
	if (rgfxCopyRefusalFirst(&inPlaceRefusalsLogged, why)) {
		char name[32] = {};
		proc_name(proc_selfpid(), name, sizeof(name));
		IOLog("RgfxAccelerator: %s[%d] gets no block in place of a surface of %llu bytes (block "
		      "%llu bytes, 0x%x): %s; the device caches every surface, and the process copies "
		      "this one in a copy block (the first refusal of this kind)\n",
		      name, proc_selfpid(), length, size, r, rgfxCopyRefusalName(why));
	}
	noteDormant();
	return r;
}

// A copy block of a plane of `length` bytes, block `size`, was made for the asking process, or
// held again (`made` false), where the device caches every surface: counted, the first made
// logged, out of the contexts' lock.
void noteFallbackCopy(bool made, UInt64 length, UInt64 size)
{
	__atomic_fetch_add(made ? &fallbackCopiesMade : &fallbackCopiesHeld, 1, __ATOMIC_RELAXED);
	if (made && rgfxCopyRefusalFirst(&fallbackCopyLogged, 0)) {
		char name[32] = {};
		proc_name(proc_selfpid(), name, sizeof(name));
		IOLog("RgfxAccelerator: fallback copy: %s[%d] takes a copy block of a plane of %llu "
		      "bytes (block %llu bytes), a second copy beside the surface's device cache, as "
		      "the device caches every surface (the first; the dormancy line counts them)\n",
		      name, proc_selfpid(), length, size);
	}
	noteDormant();
}

// A chunked pages block refused for `why`, with `made` of `count` chunks taken: logged the first
// time, the process then taking plain pages. Answers kIOReturnNoMemory.
IOReturn refuseChunks(const char *why, UInt32 made, UInt32 count)
{
	static char logged;
	if (rgfxFirstCalls(&logged, 0, 1)) {
		char name[32] = {};
		proc_name(proc_selfpid(), name, sizeof(name));
		IOLog("RgfxAccelerator: %s[%d] gets no chunked pages block of %u chunks (%u made): %s; "
		      "it takes plain pages (the first refusal)\n",
		      name, proc_selfpid(), count, made, why);
	}
	return kIOReturnNoMemory;
}

void unwire(void *pages)
{
	OSObject *held = static_cast<OSObject *>(pages);
	if (!held)
		return;
	// A chunked pages block's (pagesChunked) is the process's mapping of the kext's chunks, which
	// holds them: out of the process, then the chunks freed with the mapping.
	if (IOMemoryMap *map = OSDynamicCast(IOMemoryMap, held)) {
		IOMemoryDescriptor *md = map->getMemoryDescriptor();
		map->unmap();
		if (md)
			md->complete(kIODirectionOutIn);
		map->release();
		return;
	}
	// A pages block's (pagesBlock) is the descriptor of the process's pages, completed for the
	// direction it was prepared for: reading alone for read-only memory.
	if (IOMemoryDescriptor *md = OSDynamicCast(IOMemoryDescriptor, held)) {
		md->complete(md->getDirection());
		md->release();
	}
}

// Whether a block of the kext's holding a wire for writing covers a byte of the `count` runs at
// `runs`, sorted and apart (rgfxRunsSorted): a pages block's of writable memory or a chunked one's,
// the pages of a surface block kept for the host, or an in-place surface block's runs. A wire of
// no kind known here, or one with a byte of no segment, counts as covering them. Under
// contextLock, which keeps every wire in the table from going (each is unwired once out of it).
bool writableBlockMeets(const RgfxPageRun *runs, uint32_t count)
{
	for (uint32_t i = 0; i < blockTable.count; i++) {
		OSObject *held = static_cast<OSObject *>(blockTable.blocks[i].wired);
		if (!held)
			continue;
		IOMemoryMap *map = OSDynamicCast(IOMemoryMap, held);
		IOMemoryDescriptor *md =
		    map ? map->getMemoryDescriptor() : OSDynamicCast(IOMemoryDescriptor, held);
		if (!md)
			return true;
		// Wired for the device's reads alone (kIODirectionOut): read-only memory's.
		if (!(md->getDirection() & kIODirectionIn))
			continue;
		const IOByteCount length = md->getLength();
		for (IOByteCount at = 0; at < length;) {
			IOByteCount n = 0;
			const addr64_t phys = md->getPhysicalSegment(at, &n, kIOMemoryMapperNone);
			if (!phys || !n || rgfxRunsMeet(runs, count, phys, n))
				return true;
			at += n;
		}
	}
	if (!surfaceTable.entries)
		return false;
	for (uint32_t i = 0; i < surfaceTable.capacity; i++) {
		const RgfxSurfaceEntry &e = surfaceTable.entries[i];
		if (!e.used || !e.inPlace || !e.runs)
			continue;
		for (uint32_t r = 0; r < e.runCount; r++)
			if (rgfxRunsMeet(runs, count, e.runs[r].address, e.runs[r].length))
				return true;
	}
	return false;
}

// Whether the `length` bytes `md` holds, a sole holder's memory wired for reading (pagesBlock),
// may take a block marked unchanging: no pages block of writable memory is being made
// (writableMakes), and no block of the kext's holding a wire for writing covers a page of them
// (writableBlockMeets). A wire holds no reference to the memory it wires, so the bundle's count
// leaves these out; a writable wire made from here on is refused the pages, whose mapping's
// maximum protection holds no write (RgfxPagesBlock.hpp). Their runs are sorted and made apart in
// memory of their own first; false where it could not be had. The first refusal is logged.
bool soleHolderAlone(IOMemoryDescriptor *md, UInt64 length)
{
	auto segment = [md](uint64_t at, uint64_t *bytes) -> uint64_t {
		IOByteCount n = 0;
		const addr64_t phys = md->getPhysicalSegment(at, &n, kIOMemoryMapperNone);
		*bytes = n;
		return phys;
	};
	const uint32_t count = rgfxPagesRuns(length, segment, nullptr, 0);
	const vm_size_t listBytes = static_cast<vm_size_t>(count) * sizeof(RgfxPageRun);
	RgfxPageRun *runs = count ? static_cast<RgfxPageRun *>(IOMalloc(listBytes)) : nullptr;
	bool alone = runs && rgfxPagesRuns(length, segment, runs, count) == count;
	if (alone) {
		const uint32_t apart = rgfxRunsSorted(runs, count);
		IOLockLock(contextLock);
		alone = writableMakes == 0 && !writableBlockMeets(runs, apart);
		IOLockUnlock(contextLock);
	}
	if (runs)
		IOFree(runs, listBytes);
	static char refused;
	if (!alone && rgfxFirstCalls(&refused, 0, 1)) {
		char name[32] = {};
		proc_name(proc_selfpid(), name, sizeof(name));
		IOLog("RgfxAccelerator: %s[%d]'s sole holder's pages block of 0x%llx bytes is refused: a "
		      "writable block of the kext's covers its pages, or one is being made; it takes a "
		      "read-only block (the first refusal)\n",
		      name, proc_selfpid(), length);
	}
	return alone;
}

// Writes the `count` runs of `runs` at region offset `at` (page aligned) for the device, through a
// kernel mapping of their pages, write-back as the processes map the region: false where none
// could be made.
bool writeRuns(IODeviceMemory *region, UInt64 at, const RgfxPageRun *runs, UInt32 count)
{
	UInt64 bytes = sizeof(RgfxPageRun) * static_cast<UInt64>(count);
	IOMemoryMap *map = region->createMappingInTask(
	    kernel_task, 0, kIOMapAnywhere | kIOMapCopybackCache, at, alignUp(bytes, kPage));
	if (!map)
		return false;
	bcopy(runs, reinterpret_cast<void *>(map->getVirtualAddress()), bytes);
#if RGFX_GUEST_ARM64
	// Where the kext took PAGES_16K, the device is told of the runs in whole 16 KiB pages: the
	// last ends at its page's end, as the length the device is told does (postPages). The caller's
	// runs stay as the memory's segments are, which a later ask's walk compares.
	if (pages16k)
		rgfxRunsToPageEnd(reinterpret_cast<RgfxPageRun *>(map->getVirtualAddress()), count,
		                  kRgfxPage16K);
#endif
	map->release();
	return true;
}

// The last holder of entry `e` let it go, or the dormant `e` goes: its block is freed (its
// BLOCK_RELEASE names `context`, or a dormant block's last holder's), or kept for good where the
// device may still use it (`keep`, a close not answered, or a create naming it in flight), and
// the entry goes. Under contextLock; whether a release is to be posted.
//
// For an in-place block the host maps the surface's own pages, so those pages stay wired as long
// as the block is in the table, lest the guest recycle them under the host's view. `wired` is the
// last holder's wired descriptor of them (null for a copy block, or where the caller has none):
// it is attached to the block and unwired only once the block leaves the table (its release
// answered OK, releaseFreedBlocks). `*kept` is then true and the caller must not unwire `wired`.
bool letGoBlock(RgfxSurfaceEntry &e, UInt32 context, bool keep, void *wired = nullptr,
                bool *kept = nullptr)
{
	// A deferred block's holders wire no pages: where the host may map them (named, being named,
	// or asked and not answered), the block takes a wire of its own, before its cache goes.
	IOMemoryDescriptor *hostPages = e.inPlace && e.deferred && !wired && e.cache
	                                    ? rgfxSurfaceCacheHostPages(e.cache, e.offset)
	                                    : nullptr;
	bool release = false;
	if (!keep) {
		if (!e.dormant)
			rgfxBlockSetContext(blockTable, e.offset, context);
		release = rgfxBlockFree(blockTable, &e, e.offset, mach_absolute_time()) == kRgfxBlockOk;
	}
	if (!release)
		rgfxBlockKeepAt(blockTable, e.offset);
	// The block stays in the table (freed for its release, or kept): its surface's pages stay
	// wired until it leaves. A copy block holds no such wire.
	bool ownedWire = e.inPlace && wired && rgfxBlockSetWired(blockTable, e.offset, wired);
	if (kept)
		*kept = ownedWire;
	// Never given back to the guest while the host may map it: kept for good where the block
	// cannot hold it.
	static char wiredForGood;
	if (hostPages && !rgfxBlockSetWired(blockTable, e.offset, hostPages) &&
	    rgfxFirstCalls(&wiredForGood, 0, 1))
		IOLog("RgfxAccelerator: the deferred block 0x%llx's pages stay wired for good: its block "
		      "is gone\n",
		      e.offset);
	freeRuns(e.runs, e.runCount);
	// Its surface's locks no longer wait for the writes named through it, but go on waiting for
	// those named through the surface's other blocks; a cached one's wait for its release's
	// answer, which copies the cache into the pages. A cached block kept instead
	// is cached no more, but the device may still map its pages in place: the block holds their
	// wiring, the last holder's, or where it gave none (a dormant block's, kept as a create in
	// flight names it), the cache's, so they never go back to macOS while it is in the table.
	void *cacheWire = nullptr;
	const bool blockWired = ownedWire || hostPages != nullptr;
	// The entry's references of the device cache and the surface go out of this lock, the
	// cache's first, where the locks' state no longer holds them.
	if (rgfxSurfaceLocksForget(e.cache, e.surface, e.offset, e.cached && release, blockWired,
	                           &cacheWire)) {
		letGo(static_cast<OSObject *>(e.cache));
		letGo(static_cast<OSObject *>(e.surface));
	}
	if (cacheWire && !rgfxBlockHoldWire(blockTable, e.offset, cacheWire))
		unwire(cacheWire);
	rgfxSurfaceClear(surfaceTable, e);
	return release;
}

// The dormant entry `i` goes, for `why`. Under contextLock; whether a release is to be posted.
bool letGoDormant(UInt32 i, RgfxDormantCause why, bool written = false)
{
	dormantStats.letGo[why]++;
	if (why == kRgfxDormantPurged && written)
		dormantStats.purgedWritten++;
	if (((why >= kRgfxDormantCount && why <= kRgfxDormantNoSpace) ||
	     why == kRgfxDormantDeferredBytes) &&
	    surfaceTable.entries[i].purgeable)
		dormantStats.volatileFirst++;
	dormantStats.changes++;
	return letGoBlock(surfaceTable.entries[i], 0, false);
}

// The dormant blocks past their caps go, the oldest first. Under contextLock; whether a release
// is to be posted.
bool trimDormant()
{
	bool release = false;
	RgfxDormantCause why = kRgfxDormantCauses;
	for (int32_t i; (i = rgfxSurfaceOverCaps(surfaceTable, dormantMaxBytes, &why)) >= 0;)
		release |= letGoDormant(static_cast<UInt32>(i), why);
	// The deferred ones past the smaller of half the device's budget for them and the dormant
	// bytes' cap.
	const uint64_t deferredCap = rgfxSurfaceDormantDeferredCap(deferredBudget, dormantMaxBytes);
	for (int32_t i; (i = rgfxSurfaceOverDeferredCap(surfaceTable, deferredCap, &why)) >= 0;)
		release |= letGoDormant(static_cast<UInt32>(i), why);
	return release;
}

// Arms the age timer for the next dormant block to age (rgfxSurfaceNextAge), where it is not
// armed for a later time: a block that sleeps later ages later, and a block held again or let go
// before its age leaves the timer as it was, whose run finds none aged and arms it for the next
// (ageTimerFired). Where none waits to age, nothing is armed. Under contextLock.
void armAge(UInt64 now)
{
	if (ageArmedAt > now)
		return;
	UInt64 at = 0;
	ageArmedAt = rgfxSurfaceNextAge(surfaceTable, now, dormantAge, &at) ? at : 0;
	if (ageArmedAt)
		thread_call_enter_delayed(ageTimer, ageArmedAt);
}

// The dormant entry `i` goes for its age. One whose release copies its cache into its pages
// (`written`: the GPU wrote it since its last copy, a deferred one's pages named first for it) is
// the one such in flight (agePace) until its answer. Where clients of its surface are left, the
// release worker's sample of them takes it. Under contextLock, on the release worker; whether a
// release is to be posted.
bool ageDormant(UInt32 i, bool written, UInt64 now)
{
	RgfxSurfaceEntry &e = surfaceTable.entries[i];
	const UInt64 offset = e.offset;
	uint64_t window = 0;
	nanoseconds_to_absolutetime(static_cast<uint64_t>(kDormantLogMs) * 1000000ull, &window);
	if (now - agedNamedAt >= window) {
		agedNamedAt = now;
		agedNamedCount = 0;
	}
	// IOSurface's client count loads a field and takes no lock (rgfxSurfaceLocksFresh); the
	// surface is retained, the sample's own, only where clients are left, so the retain changes
	// no release's flags (rgfxSurfaceCacheReleaseFlags), and it is released before any release
	// is posted.
	OSObject *surface = static_cast<OSObject *>(e.surface);
	if (surface && e.surfaceId && agedNamedCount < kAgedNamed && agedClientCount < kAgedNamed &&
	    rgfxIOSurfaceClientCount(surface) > 0) {
		surface->retain();
		agedClients[agedClientCount++] = {surface, e.surfaceId, e.length, e.deferred, written};
		agedNamedCount++;
	}
	const bool release = letGoDormant(i, kRgfxDormantAged, written);
	if (release && written) {
		agePace = offset;
		dormantStats.agedWritten++;
	}
	return release;
}

// The dormant blocks their surfaces asked to go (rgfxSurfaceCacheLetGoOf) go, and the others
// take whether their surfaces are volatile; on the release worker (`aging`), those that slept
// kRgfxDormantAgeMs go too (ageDormant), those whose releases copy one at a time. Then the age
// timer is armed for the next to age. Under contextLock; whether a release is to be posted.
bool reapDormant(bool aging)
{
	bool release = false;
	const UInt64 now = mach_absolute_time();
	for (UInt32 i = 0; surfaceTable.dormantCount && i < surfaceTable.capacity; i++) {
		RgfxSurfaceEntry &e = surfaceTable.entries[i];
		if (!e.used || !e.dormant || e.pending)
			continue;
		bool written = false, purgeable = false;
		const uint32_t why = rgfxSurfaceCacheLetGoOf(e.offset, &written, &purgeable);
		e.purgeable = purgeable;
		if (why < kRgfxDormantCauses)
			release |= letGoDormant(i, static_cast<RgfxDormantCause>(why), written);
		else if (aging && rgfxSurfaceAged(e, now, dormantAge) && !(written && agePace))
			release |= ageDormant(i, written, now);
	}
	armAge(now);
	return release;
}

// A diagnostic: logs, for each dormant block let go for its age with clients of its surface left
// that the release worker sampled (ageDormant), which processes with a context of the accelerator
// open find its surface by its ID, and releases the sample's retain of it. A process with no
// context open is not looked in, so it may name fewer processes than the surface has clients. Out
// of every lock, on the release worker.
void nameAgedClients(RgfxAccelerator *accel)
{
	AgedClient aged[kAgedNamed];
	IOLockLock(contextLock);
	const UInt32 n = agedClientCount;
	for (UInt32 i = 0; i < n; i++)
		aged[i] = agedClients[i];
	agedClientCount = 0;
	IOLockUnlock(contextLock);
	if (!n)
		return;
	// The accelerator's clients, gathered (retained) first, so none goes while they are walked.
	OSArray *clients = OSArray::withCapacity(16);
	OSIterator *it = clients ? accel->getClientIterator() : nullptr;
	if (it) {
		do {
			it->reset();
			clients->flushCollection();
			while (OSObject *o = it->getNextObject())
				if (OSDynamicCast(RgfxAcceleratorUserClient, o))
					clients->setObject(o);
		} while (!it->isValid());
		it->release();
	}
	const unsigned count = clients ? clients->getCount() : 0;
	for (UInt32 i = 0; i < n; i++) {
		char names[384] = "";
		UInt32 looked = 0, found = 0;
		for (unsigned c = 0; c < count; c++) {
			auto *client = static_cast<RgfxAcceleratorUserClient *>(clients->getObject(c));
			bool asked = false;
			OSObject *surface = client->lookupSurfaceOfProcess(aged[i].surfaceId, &asked);
			looked += asked;
			if (surface == aged[i].surface) {
				const OSString *who =
				    OSDynamicCast(OSString, client->getProperty(kIOUserClientCreatorKey));
				if (found++)
					strlcat(names, "; ", sizeof(names));
				strlcat(names, who ? who->getCStringNoCopy() : "?", sizeof(names));
			}
			OSSafeReleaseNULL(surface);
		}
		IOLog("RgfxAccelerator: a dormant block let go for its age: IOSurface %u, %llu KiB, %s%s, "
		      "%d clients, %d retains (this line's own among them); its ID finds it in %u of the "
		      "%u contexts open: %s\n",
		      aged[i].surfaceId, aged[i].bytes >> 10, aged[i].deferred ? "deferred" : "wired",
		      aged[i].written ? ", the GPU's writes copied" : "",
		      rgfxIOSurfaceClientCount(aged[i].surface), aged[i].surface->getRetainCount(), found,
		      looked, found ? names : "none");
		aged[i].surface->release();
	}
	OSSafeReleaseNULL(clients);
}

// Logs what the releases took (ReleaseStats), where more were answered and kReleaseLogMs passed
// since the last line. Not under contextLock.
void noteReleases()
{
	if (!contextLock)
		return;
	const uint64_t now = mach_absolute_time();
	uint64_t interval = 0;
	nanoseconds_to_absolutetime(static_cast<uint64_t>(kReleaseLogMs) * 1000000ull, &interval);
	IOLockLock(contextLock);
	const bool log = releaseStats.latency.count != releaseStats.loggedCount &&
	                 now - releaseStats.loggedAt >= interval;
	UInt64 count = 0, p50 = 0, p99 = 0, most = 0, reaps = 0, r50 = 0, r99 = 0, rmost = 0;
	UInt64 kept = 0, late = 0, waits = 0, failed = 0, writeBacks = 0, writeBacksLate = 0;
	UInt32 inFlight = 0;
	if (log) {
		const ReleaseStats &s = releaseStats;
		count = s.latency.count;
		p50 = rgfxLatencyPercentile(s.latency, 500);
		p99 = rgfxLatencyPercentile(s.latency, 990);
		most = s.latency.maxNs;
		reaps = s.reapWait.count;
		r50 = rgfxLatencyPercentile(s.reapWait, 500);
		r99 = rgfxLatencyPercentile(s.reapWait, 990);
		rmost = s.reapWait.maxNs;
		kept = s.kept;
		late = s.late;
		inFlight = s.inFlightMost;
		waits = s.roomWaits;
		failed = s.roomWaitsFailed;
		writeBacks = s.writeBackWaits;
		writeBacksLate = s.writeBackLate;
		releaseStats.loggedCount = count;
		releaseStats.loggedAt = now;
	}
	IOLockUnlock(contextLock);
	if (!log)
		return;
	// The CPU locks that slept for a release's answer (RgfxReleaseLockWaits), out of contextLock.
	uint64_t lockWaits = 0, lockMostUs = 0;
	rgfxSurfaceLocksReleaseWaits(&lockWaits, &lockMostUs);
	IOLog("RgfxAccelerator: releases: %llu answered (%llu kept, %llu late), %u in flight at most; "
	      "freed to answered p50 %llu us, p99 %llu us, max %llu us; dormant reaps %llu, waited "
	      "p50 %llu us, p99 %llu us, max %llu us; room waits %llu (%llu found none); write-back "
	      "waits %llu (%llu late); lock waits on a release %llu (longest %llu.%03llu ms)\n",
	      count, kept, late, inFlight, p50 / 1000, p99 / 1000, most / 1000, reaps, r50 / 1000,
	      r99 / 1000, rmost / 1000, waits, failed, writeBacks, writeBacksLate, lockWaits,
	      lockMostUs / 1000, lockMostUs % 1000);
}

// Logs what zeroing new blocks took (zeroStats), by kind: how many, their KiB, and the time each
// took, mean, p50, p99 and the most; then of every kind the time in the kernel mappings and in the
// stores, and the grants that failed for a span not mapped. Where more were zeroed and kZeroLogMs
// passed since the last line. Not under contextLock.
void noteZeroing()
{
	if (!contextLock)
		return;
	const uint64_t now = mach_absolute_time();
	uint64_t interval = 0;
	nanoseconds_to_absolutetime(static_cast<uint64_t>(kZeroLogMs) * 1000000ull, &interval);
	struct Kind {
		UInt64 count, kib, mean, p50, p99, most;
	} k[kRgfxZeroKinds] = {};
	UInt64 mapUs = 0, storeUs = 0, failed = 0;
	IOLockLock(contextLock);
	const UInt64 count = rgfxZeroCount(zeroStats);
	const bool log = count != zeroStats.loggedCount && now - zeroStats.loggedAt >= interval;
	if (log) {
		for (UInt32 i = 0; i < kRgfxZeroKinds; i++) {
			const RgfxLatency &l = zeroStats.took[i];
			k[i] = {l.count,
			        zeroStats.bytes[i] >> 10,
			        l.count ? zeroStats.ns[i] / l.count : 0,
			        rgfxLatencyPercentile(l, 500),
			        rgfxLatencyPercentile(l, 990),
			        l.maxNs};
		}
		mapUs = zeroStats.mapNs / 1000;
		storeUs = zeroStats.storeNs / 1000;
		failed = zeroStats.failed;
		zeroStats.loggedCount = count;
		zeroStats.loggedAt = now;
	}
	IOLockUnlock(contextLock);
	if (!log)
		return;
	static const char *const names[kRgfxZeroKinds] = {"bodies", "split", "write-back",
	                                                  "surface copies", "surface headers"};
	for (UInt32 i = 0; i < kRgfxZeroKinds; i++)
		if (k[i].count)
			IOLog("RgfxAccelerator: zeroed blocks, %s: %llu (%llu KiB), each mean %llu ns, p50 "
			      "%llu ns, p99 %llu ns, max %llu ns\n",
			      names[i], k[i].count, k[i].kib, k[i].mean, k[i].p50, k[i].p99, k[i].most);
	IOLog("RgfxAccelerator: zeroed blocks: %llu in all, %llu us in mappings, %llu us in stores, %llu "
	      "not mapped\n",
	      count, mapUs, storeUs, failed);
}

// The most WindowServer's blocks came to at the last line of noteReserve. Under contextLock.
UInt32 reserveLoggedCount = 0;
UInt64 reserveLoggedBytes = 0;

// Logs what WindowServer's blocks came to at most (RgfxBlockTable's peaks), as that grows by
// 64 blocks or a MiB: what its reserve is sized from. Not under contextLock.
void noteReserve()
{
	if (!contextLock)
		return;
	IOLockLock(contextLock);
	const RgfxBlockTable t = blockTable;
	const bool log = t.reservedPeakCount >= reserveLoggedCount + 64 ||
	                 t.reservedPeakBytes >= reserveLoggedBytes + (1ull << 20);
	if (log) {
		reserveLoggedCount = t.reservedPeakCount;
		reserveLoggedBytes = t.reservedPeakBytes;
	}
	IOLockUnlock(contextLock);
	if (!log)
		return;
	// And its queues, of the watched rings (RgfxQueueLimits.hpp's reserve).
	UInt32 queues = 0, all = 0;
	if (watchLock) {
		IOLockLock(watchLock);
		for (UInt32 i = 0; i < watchedCount; i++)
			queues += watched[i].client && watched[i].client->isWindowServer();
		all = watchedCount;
		IOLockUnlock(watchLock);
	}
	IOLog("RgfxAccelerator: WindowServer's blocks: %u (%llu KiB), at most %u (%llu KiB); "
	      "its reserve: %u entries, %llu MiB; the table holds %u; its queues: %u of %u "
	      "watched (reserve %u)\n",
	      t.reservedCount, t.reservedBytes >> 10, t.reservedPeakCount, t.reservedPeakBytes >> 10,
	      t.reserveEntries, t.reserveBytes >> 20, t.count, queues, all,
	      kRgfxWindowServerQueues);
}

// Logs what the dormant blocks did, where it changed and kDormantLogMs passed since the last
// line. Not under contextLock.
void noteDormant()
{
	if (!contextLock)
		return;
	const uint64_t now = mach_absolute_time();
	uint64_t interval = 0;
	nanoseconds_to_absolutetime(static_cast<uint64_t>(kDormantLogMs) * 1000000ull, &interval);
	// Read first, holding no other lock.
	const UInt64 noRoom = rgfxSurfaceCacheNoRoom();
	const UInt64 retaken = rgfxSurfaceCacheRetaken();
	UInt64 carries[kRgfxCarryOutcomes] = {};
	if (deferCarries)
		rgfxSurfaceCacheCarries(carries);
	const UInt64 fallback = cacheEvery ? fallbackSum() : 0;
	const UInt64 cacheTables = cacheEvery ? rgfxSurfaceCacheGrown() : 0;
	IOLockLock(contextLock);
	const bool log = (dormantStats.changes != dormantStats.loggedChanges ||
	                  noRoom != dormantStats.loggedNoRoom ||
	                  fallback != dormantStats.loggedFallback) &&
	                 now - dormantStats.loggedAt >= interval;
	const DormantStats d = dormantStats;
	const UInt32 count = surfaceTable.dormantCount;
	const UInt64 bytes = surfaceTable.dormantBytes;
	const UInt32 entries = surfaceTable.capacity;
	if (log) {
		dormantStats.loggedChanges = dormantStats.changes;
		dormantStats.loggedNoRoom = noRoom;
		dormantStats.loggedFallback = fallback;
		dormantStats.loggedAt = now;
	}
	IOLockUnlock(contextLock);
	// Where the device caches every surface: the copy blocks beside the surfaces' device caches,
	// the asks in place refused by why, and how far the tables grew.
	if (log && cacheEvery) {
		UInt64 r[kRgfxCopyRefusals] = {};
		for (UInt32 i = 0; i < kRgfxCopyRefusals; i++)
			r[i] = __atomic_load_n(&inPlaceRefused[i], __ATOMIC_RELAXED);
		IOLog("RgfxAccelerator: every surface cached: fallback copy blocks %llu made, %llu held "
		      "again; asks in place refused: %llu uncacheable, %llu no device cache, %llu by the "
		      "device, %llu no room, %llu table full, %llu not mapped, %llu share not posted, "
		      "%llu pages not wired, %llu of another shape or mode, %llu holders; grown: %llu "
		      "chunks of the surface table (%u entries), %llu blocks' holds, %llu cached-surface "
		      "tables\n",
		      __atomic_load_n(&fallbackCopiesMade, __ATOMIC_RELAXED),
		      __atomic_load_n(&fallbackCopiesHeld, __ATOMIC_RELAXED),
		      r[kRgfxCopyRefusedUncacheable], r[kRgfxCopyRefusedNoCache], r[kRgfxCopyRefusedHost],
		      r[kRgfxCopyRefusedRoom], r[kRgfxCopyRefusedTable], r[kRgfxCopyRefusedMap],
		      r[kRgfxCopyRefusedShare], r[kRgfxCopyRefusedPages],
		      r[kRgfxCopyRefusedShape] + r[kRgfxCopyRefusedDiffers], r[kRgfxCopyRefusedHolders],
		      d.tableChunks, entries, d.holdsGrown, cacheTables);
	}
	if (log)
		IOLog("RgfxAccelerator: dormant surface blocks: %u held (%llu of %llu MiB); %llu slept, "
		      "%llu revived; let go: %llu purged (%llu with a cache written), %llu made "
		      "empty, %llu with no client at sleep, %llu past the count, %llu past the "
		      "bytes, %llu for a table entry, %llu for the region's room (%llu of these "
		      "volatile), %llu asked otherwise, %llu past the deferred bytes, %llu for their age "
		      "(%llu with GPU writes no download copied, one at a time); %llu released with "
		      "no client left (%llu with GPU writes no download copied), %llu of them held by "
		      "the kext alone, as the host counts them (%llu with GPU writes no download copied; "
		      "%llu taken again before the answer); %llu not cached: no room; %llu deferred "
		      "(%llu refused), %llu "
		      "released with no pages named; %llu asks found a cached block by its surface\n",
		      count, bytes >> 20, dormantMaxBytes >> 20, d.slept, d.revived,
		      d.letGo[kRgfxDormantPurged], d.purgedWritten, d.letGo[kRgfxDormantEmptied],
		      d.letGo[kRgfxDormantNoClients],
		      d.letGo[kRgfxDormantCount], d.letGo[kRgfxDormantBytes],
		      d.letGo[kRgfxDormantTableFull], d.letGo[kRgfxDormantNoSpace], d.volatileFirst,
		      d.letGo[kRgfxDormantStale], d.letGo[kRgfxDormantDeferredBytes],
		      d.letGo[kRgfxDormantAged], d.agedWritten, d.unread,
		      d.unreadWritten, d.unheld, d.unheldWritten, retaken, noRoom, d.deferred,
		      d.deferredRefused, d.deferredUnattached, d.foundBySurface);
	// How the deferrals of surfaces whose asks listed resident pages ended (RgfxDeferCarry.hpp).
	if (log && deferCarries)
		IOLog("RgfxAccelerator: deferrals of listed pages: %llu carried them, %llu found none "
		      "resident; not deferred: %llu touched, %llu not counted, %llu with other pages "
		      "resident, compressed or paged out, %llu not wired with no fault, %llu counted "
		      "otherwise after the wire, %llu with no runs\n",
		      carries[kRgfxCarryTaken], carries[kRgfxCarryNone], carries[kRgfxCarryTouched],
		      carries[kRgfxCarryUncounted], carries[kRgfxCarryCounted], carries[kRgfxCarryUnwired],
		      carries[kRgfxCarryFaulted], carries[kRgfxCarryNoRuns]);
}

// The last holder, of context `context`, of the cached entry `e` let it go: the block sleeps
// rather than going, where its surface stays cached (rgfxSurfaceCacheSleep), the entry keeping
// its references of the surface and its device cache. Under contextLock. The entry stays
// pending until the caller has posted the hold's BLOCK_UNSHARE and called wakeSlept with
// `*surface`, the surface retained once more, so no ask's BLOCK_SHARE overtakes it.
bool sleepBlock(RgfxSurfaceEntry &e, UInt32 context, OSObject **surface)
{
	*surface = nullptr;
	bool purgeable = false;
	if (!e.cached || !e.inPlace || e.pending || !e.cache || !e.surface ||
	    !rgfxSurfaceCacheSleep(e.cache, &purgeable))
		return false;
	rgfxBlockSetContext(blockTable, e.offset, context);
	rgfxSurfaceSleep(surfaceTable, e, mach_absolute_time());
	e.purgeable = purgeable;
	e.pending = true;
	*surface = static_cast<OSObject *>(e.surface);
	(*surface)->retain();
	dormantStats.slept++;
	dormantStats.changes++;
	return true;
}

// The BLOCK_UNSHARE of the block at `offset` (serial `serial`) that slept is posted: the entry is
// no longer pending, so it ages (armAge), and the dormant blocks past their caps, or asked to go
// meanwhile, go. Its surface, `surface` (sleepBlock), is read for its clients once, out of the
// contexts' lock, then released: one with none left, its last gone while the block was held, its
// op 5 then letting nothing go, asks the block to go. Takes contextLock; whether a release is to
// be posted.
bool wakeSlept(UInt64 offset, UInt64 serial, OSObject *surface)
{
	if (surface && rgfxIOSurfaceClientCount(surface) == 0)
		rgfxSurfaceCacheUnclaimed(offset);
	OSSafeReleaseNULL(surface);
	IOLockLock(contextLock);
	const int32_t at = rgfxSurfaceAt(surfaceTable, offset);
	if (at >= 0 && surfaceTable.entries[at].serial == serial)
		surfaceTable.entries[at].pending = false;
	IOLockWakeup(contextLock, &surfaceTable, false);
	bool release = reapDormant();
	release |= trimDormant();
	IOLockUnlock(contextLock);
	return release;
}
} // namespace

IOReturn RgfxAccelerator::acquireSurfaceBlock(RgfxAcceleratorUserClient *client, UInt32 context,
                                             task_t task, UInt64 address, UInt64 length,
                                             UInt64 size, bool inPlace, uint32_t surfaceId,
                                             bool cacheable, const RgfxSurfacePagesLayout *layout,
                                             const RgfxSurfaceResident *resident,
                                             SurfaceBlock *block)
{
	if (!contextLock)
		return kIOReturnNotReady;
	if (inPlace && (!surfacePages || !region))
		return kIOReturnUnsupported;
	// A refused copy block says why, once a reason (refuseCopy); the bundle counts the refusals
	// of blocks in place, and so does the kext, by why, where the device caches every surface
	// (refuseInPlace).
	auto refused = [&](RgfxCopyRefusal why, IOReturn r) {
		if (inPlace)
			return cacheEvery ? refuseInPlace(why, length, size, r) : r;
		return refuseCopy(why, length, size, r);
	};
	if (!length || length > kMaxPlaneBytes || !size || size % kPage || size > 2 * kMaxPlaneBytes)
		return refused(kRgfxCopyRefusedShape, kIOReturnBadArgument);
	// A copy block holds the plane's bytes; a block in place holds none of the surface's whole
	// pages, which the device maps as they are.
	if (inPlace ? address % kPage || length % kPage : size < length)
		return refused(kRgfxCopyRefusedShape, kIOReturnBadArgument);
	// Where the device caches every surface, a block in place is cached or not made: an ask that
	// names no surface, or asks no cache (the bundle's video decoder's outputs where the host
	// lands no picture in a cache), is refused before anything is posted.
	if (inPlace && cacheEvery && (!surfaceId || !cacheable))
		return refused(kRgfxCopyRefusedUncacheable, kIOReturnUnsupported);
	RgfxSurfaceTable &table = surfaceTable;
	// The asker's IOSurface, where the device caches surfaces: a new block of it waits for its
	// pages' write-back (rgfxSurfaceCacheWritingBack), and a cached block in place of it, held or
	// dormant, is the ask's, found by it (rgfxSurfaceFindCached), and so is a dormant block found
	// by the asker's pages that is its block (reviveSurfaceBlock). Where a block of it may be
	// deferred (RgfxSurfaceBlocks.hpp), a deferred block of it is the ask's, found by it whatever
	// the asker's pages, and a fresh one may be deferred, where cacheable and within the device's
	// budget. None wires the asker's pages: the kext wires them only where none holds.
	// Looked up before the contexts' lock, under which nothing calls into IOSurface
	// (ContextState), and released once the ask is done, out of it, but a new deferred entry's,
	// which keeps it.
	struct SurfaceRef {
		OSObject *object = nullptr;
		~SurfaceRef() { OSSafeReleaseNULL(object); }
	} asker;
	if (inPlace && surfaceId && (surfaceCache || deferredBudget))
		asker.object = rgfxSurfaceLocksLookup(this, task, surfaceId);
	// Whether the asker's surface reads fresh (rgfxSurfaceLocksFresh), counted out of the contexts'
	// lock, which every process's block allocations, surface asks and releases take: a count makes
	// a mapping of the surface's memory and took up to 81.8 ms (RgfxAcceleratorLocks.cpp). The
	// ask counts where a deferral is otherwise its, then takes the lock again and looks again;
	// where it waits under the lock after the count, it counts again.
	bool fresh = false, counted = false;
	bool defer = false, deferredFound = false, cachedFound = false;
	uint64_t listed = 0;
	for (;;) {
		IOLockLock(contextLock);
		if (!table.entries) {
			auto *made = static_cast<RgfxSurfaceEntry *>(
			    IOMalloc(sizeof(RgfxSurfaceEntry) * kMaxSurfaceBlocks));
			if (made) {
				bzero(made, sizeof(RgfxSurfaceEntry) * kMaxSurfaceBlocks);
				table = {made, kMaxSurfaceBlocks};
			}
		}
		defer = deferredFound = cachedFound = false;
		// The surface's resident pages the ask listed, where the host lets a deferral carry
		// them (RgfxDeferCarry.hpp): a surface fresh but for those may be deferred too.
		listed = resident && deferCarries ? rgfxResidentPages(*resident, length, PAGE_SIZE) : 0;
		if (!listed)
			resident = nullptr;
		if (asker.object && table.entries && surfaceCache)
			cachedFound = rgfxSurfaceFindCached(table, asker.object, length, size, true) >= 0;
		if (asker.object && table.entries && deferredBudget && !cachedFound) {
			int32_t d = -1;
			while (asker.object && (d = rgfxSurfaceFindDeferred(table, asker.object)) >= 0 &&
			       table.entries[d].pending) {
				counted = false;
				IOLockSleep(contextLock, &surfaceTable, THREAD_UNINT);
			}
			deferredFound = d >= 0;
			// Where the device answers which surfaces need a cache, the deferral asks with the
			// surface's layout: an ask with none (an older bundle's) stays in place, as it did.
			defer = asker.object && !deferredFound && cacheable && (!askCache || layout) &&
			        rgfxSurfaceDeferFits(table, length, deferredBudget);
			if (defer && !counted) {
				IOLockUnlock(contextLock);
				fresh = rgfxSurfaceLocksFresh(asker.object, length, listed);
				counted = true;
				continue;
			}
			defer = defer && fresh;
		}
		break;
	}
	IOLockUnlock(contextLock);
	// A cached block of the surface is the ask's, found by the surface, only where the asker
	// maps the surface where it asks, IOSurface's own mapping in its task, looked up, not wired:
	// else it wires its range, as for a surface with no cached block, a range it does not map
	// refused.
	const bool mapsSurface =
	    cachedFound && rgfxSurfaceLocksMapsAt(asker.object, task, address, length);
	cachedFound = mapsSurface;
	RgfxPageRun *runs = nullptr;
	UInt32 count = 0;
	IOMemoryDescriptor *pages = nullptr;
	// A block in place is no other ask's until the device has answered for its pages: the ask
	// waits for the answer, which keeps the block or lets it go. A dormant block of the plane is
	// held again by an ask of the same surface (reviveSurfaceBlock, or reviveBlockOfSurface where
	// the ask found it by its surface), and goes where the ask is another's, or of the other
	// mode: the ask then makes its own.
	bool differs = false, revived = false, release = false, waitedForRoom = false;
	// The ask found a cached block in place of its surface by the surface, wiring nothing.
	bool heldBySurface = false;
	// Until when a new block waits for the region's room, once dormant blocks went for it.
	uint64_t roomDeadline = 0;
	// When a new block began to wait for its surface's write-back, and whether it went on past
	// its wait (rgfxCacheNewBlockStep).
	uint64_t writeBackFrom = 0;
	// Whether the wait for the previous block's write-back ended unanswered, and then whether the
	// block goes on without it (rgfxCacheNewBlockStep).
	bool writeBackGaveUp = false;
	bool writeBackLate = false;
	int32_t at = -1, slot = -1;
	RgfxBlockPin pin = {};
	UInt64 offset = 0, total = 0;
	RgfxBlockResult made = kRgfxBlockTableFull;
	for (bool wire = !defer && !deferredFound && !cachedFound;;) {
		if (wire) {
			pages = wirePlane(task, address, length, &runs, &count);
			if (!pages)
				return refused(kRgfxCopyRefusedPages, kIOReturnBadArgument);
		}
		IOLockLock(contextLock);
		// The ask finds no deferred block and has no pages: it wires them, and looks again.
		bool needPages = false;
		// The surface counted, out of the lock, just before this pass took it.
		bool countedNow = false;
		for (;;) {
			bool countedHere = countedNow;
			countedNow = false;
			int32_t d = -1;
			while (table.entries &&
			       (rgfxSurfacePending(table, runs, count) ||
			        ((d = rgfxSurfaceFindDeferred(table, asker.object)) >= 0 &&
			         table.entries[d].pending) ||
			        ((d = rgfxSurfaceFindCached(table, asker.object, length, size,
			                                    mapsSurface)) >= 0 &&
			         table.entries[d].pending))) {
				countedHere = false;
				IOLockSleep(contextLock, &surfaceTable, THREAD_UNINT);
			}
			differs = false;
			at = -1;
			// A deferred block of the asker's surface is its block, held again where dormant, and
			// so is a cached block in place of it that the asker maps where it asks, its pages
			// wired by its cache.
			d = table.entries ? rgfxSurfaceFindDeferred(table, asker.object) : -1;
			const int32_t cachedAt =
			    d < 0 && table.entries && surfaceCache
			        ? rgfxSurfaceFindCached(table, asker.object, length, size, mapsSurface)
			        : -1;
			if (cachedAt >= 0)
				d = cachedAt;
			if (d >= 0) {
				RgfxSurfaceEntry &de = table.entries[d];
				if (de.size != size || de.length != length) {
					differs = true;
					break;
				}
				// Held new by another of the client's asks, its share not yet posted, or let go
				// by a hold whose unshare is not yet posted: held once it is
				// (rgfxSurfaceAskWaits).
				if (rgfxSurfaceAskWaits(de, blockTable, client)) {
					IOLockSleep(contextLock, &surfaceTable, THREAD_UNINT);
					continue;
				}
				if (de.dormant) {
					revived = reviveBlockOfSurface(de, surfaceId);
					if (!revived) {
						release |= letGoDormant(static_cast<UInt32>(d), kRgfxDormantStale);
						continue;
					}
				}
				at = d;
				heldBySurface = cachedAt >= 0;
				break;
			}
			// No pages, no deferred block: a new one is deferred where its surface is fresh
			// still, and fits the budget. The surface is counted again out of the lock, and the
			// pass looks again under it.
			const bool fits =
			    !count && defer && rgfxSurfaceDeferFits(table, length, deferredBudget);
			if (fits && !countedHere) {
				IOLockUnlock(contextLock);
				fresh = rgfxSurfaceLocksFresh(asker.object, length, listed);
				IOLockLock(contextLock);
				countedNow = true;
				continue;
			}
			if (!count && (!fits || !fresh)) {
				needPages = true;
				break;
			}
			at = table.entries && count
			         ? rgfxSurfaceFind(table, runs, count, length, size, inPlace, &differs)
			         : -1;
			if (at >= 0 && table.entries[at].dormant) {
				revived = reviveSurfaceBlock(table.entries[at], asker.object, surfaceId);
				if (revived)
					break;
				release |= letGoDormant(static_cast<UInt32>(at), kRgfxDormantStale);
				continue;
			}
			const int32_t meeting =
			    at < 0 && differs ? rgfxSurfaceDormantMeeting(table, runs, count) : -1;
			if (meeting >= 0) {
				release |= letGoDormant(static_cast<UInt32>(meeting), kRgfxDormantStale);
				continue;
			}
			if (at >= 0 && rgfxSurfaceAskWaits(table.entries[at], blockTable, client)) {
				IOLockSleep(contextLock, &surfaceTable, THREAD_UNINT);
				continue;
			}
			if (at >= 0 || differs || !table.entries)
				break;
			// A new block in place of a surface whose previous block's release is unanswered
			// waits for it: the host copies that block's cache into the pages first, before
			// anything of this block may use them. Then the ask looks again, its surface fresh or
			// not, found by its pages or not.
			const RgfxNewBlockStep writeBack = rgfxCacheNewBlockStep(
			    inPlace && !writeBackLate && rgfxSurfaceCacheWritingBack(asker.object),
			    writeBackGaveUp);
			if (writeBack == kRgfxNewBlockWait) {
				if (!writeBackFrom) {
					writeBackFrom = mach_absolute_time();
					releaseStats.writeBackWaits++;
				}
				// Its release posted first, where this ask let its block go.
				if (release)
					thread_call_enter(releaseCall);
				release = false;
				IOLockUnlock(contextLock);
				writeBackGaveUp = !rgfxSurfaceCacheAwaitWriteBack(this, asker.object);
				IOLockLock(contextLock);
				continue;
			}
			if (writeBack == kRgfxNewBlockLate) {
				writeBackLate = true;
				releaseStats.writeBackLate++;
			}
			// A new block in place holds the runs past the span the processes map
			// (rgfxSurfaceRunsFrom), whole pages of them; a deferred one room for one run a
			// page of the plane.
			const UInt64 runBytes = sizeof(RgfxPageRun) * static_cast<UInt64>(count);
			total = !inPlace ? size
			        : count  ? rgfxSurfaceRunsFrom(size) + alignUp(runBytes, kPage)
			                 : rgfxSurfaceRunsFrom(size) + rgfxSurfaceRunRoom(length);
			// A new block: a dormant one gives its entry where the table is full, and the
			// region's room where it has none, its release waited for a while, once.
			slot = rgfxSurfaceFreeEntry(table);
			// Where the device caches every surface, a full table grows by a chunk, its
			// entries never moving, before a dormant block gives its entry.
			if (slot < 0 && cacheEvery && rgfxSurfaceMayGrow(table)) {
				const size_t bytes = sizeof(RgfxSurfaceEntry) * kRgfxSurfaceChunkEntries;
				auto *chunk = static_cast<RgfxSurfaceEntry *>(IOMalloc(bytes));
				if (chunk)
					bzero(chunk, bytes);
				if (rgfxSurfaceGrow(table, chunk)) {
					dormantStats.tableChunks++;
					dormantStats.changes++;
					slot = rgfxSurfaceFreeEntry(table);
				} else if (chunk) {
					IOFree(chunk, bytes);
				}
			}
			if (slot < 0) {
				const int32_t oldest = rgfxSurfaceOldestDormant(table);
				if (oldest >= 0) {
					release |= letGoDormant(static_cast<UInt32>(oldest), kRgfxDormantTableFull);
					slot = rgfxSurfaceFreeEntry(table);
				}
			}
			made = slot < 0 ? kRgfxBlockTableFull
			                : rgfxBlockAlloc(blockTable, &table.entries[slot], context, total,
			                                 kPage, &offset, &pin, client->isWindowServer());
			if (made != kRgfxBlockNoSpace)
				break;
			// No room: dormant blocks go once, and the ask waits for room until its deadline,
			// whatever else wakes it meanwhile (rgfxSurfaceRoomStep).
			const RgfxSurfaceRoomStep step =
			    rgfxSurfaceRoomStep(roomDeadline, table.dormantCount, mach_absolute_time());
			if (step == kRgfxSurfaceRoomGiveUp)
				break;
			if (step == kRgfxSurfaceRoomLetGoAndWait) {
				waitedForRoom = true;
				releaseStats.roomWaits++;
				for (UInt32 n = 0; n < kDormantRoomBlocks; n++) {
					const int32_t oldest = rgfxSurfaceOldestDormant(table);
					if (oldest < 0)
						break;
					release |= letGoDormant(static_cast<UInt32>(oldest), kRgfxDormantNoSpace);
				}
				if (release)
					thread_call_enter(releaseCall);
				release = false;
				clock_interval_to_deadline(kDormantRoomMs, kMillisecondScale, &roomDeadline);
			}
			IOLockSleepDeadline(contextLock, &surfaceTable, roomDeadline, THREAD_UNINT);
		}
		if (!needPages)
			break;
		IOLockUnlock(contextLock);
		defer = false;
		wire = true;
	}
	if (waitedForRoom && made == kRgfxBlockNoSpace)
		releaseStats.roomWaitsFailed++;
	if (release)
		thread_call_enter(releaseCall);
	if (at >= 0) {
		// Another process's plane, or a dormant one held again: this client holds its block
		// too, in its window from its first hold, mapped under the lock so no let-go of the
		// hold comes between. A block held again is fresh to its holders. A deferred block's
		// holders hold no pages: the asker's, where it wired them, go.
		RgfxSurfaceEntry &e = table.entries[at];
		dormantStats.foundBySurface += heldBySurface;
		IOMemoryDescriptor *own = e.deferred ? pages : nullptr;
		if (own)
			pages = nullptr;
		RgfxSurfaceHoldResult held = rgfxSurfaceHold(e, client, context, pages);
		// Where the device caches every surface, a block whose holds are full takes more, twice
		// as many past the entry's own each time, rather than refuse the holder.
		if (held == kRgfxSurfaceHoldFull && cacheEvery) {
			const uint32_t more =
			    e.holds.moreCapacity ? 2 * e.holds.moreCapacity : kRgfxSurfaceHolders;
			auto *grown = static_cast<RgfxSurfaceHold *>(IOMalloc(sizeof(RgfxSurfaceHold) * more));
			uint32_t oldCapacity = 0;
			RgfxSurfaceHold *old = rgfxSurfaceGrowHolds(e, grown, more, &oldCapacity);
			if (grown && old != grown) {
				dormantStats.holdsGrown++;
				dormantStats.changes++;
				held = rgfxSurfaceHold(e, client, context, pages);
			}
			if (old)
				IOFree(old, sizeof(RgfxSurfaceHold) * oldCapacity);
		}
		*block = {e.offset, e.size, e.serial, revived, e.cached};
		IOReturn mapped = kIOReturnSuccess;
		bool keptWire = false;
		if (held == kRgfxSurfaceHoldNew) {
			mapped = client->mapSpan(e.offset, rgfxWindowSpanLength(e.size));
			if (mapped != kIOReturnSuccess) {
				// No hold the device was not told of, nor one not in the window; a block held
				// again goes, holding none.
				void *mine = nullptr;
				UInt32 c = 0;
				rgfxSurfaceLetGo(e, client, true, &mine, &c);
				client->unmapSpan(e.offset, rgfxWindowSpanLength(e.size));
				held = kRgfxSurfaceHoldFull;
				if (!e.holdCount && letGoBlock(e, context, false, mine, &keptWire))
					thread_call_enter(releaseCall);
			}
		}
		IOLockUnlock(contextLock);
		freeRuns(runs, count);
		unwire(own);
		if (held != kRgfxSurfaceHoldNew) {
			if (!keptWire)
				unwire(pages);
			if (mapped != kIOReturnSuccess)
				return refused(kRgfxCopyRefusedMap, mapped);
			if (held != kRgfxSurfaceHoldAgain)
				return refused(kRgfxCopyRefusedHolders, kIOReturnNoResources);
			// Another ask of the client's: its copy block is counted at its first.
			return kIOReturnSuccess;
		}
		RgfxBlockGrant share = {};
		share.context = context;
		share.offset = block->offset;
		share.size = block->size;
		IOReturn posted = postLifecycle(RGFX_CMD_BLOCK_SHARE, &share, sizeof(share), 0, nullptr,
		                                0, nullptr, nullptr, 0);
		// The client's other asks of the block, waiting for the share (rgfxSurfaceSharing), hold
		// it again, or find it no longer held.
		void *mine = nullptr;
		UInt32 c = 0;
		bool shareKeptWire = false;
		IOLockLock(contextLock);
		release = false;
		const int32_t again = rgfxSurfaceAt(table, block->offset);
		if (posted == kIOReturnSuccess) {
			if (again >= 0)
				rgfxSurfaceShared(table.entries[again], client);
		} else {
			// No hold the device was not told of: let it go again.
			RgfxSurfaceLetGo gone = again >= 0 ? rgfxSurfaceLetGo(table.entries[again], client,
			                                                      true, &mine, &c)
			                                   : kRgfxSurfaceLetGoNotHeld;
			if (gone != kRgfxSurfaceLetGoNotHeld)
				client->unmapSpan(block->offset, rgfxWindowSpanLength(block->size));
			if (gone == kRgfxSurfaceLetGoLast)
				release = letGoBlock(table.entries[again], c, false, mine, &shareKeptWire);
		}
		IOLockWakeup(contextLock, &surfaceTable, false);
		IOLockUnlock(contextLock);
		if (!shareKeptWire)
			unwire(mine);
		if (release)
			thread_call_enter(releaseCall);
		if (revived)
			noteDormant();
		// The asker holds the surface: the processes see its clients counted anew.
		if (posted == kIOReturnSuccess && block->cached)
			rgfxSurfaceCacheNoteClients(block->offset);
		if (posted == kIOReturnSuccess && !inPlace && cacheEvery)
			noteFallbackCopy(false, length, size);
		return posted == kIOReturnSuccess ? posted : refused(kRgfxCopyRefusedShare, posted);
	}
	if (made != kRgfxBlockOk) {
		IOLockUnlock(contextLock);
		freeRuns(runs, count);
		unwire(pages);
		if (differs)
			return refused(kRgfxCopyRefusedDiffers, kIOReturnBadArgument);
		return made == kRgfxBlockNoSpace ? refused(kRgfxCopyRefusedRoom, kIOReturnNoSpace)
		                                 : refused(kRgfxCopyRefusedTable, kIOReturnNoResources);
	}
	RgfxSurfaceEntry &e = table.entries[slot];
	e.used = true;
	e.offset = offset;
	e.size = size;
	e.serial = pin.serial;
	e.inPlace = inPlace;
	e.pending = inPlace;
	e.length = length;
	e.runs = runs;
	e.runCount = count;
	// A block in place with no pages is deferred, its surface its key from here on.
	const bool deferring = inPlace && !count;
	if (deferring) {
		e.surface = asker.object;
		asker.object = nullptr;
		e.surfaceId = surfaceId;
		rgfxSurfaceDefer(table, e);
	}
	rgfxSurfaceHold(e, client, context, pages);
	*block = {offset, size, pin.serial, true, false};
	// In the client's window, under the lock, so no let-go of the hold comes between: the part
	// the processes map, never the runs. A block that is not goes back as if never made: the
	// device was not told of it. That part is zeroed first, as allocBlock's spans are: whatever
	// the region's last holder of it left there, the surface's bytes reach it only from its
	// holders' copies and from the device (RgfxBlockZero.hpp).
	const RgfxZeroSpan span = rgfxSurfaceZeroSpan(offset, size);
	UInt64 mapNs = 0, storeNs = 0;
	const UInt64 zeroFrom = mach_absolute_time();
	const bool zeroed = zeroSpan(region, span, &mapNs, &storeNs);
	rgfxZeroNote(zeroStats, inPlace ? kRgfxZeroSurfaceHeader : kRgfxZeroSurfaceCopy,
	             span.length, nanosSince(zeroFrom, mach_absolute_time()), mapNs, storeNs, zeroed);
	IOReturn mapped = zeroed ? client->mapSpan(span.offset, span.length) : kIOReturnNoMemory;
	if (mapped != kIOReturnSuccess) {
		OSObject *deferredSurface = deferring ? static_cast<OSObject *>(e.surface) : nullptr;
		client->unmapSpan(offset, rgfxWindowSpanLength(size));
		rgfxBlockDrop(blockTable, pin);
		rgfxSurfaceClear(table, e);
		if (inPlace)
			IOLockWakeup(contextLock, &surfaceTable, false);
		IOLockUnlock(contextLock);
		freeRuns(runs, count);
		unwire(pages);
		OSSafeReleaseNULL(deferredSurface);
		return refused(kRgfxCopyRefusedMap, mapped);
	}
	IOLockUnlock(contextLock);
	if (writeBackLate)
		IOLog("RGFX: WARN: IOSurface %u's new block 0x%llx goes on after %llu ms with its previous "
		      "block's release unanswered, %s: the host's copy of that block's cache into the "
		      "pages may land over this block's\n",
		      surfaceId, offset, nanosSince(writeBackFrom, mach_absolute_time()) / 1000000,
		      deviceAnswers() ? "its thread aborted" : "the device stopped");
	// The device learns of the block before any process does; it is pinned until then, so no
	// release overtakes the share. A block in place first hands the device its surface's pages,
	// and goes as a share not posted goes where the device maps none of them: the process makes
	// a copy instead.
	// A block in place may be cached: its surface's device cache is made before the device
	// learns of the block, so its CPU generation counts from the start. A deferred one is cached
	// with no pages, or has them named now (deferSurfaceBlock). Where the device answers which
	// surfaces need a cache (askCache), a cacheable block asks first, with its surface's layout,
	// and is cached only where the device answers RGFX_STATUS_CACHE: its pages are then posted
	// again, cached, the device keeping no view of them meanwhile. One asked with no layout (an
	// older bundle's) stays in place, as every block of such a device did. Where the device asks
	// nothing, a cached block's message carries the layout, which places its cache on the host
	// (rgfxPagesCarryLayout).
	// Where the device caches every surface, a block in place asks nothing: it is cached, or
	// goes back as if never made, as one not mapped does, with nothing posted, and its asker
	// copies the surface (unmade).
	const bool asks = askCache && !cacheEvery;
	auto unmade = [&] {
		IOLockLock(contextLock);
		client->unmapSpan(offset, rgfxWindowSpanLength(size));
		rgfxBlockDrop(blockTable, pin);
		rgfxSurfaceClear(table, e);
		IOLockWakeup(contextLock, &surfaceTable, false);
		IOLockUnlock(contextLock);
		freeRuns(runs, count);
		unwire(pages);
		return refused(kRgfxCopyRefusedNoCache, kIOReturnNotReady);
	};
	// Why a block in place the device refused was not made, where it caches every surface.
	RgfxCopyRefusal why = kRgfxCopyRefusedShare;
	bool cached = false;
	IOReturn posted = kIOReturnSuccess;
	if (deferring) {
		if (!deferSurfaceBlock(e, context, surfaceId, total, layout, task, address, resident,
		                       &cached)) {
			if (cacheEvery && !cached)
				return unmade();
			posted = kIOReturnUnsupported;
			why = kRgfxCopyRefusedHost;
		}
	} else {
		const bool ask = inPlace && asks && cacheable && surfaceId && layout;
		cached = inPlace && !asks && surfaceCache && cacheable && surfaceId &&
		         cacheSurface(e, task, surfaceId, offset);
		if (inPlace && cacheEvery && !cached)
			return unmade();
		UInt32 status = RGFX_STATUS_OK;
		const bool carried = rgfxPagesCarryLayout(layout != nullptr, ask, cached, asks);
		if (inPlace && !postSurfacePages(context, offset, total, size, length, runs, count,
		                                 cached, carried ? layout : nullptr, &status)) {
			if (ask && status == RGFX_STATUS_CACHE) {
				cached = cacheSurface(e, task, surfaceId, offset);
				if (postPages(context, offset, total, offset + rgfxSurfaceRunsFrom(size),
				              length, count, cached ? RGFX_SURFACE_PAGES_CACHED : 0) !=
				    kIOReturnSuccess)
					posted = kIOReturnUnsupported;
			} else {
				posted = kIOReturnUnsupported;
				why = kRgfxCopyRefusedHost;
			}
		}
	}
	block->cached = cached;
	if (posted == kIOReturnSuccess) {
		RgfxBlockGrant share = {};
		share.context = context;
		share.offset = offset;
		share.size = size;
		posted = postLifecycle(RGFX_CMD_BLOCK_SHARE, &share, sizeof(share), 0, nullptr, 0,
		                       nullptr, nullptr, 0);
	}
	void *mine = nullptr;
	release = false;
	bool keptWire = false;
	IOLockLock(contextLock);
	rgfxBlockUnpin(blockTable, pin);
	if (posted != kIOReturnSuccess) {
		UInt32 c = 0;
		RgfxSurfaceLetGo gone = rgfxSurfaceLetGo(e, client, true, &mine, &c);
		if (gone != kRgfxSurfaceLetGoNotHeld)
			client->unmapSpan(offset, rgfxWindowSpanLength(size));
		if (gone == kRgfxSurfaceLetGoLast)
			release = letGoBlock(e, c, false, mine, &keptWire);
	}
	// The askers waiting for the answer, or for the asker's share (rgfxSurfaceSharing), find the
	// block, or none.
	if (e.used && e.offset == offset && e.serial == pin.serial) {
		if (inPlace)
			e.pending = false;
		rgfxSurfaceShared(e, client);
	}
	IOLockWakeup(contextLock, &surfaceTable, false);
	IOLockUnlock(contextLock);
	if (!keptWire)
		unwire(mine);
	if (release)
		thread_call_enter(releaseCall);
	if (client->isWindowServer())
		noteReserve();
	if (posted == kIOReturnSuccess && !inPlace && cacheEvery)
		noteFallbackCopy(true, length, size);
	return posted == kIOReturnSuccess ? posted : refused(why, posted);
}

void RgfxAccelerator::wakeReleases()
{
	if (!__atomic_load_n(&contextLock, __ATOMIC_ACQUIRE))
		return;
	// When the first dormant block asked to go, for the worker's reap of it (ReleaseStats), set
	// with no lock: the control function calls this holding IOSurface's lock (ContextState).
	UInt64 none = 0;
	__atomic_compare_exchange_n(&releaseStats.reapAskedAt, &none, mach_absolute_time(), false,
	                            __ATOMIC_RELAXED, __ATOMIC_RELAXED);
	thread_call_enter(releaseCall);
}

void RgfxAccelerator::retryRefusedBlocks()
{
	if (!contextLock)
		return;
	IOLockLock(contextLock);
	UInt32 n = rgfxBlockRetryRefused(blockTable, mach_absolute_time());
	IOLockUnlock(contextLock);
	if (n) {
		thread_call_enter(releaseCall);
		IOLog("RgfxAccelerator: %u refused block release(s) posted again after a context "
		      "close\n",
		      n);
	}
}

bool RgfxAccelerator::reviveSurfaceBlock(RgfxSurfaceEntry &e, OSObject *surface,
                                         uint32_t surfaceId)
{
	// The asker's surface is the dormant block's only where it is the surface the block holds,
	// with the block's device cache, the one IOSurface gives that surface for this accelerator:
	// the block's pages, which the ask found it by, are that surface's (rgfxSurfaceLocksAttach
	// checked them at the block's caching), and no other surface has the cache.
	if (!surfaceCache || !surfaceId || !e.runCount || !surface || surface != e.surface ||
	    !e.cache || !rgfxSurfaceRevives(e, e.cache, rgfxSurfaceCacheWake(e.cache)))
		return false;
	rgfxSurfaceWake(surfaceTable, e);
	e.surfaceId = surfaceId;
	dormantStats.revived++;
	dormantStats.changes++;
	return true;
}

bool RgfxAccelerator::cacheSurface(RgfxSurfaceEntry &e, task_t task, uint32_t surfaceId,
                                   UInt64 offset)
{
	void *surface = nullptr, *cache = nullptr;
	if (!rgfxSurfaceLocksAttach(this, task, surfaceId, e.runs[0].address, &surface, &cache))
		return false;
	// The header's page, where the kext writes the surface's CPU generation for the processes.
	IOMemoryMap *header = region->createMappingInTask(
	    kernel_task, 0, kIOMapAnywhere | kIOMapCopybackCache, offset, kPage);
	if (!header || !rgfxSurfaceCacheAdd(this, cache, surface, offset, surfaceId, header,
	                                    kRgfxSurfaceCpuGenOffset)) {
		if (header)
			header->release();
		// Not cached: the cache's reference and the surface's go.
		static_cast<OSObject *>(cache)->release();
		static_cast<OSObject *>(surface)->release();
		return false;
	}
	// Whether the block's runs are the surface's memory from its first byte, which the cache
	// holds wired now: an ask of the surface that maps it so finds the block by the surface
	// (rgfxSurfaceFindCached).
	const bool start = rgfxSurfaceLocksStartsAt(static_cast<OSObject *>(surface), e.runs,
	                                            e.runCount, e.length);
	// The entry is pending until the device answers its pages, so no other asker reads these,
	// and nothing lets it go meanwhile (deferSurfaceBlock).
	IOLockLock(contextLock);
	e.surface = surface;
	e.cache = cache;
	e.surfaceId = surfaceId;
	e.cached = true;
	e.surfaceStart = start;
	IOLockUnlock(contextLock);
	return true;
}

bool RgfxAccelerator::reviveBlockOfSurface(RgfxSurfaceEntry &e, uint32_t surfaceId)
{
	// The surface is the block's own, found by it: its device cache is the block's, held, the
	// only one IOSurface gives the surface for this accelerator.
	if (!rgfxSurfaceRevives(e, e.cache, rgfxSurfaceCacheWake(e.cache)))
		return false;
	rgfxSurfaceWake(surfaceTable, e);
	e.surfaceId = surfaceId;
	dormantStats.revived++;
	dormantStats.changes++;
	return true;
}

bool RgfxAccelerator::deferSurfaceBlock(RgfxSurfaceEntry &e, UInt32 context, uint32_t surfaceId,
                                        UInt64 total, const RgfxSurfacePagesLayout *layout,
                                        task_t task, UInt64 address,
                                        const RgfxSurfaceResident *resident, bool *cached)
{
	// The entry is pending until the device answers its pages, so no other asker reads it. Nor
	// does anything let it go meanwhile, so `e` is this block's still under the contexts' lock
	// taken again: its hold is the asker's alone, which a release refuses while it is pending,
	// and another ask, of any client, waits for; the asker's client's close waits for the
	// client's asks in flight, this one among them, before it lets go of anything (RgfxAskGate.hpp);
	// and the dormant blocks' let-gos pass over it. None of this rests on IOKit ordering a close
	// after a call in flight: the user client sets no IOUserClientDefaultLocking.
	OSObject *surface = static_cast<OSObject *>(e.surface);
	const UInt64 offset = e.offset, size = e.size, length = e.length;
	// The header's page, where the kext writes the surface's CPU generation for the processes.
	IOMemoryMap *header = region->createMappingInTask(
	    kernel_task, 0, kIOMapAnywhere | kIOMapCopybackCache, offset, kPage);
	void *cache = nullptr;
	// The deferral's runs where it carries resident pages of the surface (RgfxDeferCarry.hpp):
	// a run a page at most, and one of zeros before each and at the end.
	RgfxPageRun carried[2 * kRgfxCarryPagesMost + 1] = {};
	UInt32 carriedCount = 0;
	const RgfxDeferAnswer answer =
	    header ? rgfxSurfaceLocksDefer(this, surface, surfaceId, offset, size, length, context,
	                                   header, task, address, resident, carried,
	                                   sizeof(carried) / sizeof(carried[0]), &carriedCount,
	                                   &cache)
	           : kRgfxDeferNoCache;
	// Not cached: its surface is looked up anew at its first write named, as any block's, and the
	// entry's reference goes once its pages are named.
	OSObject *uncached = answer == kRgfxDeferNoCache ? surface : nullptr;
	IOLockLock(contextLock);
	if (uncached) {
		e.surface = nullptr;
	} else {
		e.cache = cache;
		e.cached = true;
	}
	IOLockUnlock(contextLock);
	if (uncached)
		OSSafeReleaseNULL(header);
	*cached = !uncached;
	// Where the device caches every surface, a block not cached names no pages: the caller lets
	// it go as if never made, nothing posted.
	if (uncached && cacheEvery) {
		OSSafeReleaseNULL(uncached);
		return false;
	}
	// Where the device answers which surfaces need a cache, and does not cache every surface,
	// the block asks with its surface's layout, at its deferral and at its naming: the host
	// defers only a block that would need a cache whatever its pages, and a block whose pages it
	// then takes in place is not cached.
	const bool asks = askCache && !cacheEvery;
	const RgfxSurfacePagesLayout *asking = asks ? layout : nullptr;
	// Where the device asks nothing, a cached block's messages carry the surface's layout, which
	// places its cache on the host (rgfxPagesCarryLayout).
	const RgfxSurfacePagesLayout *carriedLayout =
	    rgfxPagesCarryLayout(layout != nullptr, false, *cached, asks) ? layout : nullptr;
	// A deferral that carries pages names them in its runs, past the part the processes map, in
	// the room the block keeps for one run a page: one whose runs could not be written names its
	// pages now, as a refused one does, nothing read of the carried pages.
	const bool runsWritten = !carriedCount ||
	                         writeRuns(region, offset + rgfxSurfaceRunsFrom(size), carried,
	                                   carriedCount);
	if (answer == kRgfxDeferFresh && !runsWritten)
		rgfxSurfaceLocksRefusedCarry(cache);
	if (answer == kRgfxDeferFresh && runsWritten) {
		UInt32 status = RGFX_STATUS_OK;
		const UInt32 flags = RGFX_SURFACE_PAGES_CACHED | RGFX_SURFACE_PAGES_DEFERRED |
		                     (asking ? RGFX_SURFACE_PAGES_ASK_CACHE : 0);
		const IOReturn r = postPages(context, offset, total, offset + rgfxSurfaceRunsFrom(size),
		                             length, carriedCount, flags, &status,
		                             asking ? asking : carriedLayout);
		if (r == kIOReturnSuccess || r != kIOReturnUnsupported || status != RGFX_STATUS_REFUSED) {
			// Deferred, or not answered: a block whose answer did not come goes through its
			// release, its region bytes given out again only at an OK answer. No guest page was
			// named, so nothing the host may touch is given back.
			rgfxSurfaceCacheSettle(cache, true);
			IOLockLock(contextLock);
			dormantStats.deferred += r == kIOReturnSuccess;
			dormantStats.changes++;
			IOLockUnlock(contextLock);
			// Once per kind a boot: a surface's every block meets the same cause.
			static char unanswered;
			if (r != kIOReturnSuccess &&
			    rgfxFirstCalls(&unanswered, (static_cast<UInt64>(r) << 32) | status, 1))
				IOLog("RgfxAccelerator: the deferred block 0x%llx was not answered (0x%x, status "
				      "%u): it goes\n",
				      offset, r, status);
			return r == kIOReturnSuccess;
		}
		IOLockLock(contextLock);
		dormantStats.deferredRefused++;
		dormantStats.changes++;
		IOLockUnlock(contextLock);
		// The host made nothing, so it reads none of the pages the deferral carried.
		rgfxSurfaceLocksRefusedCarry(cache);
	}
	// Not fresh, refused, or with no cache: the block's pages are named now, as any block's in
	// place, and its asker's hold wires them as any holder's. Where the device answers which
	// surfaces need a cache they ask, as a block not deferred does: answered that it needs one,
	// they are named again cached; answered in place, the surface is not cached after all, its
	// cache's entry goes, and the entry's reference of the surface goes once they are named.
	// Where the device asks nothing, a cached block's pages carry the surface's layout.
	IOMemoryDescriptor *memory = OSDynamicCast(IOMemoryDescriptor, rgfxIOSurfaceMemory(surface));
	RgfxPageRun *runs = nullptr;
	UInt32 count = 0;
	bool inPlace = false;
	const RgfxPagesNaming naming =
	    memory ? attachSurfacePages(context, offset, size, length, memory,
	                                *cached ? RGFX_SURFACE_PAGES_CACHED : 0, &runs, &count,
	                                asking, &inPlace, carriedLayout)
	           : kRgfxPagesNotNamed;
	if (inPlace && *cached) {
		rgfxSurfaceLocksUngate(cache);
		IOLockLock(contextLock);
		e.cache = nullptr;
		e.cached = false;
		e.surface = nullptr;
		IOLockUnlock(contextLock);
		uncached = surface;
		*cached = false;
	}
	if (*cached)
		rgfxSurfaceCacheSettle(cache, naming != kRgfxPagesNamed);
	if (naming == kRgfxPagesUnanswered) {
		// The host may yet map the pages: the asker's hold takes the wiring the naming left, which
		// the block keeps as it goes until its release is answered OK.
		memory->retain();
		IOLockLock(contextLock);
		if (e.holdCount)
			e.holds[0].pages = memory;
		const bool held = e.holdCount != 0;
		IOLockUnlock(contextLock);
		static char unheld;
		if (!held && rgfxFirstCalls(&unheld, 0, 1))
			IOLog("RgfxAccelerator: the block 0x%llx's pages stay wired for good: no hold to "
			      "keep them\n",
			      offset);
	}
	if (naming != kRgfxPagesNamed) {
		OSSafeReleaseNULL(uncached);
		return false;
	}
	// The hold's wiring: the naming's where no cache keeps that, else one of its own
	// (rgfxAskHoldWiresAgain).
	IOMemoryDescriptor *held = memory;
	held->retain();
	if (rgfxAskHoldWiresAgain(*cached, naming) &&
	    held->prepare(kIODirectionOutIn) != kIOReturnSuccess)
		OSSafeReleaseNULL(held);
	IOLockLock(contextLock);
	rgfxSurfaceUndefer(surfaceTable, e, runs, count);
	// Its runs are its surface's memory from its first byte (attachSurfacePages).
	e.surfaceStart = true;
	if (e.holdCount)
		e.holds[0].pages = held;
	IOLockUnlock(contextLock);
	OSSafeReleaseNULL(uncached);
	return true;
}

RgfxPagesNaming RgfxAccelerator::attachSurfacePages(UInt32 context, UInt64 offset, UInt64 size,
                                                    UInt64 length, IOMemoryDescriptor *memory,
                                                    UInt32 flags, RgfxPageRun **runsOut,
                                                    UInt32 *countOut,
                                                    const RgfxSurfacePagesLayout *layout,
                                                    bool *inPlace,
                                                    const RgfxSurfacePagesLayout *carriedLayout)
{
	if (length > memory->getLength())
		return kRgfxPagesNotNamed;
#if defined(__x86_64__)
	faultTopDown(memory, length);
#endif
	if (memory->prepare(kIODirectionOutIn) != kIOReturnSuccess)
		return kRgfxPagesNotNamed;
	UInt32 count = 0;
	RgfxPageRun *runs = walkRuns(memory, 0, length, &count);
	// Its runs past the span its holders map (rgfxSurfaceRunsFrom).
	const UInt64 runsAt = offset + rgfxSurfaceRunsFrom(size);
	RgfxPagesNaming naming = kRgfxPagesNotNamed;
	const char *why = nullptr;
	if (!runs) {
		why = "its runs do not fit";
	} else if (!writeRuns(region, runsAt, runs, count)) {
		why = "its runs could not be written";
	} else {
		const UInt64 total = rgfxSurfaceRunsFrom(size) + rgfxSurfaceRunRoom(length);
		IOReturn r = kIOReturnSuccess;
		UInt32 status = RGFX_STATUS_OK;
		if (layout) {
			// The ask: in place where answered OK; named again with `flags` where the host
			// answered that the surface needs a device cache, the runs written already.
			r = postPages(context, offset, total, runsAt, length, count,
			              RGFX_SURFACE_PAGES_ASK_CACHE, &status, layout);
			if (r == kIOReturnSuccess && inPlace)
				*inPlace = true;
			else if (r == kIOReturnUnsupported && status == RGFX_STATUS_CACHE)
				r = postPages(context, offset, total, runsAt, length, count, flags);
		} else {
			r = postPages(context, offset, total, runsAt, length, count, flags, nullptr,
			              carriedLayout);
		}
		naming = rgfxPagesNaming(r == kIOReturnSuccess || r == kIOReturnUnsupported,
		                         r == kIOReturnSuccess);
		if (naming == kRgfxPagesNotNamed)
			why = "the device refused them";
		else if (naming == kRgfxPagesUnanswered)
			why = "they were not answered, and stay wired until the block's release is answered";
	}
	if (naming != kRgfxPagesNamed) {
		static char unnamed;
		if (rgfxFirstCalls(&unnamed, rgfxKeyOf(why), 1))
			IOLog("RgfxAccelerator: the block 0x%llx's pages (flags 0x%x) were not named: %s\n",
			      offset, flags, why);
		freeRuns(runs, count);
		// The host may yet take pages it did not answer for: those stay wired.
		if (!rgfxPagesNamingWired(naming))
			memory->complete(kIODirectionOutIn);
		return naming;
	}
	if (runsOut) {
		*runsOut = runs;
		*countOut = count;
	} else {
		freeRuns(runs, count);
	}
	return naming;
}

IOReturn RgfxAccelerator::downloadSurfaceCache(UInt64 offset, UInt32 timeoutMs)
{
	RgfxSurfaceDownload message = {};
	message.block_offset = offset;
	RgfxComplete answer = {};
	UInt32 answered = 0;
	IOReturn r = postLifecycle(RGFX_CMD_SURFACE_DOWNLOAD, &message, sizeof(message),
	                           RGFX_EVT_COMPLETE, &answer, sizeof(answer), &answered, nullptr,
	                           timeoutMs);
	if (r != kIOReturnSuccess)
		return r;
	return answered >= sizeof(answer) && answer.status == RGFX_STATUS_OK ? kIOReturnSuccess
	                                                                       : kIOReturnUnsupported;
}

bool RgfxAccelerator::postSurfacePages(UInt32 context, UInt64 offset, UInt64 total, UInt64 size,
                                       UInt64 length, const RgfxPageRun *runs, UInt32 count,
                                       bool cached, const RgfxSurfacePagesLayout *layout,
                                       UInt32 *status)
{
	if (!writeRuns(region, offset + rgfxSurfaceRunsFrom(size), runs, count)) {
		static char unwritten;
		if (rgfxFirstCalls(&unwritten, 0, 1))
			IOLog("RgfxAccelerator: the block 0x%llx's runs could not be written: its surface is "
			      "copied\n",
			      offset);
		return false;
	}
	const UInt32 flags = cached ? RGFX_SURFACE_PAGES_CACHED
	                     : layout ? RGFX_SURFACE_PAGES_ASK_CACHE
	                              : 0;
	IOReturn r = postPages(context, offset, total, offset + rgfxSurfaceRunsFrom(size), length,
	                       count, flags, status, layout);
	static char unanswered;
	if (r != kIOReturnSuccess && r != kIOReturnUnsupported &&
	    rgfxFirstCalls(&unanswered, static_cast<UInt32>(r), 1))
		IOLog("RgfxAccelerator: the block 0x%llx's pages were not answered (0x%x): its surface "
		      "is copied\n",
		      offset, r);
	return r == kIOReturnSuccess;
}

IOReturn RgfxAccelerator::postPages(UInt32 context, UInt64 offset, UInt64 total,
                                    UInt64 runsOffset, UInt64 length, UInt32 count, UInt32 flags,
                                    UInt32 *status, const RgfxSurfacePagesLayout *layout,
                                    UInt64 *gpuAddress)
{
	// The message, then where it has flags, the part that holds them, and where it has a layout,
	// the layout.
	struct {
		RgfxSurfacePages pages;
		RgfxSurfacePagesCache cache;
		RgfxSurfacePagesLayout layout;
	} message = {};
	static_assert(sizeof(RgfxSurfacePages) == RGFX_SURFACE_PAGES_CACHE_OFFSET,
	              "the cache's part follows the message");
	static_assert(__builtin_offsetof(decltype(message), layout) ==
	                  RGFX_SURFACE_PAGES_LAYOUT_OFFSET,
	              "the layout follows the cache's part");
	message.pages.context = context;
	message.pages.run_count = count;
	message.pages.block_offset = offset;
	message.pages.block_size = total;
	message.pages.runs_offset = runsOffset;
	message.pages.length = length;
#if RGFX_GUEST_ARM64
	// Where the kext took PAGES_16K: whole 16 KiB pages, as its runs are (writeRuns).
	if (pages16k)
		message.pages.length = rgfxToPageEnd(length, kRgfxPage16K);
#endif
	message.cache.flags = flags;
	if (layout)
		message.layout = *layout;
	const UInt32 bytes = layout  ? sizeof(message)
	                     : flags ? RGFX_SURFACE_PAGES_LAYOUT_OFFSET
	                             : sizeof(message.pages);
	// A COMPLETE, or for a pages block where the kext took IMPORT_ADDRESSES, an RgfxPagesAnswer,
	// which carries the GPU address of the block's view (rgfxPagesAnswer); 0 where it took
	// IMPORT_ADDRESSES_LATER too, the device answering before the view has one.
	RgfxPagesAnswer answer = {};
	UInt32 answered = 0;
	IOReturn r = postLifecycle(RGFX_CMD_SURFACE_PAGES, &message, bytes, RGFX_EVT_COMPLETE,
	                           &answer, sizeof(answer), &answered, nullptr,
	                           ReimsGraphics::kLifecycleUntilAnswered);
	UInt32 answeredStatus = 0;
	UInt64 at = 0;
	if (r == kIOReturnSuccess && !rgfxPagesAnswer(answer, answered, &answeredStatus, &at))
		r = kIOReturnTimeout;
	if (r != kIOReturnSuccess)
		return r;
	if (status)
		*status = answeredStatus;
	if (gpuAddress)
		*gpuAddress = at;
	return answeredStatus == RGFX_STATUS_OK ? kIOReturnSuccess : kIOReturnUnsupported;
}

IOReturn RgfxAccelerator::pagesBlock(RgfxAcceleratorUserClient *client, UInt32 context,
                                     task_t task, UInt64 address, UInt64 length, UInt64 how,
                                     UInt64 *offset, UInt64 *size, UInt64 *gpuAddress)
{
	if (!contextLock)
		return kIOReturnNotReady;
	// A device that maps no guest pages in place, or one that did not take the feature, makes
	// no pages block: the process copies the memory instead.
	if (!surfacePages || !region || !(featureWord() & RGFX_FEATURE_PAGES_BUFFERS))
		return kIOReturnUnsupported;
	// Read-only memory only where the host keeps the GPU's writes out of it: the GPU's writes
	// would otherwise land in pages the process cannot write, a file's among them; unchanging
	// memory only where the host knows its mark.
	const RgfxPagesWiring wiring = rgfxPagesWiring(how, featureWord());
	if (wiring.access == RgfxPagesAccess::kBadArgument)
		return kIOReturnBadArgument;
	if (wiring.access == RgfxPagesAccess::kRefused)
		return kIOReturnUnsupported;
	RgfxPagesRange range = {};
#if RGFX_GUEST_ARM64
	// Whole 16 KiB pages where the kext took PAGES_16K, as the bundle places its buffer at the
	// pointer's offset in such a page then.
	const UInt64 rangePage = pages16k ? kRgfxPage16K : kPage;
#else
	const UInt64 rangePage = kPage;
#endif
	if (!rgfxPagesRange(address, length, rangePage, &range))
		return kIOReturnBadArgument;
	// Wired for the block's life: writable memory for reading and writing, which resolves
	// copy-on-write first, so a private mapping's pages are its own before the device maps them;
	// read-only memory for reading alone (kIODirectionOut: the device reads the memory), which
	// asks of the VM system no access the process lacks, unchanging memory among it, whose
	// private mapping's pages the wire copies for the process (RgfxPagesBlock.hpp).
	const IODirection direction =
	    wiring.access == RgfxPagesAccess::kRead ? kIODirectionOut : kIODirectionOutIn;
	// Writable memory's make is counted from before its wire, so a sole holder's block made while
	// it is in flight sees it (soleHolderAlone).
	const bool writableMake = direction == kIODirectionOutIn;
	auto failMake = [writableMake](IOReturn r) {
		if (writableMake) {
			IOLockLock(contextLock);
			writableMakes--;
			IOLockUnlock(contextLock);
		}
		return r;
	};
	if (writableMake) {
		IOLockLock(contextLock);
		writableMakes++;
		IOLockUnlock(contextLock);
	}
	IOMemoryDescriptor *md =
	    IOMemoryDescriptor::withAddressRange(range.base, range.length, direction, task);
	if (!md)
		return failMake(kIOReturnNoMemory);
#if defined(__x86_64__)
	faultTopDown(task, range.base, range.length);
#endif
	if (md->prepare(direction) != kIOReturnSuccess) {
		md->release();
		return failMake(kIOReturnBadArgument);
	}
	if (wiring.soleHolder && !soleHolderAlone(md, range.length)) {
		md->complete(direction);
		md->release();
		return kIOReturnNotPermitted;
	}
	return pagesBlockOver(client, context, md, range.length, md, offset, size, wiring.flags,
	                      gpuAddress, writableMake);
}

IOReturn RgfxAccelerator::pagesChunked(RgfxAcceleratorUserClient *client, UInt32 context,
                                       task_t task, UInt64 length, UInt64 *address,
                                       UInt64 *offset, UInt64 *size)
{
	if (!contextLock)
		return kIOReturnNotReady;
	if (!surfacePages || !region || !(featureWord() & RGFX_FEATURE_PAGES_BUFFERS))
		return kIOReturnUnsupported;
	if (length == 0 || length % kRgfxPagesChunk != 0 || length > kRgfxPagesChunkedMaxBytes)
		return kIOReturnBadArgument;
	// The chunks, each a run of RAM of its own at a multiple of its bytes (kRgfxPagesChunkMask),
	// wired as the kernel's memory is, and zero-filled: the process sees them.
	const UInt32 count = static_cast<UInt32>(length / kRgfxPagesChunk);
	const vm_size_t listBytes = count * sizeof(IOMemoryDescriptor *);
	IOMemoryDescriptor **chunks = static_cast<IOMemoryDescriptor **>(IOMalloc(listBytes));
	if (!chunks)
		return kIOReturnNoMemory;
	UInt32 made = 0;
	for (; made < count; made++) {
		IOBufferMemoryDescriptor *chunk = IOBufferMemoryDescriptor::inTaskWithPhysicalMask(
		    kernel_task,
		    kIODirectionOutIn | kIOMemoryPhysicallyContiguous | kIOMemoryKernelUserShared,
		    kRgfxPagesChunk, kRgfxPagesChunkMask);
		if (!chunk)
			break;
		bzero(chunk->getBytesNoCopy(), kRgfxPagesChunk);
		chunks[made] = chunk;
	}
	IOMultiMemoryDescriptor *md =
	    made == count ? IOMultiMemoryDescriptor::withDescriptors(chunks, count, kIODirectionOutIn,
	                                                             false)
	                  : nullptr;
	// The descriptor holds the chunks it was made of.
	for (UInt32 i = 0; i < made; i++)
		chunks[i]->release();
	IOFree(chunks, listBytes);
	if (!md)
		return refuseChunks(made < count ? "the kernel gave too few chunks" : "no descriptor",
		                    made, count);
	if (md->prepare(kIODirectionOutIn) != kIOReturnSuccess) {
		md->release();
		return refuseChunks("the chunks were not prepared", count, count);
	}
	// The process's mapping of them, read and write, which holds them from here on: the block's,
	// unmapped and let go of where it is unwired (unwire).
	IOMemoryMap *map = md->createMappingInTask(task, 0, kIOMapAnywhere);
	if (!map) {
		md->complete(kIODirectionOutIn);
		md->release();
		return refuseChunks("the process got no mapping of them", count, count);
	}
	md->release();
	const UInt64 at = map->getAddress();
	const IOReturn r = pagesBlockOver(client, context, md, length, map, offset, size,
	                                  RGFX_SURFACE_PAGES_PRIVATE, nullptr);
	if (r == kIOReturnSuccess)
		*address = at;
	return r;
}

IOReturn RgfxAccelerator::pagesBlockOver(RgfxAcceleratorUserClient *client, UInt32 context,
                                         IOMemoryDescriptor *md, UInt64 length, void *wired,
                                         UInt64 *offset, UInt64 *size, UInt32 flags,
                                         UInt64 *gpuAddress, bool writableMake)
{
	auto segment = [md](uint64_t at, uint64_t *bytes) -> uint64_t {
		IOByteCount n = 0;
		const addr64_t phys = md->getPhysicalSegment(at, &n, kIOMemoryMapperNone);
		*bytes = n;
		return phys;
	};
	const uint32_t count = rgfxPagesRuns(length, segment, nullptr, 0);
	if (!count) {
		unwire(wired);
		if (writableMake) {
			IOLockLock(contextLock);
			writableMakes--;
			IOLockUnlock(contextLock);
		}
		return kIOReturnBadArgument;
	}
	// The client's block, holding the wired pages from here on, and pinned until the device has
	// its grant. It is never in the client's window: the process never sees a guest physical
	// address. A writable make's count ends here, its block in the table or failed.
	const UInt64 bytes = rgfxPagesBlockSize(count, kPage);
	RgfxBlockPin pin = {};
	UInt64 at = 0;
	IOLockLock(contextLock);
	const RgfxBlockResult made = rgfxBlockAlloc(blockTable, client, context, bytes, kPage, &at,
	                                            &pin, client->isWindowServer());
	if (made == kRgfxBlockOk)
		rgfxBlockSetWired(blockTable, at, wired);
	if (writableMake)
		writableMakes--;
	IOLockUnlock(contextLock);
	if (made != kRgfxBlockOk) {
		unwire(wired);
		if (made == kRgfxBlockNoSpace)
			return kIOReturnNoSpace;
		return made == kRgfxBlockTableFull ? kIOReturnNoResources : kIOReturnBadArgument;
	}
	// The runs, written straight into the block through a kernel mapping of it, write-back as
	// the device reads the region.
	bool written = false;
	if (IOMemoryMap *map = region->createMappingInTask(
	        kernel_task, 0, kIOMapAnywhere | kIOMapCopybackCache, at, bytes)) {
		auto *runs = reinterpret_cast<RgfxPageRun *>(map->getVirtualAddress());
		written = rgfxPagesRuns(length, segment, runs, count) == count;
		map->release();
	}
	UInt64 viewAddress = 0;
	IOReturn r = written ? postPages(context, at, bytes, at, length, count, flags, nullptr,
	                                 nullptr, &viewAddress)
	                     : kIOReturnUnsupported;
	// The device has no view of a block it never heard of, or refused: the block goes back as if
	// never made, and its pages are unwired.
	if (!written || r == kIOReturnUnsupported) {
		void *dropped = nullptr;
		IOLockLock(contextLock);
		const int64_t i = rgfxBlockIndex(blockTable, at);
		if (i >= 0 && blockTable.blocks[i].serial == pin.serial) {
			dropped = blockTable.blocks[i].wired;
			rgfxBlockDrop(blockTable, pin);
		}
		IOLockUnlock(contextLock);
		unwire(dropped);
		return kIOReturnUnsupported;
	}
	if (r == kIOReturnSuccess) {
		RgfxBlockGrant grant = {};
		grant.context = context;
		grant.offset = at;
		grant.size = bytes;
		r = postLifecycle(RGFX_CMD_BLOCK_GRANT, &grant, sizeof(grant), 0, nullptr, 0, nullptr,
		                  nullptr, 0);
	}
	IOLockLock(contextLock);
	rgfxBlockUnpin(blockTable, pin);
	// Pages not answered, or a grant not posted: the device may have a view of the pages, so the
	// block goes through its release, which drops the view, and is unwired at its answer.
	const bool release =
	    r != kIOReturnSuccess &&
	    rgfxBlockFree(blockTable, client, at, mach_absolute_time()) == kRgfxBlockOk;
	IOLockUnlock(contextLock);
	if (release)
		thread_call_enter(releaseCall);
	if (r != kIOReturnSuccess) {
		IOLog("RgfxAccelerator: context %u's pages block 0x%llx (%u runs of 0x%llx bytes) was "
		      "not answered or granted (0x%x): it is released, and the memory copied\n",
		      context, at, count, length, r);
		return kIOReturnUnsupported;
	}
	*offset = at;
	*size = bytes;
	if (gpuAddress)
		*gpuAddress = viewAddress;
	return kIOReturnSuccess;
}

IOReturn RgfxAccelerator::releaseSurfaceBlock(RgfxAcceleratorUserClient *client, UInt64 offset)
{
	if (!contextLock)
		return kIOReturnNotReady;
	RgfxSurfaceTable &table = surfaceTable;
	IOLockLock(contextLock);
	int32_t at = table.entries ? rgfxSurfaceAt(table, offset) : -1;
	// A block in place waiting for the device's answer is no process's to let go yet: its
	// maker reads its runs until then, and no process has learnt of it.
	if (at >= 0 && table.entries[at].pending)
		at = -1;
	void *pages = nullptr;
	UInt32 context = 0;
	RgfxSurfaceLetGo gone = at < 0 ? kRgfxSurfaceLetGoNotHeld
	                               : rgfxSurfaceLetGo(table.entries[at], client, false, &pages,
	                                                  &context);
	UInt64 size = at < 0 ? 0 : table.entries[at].size;
	UInt64 serial = at < 0 ? 0 : table.entries[at].serial;
	// Out of the client's window once its hold ends, before the block can be anyone else's.
	if (gone == kRgfxSurfaceLetGoHold || gone == kRgfxSurfaceLetGoLast)
		client->unmapSpan(offset, rgfxWindowSpanLength(size));
	bool release = false, slept = false, keptWire = false;
	OSObject *sleeper = nullptr;
	if (gone == kRgfxSurfaceLetGoLast) {
		slept = sleepBlock(table.entries[at], context, &sleeper);
		if (!slept)
			release = letGoBlock(table.entries[at], context, false, pages, &keptWire);
	}
	// The hold's BLOCK_UNSHARE is posted out of the lock. Until it is, the block's release and
	// every new hold of it wait for it (rgfxBlockBeginUnshare), so the device never carries it
	// out after this context's next share of the block, or of a block given its span again.
	const bool unsharing = gone == kRgfxSurfaceLetGoHold || slept;
	RgfxBlockPin unshareMark = {};
	const bool marked = unsharing && rgfxBlockBeginUnshare(blockTable, offset, &unshareMark);
	IOLockUnlock(contextLock);
	if (unsharing) {
		// Other holders keep it, or it sleeps: the device no longer lets this context name it.
		RgfxBlockGrant unshare = {};
		unshare.context = context;
		unshare.offset = offset;
		unshare.size = size;
		postLifecycle(RGFX_CMD_BLOCK_UNSHARE, &unshare, sizeof(unshare), 0, nullptr, 0, nullptr,
		              nullptr, 0);
	}
	if (marked) {
		IOLockLock(contextLock);
		release |= rgfxBlockEndUnshare(blockTable, unshareMark);
		IOLockWakeup(contextLock, &surfaceTable, false);
		IOLockUnlock(contextLock);
	}
	if (slept)
		release |= wakeSlept(offset, serial, sleeper);
	// An in-place block's pages stay wired until its release is answered (the block owns the
	// wire now); else unwire the last holder's here.
	if (!keptWire)
		unwire(pages);
	if (release)
		thread_call_enter(releaseCall);
	if (slept)
		noteDormant();
	return gone == kRgfxSurfaceLetGoNotHeld ? kIOReturnBadArgument : kIOReturnSuccess;
}

RgfxAccelerator::SurfaceCacheAnswer
RgfxAccelerator::surfaceDeviceCache(RgfxAcceleratorUserClient *client, task_t task,
                                    UInt64 offset, uint32_t surfaceId, void **cache,
                                    OSObject **surface, bool *inPlace)
{
	if (!contextLock)
		return kSurfaceCacheNotHeld;
	RgfxSurfaceTable &table = surfaceTable;
	// A held block with no device cache yet has its surface's made out of the contexts' lock
	// (ContextState's lock order), for the block of that serial and first page, and the entry is
	// read again under the lock: the block that takes the attach is the one it was made for, and
	// an attach no block takes is released out of the lock, the cache's first.
	void *madeCache = nullptr, *madeSurface = nullptr;
	bool attached = false, tried = false;
	UInt64 madeSerial = 0, madeAt = 0;
	SurfaceCacheAnswer answer = kSurfaceCacheMade;
	IOLockLock(contextLock);
	for (;;) {
		const int32_t at = table.entries ? rgfxSurfaceAt(table, offset) : -1;
		RgfxSurfaceEntry *e = at >= 0 ? &table.entries[at] : nullptr;
		answer = kSurfaceCacheMade;
		if (!e || (!e->runCount && !e->deferred) || !rgfxSurfaceHeldBy(table, client, offset, 1))
			answer = kSurfaceCacheNotHeld;
		else if (e->pending)
			answer = kSurfaceCachePending;
		const bool needed = answer == kSurfaceCacheMade && !e->cache && !e->noCache;
		if (needed && (!tried || e->serial != madeSerial || e->runs[0].address != madeAt)) {
			madeSerial = e->serial;
			madeAt = e->runs[0].address;
			IOLockUnlock(contextLock);
			if (madeCache)
				static_cast<OSObject *>(madeCache)->release();
			if (madeSurface)
				static_cast<OSObject *>(madeSurface)->release();
			madeCache = madeSurface = nullptr;
			attached = rgfxSurfaceLocksAttach(this, task, surfaceId, madeAt, &madeSurface,
			                                  &madeCache);
			tried = true;
			IOLockLock(contextLock);
			continue;
		}
		if (needed) {
			e->noCache = !attached;
			if (attached) {
				e->surface = madeSurface;
				e->cache = madeCache;
				e->surfaceId = surfaceId;
				madeCache = madeSurface = nullptr;
			}
		}
		if (answer == kSurfaceCacheMade && !e->cache)
			answer = kSurfaceCacheNone;
		else if (answer == kSurfaceCacheMade && e->surfaceId != surfaceId)
			answer = kSurfaceCacheOtherSurface;
		if (answer == kSurfaceCacheMade) {
			*cache = e->cache;
			static_cast<OSObject *>(e->cache)->retain();
			*surface = static_cast<OSObject *>(e->surface);
			(*surface)->retain();
			*inPlace = e->inPlace;
		}
		break;
	}
	IOLockUnlock(contextLock);
	if (madeCache)
		static_cast<OSObject *>(madeCache)->release();
	if (madeSurface)
		static_cast<OSObject *>(madeSurface)->release();
	return answer;
}

void RgfxAccelerator::dropSurfaceBlocks(const void *client, bool closed)
{
	if (!contextLock)
		return;
	RgfxSurfaceTable &table = surfaceTable;
	bool release = false;
	UInt32 dropped = 0;
	for (UInt32 i = 0; i < table.capacity; i++) {
		void *pages = nullptr;
		UInt32 context = 0;
		IOLockLock(contextLock);
		RgfxSurfaceLetGo gone =
		    table.entries[i].used
		        ? rgfxSurfaceLetGo(table.entries[i], client, true, &pages, &context)
		        : kRgfxSurfaceLetGoNotHeld;
		// The device ended the context's holds at its close; the last holder's block goes as
		// its blocks go, or sleeps where cached, or is kept where the close was not answered.
		const UInt64 offset = table.entries[i].offset, serial = table.entries[i].serial;
		bool slept = false, keptWire = false;
		OSObject *sleeper = nullptr;
		if (gone == kRgfxSurfaceLetGoLast) {
			slept = closed && sleepBlock(table.entries[i], context, &sleeper);
			if (!slept)
				release |= letGoBlock(table.entries[i], context, !closed, pages, &keptWire);
		}
		IOLockUnlock(contextLock);
		if (gone != kRgfxSurfaceLetGoNotHeld)
			dropped++;
		// The device ended the hold already: no BLOCK_UNSHARE.
		if (slept)
			release |= wakeSlept(offset, serial, sleeper);
		// An in-place block kept for its release holds the wire now; else unwire it here.
		if (!keptWire)
			unwire(pages);
	}
	if (release)
		thread_call_enter(releaseCall);
	if (dropped)
		IOLog("RgfxAccelerator: %u shared surface blocks let go at a close\n", dropped);
	noteDormant();
}

// MARK: - The queues' completion rings

IOMemoryMap *RgfxAccelerator::mapRingHeader(UInt64 offset, volatile UInt8 **header)
{
	if (!region || offset % 8 || offset + RGFX_RING_HEADER_SIZE > regionSize)
		return nullptr;
	// The header's page or pages, write-back as the bundle maps the region.
	UInt64 page = offset & ~(kPage - 1);
	UInt64 length = alignUp(offset + RGFX_RING_HEADER_SIZE, kPage) - page;
	IOMemoryMap *map = region->createMappingInTask(kernel_task, 0,
	                                               kIOMapAnywhere | kIOMapCopybackCache, page,
	                                               length);
	if (map)
		*header = reinterpret_cast<volatile UInt8 *>(map->getVirtualAddress()) + (offset - page);
	return map;
}

IOReturn RgfxAccelerator::watchQueue(RgfxAcceleratorUserClient *client, UInt64 objId,
                                     UInt64 completeOffset)
{
	if (!contextLock || !region || completeOffset % 8 ||
	    completeOffset + RGFX_RING_HEADER_SIZE > regionSize)
		return kIOReturnBadArgument;
	volatile UInt8 *header = nullptr;
	IOMemoryMap *map = mapRingHeader(completeOffset, &header);
	if (!map)
		return kIOReturnNoMemory;
	IOLockLock(watchLock);
	if (!rgfxWatchAdmitted(watchedCount, client->isWindowServer())) {
		IOLockUnlock(watchLock);
		map->release();
		IOLog("RgfxAccelerator: queue 0x%llx: every watched ring is taken\n", objId);
		return kIOReturnNoResources;
	}
	IOInterruptState is = IOSimpleLockLockDisableInterrupt(filterLock);
	RgfxWatchedRing &w = watched[watchedCount++];
	w.client = client;
	w.objId = objId;
	w.map = map;
	w.header = header;
	w.lastProducer = loadHeader64(header, kRingProducer);
	w.filterProducer = w.lastProducer;
	IOSimpleLockUnlockEnableInterrupt(filterLock, is);
	bool hook = !hooked;
	hooked = true;
	IOLockUnlock(watchLock);
	// The first watched ring has the framebuffer call queueFilter and queueInterrupt from now on.
	if (hook) {
		ReimsGraphics *fb = copyFramebuffer();
		if (fb) {
			fb->setQueueInterrupt(this, &queueInterruptHook, &queueFilterHook);
			fb->release();
		} else {
			IOLockLock(watchLock);
			hooked = false;
			IOLockUnlock(watchLock);
		}
	}
	return kIOReturnSuccess;
}

void RgfxAccelerator::unwatchQueue(RgfxAcceleratorUserClient *client, UInt64 objId)
{
	if (!watchLock)
		return;
	IOMemoryMap *map = nullptr;
	IOLockLock(watchLock);
	for (UInt32 i = 0; i < watchedCount; i++) {
		if (watched[i].client == client && watched[i].objId == objId) {
			map = watched[i].map;
			IOInterruptState is = IOSimpleLockLockDisableInterrupt(filterLock);
			watched[i] = watched[--watchedCount];
			IOSimpleLockUnlockEnableInterrupt(filterLock, is);
			break;
		}
	}
	IOLockUnlock(watchLock);
	if (map) {
		// The queue's writes go with it: none of its buffers holds a lock any more.
		forgetQueueWrites(objId);
		map->release();
	}
}

void RgfxAccelerator::unwatchClient(RgfxAcceleratorUserClient *client)
{
	if (!watchLock)
		return;
	IOLockLock(watchLock);
	for (UInt32 i = 0; i < watchedCount;) {
		if (watched[i].client == client) {
			// Released under the lock, out of the table first: neither scan meets a ring whose
			// map is gone, nor the filter's a client let go.
			forgetQueueWrites(watched[i].objId);
			IOMemoryMap *map = watched[i].map;
			IOInterruptState is = IOSimpleLockLockDisableInterrupt(filterLock);
			watched[i] = watched[--watchedCount];
			IOSimpleLockUnlockEnableInterrupt(filterLock, is);
			map->release();
		} else {
			i++;
		}
	}
	IOLockUnlock(watchLock);
}

// On the framebuffer's work loop, once per pass over the control ring: the device raised its
// vector, for a completion on some queue's ring or the control ring's. A ring whose producer
// moved since the last look and that holds records its client has not taken wakes the client,
// unless the vector's filter has looked at that producer (RgfxQueueWakes.hpp).
void RgfxAccelerator::queueInterrupt()
{
	if (!watchLock)
		return;
	IOLockLock(watchLock);
	for (UInt32 i = 0; i < watchedCount; i++) {
		RgfxWatchedRing &w = watched[i];
		const UInt64 producer = loadHeader64(w.header, kRingProducer);
		if (rgfxLoopWakes(&w.lastProducer, &w.filterProducer, producer,
		                  [&w] { return loadHeader64(w.header, kRingConsumer); }))
			w.client->wakeCompletions();
	}
	IOLockUnlock(watchLock);
	// A lock waiting for a surface drawn in place looks at the completions again.
	rgfxSurfaceLocksWake();
}

// At primary interrupt context, from the vector's filter (ReimsGraphics::filterAction), with
// interrupts disabled: the first look at each watched ring, which wakes its client as the
// interrupt arrives, so the client's completion thread is not woken by the work loop's look,
// after the work loop's thread is scheduled and has taken the control ring. It takes filterLock
// and each woken client's completion lock, spin locks that every other holder takes with
// interrupts disabled, and nothing else: no allocation, no release, no blocking lock. A ring's
// header mapping and its client stay while its entry is in the table.
void RgfxAccelerator::queueFilter()
{
	if (!filterLock)
		return;
	IOSimpleLockLock(filterLock);
	for (UInt32 i = 0; i < watchedCount; i++) {
		RgfxWatchedRing &w = watched[i];
		if (rgfxFilterWakes(&w.filterProducer, loadHeader64(w.header, kRingProducer),
		                    [&w] { return loadHeader64(w.header, kRingConsumer); }))
			w.client->wakeCompletions();
	}
	IOSimpleLockUnlock(filterLock);
}

UInt64 RgfxAccelerator::queueCompleted(UInt64 objId)
{
	if (!watchLock)
		return 0;
	UInt64 completed = 0;
	IOLockLock(watchLock);
	for (UInt32 i = 0; i < watchedCount; i++) {
		if (watched[i].objId == objId) {
			completed = loadHeader64(watched[i].header, kRingCompletedSeqno);
			break;
		}
	}
	IOLockUnlock(watchLock);
	return completed;
}

// MARK: - The object lifecycle

IOReturn RgfxAccelerator::postLifecycle(UInt32 type, const void *message, UInt32 size,
                                        UInt32 replyType, void *reply, UInt32 replyCapacity,
                                        UInt32 *replyLength, UInt64 *seqno, UInt32 timeoutMs)
{
	ReimsGraphics *fb = copyFramebuffer();
	if (!fb)
		return kIOReturnNotReady;
	IOReturn r = fb->postLifecycle(type, message, size, replyType, reply, replyCapacity,
	                               replyLength, seqno, timeoutMs);
	fb->release();
	return r;
}

bool RgfxAccelerator::deviceAnswers()
{
	ReimsGraphics *fb = copyFramebuffer();
	const bool up = fb && fb->answers();
	OSSafeReleaseNULL(fb);
	return up;
}

IOReturn RgfxAccelerator::postRun(UInt32 type, const void *messages, UInt32 size, UInt32 count,
                                  UInt32 *posted)
{
	*posted = 0;
	ReimsGraphics *fb = copyFramebuffer();
	if (!fb)
		return kIOReturnNotReady;
	IOReturn r = fb->postRun(type, messages, size, count, nullptr, posted);
	fb->release();
	return r;
}

IOReturn RgfxAccelerator::postDeferred(UInt32 context, UInt32 type, const void *message,
                                       UInt32 size, UInt64 *seqno, const UInt8 *key)
{
	ReimsGraphics *fb = copyFramebuffer();
	if (!fb)
		return kIOReturnNotReady;
	IOReturn r = fb->postDeferred(context, type, message, size, seqno, key);
	fb->release();
	return r;
}

IOReturn RgfxAccelerator::takeDeferred(UInt32 context, UInt64 waitFor, UInt32 timeoutMs,
                                       UInt8 *out, UInt32 capacity, UInt32 *length,
                                       UInt32 *count)
{
	ReimsGraphics *fb = copyFramebuffer();
	if (!fb)
		return kIOReturnNotReady;
	IOReturn r = fb->takeDeferred(context, waitFor, timeoutMs, out, capacity, length, count);
	fb->release();
	return r;
}

void RgfxAccelerator::dropDeferred(UInt32 context)
{
	ReimsGraphics *fb = copyFramebuffer();
	if (!fb)
		return;
	fb->dropDeferred(context);
	fb->release();
}

void RgfxAccelerator::forgetDeferred(UInt64 seqno)
{
	ReimsGraphics *fb = copyFramebuffer();
	if (!fb)
		return;
	fb->forgetDeferred(seqno);
	fb->release();
}

bool RgfxAccelerator::findSharedPipeline(const UInt8 *key, UInt64 seqno, UInt64 objId,
                                         RgfxPipelineReflection *out)
{
	ReimsGraphics *fb = copyFramebuffer();
	if (!fb)
		return false;
	const bool found = fb->findSharedPipeline(key, seqno, objId, out);
	fb->release();
	return found;
}

void RgfxAccelerator::learnSharedPipeline(const UInt8 *reply, UInt32 length)
{
	ReimsGraphics *fb = copyFramebuffer();
	if (!fb)
		return;
	fb->learnSharedPipeline(reply, length);
	fb->release();
}

UInt32 RgfxAccelerator::openQueue(const RgfxQueueCreate &create, UInt32 flags)
{
	struct {
		RgfxQueueCreate create;
		RgfxQueueCreateFlags tail;
	} message = {};
	static_assert(sizeof(message) == RGFX_QUEUE_CREATE_FLAGS_OFFSET + sizeof(RgfxQueueCreateFlags),
	              "the tail follows the create");
	message.create = create;
	message.tail.flags = flags;
	const UInt32 size = flags ? sizeof(message) : sizeof(create);
	RgfxComplete answer = {};
	UInt32 length = 0;
	IOReturn r = postLifecycle(RGFX_CMD_QUEUE_CREATE, &message, size, RGFX_EVT_COMPLETE, &answer,
	                           sizeof(answer), &length, nullptr,
	                           ReimsGraphics::kLifecycleUntilAnswered);
	if (r != kIOReturnSuccess || length < sizeof(answer)) {
		IOLog("RgfxAccelerator: queue 0x%llx: no answer to its create (0x%x)\n", create.obj_id, r);
		return RGFX_STATUS_INVALID_ARGUMENT;
	}
	return answer.status;
}

void RgfxAccelerator::closeQueue(UInt64 objId)
{
	RgfxObjectDestroy destroy = {};
	destroy.obj_id = objId;
	postLifecycle(RGFX_CMD_OBJECT_DESTROY, &destroy, sizeof(destroy), 0, nullptr, 0, nullptr,
	              nullptr, 0);
}
