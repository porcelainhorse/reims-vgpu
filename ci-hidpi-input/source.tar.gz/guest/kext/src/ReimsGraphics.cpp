/*
 * ReimsGraphics: the reims-graphics device's display driver (ReimsGraphics.hpp
 * says what it does and on which threads).
 */

#include "ReimsGraphics.hpp"
#include "RgfxAccelerator.hpp"
#include "RgfxAnswerLook.hpp"
#include "RgfxBootConsole.hpp"
#include "RgfxCompletionArm.hpp"
#include "RgfxControlRing.hpp"
#include "RgfxDisplayPower.hpp"
#include "RgfxFeatures.hpp"
#include "RgfxLifecycleAnswers.hpp"
#include "RgfxPat.hpp"
#include "RgfxPipeColor.hpp"
#include "RgfxPointerDevice.hpp"
#include "RgfxRegionMapping.hpp"

#include <IOKit/IOLib.h>
#include <IOKit/IOMessage.h>
#include <IOKit/IOPlatformExpert.h>
#include <IOKit/IOUserClient.h>
#include <kern/clock.h>
#include <kern/task.h>
#include <kern/task_ref.h>
#include <kern/thread.h>
#include <libkern/libkern.h>
#include <libkern/OSKextLib.h>

#include "RgfxAccelTypes.hpp"
#include "RgfxDisplayIdentity.hpp"
#include "RgfxTrace.hpp"

#if defined(__x86_64__)
#define super IOFramebuffer
OSDefineMetaClassAndStructors(ReimsGraphics, IOFramebuffer);
#else
#define super IOMobileFramebufferLegacy
OSDefineMetaClassAndStructors(ReimsGraphics, IOMobileFramebufferLegacy);
#endif

namespace {

// The control ring's byte ring is a power of two, so an index wraps with a mask.
constexpr UInt32 kRingBytes = RGFX_CONTROL_RING_DATA_SIZE;
constexpr UInt32 kRingMask = kRingBytes - 1;
static_assert((kRingBytes & kRingMask) == 0, "the ring size is not a power of two");
constexpr UInt32 kHeaderBytes = sizeof(RgfxMsgHeader);

// A message's size is a multiple of this.
constexpr UInt32 kMsgAlign = 8;

// What a call naming a mode or depth the framebuffer does not hold answers (RgfxDisplayModes.hpp).
static_assert(kRgfxIOReturnError == static_cast<uint32_t>(kIOReturnError) &&
                  kRgfxIOReturnUnsupportedMode == static_cast<uint32_t>(kIOReturnUnsupportedMode),
              "RgfxDisplayModes.hpp's statuses are IOReturn's");
#if defined(__x86_64__)
// A mode the device no longer shows (RgfxDisplayModes.hpp).
static_assert(kRgfxModeNeverShowFlag == kDisplayModeNeverShowFlag,
              "RgfxDisplayModes.hpp's never-show flag is IOGraphicsTypes.h's");
// The display's connection is built in (RgfxDisplayIdentity.hpp).
static_assert(kRgfxDisplayConnectionFlags == kIOConnectionBuiltIn,
              "RgfxDisplayIdentity.hpp's connection flags are IOGraphicsTypes.h's built-in one");
IOReturn noSuchMode(RgfxModeCall call)
{
	return static_cast<IOReturn>(rgfxNoSuchModeStatus(call));
}
#endif

// The ring header's fields, by their offset in it (each in a 64-byte line).
constexpr UInt32 kRingProducer = __builtin_offsetof(RgfxRingHeader, producer);
constexpr UInt32 kRingConsumer = __builtin_offsetof(RgfxRingHeader, consumer);
constexpr UInt32 kRingConsumerIdle = __builtin_offsetof(RgfxRingHeader, consumer_idle);
constexpr UInt32 kRingProducerWaiting = __builtin_offsetof(RgfxRingHeader, producer_waiting);
constexpr UInt32 kRingArmed = __builtin_offsetof(RgfxRingHeader, armed);
constexpr UInt32 kRingGuestClockOffset = __builtin_offsetof(RgfxRingHeader, guest_clock_offset_ns);
constexpr UInt32 kRingGuestClockBound = __builtin_offsetof(RgfxRingHeader, guest_clock_bound_ns);

// Scanout rows start on 256-byte boundaries, as the option ROM's do, so the
// boot frame keeps its layout when the driver takes the display over.
constexpr UInt32 kStrideAlign = 256;
constexpr UInt32 kMaxDimension = kRgfxDisplayMaxDimension;

// How long a command waits for ring space, and then for its answer. Both keep a deadline, as
// neither waits for the host's work: the ring's room frees as the host's reader takes messages
// off it into the contexts' lanes, which it does behind no compile, so a ring full for 5 s is a
// host that stopped reading; and the asks answered within kAnswerTimeoutMs are the display's
// commands, which the host's display answers on no context's lane, and the kept pipeline
// answers at the start (seedSharedPipelines), which the host reads from its store before any
// process runs, a short seed costing only a cold compile later. A wait behind a compile has no
// deadline (RgfxAnswerWait.hpp).
constexpr UInt32 kPostTimeoutMs = 5000;
constexpr UInt32 kAnswerTimeoutMs = 5000;
// How often the control ring's room line is logged at most, while posts sleep for room: a summary,
// at most once a minute (docs/conventions.md).
constexpr UInt32 kRoomLogMs = 60000;

// Answers carry the device's status; a payload the driver cannot read is
// answered with this one.
constexpr UInt32 kStatusUnreadable = 0xffffffff;

// The ring's header fields: atomic, as the protocol orders them.
inline UInt64 load64(const volatile UInt8 *p)
{
	return __atomic_load_n(reinterpret_cast<const volatile UInt64 *>(p), __ATOMIC_ACQUIRE);
}

inline void store64(volatile UInt8 *p, UInt64 value)
{
	__atomic_store_n(reinterpret_cast<volatile UInt64 *>(p), value, __ATOMIC_RELEASE);
}

inline UInt32 load32(const volatile UInt8 *p)
{
	return __atomic_load_n(reinterpret_cast<const volatile UInt32 *>(p), __ATOMIC_ACQUIRE);
}

inline void store32(volatile UInt8 *p, UInt32 value)
{
	__atomic_store_n(reinterpret_cast<volatile UInt32 *>(p), value, __ATOMIC_RELEASE);
}

inline void fullFence()
{
	__atomic_thread_fence(__ATOMIC_SEQ_CST);
}

// Ring 0's submit ring as RgfxControlRing.hpp writes it: the rings' mapping, and the
// write-combined one of the data's span (null where none was made: every word then goes through
// the rings' mapping).
struct ControlWords {
	volatile UInt8 *rings;
	volatile UInt8 *combined;

	void data(UInt32 at, UInt64 word, bool viaCombined)
	{
		volatile UInt8 *p = viaCombined && combined ? combined + (at - kRgfxControlWcFrom)
		                                            : rings + at;
		*reinterpret_cast<volatile UInt64 *>(p) = word;
	}
	void storeFence() { rgfxStoreFence(); }
	void publish(UInt64 count) { store64(rings + RGFX_CONTROL_SUBMIT_OFFSET + kRingProducer, count); }
	void fullFence() { ::fullFence(); }
	UInt32 consumerIdle() { return load32(rings + RGFX_CONTROL_SUBMIT_OFFSET + kRingConsumerIdle); }
};

// A payload's 32-bit field, little-endian as x86-64 is.
inline UInt32 field32(const volatile UInt8 *payload, UInt32 offset)
{
	return *reinterpret_cast<const volatile UInt32 *>(payload + offset);
}

#if RGFX_FB_TRACE
// A trace line, logged for a site's first `limit` calls.
#define FBTRACE(limit, fmt, ...)                                                             \
	do {                                                                                 \
		static UInt32 traced_;                                                       \
		if (__atomic_fetch_add(&traced_, 1, __ATOMIC_RELAXED) < (limit))           \
			IOLog("RGFX fb " fmt "\n", ##__VA_ARGS__);                          \
	} while (0)

#if defined(__x86_64__)
// An attribute's call, logged for the first few calls of each (kind, attribute). Its callers, the
// IOFramebuffer attribute methods, are x86-64's alone.
void traceAttribute(const char *kind, IOIndex connect, IOSelect attribute, uintptr_t value,
                    IOReturn r)
{
	struct Seen {
		const char *kind;
		IOSelect attribute;
		UInt32 count;
	};
	static Seen seen[128];
	UInt32 i = 0;
	for (; i < 128 && seen[i].kind; i++) {
		if (seen[i].kind == kind && seen[i].attribute == attribute)
			break;
	}
	if (i == 128)
		return;
	if (!seen[i].kind) {
		seen[i].kind = kind;
		seen[i].attribute = attribute;
	}
	if (seen[i].count++ >= 4)
		return;
	char cc[5];
	for (int b = 0; b < 4; b++) {
		char c = static_cast<char>((attribute >> (24 - 8 * b)) & 0xff);
		cc[b] = c >= 0x20 && c < 0x7f ? c : '.';
	}
	cc[4] = 0;
	IOLog("RGFX fb %s conn %d '%s' (0x%x) value 0x%lx -> 0x%x\n", kind, static_cast<int>(connect),
	      cc, attribute, static_cast<unsigned long>(value), r);
}
#endif
#else
#define FBTRACE(...) do {} while (0)
#if defined(__x86_64__)
inline void traceAttribute(const char *, IOIndex, IOSelect, uintptr_t, IOReturn) {}
#endif
#endif

// The guest's clock in nanoseconds, which RgfxVblankClock maps the host's stamps in, and back: an
// x86-64 guest's mach_absolute_time counts nanoseconds, and an arm64 guest's its timebase's ticks.
inline UInt64 clockNs(UInt64 absolute)
{
#if defined(__arm64__)
	UInt64 ns = 0;
	absolutetime_to_nanoseconds(absolute, &ns);
	return ns;
#else
	return absolute;
#endif
}

inline UInt64 clockAbsolute(UInt64 ns)
{
#if defined(__arm64__)
	UInt64 absolute = 0;
	nanoseconds_to_absolutetime(ns, &absolute);
	return absolute;
#else
	return ns;
#endif
}

} // namespace

// MARK: - Registers and the control rings

UInt32 ReimsGraphics::readRegister(UInt32 offset) const
{
	return rgfxRegisterRead32(registers + offset);
}

void ReimsGraphics::writeRegister(UInt32 offset, UInt32 value)
{
	rgfxRegisterWriteBarrier();
	rgfxRegisterWrite32(registers + offset, value);
}

volatile UInt8 *ReimsGraphics::ring(UInt32 offset) const
{
	return rings + offset;
}

// Puts one command on ring 0 if it fits, without blocking: callable with a
// spin lock held. The doorbell rings only when the host's consumer sleeps. A head's
// commands go on display 0's ring, as do all of the ring's calls below.
bool ReimsGraphics::tryPost(UInt32 type, const void *message, UInt32 size, UInt64 *seqno,
                            UInt64 *waiterSeqno)
{
	if (isHead())
		return device->tryPost(type, message, size, seqno, waiterSeqno);
	if (size < kHeaderBytes || size % kMsgAlign || size > kLifecycleMessageMax || !ready)
		return false;
	IOSimpleLockLock(submitLock);
	const bool written = writeLocked(type, message, size, seqno, waiterSeqno);
	const bool bell = written && publishLocked();
	IOSimpleLockUnlock(submitLock);
	if (bell)
		ringControl();
	return written;
}

// Writes one command at the producer's place if it fits, submitLock held, without publishing
// it: false where the ring has no room for it.
bool ReimsGraphics::writeLocked(UInt32 type, const void *message, UInt32 size, UInt64 *seqno,
                                UInt64 *waiterSeqno)
{
	volatile UInt8 *header = ring(RGFX_CONTROL_SUBMIT_OFFSET);
	ControlWords words = {rings, controlData};
	UInt64 used = produced - load64(header + kRingConsumer);
	UInt32 offset = static_cast<UInt32>(produced) & kRingMask;
	UInt32 tail = kRingBytes - offset;
	UInt32 pad = tail < size ? tail : 0;
	if (used > kRingBytes || kRingBytes - used < static_cast<UInt64>(pad) + size)
		return false;
	if (pad) {
		// A message never wraps: type 0 pads to the ring's end. When 8
		// bytes are left, they hold its type and size alone.
		const UInt32 padHeader[4] = {RGFX_MSG_PAD, pad, 0, 0};
		rgfxControlWrite(words, offset, padHeader, pad >= kHeaderBytes ? 16 : 8);
		produced += pad;
		offset = 0;
	}
	UInt64 s = nextSeqno++;
	if (waiterSeqno)
		__atomic_store_n(waiterSeqno, s, __ATOMIC_RELEASE);
	// The caller filled the payload fields; the header is stamped here.
	const RgfxMsgHeader h = {type, size, s};
	rgfxControlWrite(words, offset, &h, kHeaderBytes);
	rgfxControlWrite(words, offset + kHeaderBytes, static_cast<const UInt8 *>(message) + kHeaderBytes,
	                 size - kHeaderBytes);
	produced += size;
	if (seqno)
		*seqno = s;
	return true;
}

// Publishes what writeLocked wrote, submitLock held, after it: whether the host's consumer sleeps,
// and ringControl is to wake it once the lock is let go (rgfxControlPublishWantsBell).
bool ReimsGraphics::publishLocked()
{
	ControlWords words = {rings, controlData};
	return rgfxControlPublishWantsBell(words, produced);
}

// Ring 0's doorbell, out of submitLock: its write exits to the host, which no other CPU's post
// waits out.
void ReimsGraphics::ringControl()
{
	writeRegister(RGFX_REG_DOORBELL, RGFX_CONTROL_RING_ID);
}

// Puts one command on ring 0, waiting for space (waitForRoom): thread context only. A message
// that can never fit is refused at once.
IOReturn ReimsGraphics::post(UInt32 type, const void *message, UInt32 size, UInt64 *seqno,
                             UInt64 *waiterSeqno)
{
	if (isHead())
		return device->post(type, message, size, seqno, waiterSeqno);
	if (size < kHeaderBytes || size % kMsgAlign || size > kLifecycleMessageMax)
		return kIOReturnBadArgument;
	uint64_t deadline = 0;
	clock_interval_to_deadline(kPostTimeoutMs, kMillisecondScale, &deadline);
	for (;;) {
		const UInt64 mark = roomMark();
		if (tryPost(type, message, size, seqno, waiterSeqno))
			return kIOReturnSuccess;
		if (!ready)
			return kIOReturnNotReady;
		if (askForRoom() && tryPost(type, message, size, seqno, waiterSeqno))
			return kIOReturnSuccess;
		if (!waitForRoom(mark, deadline)) {
			// Once per command type a boot: every post meets a ring that stays full.
			static char site;
			if (rgfxFirstCalls(&site, type, 1))
				IOLog("ReimsGraphics: command %u: the control ring stayed full\n", type);
			return ready ? kIOReturnTimeout : kIOReturnNotReady;
		}
	}
}

UInt64 ReimsGraphics::roomMark() const
{
	return rgfxRingRoomMark(isHead() ? device->room : room);
}

bool ReimsGraphics::askForRoom()
{
	if (isHead())
		return device->askForRoom();
	if (!submitRoom)
		return false;
	store32(ring(RGFX_CONTROL_SUBMIT_OFFSET) + kRingProducerWaiting, 1);
	fullFence();
	return true;
}

bool ReimsGraphics::waitForRoom(UInt64 mark, uint64_t deadline)
{
	if (isHead())
		return device->waitForRoom(mark, deadline);
	uint64_t backstop = 0;
	nanoseconds_to_absolutetime(static_cast<uint64_t>(rgfxRingRoomBackstopUs(submitRoom)) * 1000,
	                            &backstop);
	rgfxRingRoomWait(room);
	bool log = false;
	RgfxRingRoomStats seen = {};
	IOLockLock(stateLock);
	if (ready && rgfxRingRoomSleeps(room, mark)) {
		const uint64_t from = mach_absolute_time();
		const wait_result_t r = IOLockSleepDeadline(
		    stateLock, &room, rgfxRingRoomSleepUntil(from, backstop, deadline), THREAD_UNINT);
		uint64_t ns = 0, nowNs = 0;
		const uint64_t to = mach_absolute_time();
		absolutetime_to_nanoseconds(to - from, &ns);
		absolutetime_to_nanoseconds(to, &nowNs);
		log = rgfxRingRoomNote(roomStats, ns, r == THREAD_AWAKENED, nowNs,
		                       static_cast<uint64_t>(kRoomLogMs) * 1000000ull);
		seen = roomStats;
	}
	IOLockUnlock(stateLock);
	rgfxRingRoomDone(room);
	if (log)
		IOLog("ReimsGraphics: control ring room: %llu sleeps (%llu woken by a pass), %llu us "
		      "asleep in all, %llu us at most; %llu SUBMIT_ROOM records taken\n",
		      seen.sleeps, seen.woken, seen.sleptNs / 1000, seen.mostNs / 1000,
		      __atomic_load_n(&roomRecords, __ATOMIC_RELAXED));
	return ready && mach_absolute_time() < deadline;
}

// Sends a display-control command and waits for its answer, COMPLETE or DISPLAYS, which the
// work loop hands over: thread context only, never on the work loop.
IOReturn ReimsGraphics::command(UInt32 type, const void *message, UInt32 size)
{
	if (isHead())
		return device->command(type, message, size);
	uint64_t deadline = 0;
	clock_interval_to_deadline(kAnswerTimeoutMs, kMillisecondScale, &deadline);
	// Take a waiter first, so the answer finds this thread by seqno once the message is on the
	// ring; a free one frees up with the shared array as its event.
	ControlWaiter *w = nullptr;
	IOLockLock(stateLock);
	while (!w && ready) {
		for (UInt32 i = 0; i < kControlWaiters && !w; i++) {
			if (!controlWaiters[i].waiting)
				w = &controlWaiters[i];
		}
		if (!w && IOLockSleepDeadline(stateLock, controlWaiters, deadline, THREAD_UNINT) ==
		              THREAD_TIMED_OUT)
			break;
	}
	if (!w) {
		const bool up = ready;
		IOLockUnlock(stateLock);
		if (!up)
			return kIOReturnNotReady;
		IOLog("ReimsGraphics: command %u: every control waiter is taken\n", type);
		return kIOReturnBusy;
	}
	w->waiting = true;
	w->seqno = 0;
	w->status = 0;
	w->done = false;
	IOLockUnlock(stateLock);

	UInt64 s = 0;
	IOReturn r = post(type, message, size, &s, &w->seqno);
	IOLockLock(stateLock);
	while (r == kIOReturnSuccess && !w->done) {
		if (!ready)
			r = kIOReturnNotReady;
		else if (IOLockSleepDeadline(stateLock, &w->done, deadline, THREAD_UNINT) ==
		             THREAD_TIMED_OUT &&
		         !w->done)
			r = kIOReturnTimeout;
	}
	UInt32 status = w->status;
	w->waiting = false;
	w->seqno = 0;
	// A slot freed: the free event is the shared array, the slot seekers'.
	IOLockWakeup(stateLock, controlWaiters, false);
	IOLockUnlock(stateLock);

	// Once per command type, and status, a boot.
	if (r == kIOReturnTimeout) {
		static char unanswered;
		if (rgfxFirstCalls(&unanswered, type, 1))
			IOLog("ReimsGraphics: command %u (seqno %llu): no answer\n", type, s);
		return kIOReturnTimeout;
	}
	if (r != kIOReturnSuccess)
		return r;
	if (status != 0) {
		static char refused;
		if (rgfxFirstCalls(&refused, (static_cast<UInt64>(type) << 32) | status, 1))
			IOLog("ReimsGraphics: command %u (seqno %llu): status %u\n", type, s, status);
		return kIOReturnError;
	}
	return kIOReturnSuccess;
}

IOReturn ReimsGraphics::postLifecycle(UInt32 type, const void *message, UInt32 size,
                                      UInt32 replyType, void *reply, UInt32 replyCapacity,
                                      UInt32 *replyLength, UInt64 *seqno, UInt32 timeoutMs,
                                      const UInt32 *seedOrder)
{
	if (replyLength)
		*replyLength = 0;
	if (!replyType)
		return post(type, message, size, seqno);
	// An answer the event handler would drop: no thread waits for it, as none would wake.
	if (!rgfxLifecycleAnswer(replyType)) {
		IOLog("ReimsGraphics: lifecycle %u: no event of type %u answers a waiter\n", type,
		      replyType);
		return kIOReturnUnsupported;
	}

	// Take a waiter of the ask's kind, so the answer finds this thread once the message is on the
	// ring. Both waits, for the waiter and for the answer, are in `timeoutMs`'s mode
	// (RgfxAnswerWait.hpp), and end where the device stops: quiesce wakes them.
	uint64_t deadline = 0;
	if (rgfxWaitHasDeadline(timeoutMs))
		clock_interval_to_deadline(timeoutMs, kMillisecondScale, &deadline);
	const UInt32 interruptible =
	    rgfxWaitInterruptible(timeoutMs) ? THREAD_INTERRUPTIBLE : THREAD_UNINT;
	// Sleeps on `event` under stateLock until woken, or past the deadline where there is one.
	auto sleepOn = [this, deadline, interruptible](void *event) {
		const wait_result_t r =
		    deadline ? IOLockSleepDeadline(stateLock, event, deadline, interruptible)
		             : IOLockSleep(stateLock, event, interruptible);
		return r == THREAD_TIMED_OUT     ? kRgfxSleepTimedOut
		       : r == THREAD_INTERRUPTED ? kRgfxSleepInterrupted
		                                 : kRgfxSleepWoken;
	};
	auto upNow = [this] { return answers(); };
	const RgfxWaiterKind kind = rgfxWaiterKind(type);
	LifecycleWaiter *w = nullptr;
	IOLockLock(stateLock);
	const RgfxWaitEnd took = rgfxAwait(
	    [this, kind, &w] {
		    const int32_t at = rgfxFreeWaiter(
		        kind, [this](uint32_t i) { return lifecycleWaiters[i].replyType == 0; });
		    w = at >= 0 ? &lifecycleWaiters[at] : nullptr;
		    return w != nullptr;
	    },
	    upNow, [&sleepOn, this] { return sleepOn(lifecycleWaiters); });
	// No waiter, the message not posted: kIOReturnBusy where the wait for one ended at its
	// deadline or at the thread's abort, so the caller never takes it for a message posted and
	// unanswered (kIOReturnTimeout, kIOReturnAborted below).
	if (took != kRgfxWaitAnswered) {
		IOLockUnlock(stateLock);
		if (took == kRgfxWaitStopped)
			return kIOReturnNotReady;
		static char untaken;
		if (rgfxFirstCalls(&untaken, (static_cast<UInt64>(type) << 32) | took, 1))
			IOLog("ReimsGraphics: lifecycle %u: every waiter of its kind is taken, %s\n", type,
			      took == kRgfxWaitTimedOut ? "past its deadline" : "and its thread aborted");
		return kIOReturnBusy;
	}
	w->seqno = 0;
	w->replyType = replyType;
	w->length = 0;
	w->done = false;
	w->seed = seedOrder != nullptr;
	w->order = seedOrder ? *seedOrder : 0;
	IOLockUnlock(stateLock);

	UInt64 s = 0;
	IOReturn r = post(type, message, size, &s, &w->seqno);
	// Most answers come within tens of microseconds: looked for here first (RgfxAnswerLook.hpp).
	if (r == kIOReturnSuccess)
		lookForAnswer(w);
	IOLockLock(stateLock);
	// Each waiter sleeps on its own `done`, so an answer wakes only the thread it is for, not
	// every waiter (which, with many in flight, would herd on stateLock and starve the work loop
	// that delivers the answers). The free event below stays the shared array, a slot's seekers'.
	if (r == kIOReturnSuccess)
		r = rgfxWaitReturn(rgfxAwait([w] { return w->done; }, upNow,
		                             [&sleepOn, w] { return sleepOn(&w->done); }));
	if (r == kIOReturnSuccess) {
		UInt32 n = w->length < replyCapacity ? w->length : replyCapacity;
		memcpy(reply, w->reply, n);
		if (replyLength)
			*replyLength = n;
	}
	w->replyType = 0;
	w->seqno = 0;
	w->seed = false;
	IOLockWakeup(stateLock, lifecycleWaiters, false);
	IOLockUnlock(stateLock);
	// Once per command type and end a boot (docs/conventions.md).
	static char unanswered;
	if ((r == kIOReturnTimeout || r == kIOReturnAborted || r == kIOReturnNotReady) &&
	    rgfxFirstCalls(&unanswered, (static_cast<UInt64>(type) << 32) | static_cast<UInt32>(r),
	                   1))
		IOLog("ReimsGraphics: lifecycle %u (seqno %llu): no answer: %s\n", type, s,
		      r == kIOReturnTimeout   ? "its deadline passed"
		      : r == kIOReturnAborted ? "its thread was aborted"
		                              : "the device stopped");
	if (seqno)
		*seqno = s;
	return r;
}

IOReturn ReimsGraphics::postDeferred(UInt32 context, UInt32 type, const void *message,
                                     UInt32 size, UInt64 *seqno, const UInt8 *key)
{
	IOLockLock(stateLock);
	const int slot = deferredAnswers.reserve(context, key);
	IOLockUnlock(stateLock);
	if (slot < 0)
		return kIOReturnNoResources;
	UInt64 s = 0;
	// The slot's seqno is stamped before the device can see the create, so its answer finds it.
	IOReturn r = post(type, message, size, &s, deferredAnswers.seqnoOf(slot));
	if (r != kIOReturnSuccess) {
		IOLockLock(stateLock);
		deferredAnswers.cancel(slot);
		IOLockUnlock(stateLock);
	}
	if (seqno)
		*seqno = s;
	return r;
}

IOReturn ReimsGraphics::takeDeferred(UInt32 context, UInt64 waitFor, UInt32 timeoutMs, UInt8 *out,
                                     UInt32 capacity, UInt32 *length, UInt32 *count)
{
	uint64_t deadline = 0;
	if (rgfxWaitHasDeadline(timeoutMs))
		clock_interval_to_deadline(timeoutMs, kMillisecondScale, &deadline);
	const UInt32 interruptible =
	    rgfxWaitInterruptible(timeoutMs) ? THREAD_INTERRUPTIBLE : THREAD_UNINT;
	IOLockLock(stateLock);
	const RgfxWaitEnd end = rgfxAwait(
	    [this, context, waitFor] {
		    return waitFor == 0 ||
		           deferredAnswers.state(context, waitFor) != DeferredAnswers::kWaiting;
	    },
	    [this] { return answers(); },
	    [this, deadline, interruptible] {
		    const wait_result_t r =
		        deadline
		            ? IOLockSleepDeadline(stateLock, &deferredAnswers, deadline, interruptible)
		            : IOLockSleep(stateLock, &deferredAnswers, interruptible);
		    return r == THREAD_TIMED_OUT     ? kRgfxSleepTimedOut
		           : r == THREAD_INTERRUPTED ? kRgfxSleepInterrupted
		                                     : kRgfxSleepWoken;
	    });
	*length = deferredAnswers.take(context, out, capacity, count);
	IOLockUnlock(stateLock);
	const IOReturn r = rgfxWaitReturn(end);
	// Once per end a boot (docs/conventions.md).
	static char unanswered;
	if (r != kIOReturnSuccess && rgfxFirstCalls(&unanswered, static_cast<UInt32>(r), 1))
		IOLog("ReimsGraphics: context %u: no answer to its deferred create (seqno %llu): %s\n",
		      context, waitFor,
		      r == kIOReturnTimeout   ? "its deadline passed"
		      : r == kIOReturnAborted ? "its thread was aborted"
		                              : "the device stopped");
	return r;
}

void ReimsGraphics::dropDeferred(UInt32 context)
{
	IOLockLock(stateLock);
	deferredAnswers.drop(context);
	IOLockWakeup(stateLock, &deferredAnswers, false);
	IOLockUnlock(stateLock);
}

void ReimsGraphics::forgetDeferred(UInt64 seqno)
{
	IOLockLock(stateLock);
	deferredAnswers.forget(seqno);
	IOLockUnlock(stateLock);
}

bool ReimsGraphics::findSharedPipeline(const UInt8 *key, UInt64 seqno, UInt64 objId,
                                       RgfxPipelineReflection *out)
{
	if (!sharedPipelines)
		return false;
	IOLockLock(stateLock);
	const bool found = sharedPipelines->find(key, seqno, objId, out);
	IOLockUnlock(stateLock);
	return found;
}

void ReimsGraphics::learnSharedPipeline(const UInt8 *reply, UInt32 length)
{
	if (!sharedPipelines)
		return;
	IOLockLock(stateLock);
	sharedPipelines->learn(reply, length);
	IOLockUnlock(stateLock);
}

void ReimsGraphics::seedSharedPipelines()
{
	if (!sharedPipelines || !pipelineAnswersTaken)
		return;
	// A query's answers fill at most a quarter of the completion ring, so its other events go on.
	constexpr UInt32 kSeedBatch = 64;
	static_assert(kSeedBatch * SharedPipelines::kKeyedReplyBytes <= kRingBytes / 4,
	              "a seed's answers leave the completion ring room");
	UInt32 handed = 0;
	while (handed < SharedPipelines::kSeeds) {
		RgfxPipelineAnswersQuery query;
		bzero(&query, sizeof(query));
		query.first = handed;
		query.most = kSeedBatch;
		RgfxComplete reply;
		bzero(&reply, sizeof(reply));
		UInt32 length = 0;
		const UInt32 order = handed;
		IOReturn r = postLifecycle(RGFX_CMD_PIPELINE_ANSWERS, &query, sizeof(query),
		                           RGFX_EVT_COMPLETE, &reply, sizeof(reply), &length, nullptr,
		                           kAnswerTimeoutMs, &order);
		if (r != kIOReturnSuccess || length < sizeof(reply) || reply.status > kSeedBatch) {
			IOLog("ReimsGraphics: the device's kept pipeline answers stop at %u (0x%x, %u)\n",
			      handed, r, reply.status);
			break;
		}
		handed += reply.status;
		if (reply.status < kSeedBatch)
			break;
	}
	IOLockLock(stateLock);
	const UInt32 kept = sharedPipelines->size();
	IOLockUnlock(stateLock);
	IOLog("ReimsGraphics: %u pipeline answers of earlier runs from the device, %u kept\n", handed,
	      kept);
}

void ReimsGraphics::kickWorkLoop()
{
	if (isHead()) {
		device->kickWorkLoop();
		return;
	}
	if (kick)
		kick->interruptOccurred(nullptr, nullptr, 0);
}

// MARK: - The display's panel

static_assert(kRgfxMessageDeviceWillPowerOff == kIOMessageDeviceWillPowerOff,
              "RgfxDisplayPower.hpp's WillPowerOff is the kernel's");
static_assert(kRgfxMessageDeviceHasPoweredOn == kIOMessageDeviceHasPoweredOn,
              "RgfxDisplayPower.hpp's HasPoweredOn is the kernel's");

// Where the host took DISPLAY_POWER, the x86-64 framebuffer follows the display wrangler's power:
// its handler registers the framebuffer's general interest in the wrangler once it is published,
// or at once where it is already. An arm64 guest has none, and the arm64e framebuffer does not
// take DISPLAY_POWER (RgfxFeatures.hpp).
void ReimsGraphics::startDisplayPower()
{
#if defined(__x86_64__)
	if (!displayPowerTaken)
		return;
	OSDictionary *matching = serviceMatching("IODisplayWrangler");
	IONotifier *notifier = matching ? addMatchingNotification(gIOFirstPublishNotification, matching,
	                                                          wranglerPublished, this)
	                                : nullptr;
	OSSafeReleaseNULL(matching);
	if (!notifier) {
		IOLog("ReimsGraphics: no notification of the display wrangler: the display stays lit "
		      "through its sleep\n");
		return;
	}
	IOLockLock(stateLock);
	wranglerNotifier = notifier;
	IOLockUnlock(stateLock);
#endif
}

// Each notifier's remove waits for its handler where one runs: the publication's first, which
// may register the interest, then the interest's.
void ReimsGraphics::stopDisplayPower()
{
	IOLockLock(stateLock);
	IONotifier *notifier = wranglerNotifier;
	wranglerNotifier = nullptr;
	IOLockUnlock(stateLock);
	if (notifier)
		notifier->remove();
	IOLockLock(stateLock);
	IONotifier *interest = wranglerInterest;
	wranglerInterest = nullptr;
	IOLockUnlock(stateLock);
	if (interest)
		interest->remove();
}

bool ReimsGraphics::wranglerPublished(void *target, void *, IOService *wrangler, IONotifier *)
{
	ReimsGraphics *self = static_cast<ReimsGraphics *>(target);
	IOLockLock(self->stateLock);
	const bool registered = self->wranglerInterest != nullptr;
	IOLockUnlock(self->stateLock);
	if (registered)
		return true;
	IONotifier *interest =
	    wrangler->registerInterest(gIOGeneralInterest, wranglerMessage, self, nullptr);
	IOLockLock(self->stateLock);
	if (!self->wranglerInterest) {
		self->wranglerInterest = interest;
		interest = nullptr;
	}
	IOLockUnlock(self->stateLock);
	if (interest)
		interest->remove();
	IOLog("ReimsGraphics: the display's panel %s the display wrangler's power\n",
	      self->wranglerInterest ? "follows" : "cannot follow");
	return true;
}

// The wrangler's power messages: the panel each leaves (RgfxDisplayPower.hpp), which the work loop
// tells the host. Every message is answered at once: the framebuffer holds up no power change.
IOReturn ReimsGraphics::wranglerMessage(void *target, void *, UInt32 type, IOService *,
                                        void *argument, vm_size_t size)
{
	ReimsGraphics *self = static_cast<ReimsGraphics *>(target);
	const IOPowerStateChangeNotification *change =
	    argument && size >= sizeof(IOPowerStateChangeNotification)
	        ? static_cast<const IOPowerStateChangeNotification *>(argument)
	        : nullptr;
	const RgfxPanel panel =
	    rgfxPanelAfter(type, change != nullptr, change ? change->stateNumber : 0);
	if (panel == RgfxPanel::Unchanged)
		return kIOReturnSuccess;
	const bool lit = panel == RgfxPanel::On;
	if (self->wantPanel(lit))
		IOLog("ReimsGraphics: the display wrangler goes to power state %lu: the display's panel "
		      "%s\n",
		      change->stateNumber, lit ? "lights" : "goes dark");
	return kIOReturnSuccess;
}

// The wrangler's power is every display's: display 0's framebuffer sets each head's panel too.
bool ReimsGraphics::wantPanel(bool lit)
{
	IOSimpleLockLock(interruptLock);
	bool changed = panelWanted != lit;
	panelWanted = lit;
	for (UInt32 i = 1; i < RGFX_DISPLAYS_MAX; i++) {
		if (ReimsGraphics *head = heads[i]) {
			changed = changed || head->panelWanted != lit;
			head->panelWanted = lit;
		}
	}
	IOSimpleLockUnlock(interruptLock);
	if (changed)
		kickWorkLoop();
	return changed;
}

// MARK: - The work loop

void ReimsGraphics::serviceAction(OSObject *owner, IOInterruptEventSource *, int)
{
	static_cast<ReimsGraphics *>(owner)->service();
}

// At primary interrupt context, as each interrupt of the vector arrives, with interrupts disabled:
// the accelerator looks at its queues' completion rings and wakes their clients' completion
// threads, which then run beside the work loop's pass instead of after it. Every interrupt still
// goes on to that pass (true), which runs as it did without the filter.
bool ReimsGraphics::filterAction(OSObject *owner, IOFilterInterruptEventSource *)
{
	ReimsGraphics *self = static_cast<ReimsGraphics *>(owner);
	if (__atomic_load_n(&self->ready, __ATOMIC_ACQUIRE) && self->queueFilterLock) {
		IOSimpleLockLock(self->queueFilterLock);
		if (self->queueFilter)
			self->queueFilter(self->queueFilterTarget);
		IOSimpleLockUnlock(self->queueFilterLock);
	}
	return true;
}

// Drains the completion ring, then arms its interrupt and looks again, so an
// event published meanwhile is never left without one. Then sends what
// IOFramebuffer asked of vblank, and a display refresh a DISPLAY_CHANGED
// asked for, neither of which may wait for ring space here: the host may be
// waiting for this loop to free the completion ring.
void ReimsGraphics::service()
{
	if (!ready)
		return;
	takeCompletions();
	// The host has moved on: a post waiting for room on the control ring looks again.
	if (rgfxRingRoomPass(room)) {
		IOLockLock(stateLock);
		IOLockWakeup(stateLock, &room, false);
		IOLockUnlock(stateLock);
	}

	// The queues' completions share the vector: the accelerator looks at its rings.
	IOSimpleLockLock(interruptLock);
	OSObject *queues = queueTarget;
	QueueInterruptHook queuesHook = queueHook;
	if (queues)
		queues->retain();
	IOSimpleLockUnlock(interruptLock);
	if (queues) {
		queuesHook(queues);
		queues->release();
	}

	// Each display's, display 0's first.
	ReimsGraphics *fbs[RGFX_DISPLAYS_MAX];
	const UInt32 n = copyDisplays(fbs);
	for (UInt32 i = 0; i < n; i++)
		serviceDisplay(fbs[i]);
	releaseDisplays(fbs, n);
	if (refreshes.wanted()) {
		UInt64 seqno = 0;
		RgfxGetDisplays getDisplays = {};
		if (tryPost(RGFX_CMD_GET_DISPLAYS, &getDisplays, sizeof(getDisplays), &seqno))
			refreshes.posted(seqno);
	}
}

void ReimsGraphics::serviceDisplay(ReimsGraphics *fb)
{
	IOSimpleLockLock(interruptLock);
	Interrupt late = {};
	if (fb->displayChange.armed(fb->connect.enabled && fb->connect.proc))
		late = fb->connect;
	bool want = fb->vblankWanted || fb->pipes.anyVblank();
	const bool panel = fb->panelWanted;
	IOSimpleLockUnlock(interruptLock);
	if (late.proc)
		late.proc(late.target, late.ref);
	if (want != fb->vblankSent) {
		RgfxSetVblank v = {};
		v.display = fb->displayId;
		v.enabled = want ? 1u : 0u;
		if (tryPost(RGFX_CMD_SET_VBLANK, &v, sizeof(v), nullptr))
			fb->vblankSent = want;
	}
	if (rgfxPanelToSend(displayPowerTaken, panel, fb->panelTold)) {
		RgfxSetDisplayPower p = {};
		p.display = fb->displayId;
		p.on = panel ? 1u : 0u;
		if (tryPost(RGFX_CMD_SET_DISPLAY_POWER, &p, sizeof(p), nullptr))
			fb->panelTold = panel;
	}
}

UInt32 ReimsGraphics::copyDisplays(ReimsGraphics **out)
{
	UInt32 n = 0;
	retain();
	out[n++] = this;
	IOSimpleLockLock(interruptLock);
	for (UInt32 i = 1; i < RGFX_DISPLAYS_MAX; i++) {
		if (ReimsGraphics *head = heads[i]) {
			head->retain();
			out[n++] = head;
		}
	}
	IOSimpleLockUnlock(interruptLock);
	return n;
}

void ReimsGraphics::releaseDisplays(ReimsGraphics **fbs, UInt32 n)
{
	for (UInt32 i = 0; i < n; i++)
		fbs[i]->release();
}

ReimsGraphics *ReimsGraphics::copyDisplay(UInt32 display)
{
	if (isHead())
		return device->copyDisplay(display);
	if (display == 0) {
		retain();
		return this;
	}
	if (display >= RGFX_DISPLAYS_MAX || !interruptLock)
		return nullptr;
	IOSimpleLockLock(interruptLock);
	ReimsGraphics *head = heads[display];
	if (head)
		head->retain();
	IOSimpleLockUnlock(interruptLock);
	return head;
}

// The completion ring drained, then its interrupt armed and the ring looked at again, so an event
// published meanwhile is never left without one; armed only where something changed since the
// last arm found it empty (RgfxCompletionArm.hpp): in the work loop's gate (service, takeAction).
void ReimsGraphics::takeCompletions()
{
	struct Ring {
		ReimsGraphics *self;
		volatile UInt8 *events;
		uint64_t producer() { return load64(events + kRingProducer); }
		void take(uint64_t end) { self->drainEvents(end); }
		void arm()
		{
			store32(events + kRingArmed, 1);
			fullFence();
		}
	} completions = {this, ring(RGFX_CONTROL_COMPLETE_OFFSET)};
	rgfxTakeAndArm(completions, consumed, armedAt);
}

// A waiter's take of the completion ring (lookForAnswer), in the work loop's gate as the work
// loop's own; the rest of service() follows at the interrupt the record raised.
IOReturn ReimsGraphics::takeAction(OSObject *owner, void *, void *, void *, void *)
{
	ReimsGraphics *self = static_cast<ReimsGraphics *>(owner);
	if (self->ready)
		self->takeCompletions();
	return kIOReturnSuccess;
}

// Looks for `w`'s answer for at most kRgfxAnswerLookNs (RgfxAnswerLook.hpp), taking the
// completion ring in the work loop's gate where it holds a record the work loop has not taken,
// and the gate is free (lookGate's attemptAction): it never waits for it, as its holder may wait
// for a lock this thread's caller holds (the event hooks take the release table's lock and the
// pipe clients'), which only the sleep's deadline below bounds. A device that stops meanwhile ends
// the look: its caller then waits as before.
void ReimsGraphics::lookForAnswer(const LifecycleWaiter *w)
{
	IOCommandGate *gate = lookGate;
	if (!ready || !gate)
		return;
	gate->retain();
	volatile UInt8 *events = ring(RGFX_CONTROL_COMPLETE_OFFSET);
	uint64_t span = 0;
	nanoseconds_to_absolutetime(kRgfxAnswerLookNs, &span);
	rgfxLookForAnswer(
	    mach_absolute_time() + span, [] { return mach_absolute_time(); },
	    [this, w] {
		    return !__atomic_load_n(&ready, __ATOMIC_RELAXED) ||
		           __atomic_load_n(&w->done, __ATOMIC_ACQUIRE);
	    },
	    [events] { return load64(events + kRingProducer) != load64(events + kRingConsumer); },
	    [this, gate] {
		    return gate->attemptAction(&ReimsGraphics::takeAction, this) == kIOReturnSuccess;
	    },
	    [] { rgfxAnswerLookPause(); });
	gate->release();
}

void ReimsGraphics::drainEvents(UInt64 end)
{
	volatile UInt8 *header = ring(RGFX_CONTROL_COMPLETE_OFFSET);
	volatile UInt8 *bytes = header + RGFX_RING_HEADER_SIZE;
	const UInt64 from = consumed;
	while (consumed != end) {
		static char outOfRange;
		if (end - consumed > kRingBytes) {
			if (rgfxFirstCalls(&outOfRange, 0, 1))
				IOLog("ReimsGraphics: the completion ring's producer is out of range; skipping to "
				      "it\n");
			consumed = end;
			break;
		}
		UInt32 offset = static_cast<UInt32>(consumed % kRingBytes);
		UInt32 tail = kRingBytes - offset;
		if (tail < kHeaderBytes) {
			// Too few bytes for a header: the producer padded to the end.
			consumed += tail;
			continue;
		}
		const volatile UInt8 *m = bytes + offset;
		UInt32 type = field32(m, 0);
		UInt32 size = field32(m, 4);
		UInt64 seqno = *reinterpret_cast<const volatile UInt64 *>(m + 8);
		if (type == RGFX_MSG_PAD) {
			consumed += tail;
			continue;
		}
		if (size < kHeaderBytes || size % kMsgAlign || size > tail || size > end - consumed) {
			static char malformed;
			if (rgfxFirstCalls(&malformed, type, 1))
				IOLog("ReimsGraphics: malformed event (type %u, size %u); skipping the ring's "
				      "contents\n",
				      type, size);
			consumed = end;
			break;
		}
		handleEvent(type, seqno, m + kHeaderBytes, size - kHeaderBytes);
		consumed += size;
	}
	if (consumed != from)
		store64(header + kRingConsumer, consumed);
}

void ReimsGraphics::handleEvent(UInt32 type, UInt64 seqno, const volatile UInt8 *payload, UInt32 size)
{
	switch (type) {
	case RGFX_EVT_COMPLETE: {
		if (answerLifecycle(type, seqno, payload, size))
			return;
		UInt32 status = size >= sizeof(uint32_t) ? field32(payload, 0) : kStatusUnreadable;
		// A block release's, which no thread waits for: the accelerator's.
		IOSimpleLockLock(interruptLock);
		OSObject *releases = releaseTarget;
		ReleaseAnswerHook releasesHook = releaseHook;
		if (releases)
			releases->retain();
		IOSimpleLockUnlock(interruptLock);
		if (releases) {
			const bool released = releasesHook(releases, seqno, status);
			releases->release();
			if (released)
				return;
		}
		answer(seqno, status);
		// Every pipe client of every display: the one whose transaction this answers takes it,
		// at the time of the refresh of its display the host answered in.
		const UInt64 nowNs = clockNs(mach_absolute_time());
		ReimsGraphics *fbs[RGFX_DISPLAYS_MAX];
		const UInt32 displays = copyDisplays(fbs);
		for (UInt32 d = 0; d < displays; d++) {
			ReimsGraphics *fb = fbs[d];
			UInt64 shown = clockAbsolute(fb->vblankClock.shownAt(nowNs));
			OSObject *clients[kMaxPipeClients];
			IOSimpleLockLock(interruptLock);
			UInt32 n = fb->pipes.all(clients);
			PipePresentHook hook = fb->pipePresentHook;
			for (UInt32 i = 0; i < n; i++)
				clients[i]->retain();
			IOSimpleLockUnlock(interruptLock);
			for (UInt32 i = 0; i < n; i++) {
				if (hook)
					hook(clients[i], seqno, status, shown);
				clients[i]->release();
			}
		}
		releaseDisplays(fbs, displays);
		// The display shows a surface from this answer: the boot screen under it, black, once.
		if (status == RGFX_STATUS_OK && !bootScreenCleared &&
		    seqno == __atomic_load_n(&bootScreenSeqno, __ATOMIC_ACQUIRE)) {
			__atomic_store_n(&bootScreenCleared, true, __ATOMIC_RELEASE);
			clearBootScreen();
		}
		return;
	}
	case RGFX_EVT_DISPLAYS: {
		answer(seqno, parseDisplays(payload, size));
		const UInt32 refreshed = refreshes.answered(seqno);
		if (!refreshed)
			return;
		// The refresh a DISPLAY_CHANGED asked for: now IOFramebuffer
		// senses the connection again, or once it has its connect interrupt
		// registered and on (RgfxDisplayModes.hpp, RgfxConnectChange), on
		// each display the refresh was for.
#if defined(__arm64e__)
		// On arm64 a list that changed the modes is republished, off this work loop, and the
		// processes told (republishMobileDisplay): display 0's, and each head's while it is in the
		// table, which its stop takes it out of before it waits for its call (stopHead).
		if (__atomic_exchange_n(&mobileListChanged, false, __ATOMIC_RELAXED) && mobileChangeCall &&
		    hasStarted())
			thread_call_enter(mobileChangeCall);
		IOSimpleLockLock(interruptLock);
		for (UInt32 i = 1; i < RGFX_DISPLAYS_MAX; i++) {
			ReimsGraphics *head = heads[i];
			if (head && __atomic_exchange_n(&head->mobileListChanged, false, __ATOMIC_RELAXED) &&
			    head->mobileChangeCall && head->hasStarted())
				thread_call_enter(head->mobileChangeCall);
		}
		IOSimpleLockUnlock(interruptLock);
#endif
		ReimsGraphics *fbs[RGFX_DISPLAYS_MAX];
		const UInt32 displays = copyDisplays(fbs);
		Interrupt fires[RGFX_DISPLAYS_MAX] = {};
		IOSimpleLockLock(interruptLock);
		for (UInt32 d = 0; d < displays; d++) {
			ReimsGraphics *fb = fbs[d];
			const UInt32 index = fb == this ? 0 : fb->displayId;
			if ((refreshed & (1u << index)) &&
			    fb->displayChange.changed(fb->connect.enabled && fb->connect.proc))
				fires[d] = fb->connect;
		}
		IOSimpleLockUnlock(interruptLock);
		for (UInt32 d = 0; d < displays; d++) {
			if (fires[d].enabled && fires[d].proc)
				fires[d].proc(fires[d].target, fires[d].ref);
		}
		releaseDisplays(fbs, displays);
		return;
	}
	case RGFX_EVT_DISPLAY_CHANGED:
		// A refresh for the display it names (rgfxEventDisplay).
		refreshes.changed(drivenIndex(rgfxEventDisplay(payload, size)));
		return;
	case RGFX_EVT_SUBMIT_ROOM:
		// The host took from the control ring after a post set its producer_waiting: the pass
		// that drains this wakes the posts waiting for room (service). Counted for the room line.
		__atomic_fetch_add(&roomRecords, 1, __ATOMIC_RELAXED);
		return;
	case RGFX_EVT_VBLANK: {
		// The refresh of the display it names (rgfxEventDisplay): its framebuffer's.
		ReimsGraphics *fb = copyDisplay(drivenIndex(rgfxEventDisplay(payload, size)));
		if (!fb)
			return;
		OSObject *clients[kMaxPipeClients];
		IOSimpleLockLock(interruptLock);
		const Interrupt fire = fb->vblank;
		UInt32 n = fb->pipes.wantingVblank(clients);
		PipeVblankHook hook = fb->pipeVblankHook;
		for (UInt32 i = 0; i < n; i++)
			clients[i]->retain();
		IOSimpleLockUnlock(interruptLock);
		// The event's count and the host's stamp are 8 and 16 bytes into its payload
		// (RgfxVblank); the refresh's time is the stamp in the guest's clock.
		UInt64 count = size >= 16 ? *reinterpret_cast<const volatile UInt64 *>(payload + 8) : 0;
		UInt64 now = clockNs(mach_absolute_time());
		if (hostTime) {
			// The host's clock, read between two of ours (RgfxVblankClock::reading): only LO's
			// read is timed.
			UInt32 hi = readRegister(RGFX_REG_HOST_TIME_HI);
			UInt64 before = clockNs(mach_absolute_time());
			UInt32 lo = readRegister(RGFX_REG_HOST_TIME_LO);
			UInt64 after = clockNs(mach_absolute_time());
			UInt32 hiAgain = readRegister(RGFX_REG_HOST_TIME_HI);
			fb->vblankClock.reading(before, RgfxVblankClock::hostTime(hi, lo, hiAgain), after);
			// Where the bundle stamps its command buffers (GUEST_TIMES), the held reading's
			// offset and bound go in ring 0's header for the host: the offset, then the bound
			// with release, which the host reads first.
			int64_t offset = 0;
			uint64_t bound = 0;
			if (guestTimes && fb->vblankClock.offsetAt(after, &offset, &bound)) {
				volatile UInt8 *header = ring(RGFX_CONTROL_SUBMIT_OFFSET);
				store64(header + kRingGuestClockOffset, static_cast<UInt64>(offset));
				store32(header + kRingGuestClockBound, RgfxVblankClock::headerBound(bound));
			}
		}
		UInt64 time = clockAbsolute(
		    size >= 24 ? fb->vblankClock.vblank(count,
		                                        *reinterpret_cast<const volatile UInt64 *>(payload + 16),
		                                        now)
		               : now);
		UInt64 next = clockAbsolute(size >= 24 ? fb->vblankClock.next()
		                                       : now + RgfxVblankClock::kDefaultPeriodNs);
		for (UInt32 i = 0; i < n; i++) {
			if (hook)
				hook(clients[i], count, time, next);
			clients[i]->release();
		}
		if (fire.enabled && fire.proc)
			fire.proc(fire.target, fire.ref);
		fb->release();
		return;
	}
	case RGFX_EVT_POINTER_MOTION:
		// The host's pointer drives the guest's own mouse (RgfxPointerDevice.hpp).
		pointerMotion(payload, size);
		return;
#if defined(__arm64e__)
	case RGFX_EVT_VT_MESSAGE:
		// The host's side's message, for the guest's VideoToolbox (RgfxVtService.hpp).
		vtMessage(payload, size);
		return;
	case RGFX_EVT_VT_RING:
		// The host's side's messages in the VideoToolbox ring, through the count the event
		// carries, at the event's place among the others (RgfxVtRing.hpp).
		vtRing(payload, size);
		return;
#endif
	case RGFX_EVT_POINTER_OVER:
		// The host's pointer is over another display: the cursor goes there
		// (ReimsGraphicsPointer.cpp).
		pointerOver(payload, size);
		return;
	default:
		// The creates' and queries' answers, a POOL_TAKE's POOL_BLOCK, a PRIVATE_TAKE's
		// PRIVATE_BLOCK, and on arm64e a VT_MESSAGE's VT_STATUS (RgfxVtService.hpp): each for the
		// thread that waits for it (RgfxLifecycleAnswers.hpp).
		if (rgfxLifecycleAnswer(type))
			answerLifecycle(type, seqno, payload, size);
		return;
	}
}

// Display 0's, once its start is done: the guest's own mouse, where the host took
// POINTER_MOTION and none is up yet (a start after a reset keeps the one it has).
void ReimsGraphics::startPointerDevice()
{
	if (!pointerMotionTaken || __atomic_load_n(&pointerDevice, __ATOMIC_ACQUIRE))
		return;
	RgfxPointerDevice *made = RgfxPointerDevice::withProvider(this);
	if (!made) {
		IOLog("ReimsGraphics: the guest's mouse for POINTER_MOTION did not start\n");
		return;
	}
	__atomic_store_n(&pointerDevice, made, __ATOMIC_RELEASE);
	IOLog("ReimsGraphics: the guest's mouse for POINTER_MOTION is up\n");
}

// Display 0's stop, once the work loop hands the device nothing more: the device stops and goes.
void ReimsGraphics::stopPointerDevice()
{
	RgfxPointerDevice *mouse = __atomic_exchange_n(&pointerDevice, nullptr, __ATOMIC_ACQ_REL);
	if (!mouse)
		return;
	mouse->terminate();
	mouse->release();
}

// handleEvent's POINTER_MOTION, on the device's work loop: its reports to the guest's mouse.
void ReimsGraphics::pointerMotion(const volatile UInt8 *payload, UInt32 size)
{
	RgfxMotion motion = {};
	RgfxPointerDevice *mouse = __atomic_load_n(&pointerDevice, __ATOMIC_ACQUIRE);
	if (!mouse || !rgfxPointerMotionRead(payload, size, &motion)) {
		static char unread;
		if (rgfxFirstCalls(&unread, size, 1))
			IOLog("ReimsGraphics: a POINTER_MOTION of %u bytes moves nothing%s\n", size,
			      mouse ? "" : " (no mouse is up)");
		return;
	}
	mouse->post(motion);
}

// Hands a lifecycle message's answer to its waiting thread, or keeps a deferred create's for its
// process: false where neither waits for an answer of this type to `seqno`.
bool ReimsGraphics::answerLifecycle(UInt32 type, UInt64 seqno, const volatile UInt8 *payload,
                                    UInt32 size)
{
	if (seqno == 0)
		return false;
	bool found = false;
	IOLockLock(stateLock);
	// A seed's answers (seedSharedPipelines): into the shared pipelines, in the order they come.
	for (UInt32 i = 0; type == RGFX_EVT_PIPELINE_REFLECTION && i < kLifecycleWaiters && !found;
	     i++) {
		LifecycleWaiter &w = lifecycleWaiters[i];
		if (!w.seed || w.done || __atomic_load_n(&w.seqno, __ATOMIC_ACQUIRE) != seqno)
			continue;
		found = true;
		UInt8 reply[SharedPipelines::kKeyedReplyBytes];
		RgfxMsgHeader h = {type, size + kHeaderBytes, seqno};
		UInt32 n = size + kHeaderBytes < sizeof(reply) ? size + kHeaderBytes : sizeof(reply);
		memcpy(reply, &h, kHeaderBytes);
		for (UInt32 b = kHeaderBytes; b < n; b++)
			reply[b] = payload[b - kHeaderBytes];
		if (sharedPipelines)
			sharedPipelines->seed(reply, n, w.order);
		w.order++;
	}
	for (UInt32 i = 0; i < kLifecycleWaiters && !found; i++) {
		LifecycleWaiter &w = lifecycleWaiters[i];
		if (w.replyType != type || w.done ||
		    __atomic_load_n(&w.seqno, __ATOMIC_ACQUIRE) != seqno)
			continue;
		found = true;
		RgfxMsgHeader h = {type, size + kHeaderBytes, seqno};
		UInt32 n = size + kHeaderBytes < kLifecycleReplyMax ? size + kHeaderBytes
		                                                    : kLifecycleReplyMax;
		memcpy(w.reply, &h, kHeaderBytes);
		for (UInt32 b = kHeaderBytes; b < n; b++)
			w.reply[b] = payload[b - kHeaderBytes];
		w.length = n;
		w.done = true;
		// Only the thread this answer is for: its own `done` event, one thread.
		IOLockWakeup(stateLock, &w.done, true);
	}
	// Else a deferred create's (postDeferred), kept for its process to take; its waiters, if any,
	// look again. The shared pipelines take the device's own answer (RgfxSharedPipelines::
	// answered): one posted for a kept answer whose pipeline the device did not make forgets the
	// kept answer, so the next equal create waits for its own, and a made pipeline's keyed answer
	// replaces the kept one, so a kept answer the device answers otherwise (a seed of an earlier
	// run) answers no later create.
	bool refused = false;
	UInt8 refusedKey[DeferredAnswers::kKeyBytes];
	if (!found && deferredAnswers.answer(RgfxMsgHeader{type, size + kHeaderBytes, seqno},
	                                     payload, size, &refused, refusedKey)) {
		found = true;
		if (sharedPipelines) {
			UInt8 reply[SharedPipelines::kKeyedReplyBytes];
			RgfxMsgHeader h = {type, size + kHeaderBytes, seqno};
			UInt32 n = size + kHeaderBytes < sizeof(reply) ? size + kHeaderBytes : sizeof(reply);
			memcpy(reply, &h, kHeaderBytes);
			for (UInt32 b = kHeaderBytes; b < n; b++)
				reply[b] = payload[b - kHeaderBytes];
			sharedPipelines->answered(reply, n, refused ? refusedKey : nullptr);
		}
		IOLockWakeup(stateLock, &deferredAnswers, false);
	}
	IOLockUnlock(stateLock);
	return found;
}

// Hands a display-control answer (a COMPLETE or a DISPLAYS) to its command() thread, matched by
// seqno. A COMPLETE no command() waits for (a PRESENT_SURFACE's, which the pipe clients take
// instead) matches no waiter and is dropped.
void ReimsGraphics::answer(UInt64 seqno, UInt32 status)
{
	if (seqno == 0)
		return;
	IOLockLock(stateLock);
	for (UInt32 i = 0; i < kControlWaiters; i++) {
		ControlWaiter &w = controlWaiters[i];
		if (w.waiting && !w.done && __atomic_load_n(&w.seqno, __ATOMIC_ACQUIRE) == seqno) {
			w.status = status;
			w.done = true;
			// Only the thread this answer is for: its own `done` event, one thread.
			IOLockWakeup(stateLock, &w.done, true);
			break;
		}
	}
	IOLockUnlock(stateLock);
}

// Takes the displays' modes from a DISPLAYS answer (RgfxDisplayTable.hpp, rgfxListDisplays), and
// where the host took DISPLAY_SCALE each one's host screen's scale, the record after its own, into
// display 0's framebuffer and each head's (takeListing). Where the framebuffer took MULTI_DISPLAY,
// the start's first answer fixes how many displays the kext drives. Returns the answer's status.
UInt32 ReimsGraphics::parseDisplays(const volatile UInt8 *payload, UInt32 size)
{
	RgfxListedDisplay listed[RGFX_DISPLAYS_MAX];
	UInt32 count = 0, stored = 0;
	if (!rgfxListDisplays(payload, size, displayScaleTaken, listed, RGFX_DISPLAYS_MAX, &count,
	                      &stored))
		return kStatusUnreadable;
	ReimsGraphics *fbs[RGFX_DISPLAYS_MAX];
	const UInt32 n = copyDisplays(fbs);
	IOLockLock(stateLock);
	if (!displayCount)
		displayCount = rgfxDisplaysDriven(multiDisplayTaken, count);
	for (UInt32 i = 0; i < n; i++)
		fbs[i]->takeListing(listed, stored, payload);
	IOLockUnlock(stateLock);
	releaseDisplays(fbs, n);
	return 0;
}

// This framebuffer's display of those listed: display 0's is the first listed when it starts,
// and the display of that id after; a head's, its display's id. A list without it leaves the
// display disconnected with its modes. Modes its scanout room cannot hold are left out. A list
// that changes the modes or the scale makes the next server connection drop the mode
// configuration the last one left (newUserClient), and on arm64 the display published again,
// its density with it.
void ReimsGraphics::takeListing(const RgfxListedDisplay *listed, UInt32 n,
                                const volatile UInt8 *payload)
{
	const int at = haveDisplay || isHead() ? rgfxFindListed(listed, n, displayId) : (n ? 0 : -1);
	if (at < 0) {
		connected = false;
		return;
	}
	const RgfxListedDisplay &d = listed[at];
	Mode fresh[kMaxModes];
	UInt32 freshCount = 0, freshPreferred = kMaxModes;
	UInt64 limit = scanoutLimit();
	for (UInt32 j = 0; j < d.modeCount && freshCount < kMaxModes; j++) {
		UInt32 entry = d.modesAt + j * sizeof(RgfxModeEntry);
		Mode m = {0, field32(payload, entry), field32(payload, entry + 4),
		          field32(payload, entry + 8)};
		if (!m.width || !m.height || m.width > kMaxDimension || m.height > kMaxDimension ||
		    static_cast<UInt64>(strideFor(m.width)) * m.height > limit) {
			IOLog("ReimsGraphics: display %u: mode %ux%u left out: the region cannot hold it\n",
			      d.id, m.width, m.height);
			continue;
		}
		if (j == d.preferred)
			freshPreferred = freshCount;
		fresh[freshCount++] = m;
	}
	haveDisplay = true;
	displayId = d.id;
	connected = d.connected != 0;
	const bool rescaled = d.scale != displayScale;
	displayScale = d.scale;
	const bool changed = modeSet.take(fresh, freshCount, freshPreferred) || rescaled;
	if (changed)
		modeConfig.listChanged();
#if defined(__arm64e__)
	mobileListChanged = changed;
#endif
}

// MARK: - Modes and scanout

UInt32 ReimsGraphics::refreshMhzOf(const IODetailedTimingInformationV2 &t)
{
	UInt64 total = static_cast<UInt64>(t.horizontalActive + t.horizontalBlanking) *
	               (t.verticalActive + t.verticalBlanking);
	return total ? static_cast<UInt32>((t.pixelClock * 1000 + total / 2) / total) : 0;
}

ReimsGraphics::Mode ReimsGraphics::nativeMode(const Mode &m) const
{
	Mode native = m;
	for (UInt32 i = 0; i < modeSet.modeCount; i++) {
		if (modeSet.modes[i].id == modeSet.preferredId)
			native = modeSet.modes[i];
	}
	return native;
}

void ReimsGraphics::imageSize(const Mode &m, UInt16 *width, UInt16 *height) const
{
	// The preferred mode's size at the display's density; the EDID's is a reference display's.
	Mode native = nativeMode(m);
	*width = static_cast<UInt16>(rgfxDisplayMillimetres(native.width, displayScale));
	*height = static_cast<UInt16>(rgfxDisplayMillimetres(native.height, displayScale));
}

// A mode's information flags: valid and safe; the preferred mode is the default and the display's
// native one; and a mode RgfxMode::hiDpi takes on the display's host screen, `scale120ths`, is
// valid for HiDPI (kDisplayModeValidForHiResFlag). WindowServer then lists the mode at half its
// points each way as well, drawn at all its pixels, and starts on that one where the display's
// density says so (kRgfxDisplayConnectionFlags, RgfxDisplayIdentity.hpp). Measured on the x86-64
// guest, macOS 26.7.2: a 1600x900 HiDPI mode, once chosen, kept to the next boot. A mode whose
// pixels do not halve exactly has no HiDPI one; the host offers this
// framebuffer even modes, since with a native 3841x2161 the guest never brought its display up,
// with the flag or without it (CoreGraphics listed no mode, and the framebuffer's mode was set
// again every 10 seconds). A mode the device no longer shows is answered never shown
// (rgfxListedModeFlags).
UInt32 ReimsGraphics::modeFlags(const Mode &m, bool preferred, UInt32 scale120ths)
{
	UInt32 flags = kDisplayModeValidFlag | kDisplayModeSafeFlag;
	if (preferred)
		flags |= kDisplayModeDefaultFlag | kDisplayModeNativeFlag;
	if (m.hiDpi(scale120ths))
		flags |= kDisplayModeValidForHiResFlag;
	return flags;
}

UInt32 ReimsGraphics::strideFor(UInt32 width)
{
	return (width * 4 + kStrideAlign - 1) & ~(kStrideAlign - 1);
}

// The scanout buffer's room: RGFX_SCANOUT_SPAN at the guest's allocations, before the
// accelerator's blocks (RgfxScanoutOwner.hpp), so no mode reaches a process's memory; with several
// displays, this framebuffer's display's share of it (RgfxDisplayTable.hpp, rgfxDisplayRoom).
RgfxRoom ReimsGraphics::scanoutRoom() const
{
	return rgfxDisplayRoom(regionSize, kCursorSlot, isHead() ? displayId : 0, drivenDisplays());
}

UInt64 ReimsGraphics::scanoutLimit() const
{
	return scanoutRoom().length;
}

// The boot screen, black: the logo and progress bar the firmware and the kernel's console drew
// into the scanout, which the display shows again whenever it shows the scanout (PRESENT_SURFACE
// 0, when the last display pipe client goes: WindowServer's quit at a shutdown, or its crash).
// Measured on a macOS 26.7.2 guest: a shutdown showed the boot frame of 13 s in, unchanged, until
// power off. Cleared on the work loop at the answer of the first present of a surface, while the
// display shows that surface, so the clear is never seen; once, as nothing draws the boot screen
// again. A clear that finds no mapping is not tried again.
void ReimsGraphics::clearBootScreen()
{
	if (!region)
		return;
	IOLockLock(stateLock);
	const UInt64 largest = largestScanout;
	IOLockUnlock(stateLock);
	const UInt64 length = rgfxBootScreenSpan(bootConsole, largest, scanoutLimit());
	if (length == 0)
		return;
	IOMemoryMap *map = region->createMappingInTask(
	    kernel_task, 0, kIOMapAnywhere | kIOMapCopybackCache, RGFX_ALLOCATIONS_OFFSET, length);
	if (!map) {
		IOLog("ReimsGraphics: display %u: the boot screen was not cleared: no mapping of it\n",
		      displayId);
		return;
	}
	bzero(reinterpret_cast<void *>(map->getVirtualAddress()), static_cast<size_t>(length));
	map->release();
	IOLog("ReimsGraphics: display %u: the boot screen cleared (%llu bytes of the scanout)\n",
	      displayId, length);
}

// The display's whole room, as the VRAM range gives it, through a write-back mapping: the mode
// the processes' windows and the locks map the scanout in, as the accelerator zeroes a block
// before a window maps it (RgfxBlockZero.hpp). Once per new owner, so its time is logged each
// time, the mapping's (made and taken down) apart from the stores'.
bool ReimsGraphics::zeroScanoutRoom()
{
	const RgfxRoom own = scanoutRoom();
	if (!region || !own.length)
		return true;
	const UInt64 made = mach_absolute_time();
	IOMemoryMap *map = region->createMappingInTask(
	    kernel_task, 0, kIOMapAnywhere | kIOMapCopybackCache, own.offset, own.length);
	if (!map) {
		IOLog("ReimsGraphics: display %u: the scanout's room was not zeroed: no mapping of it\n",
		      displayId);
		return false;
	}
	const UInt64 mapped = mach_absolute_time();
	bzero(reinterpret_cast<void *>(map->getVirtualAddress()), static_cast<size_t>(own.length));
	const UInt64 stored = mach_absolute_time();
	map->release();
	const UInt64 mapNs = clockNs(mapped - made) + clockNs(mach_absolute_time() - stored);
	IOLog("ReimsGraphics: display %u: the scanout's room zeroed for its new owner: %llu KiB, "
	      "%llu us mapping, %llu us stores\n",
	      displayId, own.length >> 10, mapNs / 1000, clockNs(stored - mapped) / 1000);
	return true;
}

IOReturn ReimsGraphics::setScanout(const Mode &mode)
{
	UInt32 stride = strideFor(mode.width);
	const RgfxRoom own = scanoutRoom();
	if (static_cast<UInt64>(stride) * mode.height > own.length)
		return kIOReturnNoSpace;
	RgfxSetScanout s = {};
	s.display = displayId;
	s.width = mode.width;
	s.height = mode.height;
	s.stride = stride;
	s.offset = own.offset;
	IOReturn r = command(RGFX_CMD_SET_SCANOUT, &s, sizeof(s));
	if (r != kIOReturnSuccess)
		return r;
	const UInt64 span = static_cast<UInt64>(stride) * mode.height;
	IOLockLock(stateLock);
	modeSet.set(mode);
	if (span > largestScanout)
		largestScanout = span;
	IOLockUnlock(stateLock);
	IOLog("ReimsGraphics: display %u: scanout %ux%u at %u.%03u Hz, stride %u\n", displayId,
	      mode.width, mode.height, mode.refreshMhz / 1000, mode.refreshMhz % 1000, stride);
	return kIOReturnSuccess;
}

bool ReimsGraphics::ownsScanout(task_t task)
{
	if (!task || !stateLock)
		return false;
	IOLockLock(stateLock);
	const IOUserClient *client = static_cast<const IOUserClient *>(scanoutOwner.client);
	bool owns = scanoutOwner.owns(task, client && !client->isInactive());
	IOLockUnlock(stateLock);
	return owns;
}

bool ReimsGraphics::currentScanout(UInt32 *width, UInt32 *height, UInt32 *bytesPerRow,
                                   UInt64 *offset)
{
	if (!stateLock)
		return false;
	IOLockLock(stateLock);
	bool have = modeSet.haveCurrent;
	Mode m = modeSet.current;
	IOLockUnlock(stateLock);
	if (!have)
		return false;
	*width = m.width;
	*height = m.height;
	*bytesPerRow = strideFor(m.width);
	*offset = scanoutRoom().offset;
	return true;
}

// MARK: - IOService

// IOFramebuffer makes the connection; a server connection's task is the scanout's owner from
// then on, in place of the one before it, and while the open is in flight
// (RgfxScanoutOwner.hpp).
void ReimsGraphics::scanoutOwnerMoved(task_t owner)
{
	RgfxAccelerator *accelerator = copyAccelerator();
	if (!accelerator)
		return;
	accelerator->scanoutOwnerMoved(owner);
	accelerator->release();
}

RgfxAccelerator *ReimsGraphics::copyAccelerator()
{
	if (!pci)
		return nullptr;
	RgfxAccelerator *accelerator = nullptr;
	if (OSIterator *clients = pci->getClientIterator()) {
		while (OSObject *o = clients->getNextObject()) {
			accelerator = OSDynamicCast(RgfxAccelerator, o);
			if (accelerator) {
				accelerator->retain();
				break;
			}
		}
		clients->release();
	}
	return accelerator;
}

#if defined(__x86_64__)
IOReturn ReimsGraphics::newUserClient(task_t owningTask, void *securityID, UInt32 type,
                                      IOUserClient **clientH)
{
	// WindowServer's first server connection settles whether the accelerator registers this
	// boot (RgfxAccelerator::settleBundle), before IOFramebuffer makes the connection and with no
	// lock of ours held.
	if (type == kIOFBServerConnectType) {
		if (RgfxAccelerator *accelerator = copyAccelerator()) {
			accelerator->settleBundle();
			accelerator->release();
		}
	}
	if (type != kIOFBServerConnectType || !stateLock) {
		IOReturn r = super::newUserClient(owningTask, securityID, type, clientH);
		FBTRACE(32, "newUserClient type %u -> 0x%x", type, r);
		return r;
	}
	IOLockLock(stateLock);
	const IOUserClient *held = static_cast<const IOUserClient *>(scanoutOwner.client);
	bool clear = false;
	bool marked = scanoutOwner.beginOpen(owningTask, held && !held->isInactive(), &clear);
	bool stale = modeConfig.serverOpens();
	IOLockUnlock(stateLock);
	if (clear) {
		// A task that is not the scanout's last owner: the room holds what that owner left, which
		// goes before this task owns it (RgfxScanoutOwner.hpp). Every other task's hold of the
		// scanout goes first, so none of theirs lands after the zeros. A room the kernel will not
		// map for the zeros fails the open, as a block's does its grant.
		scanoutOwnerMoved(owningTask);
		const bool zeroed = zeroScanoutRoom();
		const void *oldTask = nullptr, *oldClient = nullptr;
		IOLockLock(stateLock);
		if (zeroed)
			scanoutOwner.endClear();
		else
			scanoutOwner.endOpen(owningTask, nullptr, marked, &oldTask, &oldClient);
		IOLockUnlock(stateLock);
		if (!zeroed)
			return kIOReturnNoMemory;
	}
	if (stale && getProperty(kIOFBConfigKey)) {
		// Made from a list the device has changed since (RgfxDisplayModes.hpp).
		removeProperty(kIOFBConfigKey);
		IOLog("ReimsGraphics: the display's modes changed since the last server connection: "
		      "its mode configuration is dropped\n");
	}
	IOReturn r = super::newUserClient(owningTask, securityID, type, clientH);
	FBTRACE(32, "newUserClient type %u -> 0x%x", type, r);
	IOUserClient *made = r == kIOReturnSuccess && clientH ? *clientH : nullptr;
	if (made) {
		task_reference(owningTask);
		made->retain();
	}
	const void *oldTask = nullptr, *oldClient = nullptr;
	IOLockLock(stateLock);
	scanoutOwner.endOpen(owningTask, made, marked, &oldTask, &oldClient);
	IOLockUnlock(stateLock);
	if (oldTask)
		task_deallocate(static_cast<task_t>(const_cast<void *>(oldTask)));
	if (oldClient)
		static_cast<const IOUserClient *>(oldClient)->release();
	// The owner moved: every other task's hold of the scanout is taken back.
	if (made)
		scanoutOwnerMoved(owningTask);
	RgfxCaller caller;
	if (made)
		IOLog("ReimsGraphics: the scanout's owner is %s[%d], which holds the server connection\n",
		      caller.name, caller.pid);
	else
		IOLog("ReimsGraphics: %s[%d]'s server connection was not made (0x%x): the scanout's "
		      "owner stays\n",
		      caller.name, caller.pid, r);
	return r;
}
#endif

// IOAcceleratorFamily2's IOAccelMemoryMap::getAssignedGPUVirtualAddressLength() const,
// referenced weakly and never called (assignedLengthExported). A binder that cannot resolve it
// binds it to gOSKextUnresolved, as the kernel's linker does, or to 0: either reads as absent.
// An arm64 kernel collection has no IOAcceleratorFamily2, so the arm64e kext references nothing
// of it and reads the function as absent.
#if defined(__x86_64__)
extern "C" void rgfxAssignedGPUVirtualAddressLength()
    __asm("__ZNK16IOAccelMemoryMap34getAssignedGPUVirtualAddressLengthEv") __attribute__((weak_import));
#endif

bool ReimsGraphics::start(IOService *provider)
{
	// A head (startHeads) starts on display 0's device.
	if (isHead())
		return startHead(provider);
	device = this;
	pci = OSDynamicCast(IOPCIDevice, provider);
	if (!pci)
		return false;
	// Before IOFramebuffer's start can move the console onto this framebuffer.
	publishBootConsole();
	submitLock = IOSimpleLockAlloc();
	interruptLock = IOSimpleLockAlloc();
	queueFilterLock = IOSimpleLockAlloc();
	stateLock = IOLockAlloc();
	presentsLock = IOLockAlloc();
	cursorLock = IOLockAlloc();
	if (!submitLock || !interruptLock || !queueFilterLock || !stateLock || !presentsLock ||
	    !cursorLock)
		return false;
	// The answers kept by pipeline key, empty at each start. Without the table, none is kept and
	// every create waits.
	if (!sharedPipelines)
		sharedPipelines = static_cast<SharedPipelines *>(IOMalloc(sizeof(SharedPipelines)));
	if (sharedPipelines)
		sharedPipelines->clear();
	started = false;
	nextSeqno = 1;
	largestScanout = 0;
	bootScreenSeqno = 0;
	bootScreenCleared = false;
	modeSet.reset();
	taken = false;
	submitRoom = false;
	displayColorTaken = false;
	displayScaleTaken = false;
	displayScale = 0;
	hostTime = false;
	guestTimes = false;
	displayPowerTaken = false;
	pipelineAnswersTaken = false;
	multiDisplayTaken = false;
	pointerMotionTaken = false;
#if defined(__arm64e__)
	cursorColorTaken = false;
	vtMessagesTaken = false;
	vtService = nullptr;
	vtConsumed = 0;
#endif
	displayBoundsTaken = false;
	boundsTold = {};
	displayCount = 0;
	refreshes = {};
	wranglerNotifier = nullptr;
	wranglerInterest = nullptr;
	// The device is lit from its reset (design.md, "The display's sleep").
	panelWanted = true;
	panelTold = true;
	roomStats = {};
	roomRecords = 0;
#if defined(__x86_64__)
	assignedLength = &rgfxAssignedGPUVirtualAddressLength != nullptr &&
	                 OSKextSymbolIsResolved(rgfxAssignedGPUVirtualAddressLength);
#else
	assignedLength = false;
#endif

	pci->setMemoryEnable(true);
	// setBusMasterEnable, which the SDK deprecates in favour of setBusLeadEnable: it is virtual, so
	// the call goes through IOPCIDevice's vtable, whose slot for it holds the same member on macOS 11
	// to 26, and the kext imports nothing for it. setBusLeadEnable is a plain member the kernel links
	// by name, and macOS 11's IOPCIFamily does not export it.
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
	pci->setBusMasterEnable(true);
#pragma clang diagnostic pop

	int msixIndex = -1;
	IOReturn r = kIOReturnSuccess;
	UInt32 count = 0;
	RgfxGetDisplays getDisplays = {};

	registerMap = pci->mapDeviceMemoryWithRegister(kIOPCIConfigBaseAddress0);
	if (!registerMap) {
		IOLog("ReimsGraphics: BAR0 not mapped\n");
		goto fail;
	}
	registers = reinterpret_cast<volatile UInt8 *>(registerMap->getVirtualAddress());
	if (readRegister(RGFX_REG_MAGIC) != RGFX_MAGIC) {
		IOLog("ReimsGraphics: not the device: magic 0x%x\n", readRegister(RGFX_REG_MAGIC));
		goto fail;
	}
	// The wire's version names the region's layout and the messages (design.md, "The wire's
	// version"): a kext of another version misreads them, so it leaves the device, writing
	// nothing to it.
	if (readRegister(RGFX_REG_VERSION) != RGFX_VERSION) {
		IOLog("ReimsGraphics: the device speaks wire version %u, this kext version %u: not starting. "
		      "The kext and the host must come from one build.\n",
		      readRegister(RGFX_REG_VERSION), RGFX_VERSION);
		goto fail;
	}
#if defined(__x86_64__)
	// Before the region's first mapping: the guest PAT's entry 2 to write-back on every CPU, so
	// that the region's write-back asks are write-back on AMD and Windows hosts, and again at each
	// wake (RgfxPat.hpp).
	rgfxPatWriteBackEverywhere("start");
	rgfxPatWatchWakes();
#endif

	region = pci->getDeviceMemoryWithRegister(kIOPCIConfigBaseAddress2);
	if (!region) {
		IOLog("ReimsGraphics: no BAR2\n");
		goto fail;
	}
	region->retain();
	regionSize = (static_cast<UInt64>(readRegister(RGFX_REG_REGION_SIZE_HI)) << 32) |
	             readRegister(RGFX_REG_REGION_SIZE_LO);
	if (regionSize > region->getLength())
		regionSize = region->getLength();
	if (regionSize <= RGFX_ALLOCATIONS_OFFSET + kCursorSlot) {
		IOLog("ReimsGraphics: the region is too small: 0x%llx bytes\n", regionSize);
		goto fail;
	}
	ringMap = region->createMappingInTask(kernel_task, 0, kIOMapAnywhere | kIOMapCopybackCache, 0,
	                                      RGFX_ALLOCATIONS_OFFSET);
	cursorMap = region->createMappingInTask(kernel_task, 0, kIOMapAnywhere | kIOMapCopybackCache,
	                                        regionSize - kCursorSlot, kCursorSlot);
	if (!ringMap || !cursorMap) {
		IOLog("ReimsGraphics: BAR2 not mapped\n");
		goto fail;
	}
	rings = reinterpret_cast<volatile UInt8 *>(ringMap->getVirtualAddress());
	cursorPixels = reinterpret_cast<UInt8 *>(cursorMap->getVirtualAddress());
	// Ring 0's submit data, write-combined where the region's write-combined mappings are
	// ordinary memory (RgfxControlRing.hpp), from a descriptor of its own: a mapping's cache mode
	// is set on its descriptor's one VM object (RgfxAccelerator::copyWriteCombinedRegion). Without
	// it, the data goes through `rings` as before.
	if (kRgfxControlWriteCombines) {
		IODeviceMemory *span = IODeviceMemory::withRange(
		    region->getPhysicalSegment(0, nullptr, kIOMemoryMapperNone) + kRgfxControlWcFrom,
		    kRgfxControlWcTo - kRgfxControlWcFrom);
		if (span) {
			controlDataMap = span->createMappingInTask(
			    kernel_task, 0, kIOMapAnywhere | kIOMapWriteCombineCache, 0,
			    kRgfxControlWcTo - kRgfxControlWcFrom);
			span->release();
		}
		if (controlDataMap)
			controlData = reinterpret_cast<volatile UInt8 *>(controlDataMap->getVirtualAddress());
	}

	// MSI-X vector 0 is the device's first message-signalled interrupt.
	for (int i = 0;; i++) {
		int type = 0;
		if (pci->getInterruptType(i, &type) != kIOReturnSuccess)
			break;
		if (type & (kIOInterruptTypePCIMessaged | kIOInterruptTypePCIMessagedX)) {
			msixIndex = i;
			break;
		}
	}
	if (msixIndex < 0) {
		IOLog("ReimsGraphics: no MSI-X interrupt\n");
		goto fail;
	}
	// Its filter wakes the queues' completion waiters as an interrupt arrives (filterAction), and
	// lets each through to the work loop.
	workLoop = IOWorkLoop::workLoop();
	if (workLoop) {
		msix = IOFilterInterruptEventSource::filterInterruptEventSource(this, serviceAction,
		                                                                filterAction, pci, msixIndex);
		kick = IOInterruptEventSource::interruptEventSource(this, serviceAction);
	}
	if (!msix || !kick || workLoop->addEventSource(msix) != kIOReturnSuccess ||
	    workLoop->addEventSource(kick) != kIOReturnSuccess) {
		IOLog("ReimsGraphics: no work loop\n");
		goto fail;
	}
	// The gate a waiter takes the completion ring in (lookForAnswer): without it, waiters sleep
	// for their answers alone.
	lookGate = IOCommandGate::commandGate(this);
	if (lookGate && workLoop->addEventSource(lookGate) != kIOReturnSuccess)
		OSSafeReleaseNULL(lookGate);
	if (!lookGate)
		IOLog("ReimsGraphics: no gate for waiters to look for their answers in: they sleep for "
		      "them\n");

	// The device from scratch: reset, then the features the kext takes of the host's offer
	// (RgfxFeatures.hpp), then take the rings' counters as they stand and say the driver is
	// ready. Every refusal above leaves the device untouched; from here on it is ours, and it is
	// reset again when the kext lets it go.
	taken = true;
	writeRegister(RGFX_REG_STATUS, RGFX_STATUS_RESET);
	{
		uint64_t offered = (static_cast<uint64_t>(readRegister(RGFX_REG_FEATURES_HI)) << 32) |
		                   readRegister(RGFX_REG_FEATURES_LO);
		// PAGES_16K first, where the kext takes it: a host whose page is 16 KiB shows the
		// features over guest RAM only from that take on (RgfxFeatures.hpp).
		if (const uint64_t first = rgfxDriverFeaturesFirst(offered)) {
			writeRegister(RGFX_REG_DRIVER_FEATURES_HI, static_cast<UInt32>(first >> 32));
			offered = (static_cast<uint64_t>(readRegister(RGFX_REG_FEATURES_HI)) << 32) |
			          readRegister(RGFX_REG_FEATURES_LO);
		}
#if defined(__arm64e__)
		// MULTI_DISPLAY only where the firmware placed display 1's node as well as display 0's
		// (RgfxFeatures.hpp): a process expects a service for each node it counts.
		mobileNodes = countMobileNodes();
		IOLog("ReimsGraphics: the firmware placed display nodes for %u displays\n", mobileNodes);
		const uint64_t wanted = rgfxDriverFeatures(offered, mobileNodes);
#else
		const uint64_t wanted = rgfxDriverFeatures(offered);
#endif
		writeRegister(RGFX_REG_DRIVER_FEATURES_LO, static_cast<UInt32>(wanted));
		writeRegister(RGFX_REG_DRIVER_FEATURES_HI, static_cast<UInt32>(wanted >> 32));
		const uint64_t took =
		    (static_cast<uint64_t>(readRegister(RGFX_REG_DRIVER_FEATURES_HI)) << 32) |
		    readRegister(RGFX_REG_DRIVER_FEATURES_LO);
		IOLog("ReimsGraphics: features offered 0x%llx, taken 0x%llx of 0x%llx\n", offered, took,
		      wanted);
		// The same three words on the registry, where the guest's tools read them at any time:
		// the kernel's message buffer has let go of the line by the time a login runs.
		setProperty("RgfxFeaturesOffered", offered, 64);
		setProperty("RgfxFeaturesWanted", wanted, 64);
		setProperty("RgfxFeaturesTaken", took, 64);
		submitRoom = (took & RGFX_FEATURE_SUBMIT_ROOM) != 0;
		displayColorTaken = (took & RGFX_FEATURE_DISPLAY_COLOR) != 0;
		displayScaleTaken = (took & RGFX_FEATURE_DISPLAY_SCALE) != 0;
		hostTime = (took & RGFX_FEATURE_HOST_TIME) != 0;
		guestTimes = (took & RGFX_FEATURE_GUEST_TIMES) != 0;
		displayPowerTaken = (took & RGFX_FEATURE_DISPLAY_POWER) != 0;
		pipelineAnswersTaken =
		    (took & (RGFX_FEATURE_PIPELINE_KEYS | RGFX_FEATURE_PIPELINE_ANSWERS)) ==
		    (RGFX_FEATURE_PIPELINE_KEYS | RGFX_FEATURE_PIPELINE_ANSWERS);
		multiDisplayTaken = (took & RGFX_FEATURE_MULTI_DISPLAY) != 0;
		pointerMotionTaken = (took & RGFX_FEATURE_POINTER_MOTION) != 0;
#if defined(__arm64e__)
		vtMessagesTaken = (took & RGFX_FEATURE_VT_MESSAGES) != 0;
		cursorColorTaken = (took & RGFX_FEATURE_CURSOR_COLOR) != 0;
#endif
		constexpr uint64_t kCarriesPast = RGFX_FEATURE_MULTI_DISPLAY | RGFX_FEATURE_POINTER_OVER |
		                                  RGFX_FEATURE_DISPLAY_BOUNDS;
		displayBoundsTaken = (took & kCarriesPast) == kCarriesPast;
	}
	produced = load64(ring(RGFX_CONTROL_SUBMIT_OFFSET) + kRingProducer);
	consumed = load64(ring(RGFX_CONTROL_COMPLETE_OFFSET) + kRingConsumer);
#if defined(__arm64e__)
	// The VideoToolbox ring lies in the rings' mapping, before the guest's allocations.
	static_assert(RGFX_VT_RING_OFFSET + RGFX_RING_HEADER_SIZE + RGFX_VT_RING_DATA_SIZE <=
	                  RGFX_ALLOCATIONS_OFFSET,
	              "the VideoToolbox ring lies in the rings' mapping");
	vtConsumed = load64(ring(RGFX_VT_RING_OFFSET) + kRingConsumer);
#endif
	armedAt = kRgfxNotArmed;
	writeRegister(RGFX_REG_STATUS, RGFX_STATUS_DRIVER_READY);
	ready = true;
	msix->enable();
	kick->enable();
	kickWorkLoop();

	r = command(RGFX_CMD_GET_DISPLAYS, &getDisplays, sizeof(getDisplays));
	IOLockLock(stateLock);
	count = haveDisplay ? modeSet.modeCount : 0;
	IOLockUnlock(stateLock);
	if (r != kIOReturnSuccess || !count) {
		IOLog("ReimsGraphics: the device lists no usable display\n");
		goto fail;
	}
	IOLog("ReimsGraphics: display %u, %u modes, region 0x%llx bytes\n", displayId, count, regionSize);
	if (displayCount > 1) {
		const RgfxRoom own = scanoutRoom();
		IOLog("ReimsGraphics: %u displays, each a framebuffer of its own; display 0's scanout room "
		      "0x%llx bytes at 0x%llx\n",
		      displayCount, own.length, own.offset);
		// The display count the accelerator states (DisplayPortCount), before it can register.
		if (RgfxAccelerator *accelerator = copyAccelerator()) {
			accelerator->setProperty("DisplayPortCount", static_cast<unsigned long long>(displayCount),
			                         64);
			accelerator->release();
		}
	}
	// Before any process can make a pipeline: the bundle loads once the accelerator is published.
	seedSharedPipelines();

	publishFramebuffer();
#if defined(__arm64e__)
	if (!startMobile())
		goto fail;
#endif
	if (!startPointer())
		goto fail;

	startDisplayPower();
#if defined(__arm64e__)
	// Where the heads start too, the class's start holds this display's registration, and each
	// head's start its own, until the heads have started or the hold is due, and the release
	// registers them on a thread call that keeps processes' reads waiting until they have matched
	// (RgfxRegisterHold.hpp). Without the lock or the call, the release registers them at once.
	if (!registerLock)
		registerLock = IOLockAlloc();
	if (registerLock && !registerCall)
		registerCall = thread_call_allocate(registrationsReleased, this);
	releasedDisplays = 0;
	registerWindow.end();
	{
		uint64_t due = 0;
		clock_interval_to_deadline(static_cast<uint32_t>(kRgfxRegisterHoldNs / 1000000),
		                           kMillisecondScale, &due);
		IOLockLock(stateLock);
		registerHold.open(rgfxFramebuffersOf(displayCount, mobileNodes), due);
		IOLockUnlock(stateLock);
	}
#endif
	// The device is ours and its rings are up: contexts may open from here, as the class's start
	// can register the framebuffer and WindowServer open it before it returns.
	__atomic_store_n(&started, true, __ATOMIC_RELEASE);
	if (super::start(provider)) {
		// The other displays' framebuffers, registered after this one.
		startHeads();
#if defined(__arm64e__)
		releaseRegistrations();
#endif
		startPointerDevice();
#if defined(__arm64e__)
		startVtService();
#endif
		return true;
	}
fail:
	__atomic_store_n(&started, false, __ATOMIC_RELEASE);
	stopDisplayPower();
#if defined(__x86_64__)
	// The PAT keeps its entry 2 write-back; no wake reapplies it once the kext's code may go.
	rgfxPatStopWatching();
#endif
#if defined(__arm64e__)
	// Nothing held is registered: the service did not start.
	if (stateLock) {
		IOLockLock(stateLock);
		registerHold.release();
		IOLockUnlock(stateLock);
	}
	freeRegistrations();
	stopMobile();
#endif
	quiesce();
#if defined(__arm64e__)
	freeMobileChanges();
#endif
	freePointer();
	teardown();
	return false;
}

void ReimsGraphics::stop(IOService *provider)
{
	if (isHead()) {
		stopHead(provider);
		return;
	}
	__atomic_store_n(&started, false, __ATOMIC_RELEASE);
#if defined(__arm64e__)
	freeRegistrations();
#endif
	stopHeads();
	stopDisplayPower();
#if defined(__x86_64__)
	rgfxPatStopWatching();
#endif
#if defined(__arm64e__)
	stopMobile();
#endif
	quiesce();
	stopPointerDevice();
#if defined(__arm64e__)
	stopVtService();
	freeMobileChanges();
#endif
	freePointer();
	super::stop(provider);
	teardown();
}

// No more commands, and no work loop action left running: removing an event
// source waits for its action. Every thread waiting for the device's answer, or for a waiter or
// the ring's room to ask with, is woken under stateLock and finds the device stopped (ready
// false), so a wait with no deadline (RgfxAnswerWait.hpp) ends with the device; and so are the
// surfaces' CPU locks waiting for the device (rgfxSurfaceLocksStopped).
void ReimsGraphics::quiesce()
{
	if (stateLock) {
		IOLockLock(stateLock);
		__atomic_store_n(&ready, false, __ATOMIC_RELEASE);
		for (ControlWaiter &w : controlWaiters)
			IOLockWakeup(stateLock, &w.done, false);
		for (LifecycleWaiter &w : lifecycleWaiters)
			IOLockWakeup(stateLock, &w.done, false);
		IOLockWakeup(stateLock, controlWaiters, false);
		IOLockWakeup(stateLock, lifecycleWaiters, false);
		IOLockWakeup(stateLock, &deferredAnswers, false);
		IOLockWakeup(stateLock, &room, false);
		IOLockUnlock(stateLock);
		rgfxSurfaceLocksStopped();
	} else {
		ready = false;
	}
	if (!workLoop)
		return;
	if (msix) {
		msix->disable();
		workLoop->removeEventSource(msix);
	}
	if (kick) {
		kick->disable();
		workLoop->removeEventSource(kick);
	}
	if (lookGate)
		workLoop->removeEventSource(lookGate);
}

// The boot framebuffer the platform expert's console info names now, before IOFramebuffer moves
// the console onto this framebuffer, as the RgfxBootFramebuffer property (RgfxBootConsole.hpp),
// and once in the log; kept for clearBootScreen.
void ReimsGraphics::publishBootConsole()
{
	PE_Video video = {};
	IOPlatformExpert *platform = getPlatform();
	const bool answered = platform && platform->getConsoleInfo(&video) == kIOReturnSuccess;
	const RgfxBootConsole boot = rgfxBootConsole(answered, video.v_baseAddr, video.v_rowBytes,
	                                             video.v_width, video.v_height, video.v_depth);
	bootConsole = boot;
	IOLog("ReimsGraphics: boot framebuffer %s 0x%llx (%ux%u, %u bytes a row, %u bits)\n",
	      boot.answered ? "at" : "unknown,", boot.address, boot.width, boot.height, boot.rowBytes,
	      boot.depth);
	OSDictionary *dict = OSDictionary::withCapacity(6);
	if (!dict)
		return;
	dict->setObject("Answered", boot.answered ? kOSBooleanTrue : kOSBooleanFalse);
	const struct {
		const char *key;
		UInt64 value;
		UInt32 bits;
	} fields[] = {
		{"Address", boot.address, 64}, {"Width", boot.width, 32},
		{"Height", boot.height, 32},   {"RowBytes", boot.rowBytes, 32},
		{"Depth", boot.depth, 32},
	};
	for (const auto &f : fields) {
		if (OSNumber *n = OSNumber::withNumber(f.value, f.bits)) {
			dict->setObject(f.key, n);
			n->release();
		}
	}
	setProperty(kRgfxBootFramebufferKey, dict);
	dict->release();
}

// A start refused before it took the device leaves it unreset, writing nothing to a device whose
// registers it may misread (design.md, "The wire's version"). One that took it resets it, and the
// reset keeps the scanout (design.md, "Reset"), so the boot framebuffer driver the OS falls back to
// after a failed start is still seen.
void ReimsGraphics::teardown()
{
	if (registers && taken)
		writeRegister(RGFX_REG_STATUS, RGFX_STATUS_RESET);
	taken = false;
	OSSafeReleaseNULL(msix);
	OSSafeReleaseNULL(kick);
	OSSafeReleaseNULL(lookGate);
	OSSafeReleaseNULL(workLoop);
	OSSafeReleaseNULL(cursorMap);
	OSSafeReleaseNULL(controlDataMap);
	OSSafeReleaseNULL(ringMap);
	OSSafeReleaseNULL(region);
	OSSafeReleaseNULL(registerMap);
	rings = nullptr;
	controlData = nullptr;
	cursorPixels = nullptr;
	registers = nullptr;
}

void ReimsGraphics::publishFramebuffer()
{
	// The display's accelerator and pipe, which the wrangler, CoreDisplay and IOPresentment read
	// off the framebuffer when it is published: every display is a pipe of the one accelerator on
	// the same PCI device, named by its service-plane path, which is the PCI device's path and
	// the accelerator's class name whichever of the two starts first. An accelerator that starts
	// after renames the PCI device (GFX0) and names itself again by its new path
	// (RgfxAccelerator::copyFramebuffer, nameAccelerator). A head takes display 0's name of it.
	// IOAccelIndex is the display's pipe of that accelerator, its id, which IOPresentment
	// associates the display's pipe client with (RgfxDisplayPipeUserClient's associate), as a
	// Mac's GPU numbers the framebuffers it drives: a MacBook Pro 2019's Radeon Pro 5300M gives
	// its five IOAccelIndex 0 to 4, each its IOFBDependentIndex (measured on macOS 26.7.1).
	if (isHead()) {
		if (OSObject *named = device->copyProperty("IOAccelTypes")) {
			setProperty("IOAccelTypes", named);
			named->release();
		}
	} else {
		char path[512];
		int length = sizeof(path) - sizeof("/RgfxAccelerator");
		if (pci->getPath(path, &length, gIOServicePlane)) {
			strlcat(path, "/RgfxAccelerator", sizeof(path));
			setProperty("IOAccelTypes", path);
		}
	}
	setProperty("IOAccelIndex", isHead() ? displayId : 0u, 32);

#if defined(__x86_64__)
	// Display 0's framebuffer is its controller's first dependent (index 0), named by its own
	// registry ID, and each head the dependent of that ID at its display's index: IOGraphics makes
	// one controller of the framebuffers of a dependent ID, each at its index, and the first of
	// them to open links every one started (IOGraphics' open source, IOFBController). IOFramebuffer
	// finishes a framebuffer's open (postOpen) only for one with a dependent ID: there it publishes
	// kIOFBNeedsRefreshKey, initialises the scanout (initFB) and tests the hardware cursor, which
	// publishes kIOFBCursorInfoKey.
	setProperty(kIOFBDependentIDKey, device->getRegistryEntryID(), 64);
	setProperty(kIOFBDependentIndexKey, isHead() ? displayId : 0u, 32);

	// The timings the OS may program (validateDetailedTiming takes only the device's modes
	// among them). The scanout has no signal of its own, so any sync and level goes, and
	// nothing optional (interlace, DSC: a version 1 range); no link limits are given, as no
	// link carries the pixels. RGB at 8 bits, in one-pixel steps.
	{
		IODisplayTimingRange range;
		bzero(&range, sizeof(range));
		range.version = kIOTimingRangeV1;
		range.minPixelClock = 1000000;
		range.maxPixelClock = 100000000000ull;
		range.supportedSyncFlags = kIORangeSupportsSeparateSyncs | kIORangeSupportsSyncOnGreen |
		                           kIORangeSupportsCompositeSync | kIORangeSupportsVSyncSerration;
		range.supportedSignalLevels = kIORangeSupportsSignal_0700_0300 | kIORangeSupportsSignal_0714_0286 |
		                              kIORangeSupportsSignal_1000_0400 | kIORangeSupportsSignal_0700_0000;
		range.minFrameRate = 1;
		range.maxFrameRate = 1000;
		range.minLineRate = 1;
		range.maxLineRate = 100000000;
		range.maxHorizontalTotal = 2 * kMaxDimension;
		range.maxVerticalTotal = 2 * kMaxDimension;
		range.charSizeHorizontalActive = 1;
		range.charSizeHorizontalBlanking = 1;
		range.charSizeHorizontalSyncOffset = 1;
		range.charSizeHorizontalSyncPulse = 1;
		range.charSizeVerticalActive = 1;
		range.charSizeVerticalBlanking = 1;
		range.charSizeVerticalSyncOffset = 1;
		range.charSizeVerticalSyncPulse = 1;
		range.charSizeHorizontalBorderLeft = 1;
		range.charSizeHorizontalBorderRight = 1;
		range.charSizeVerticalBorderTop = 1;
		range.charSizeVerticalBorderBottom = 1;
		range.charSizeHorizontalTotal = 1;
		range.charSizeVerticalTotal = 1;
		range.minHorizontalActiveClocks = 1;
		range.maxHorizontalActiveClocks = kMaxDimension;
		range.maxHorizontalBlankingClocks = kMaxDimension;
		range.maxHorizontalSyncOffsetClocks = kMaxDimension;
		range.maxHorizontalPulseWidthClocks = kMaxDimension;
		range.minVerticalActiveClocks = 1;
		range.maxVerticalActiveClocks = kMaxDimension;
		range.maxVerticalBlankingClocks = kMaxDimension;
		range.maxVerticalSyncOffsetClocks = kMaxDimension;
		range.maxVerticalPulseWidthClocks = kMaxDimension;
		range.supportedPixelEncoding = kIORangePixelEncodingRGB444;
		range.supportedBitsPerColorComponent = kIORangeBitsPerColorComponent8;
		range.supportedColorimetryModes = kIORangeColorimetryNativeRGB | kIORangeColorimetrysRGB;
		range.supportedDynamicRangeModes = kIORangeDynamicRangeSDR;
		OSData *data = OSData::withBytes(&range, sizeof(range));
		if (data) {
			setProperty(kIOFBTimingRangeKey, data);
			data->release();
		}
	}

	// The class name user space reads for the framebuffer: IOObjectCopyClass and IOObjectGetClass
	// answer this property where the service carries it. CoreDisplay takes the display's GPU
	// vendor from that name, searching it for the vendor names it knows, and keeps WindowServer's
	// accelerated, transactional display model (kIOWindowServerActiveAttribute) off for a name in
	// which it finds none, as it does for "ReimsGraphics".
	setProperty("IOClassNameOverride", "ReimsGraphicsAMD");
#endif
}

// MARK: - The other displays' framebuffers

// Each display from 1 gets a framebuffer of this class, a head, attached to the PCI device as
// display 0's is, at its display's location, and started there: its start (startHead) reads its
// modes from the device and registers it, after display 0's, before WindowServer opens any of them
// (IOGraphics links the framebuffers of a dependent ID that have started as the first one opens).
// On arm64 each framebuffer's registration is held meanwhile, and display 0's start registers them
// together once the heads have started (RgfxRegisterHold.hpp); a head that fails to start, or a
// hold past its deadline, ends the hold before the next head starts, and a head started after
// that registers as it starts. A head that does not start leaves its display undriven, its window
// black; the others go on.
void ReimsGraphics::startHeads()
{
#if defined(__arm64e__)
	// On arm64, a framebuffer for each display with a node the firmware placed
	// (rgfxFramebuffersOf).
	const UInt32 count = rgfxFramebuffersOf(displayCount, mobileNodes);
	for (UInt32 i = count; i < displayCount && i < RGFX_DISPLAYS_MAX; i++)
		IOLog("ReimsGraphics: display %u has no node under /arm-io, so no framebuffer\n", i);
#else
	const UInt32 count = displayCount;
#endif
	for (UInt32 i = 1; i < count && i < RGFX_DISPLAYS_MAX; i++) {
		const bool headStarted = startHeadAt(i);
#if defined(__arm64e__)
		IOLockLock(stateLock);
		const bool due = registerHold.due(!headStarted, mach_absolute_time());
		IOLockUnlock(stateLock);
		if (due)
			releaseRegistrations();
#else
		(void)headStarted;
#endif
	}
}

// Display `i`'s head, made, attached to the PCI device and started: whether it started.
bool ReimsGraphics::startHeadAt(UInt32 i)
{
	ReimsGraphics *head = OSTypeAlloc(ReimsGraphics);
	if (!head || !head->init()) {
		OSSafeReleaseNULL(head);
		IOLog("ReimsGraphics: display %u: no framebuffer for it: no memory\n", i);
		return false;
	}
	retain();
	head->device = this;
	head->displayId = i;
	char location[8];
	snprintf(location, sizeof(location), "%u", i);
	head->setLocation(location);
	// The table holds the allocation's reference.
	IOSimpleLockLock(interruptLock);
	heads[i] = head;
	IOSimpleLockUnlock(interruptLock);
	const bool attached = head->attach(pci);
	if (!attached || !head->start(pci)) {
		IOLog("ReimsGraphics: display %u: its framebuffer did not start\n", i);
		if (attached)
			head->detach(pci);
		dropHead(head);
		return false;
	}
	IOLog("ReimsGraphics: display %u: its framebuffer started\n", i);
	return true;
}

// The heads go as display 0's framebuffer stops: out of the table, so the work loop hands them
// nothing more, then terminated, which stops each (stopHead).
void ReimsGraphics::stopHeads()
{
	for (UInt32 i = 1; i < RGFX_DISPLAYS_MAX; i++) {
		IOSimpleLockLock(interruptLock);
		ReimsGraphics *head = heads[i];
		heads[i] = nullptr;
		IOSimpleLockUnlock(interruptLock);
		if (!head)
			continue;
		static_cast<IOService *>(head)->terminate();
		head->release();
	}
}

void ReimsGraphics::dropHead(ReimsGraphics *head)
{
	bool held = false;
	IOSimpleLockLock(interruptLock);
	for (UInt32 i = 1; i < RGFX_DISPLAYS_MAX; i++) {
		if (heads[i] == head) {
			heads[i] = nullptr;
			held = true;
		}
	}
	IOSimpleLockUnlock(interruptLock);
	if (held)
		head->release();
}

// A head's start: display 0's device, rings, locks and features, its own display's modes from a
// GET_DISPLAYS of its own (parseDisplays hands each framebuffer its display), then IOFramebuffer's
// start, which registers it.
bool ReimsGraphics::startHead(IOService *provider)
{
	pci = OSDynamicCast(IOPCIDevice, provider);
	if (!pci || !device->region || !device->ready)
		return false;
	stateLock = device->stateLock;
	interruptLock = device->interruptLock;
	presentsLock = device->presentsLock;
	region = device->region;
	region->retain();
	regionSize = device->regionSize;
	cursorPixels = device->cursorPixels;
	displayColorTaken = device->displayColorTaken;
#if defined(__arm64e__)
	cursorColorTaken = device->cursorColorTaken;
#endif
	displayScaleTaken = device->displayScaleTaken;
	displayPowerTaken = device->displayPowerTaken;
	assignedLength = device->assignedLength;
	started = false;
	modeSet.reset();
	largestScanout = 0;
	// The boot screen is display 0's alone (clearBootScreen).
	bootScreenCleared = true;
	IOSimpleLockLock(interruptLock);
	panelWanted = device->panelWanted;
	IOSimpleLockUnlock(interruptLock);
	panelTold = true;

	RgfxGetDisplays getDisplays = {};
	IOReturn r = command(RGFX_CMD_GET_DISPLAYS, &getDisplays, sizeof(getDisplays));
	IOLockLock(stateLock);
	const UInt32 count = haveDisplay ? modeSet.modeCount : 0;
	IOLockUnlock(stateLock);
	const RgfxRoom own = scanoutRoom();
	if (r != kIOReturnSuccess || !count) {
		IOLog("ReimsGraphics: display %u: the device lists no usable modes for it (0x%x)\n",
		      displayId, r);
		OSSafeReleaseNULL(region);
		return false;
	}
	IOLog("ReimsGraphics: display %u, %u modes, scanout room 0x%llx bytes at 0x%llx\n", displayId,
	      count, own.length, own.offset);
	publishFramebuffer();
#if defined(__arm64e__)
	// The head's display as a process finds it, and its pipe, as display 0's start sets up its
	// own.
	if (!startMobile()) {
		stopMobile();
		freeMobileChanges();
		OSSafeReleaseNULL(region);
		return false;
	}
#endif
	__atomic_store_n(&started, true, __ATOMIC_RELEASE);
	if (super::start(provider))
		return true;
	__atomic_store_n(&started, false, __ATOMIC_RELEASE);
#if defined(__arm64e__)
	stopMobile();
	freeMobileChanges();
#endif
	OSSafeReleaseNULL(region);
	return false;
}

// A head's stop: out of display 0's table first, so the work loop hands it nothing more. On arm64
// the work loop asks for the head's display changes only while the head is in the table and
// started (handleEvent), so its thread call is waited for and let go once the head is out.
void ReimsGraphics::stopHead(IOService *provider)
{
	__atomic_store_n(&started, false, __ATOMIC_RELEASE);
	device->dropHead(this);
#if defined(__arm64e__)
	stopMobile();
	freeMobileChanges();
#endif
	super::stop(provider);
	OSSafeReleaseNULL(region);
}

void ReimsGraphics::nameAccelerator(const char *path)
{
	if (isHead()) {
		device->nameAccelerator(path);
		return;
	}
	ReimsGraphics *fbs[RGFX_DISPLAYS_MAX];
	const UInt32 n = copyDisplays(fbs);
	for (UInt32 i = 0; i < n; i++) {
		OSString *named = OSDynamicCast(OSString, fbs[i]->getProperty("IOAccelTypes"));
		if (rgfxAccelTypesStale(named ? named->getCStringNoCopy() : nullptr, path))
			fbs[i]->setProperty("IOAccelTypes", path);
	}
	releaseDisplays(fbs, n);
}

void ReimsGraphics::free()
{
	// A head's locks are display 0's, which frees them; it lets display 0's framebuffer go.
	if (isHead()) {
		interruptLock = nullptr;
		stateLock = presentsLock = nullptr;
		ReimsGraphics *owner = device;
		device = nullptr;
		owner->release();
	}
	device = nullptr;
	if (cursorLock)
		IOLockFree(cursorLock);
	cursorLock = nullptr;
	if (submitLock)
		IOSimpleLockFree(submitLock);
	if (interruptLock)
		IOSimpleLockFree(interruptLock);
	// No filter call is running: quiesce disabled the vector's source, which waits for one
	// (IOInterruptController::disableInterrupt), and teardown let it go.
	if (queueFilterLock)
		IOSimpleLockFree(queueFilterLock);
	queueFilterLock = nullptr;
	if (stateLock)
		IOLockFree(stateLock);
	if (presentsLock)
		IOLockFree(presentsLock);
	submitLock = interruptLock = nullptr;
	stateLock = presentsLock = nullptr;
	if (sharedPipelines)
		IOFree(sharedPipelines, sizeof(SharedPipelines));
	sharedPipelines = nullptr;
	const void *oldTask = nullptr, *oldClient = nullptr;
	scanoutOwner.clear(&oldTask, &oldClient);
	if (oldTask)
		task_deallocate(static_cast<task_t>(const_cast<void *>(oldTask)));
	if (oldClient)
		static_cast<const IOUserClient *>(oldClient)->release();
	OSObject *clients[kMaxPipeClients];
	UInt32 held = pipes.all(clients);
	for (UInt32 i = 0; i < held; i++) {
		bool showScanout = false;
		pipes.remove(clients[i], &showScanout);
		clients[i]->release();
	}
	OSSafeReleaseNULL(queueTarget);
	OSSafeReleaseNULL(releaseTarget);
#if defined(__arm64e__)
	OSSafeReleaseNULL(mobileSwapAnswer);
	OSSafeReleaseNULL(mobileSwapLoop);
	// Its call let go in stop, or where the start failed; none is pending, as a pending call holds
	// the framebuffer.
	if (registerCall)
		thread_call_free(registerCall);
	registerCall = nullptr;
	if (registerLock)
		IOLockFree(registerLock);
	registerLock = nullptr;
	if (mobileICC)
		IOFree(mobileICC, sizeof(RgfxICCState));
	mobileICC = nullptr;
	if (mobileICCLock)
		IOLockFree(mobileICCLock);
	mobileICCLock = nullptr;
#endif
	super::free();
}

#if defined(__x86_64__)
// MARK: - IOFramebuffer: the device and its modes

IOReturn ReimsGraphics::enableController()
{
	Mode m;
	IOLockLock(stateLock);
	IODisplayModeID startup = modeSet.startupId;
	bool ok = modeSet.modeFor(startup, &m);
	IOLockUnlock(stateLock);
	IOReturn r = ok ? setScanout(m) : kIOReturnNotReady;
	FBTRACE(8, "enableController: startup mode %d -> 0x%x", static_cast<int>(startup), r);
	return r;
}

IODeviceMemory *ReimsGraphics::getApertureRange(IOPixelAperture aperture)
{
	if (aperture != kIOFBSystemAperture || !region)
		return nullptr;
	Mode m;
	IOLockLock(stateLock);
	bool ok = modeSet.haveCurrent ? (m = modeSet.current, true)
	                              : modeSet.modeFor(modeSet.startupId, &m);
	IOLockUnlock(stateLock);
	if (!ok)
		return nullptr;
	UInt64 length = round_page_64(static_cast<UInt64>(strideFor(m.width)) * m.height);
	FBTRACE(8, "getApertureRange: %ux%u, 0x%llx bytes", m.width, m.height, length);
	return IODeviceMemory::withSubRange(region, scanoutRoom().offset, length);
}

// The scanout's room. IOFramebuffer maps it into the task that asks for it on a user client (its
// server connection, and its shared one for any task of the console's user), calling this on that
// task's thread (IOGraphics' open source, clientMemoryForType). It asks in its own setup too
// (setupForCurrentConfig: in the kernel, inside the server connection's open, and for each new
// mode on the thread of the task that set it), where it reads the room's size into
// kIOFBMemorySizeKey and the aperture's offset in it. So the room goes to the scanout's owner on
// the connection it holds alone, and IOFramebuffer's setup and every other task get none
// (RgfxScanoutOwner.hpp): the framebuffer publishes no memory size. The aperture
// (getApertureRange), which the kernel maps for the console, is another range, and stays.
IODeviceMemory *ReimsGraphics::getVRAMRange()
{
	if (!region)
		return nullptr;
	task_t task = current_task();
	bool ownerConnected = false;
	bool inSetup = false;
	if (task != kernel_task && stateLock) {
		IOLockLock(stateLock);
		const IOUserClient *client = static_cast<const IOUserClient *>(scanoutOwner.client);
		ownerConnected = scanoutOwner.holdsConnection(task, client && !client->isInactive());
		inSetup = scanoutOwner.inSetup(current_thread());
		IOLockUnlock(stateLock);
	}
	bool given = rgfxMayMapVram(task, kernel_task, ownerConnected, inSetup);
	static char site;
	RgfxCaller caller;
	if (caller.pid != 0 && rgfxFirstCalls(&site, static_cast<UInt64>(caller.pid), 4))
		IOLog("ReimsGraphics: the VRAM range %s %s[%d]\n",
		      given ? "goes to the scanout's owner" : "is refused to", caller.name, caller.pid);
	if (!given)
		return nullptr;
	const RgfxRoom own = scanoutRoom();
	return IODeviceMemory::withSubRange(region, own.offset, own.length);
}

// IOFramebuffer's setup for the current mode: the thread that runs it is marked while it runs, so
// the VRAM range it asks for there is refused (getVRAMRange).
IOReturn ReimsGraphics::setupForCurrentConfig()
{
	const void *outer = nullptr;
	if (stateLock) {
		IOLockLock(stateLock);
		outer = scanoutOwner.beginSetup(current_thread());
		IOLockUnlock(stateLock);
	}
	IOReturn r = super::setupForCurrentConfig();
	if (stateLock) {
		IOLockLock(stateLock);
		scanoutOwner.endSetup(outer);
		IOLockUnlock(stateLock);
	}
	FBTRACE(8, "setupForCurrentConfig -> 0x%x", r);
	return r;
}

const char *ReimsGraphics::getPixelFormats()
{
	static const char formats[] = IO32BitDirectPixels "\0";
	return formats;
}

IOItemCount ReimsGraphics::getDisplayModeCount()
{
	IOLockLock(stateLock);
	reportedCount = modeSet.list(nullptr);
	IOLockUnlock(stateLock);
	FBTRACE(16, "getDisplayModeCount -> %u", reportedCount);
	return reportedCount;
}

// The caller's array holds the count last reported. A DISPLAYS answer may
// change the list in between: then the array still names the mode set, and the
// connect interrupt that follows has IOFramebuffer ask again (Modes::fill).
IOReturn ReimsGraphics::getDisplayModes(IODisplayModeID *allDisplayModes)
{
	IOLockLock(stateLock);
	modeSet.fill(allDisplayModes, reportedCount);
	FBTRACE(16, "getDisplayModes: %u modes, first %d", reportedCount,
	        reportedCount ? static_cast<int>(allDisplayModes[0]) : -1);
	IOLockUnlock(stateLock);
	return kIOReturnSuccess;
}

IOReturn ReimsGraphics::getInformationForDisplayMode(IODisplayModeID displayMode,
                                                     IODisplayModeInformation *info)
{
	Mode m;
	IOLockLock(stateLock);
	bool ok = modeSet.modeFor(displayMode, &m);
	bool preferred = ok && modeSet.isPreferred(m);
	const bool stale = ok && modeSet.stale(m.id);
	const UInt32 scale = displayScale;
	UInt16 mmWide = 0, mmHigh = 0;
	if (ok)
		imageSize(m, &mmWide, &mmHigh);
	IOLockUnlock(stateLock);
	FBTRACE(48, "getInformationForDisplayMode %d: %s %ux%u", static_cast<int>(displayMode),
	        ok ? "ok" : "UNKNOWN", ok ? m.width : 0, ok ? m.height : 0);
	if (!info)
		return kIOReturnBadArgument;
	if (!ok)
		return noSuchMode(RgfxModeCall::ModeInformation);
	bzero(info, sizeof(*info));
	info->nominalWidth = m.width;
	info->nominalHeight = m.height;
	info->refreshRate = static_cast<IOFixed1616>((static_cast<UInt64>(m.refreshMhz) << 16) / 1000);
	info->maxDepthIndex = 0;
	info->flags = rgfxListedModeFlags(modeFlags(m, preferred, scale), stale);
	info->imageWidth = mmWide;
	info->imageHeight = mmHigh;
	return kIOReturnSuccess;
}

UInt64 ReimsGraphics::getPixelFormatsForDisplayMode(IODisplayModeID, IOIndex)
{
	return 0;
}

IOReturn ReimsGraphics::getPixelInformation(IODisplayModeID displayMode, IOIndex depth,
                                            IOPixelAperture aperture, IOPixelInformation *pixelInfo)
{
	FBTRACE(48, "getPixelInformation mode %d depth %d aperture %d", static_cast<int>(displayMode),
	        static_cast<int>(depth), static_cast<int>(aperture));
	if (depth != 0 || aperture != kIOFBSystemAperture || !pixelInfo)
		return noSuchMode(RgfxModeCall::PixelInformation);
	Mode m;
	IOLockLock(stateLock);
	bool ok = modeSet.modeFor(displayMode, &m);
	IOLockUnlock(stateLock);
	if (!ok)
		return noSuchMode(RgfxModeCall::PixelInformation);
	// 32-bit BGRA8: little-endian 0x00RRGGBB words.
	bzero(pixelInfo, sizeof(*pixelInfo));
	pixelInfo->bytesPerRow = strideFor(m.width);
	pixelInfo->bitsPerPixel = 32;
	pixelInfo->pixelType = kIORGBDirectPixels;
	pixelInfo->componentCount = 3;
	pixelInfo->bitsPerComponent = 8;
	pixelInfo->componentMasks[0] = 0x00ff0000;
	pixelInfo->componentMasks[1] = 0x0000ff00;
	pixelInfo->componentMasks[2] = 0x000000ff;
	strlcpy(pixelInfo->pixelFormat, IO32BitDirectPixels, sizeof(pixelInfo->pixelFormat));
	pixelInfo->activeWidth = m.width;
	pixelInfo->activeHeight = m.height;
	return kIOReturnSuccess;
}

IOReturn ReimsGraphics::getCurrentDisplayMode(IODisplayModeID *displayMode, IOIndex *depth)
{
	IOLockLock(stateLock);
	IODisplayModeID id = modeSet.haveCurrent ? modeSet.current.id : modeSet.startupId;
	IOLockUnlock(stateLock);
	FBTRACE(32, "getCurrentDisplayMode -> %d", static_cast<int>(id));
	if (displayMode)
		*displayMode = id;
	if (depth)
		*depth = 0;
	return kIOReturnSuccess;
}

IOReturn ReimsGraphics::setDisplayMode(IODisplayModeID displayMode, IOIndex depth)
{
	FBTRACE(16, "setDisplayMode %d depth %d", static_cast<int>(displayMode), static_cast<int>(depth));
	if (depth != 0)
		return noSuchMode(RgfxModeCall::SetMode);
	Mode m;
	IOLockLock(stateLock);
	bool ok = modeSet.modeFor(displayMode, &m);
	IOLockUnlock(stateLock);
	return ok ? setScanout(m) : noSuchMode(RgfxModeCall::SetMode);
}

IOReturn ReimsGraphics::getStartupDisplayMode(IODisplayModeID *displayMode, IOIndex *depth)
{
	IOLockLock(stateLock);
	IODisplayModeID id = modeSet.startupId;
	IOLockUnlock(stateLock);
	FBTRACE(16, "getStartupDisplayMode -> %d", static_cast<int>(id));
	if (displayMode)
		*displayMode = id;
	if (depth)
		*depth = 0;
	return kIOReturnSuccess;
}

IOReturn ReimsGraphics::setStartupDisplayMode(IODisplayModeID displayMode, IOIndex depth)
{
	FBTRACE(16, "setStartupDisplayMode %d depth %d", static_cast<int>(displayMode),
	        static_cast<int>(depth));
	if (depth != 0)
		return noSuchMode(RgfxModeCall::SetStartupMode);
	Mode m;
	IOLockLock(stateLock);
	bool ok = modeSet.modeFor(displayMode, &m);
	if (ok)
		modeSet.startupId = displayMode;
	IOLockUnlock(stateLock);
	return ok ? kIOReturnSuccess : noSuchMode(RgfxModeCall::SetStartupMode);
}

// Each mode is a fixed-rate panel's, with the timing timingFor gives it.
IOReturn ReimsGraphics::getTimingInfoForDisplayMode(IODisplayModeID displayMode,
                                                    IOTimingInformation *info)
{
	Mode m;
	IODetailedTimingInformationV2 given;
	IOLockLock(stateLock);
	bool ok = modeSet.modeFor(displayMode, &m);
	const Modes::Programmed *p = modeSet.programmedFor(displayMode);
	if (p)
		given = p->timing;
	IOLockUnlock(stateLock);
	FBTRACE(48, "getTimingInfoForDisplayMode %d: %s%s, flags in 0x%x", static_cast<int>(displayMode),
	        ok ? "ok" : "UNKNOWN", p ? " programmed" : "", info ? static_cast<unsigned>(info->flags) : 0);
	if (!info)
		return kIOReturnBadArgument;
	if (!ok)
		return noSuchMode(RgfxModeCall::TimingInformation);
	if (p) {
		// A programmed timing is no standard one: it is given back as the OS gave it.
		bzero(info, sizeof(*info));
		info->appleTimingID = kIOTimingIDInvalid;
		info->flags = kIODetailedTimingValid;
		info->detailedInfo.v2 = given;
		return kIOReturnSuccess;
	}
	Timing timing;
	timingFor(m, &timing);
	bzero(info, sizeof(*info));
	info->appleTimingID = kIOTimingIDApple_FixedRateLCD;
	info->flags = kIODetailedTimingValid;
	IODetailedTimingInformationV2 &t = info->detailedInfo.v2;
	t.pixelClock = timing.pixelClock;
	t.minPixelClock = timing.pixelClock;
	t.maxPixelClock = timing.pixelClock;
	t.horizontalActive = timing.hActive;
	t.horizontalBlanking = timing.hBlank;
	t.horizontalSyncOffset = timing.hFront;
	t.horizontalSyncPulseWidth = timing.hSync;
	t.verticalActive = timing.vActive;
	t.verticalBlanking = timing.vBlank;
	t.verticalSyncOffset = timing.vFront;
	t.verticalSyncPulseWidth = timing.vSync;
	// Reduced blanking's sync: horizontal positive, vertical negative.
	t.horizontalSyncConfig = kIOSyncPositivePolarity;
	t.verticalSyncConfig = 0;
	return kIOReturnSuccess;
}

// IOFramebuffer gives a mode's valid, safe and default flags from IODisplay, which asks this
// (IOFramebuffer::extGetInformationForDisplayMode and IODisplay::getConnectFlagsForDisplayMode,
// read from IOGraphics' published source): unanswered, every mode is valid and safe alone. Of
// the modes valid and safe, IOGraphicsLib's default is the one flagged default, else the one of
// the most pixels (IOKitUser's published source), and WindowServer takes the default when the
// display changes. Measured on the x86-64 guest, macOS 26.7.2, with no flag answered here: once
// the window shrank, the mode set, which stays listed until another is set, was the default, so
// the guest kept it. The preferred mode is the default, and a mode the framebuffer does not list
// is left to IODisplay.
IOReturn ReimsGraphics::connectFlags(IOIndex connectIndex, IODisplayModeID displayMode,
                                     IOOptionBits *flags)
{
	Mode m;
	IOLockLock(stateLock);
	bool ok = modeSet.modeFor(displayMode, &m);
	bool preferred = ok && modeSet.isPreferred(m);
	const bool stale = ok && modeSet.stale(m.id);
	const UInt32 scale = displayScale;
	IOLockUnlock(stateLock);
	IOReturn r = kIOReturnUnsupported;
	if (connectIndex != 0 || !flags)
		r = kIOReturnBadArgument;
	else if (ok) {
		*flags = rgfxListedModeFlags(modeFlags(m, preferred, scale), stale) &
		         kDisplayModeSafetyFlags;
		r = kIOReturnSuccess;
	}
	FBTRACE(48, "connectFlags conn %d mode %d -> 0x%x flags 0x%x", static_cast<int>(connectIndex),
	        static_cast<int>(displayMode), r,
	        r == kIOReturnSuccess ? static_cast<unsigned>(*flags) : 0);
	return r;
}

// A timing the device can show: a listed mode's size and rate, unscaled and progressive. For a
// mode description, the description's mode information is filled in.
IOReturn ReimsGraphics::validateDetailedTiming(void *description, IOByteCount descripSize)
{
	IOFBDisplayModeDescription *desc = nullptr;
	IODetailedTimingInformationV2 *t = nullptr;
	if (description && descripSize == sizeof(IOFBDisplayModeDescription)) {
		desc = static_cast<IOFBDisplayModeDescription *>(description);
		t = &desc->timingInfo.detailedInfo.v2;
	} else if (description && descripSize == sizeof(IODetailedTimingInformationV2)) {
		t = static_cast<IODetailedTimingInformationV2 *>(description);
	} else {
		FBTRACE(8, "validateDetailedTiming: %lu bytes: not a timing",
		        static_cast<unsigned long>(descripSize));
		return kIOReturnUnsupported;
	}
	bool scaled = (t->horizontalScaled && t->horizontalScaled != t->horizontalActive) ||
	              (t->verticalScaled && t->verticalScaled != t->verticalActive) ||
	              t->horizontalScaledInset || t->verticalScaledInset;
	UInt32 refresh = refreshMhzOf(*t);
	Mode host;
	IOLockLock(stateLock);
	bool ok = !scaled && !(t->signalConfig & kIOInterlacedCEATiming) &&
	          modeSet.deviceMode(t->horizontalActive, t->verticalActive, refresh, &host);
	bool preferred = ok && host.id == modeSet.preferredId;
	const UInt32 scale = displayScale;
	UInt16 mmWide = 0, mmHigh = 0;
	if (ok)
		imageSize(host, &mmWide, &mmHigh);
	IOLockUnlock(stateLock);
	FBTRACE(32, "validateDetailedTiming %ux%u (scaled %ux%u) at %u mHz, clock %llu: %s",
	        t->horizontalActive, t->verticalActive, t->horizontalScaled, t->verticalScaled, refresh,
	        t->pixelClock, ok ? "ok" : "REFUSED");
	if (!ok)
		return kIOReturnUnsupportedMode;
	if (desc) {
		IODisplayModeInformation &info = desc->info;
		bzero(&info, sizeof(info));
		info.nominalWidth = t->horizontalActive;
		info.nominalHeight = t->verticalActive;
		info.refreshRate = static_cast<IOFixed1616>((static_cast<UInt64>(refresh) << 16) / 1000);
		info.maxDepthIndex = 0;
		info.flags = modeFlags(host, preferred, scale);
		info.imageWidth = mmWide;
		info.imageHeight = mmHigh;
	}
	return kIOReturnSuccess;
}

// Each element is an OSData of an IODetailedTimingInformationV2 whose first reserved word is
// the mode ID the OS gave it, at or past kIODisplayModeIDReservedBase. The mode set takes the ID
// of a programmed timing of its size and rate, as the list now names it.
IOReturn ReimsGraphics::setDetailedTimings(OSArray *array)
{
	UInt32 programmed = 0;
	IOLockLock(stateLock);
	modeSet.clearProgrammed();
	for (UInt32 i = 0; array && i < array->getCount(); i++) {
		OSData *data = OSDynamicCast(OSData, array->getObject(i));
		if (!data || data->getLength() < sizeof(IODetailedTimingInformationV2))
			continue;
		IODetailedTimingInformationV2 t;
		memcpy(&t, data->getBytesNoCopy(), sizeof(t));
		IODisplayModeID id = static_cast<IODisplayModeID>(t.__reservedA[0]);
		if (!t.horizontalActive || !t.verticalActive || t.horizontalActive > kMaxDimension ||
		    t.verticalActive > kMaxDimension)
			continue;
		Mode m = {id, t.horizontalActive, t.verticalActive, refreshMhzOf(t)};
		if (modeSet.addProgrammed(id, m, t, kIODisplayModeIDReservedBase) &&
		    modeSet.deviceMode(m.width, m.height, m.refreshMhz, nullptr))
			programmed++;
	}
	modeSet.followProgrammed();
	UInt32 count = modeSet.programmedCount;
	IOLockUnlock(stateLock);
	if (array)
		setProperty(kIOFBDetailedTimingsKey, array);
	else
		removeProperty(kIOFBDetailedTimingsKey);
	IOLog("ReimsGraphics: display %u: %u programmed timings, %u of them the device's modes\n",
	      displayId, count, programmed);
	return kIOReturnSuccess;
}

// MARK: - IOFramebuffer: attributes and the display's connection

IOReturn ReimsGraphics::getAttribute(IOSelect attribute, uintptr_t *value)
{
	if (attribute == kIOHardwareCursorAttribute) {
		if (value)
			*value = 1;
		traceAttribute("getAttribute", -1, attribute, 1, kIOReturnSuccess);
		return kIOReturnSuccess;
	}
	if (attribute == kIOWindowServerActiveAttribute) {
		// WindowServer's access to the display, as it last set it (setAttribute).
		if (!value)
			return kIOReturnBadArgument;
		*value = windowServerActive;
		traceAttribute("getAttribute", -1, attribute, *value, kIOReturnSuccess);
		return kIOReturnSuccess;
	}
	IOReturn r = super::getAttribute(attribute, value);
	traceAttribute("getAttribute", -1, attribute, value ? *value : 0, r);
	return r;
}

IOReturn ReimsGraphics::setAttribute(IOSelect attribute, uintptr_t value)
{
	// The device has no power states of its own, and the framebuffer registers none (Power).
	if (attribute == kIOPowerAttribute) {
		traceAttribute("setAttribute", -1, attribute, value, kIOReturnSuccess);
		return kIOReturnSuccess;
	}
	if (attribute == kIOWindowServerActiveAttribute) {
		// WindowServer's access to the display (a kIOWSAA_ state: CPU only, GPU only, or moving
		// between them, with or without the transactional bit, which the display pipe's
		// transactions follow): recorded, for getAttribute. The display shows the scanout, or
		// the surface the display pipe last presented, in every state.
		windowServerActive = static_cast<UInt32>(value);
		traceAttribute("setAttribute", -1, attribute, value, kIOReturnSuccess);
		return kIOReturnSuccess;
	}
	IOReturn r = super::setAttribute(attribute, value);
	traceAttribute("setAttribute", -1, attribute, value, r);
	return r;
}

IOItemCount ReimsGraphics::getConnectionCount()
{
	return 1;
}

IOReturn ReimsGraphics::getAttributeForConnection(IOIndex connectIndex, IOSelect attribute,
                                                  uintptr_t *value)
{
#if RGFX_FB_TRACE
	IOReturn r = connectionAttribute(connectIndex, attribute, value);
	traceAttribute("getAttributeForConnection", connectIndex, attribute,
	               value && r == kIOReturnSuccess ? *value : 0, r);
	return r;
}

IOReturn ReimsGraphics::connectionAttribute(IOIndex connectIndex, IOSelect attribute,
                                            uintptr_t *value)
{
#endif
	if (connectIndex != 0)
		return kIOReturnBadArgument;
	switch (attribute) {
	case kConnectionEnable:
	case kConnectionCheckEnable:
		if (!value)
			return kIOReturnBadArgument;
		IOLockLock(stateLock);
		*value = connected ? 1 : 0;
		IOLockUnlock(stateLock);
		return kIOReturnSuccess;
	case kConnectionFlags:
		// Built in, so the display's density picks its default scale (RgfxDisplayIdentity.hpp).
		if (!value)
			return kIOReturnBadArgument;
		*value = kRgfxDisplayConnectionFlags;
		return kIOReturnSuccess;
	case kConnectionSupportsHLDDCSense:
		// The driver's own EDID, block by block (getDDCBlock); value may be null.
		return kIOReturnSuccess;
	case kConnectionSupportsLLDDCSense:
	case kConnectionSupportsAppleSense:
		// No I2C lines and no sense lines.
		return kIOReturnUnsupported;
	default:
		// IOFramebuffer answers the rest, the display's parameters among them
		// (kConnectionDisplayParameterCount and kConnectionDisplayParameters: its red, green and
		// blue gamma scales and its VBL multiplier), which IODisplay publishes as
		// IODisplayParameters.
		return super::getAttributeForConnection(connectIndex, attribute, value);
	}
}

IOReturn ReimsGraphics::setAttributeForConnection(IOIndex connectIndex, IOSelect attribute,
                                                  uintptr_t value)
{
#if RGFX_FB_TRACE
	IOReturn r = setConnectionAttribute(connectIndex, attribute, value);
	traceAttribute("setAttributeForConnection", connectIndex, attribute, value, r);
	return r;
}

IOReturn ReimsGraphics::setConnectionAttribute(IOIndex connectIndex, IOSelect attribute,
                                               uintptr_t value)
{
#endif
	if (connectIndex != 0)
		return kIOReturnBadArgument;
	switch (attribute) {
	case kConnectionProbe:
	case kConnectionChanged:
	case kConnectionPower:
		// The modes are already the device's latest: the driver asks again
		// on every DISPLAY_CHANGED before it signals the change.
		return kIOReturnSuccess;
	default:
		return super::setAttributeForConnection(connectIndex, attribute, value);
	}
}

// MARK: - The display's timings (both front ends: arm64e's modes too) and EDID
#endif // defined(__x86_64__)
void ReimsGraphics::timingFor(const Mode &mode, Timing *t)
{
	// Reduced blanking: 80 pixels of horizontal blank (8 front porch, 32 sync), and enough
	// lines of vertical blank to last 460 us at the mode's rate, at least the sync's 8 and
	// the back porch's 6 and one front porch line. 460 us is the fraction
	// refreshMhz * 460 / 1e9 of a frame, so the blank is vActive * f / (1 - f) lines.
	t->hActive = mode.width;
	t->hBlank = 80;
	t->hFront = 8;
	t->hSync = 32;
	t->vActive = mode.height;
	t->vSync = 8;
	UInt64 blankPart = static_cast<UInt64>(mode.refreshMhz) * 460;
	UInt64 activePart = 1000000000ull > blankPart ? 1000000000ull - blankPart : 1;
	UInt64 vBlank = (static_cast<UInt64>(mode.height) * blankPart + activePart - 1) / activePart;
	if (vBlank < 8 + 6 + 1)
		vBlank = 8 + 6 + 1;
	t->vBlank = static_cast<UInt32>(vBlank);
	t->vFront = t->vBlank - t->vSync - 6;
	UInt64 total = static_cast<UInt64>(t->hActive + t->hBlank) * (t->vActive + t->vBlank);
	UInt64 clock = total * mode.refreshMhz / 1000;
	// macOS takes the display's rate from this timing: CVDisplayLink's nominal period is
	// IOFBCurrentPixelCount / IOFBCurrentPixelClock (measured on an x86 Mac's 60 Hz panel:
	// 6225200 / 373510000 s, a nominal period of 16666755 ns), and WebKit rounds that
	// period's inverse to whole frames a second to pick its pages' rate. Rounding the clock
	// to 10 kHz moves the rate by at most 5 kHz over the frame's pixels, far below the
	// half hertz that would change WebKit's whole number.
	t->pixelClock = (clock + 5000) / 10000 * 10000;
}
#if defined(__x86_64__)
// The EDID is one base block, made from the display's id, its host screen's scale and its native
// mode's size (RgfxDisplayIdentity.hpp).
bool ReimsGraphics::makeEdid(UInt32 index, UInt8 *b) const
{
	if (index > 0)
		return false;
	const Mode native = nativeMode(modeSet.current);
	rgfxDisplayEdid(b, displayId, displayScale, native.width, native.height);
	return true;
}

bool ReimsGraphics::hasDDCConnect(IOIndex connectIndex)
{
	IOLockLock(stateLock);
	bool r = connectIndex == 0 && haveDisplay && connected;
	IOLockUnlock(stateLock);
	FBTRACE(8, "hasDDCConnect %d -> %d", static_cast<int>(connectIndex), r);
	return r;
}

// Block 1 is the base block, as IODisplay asks for it; there is no other.
IOReturn ReimsGraphics::getDDCBlock(IOIndex connectIndex, UInt32 blockNumber, IOSelect blockType,
                                    IOOptionBits options, UInt8 *data, IOByteCount *length)
{
	if (connectIndex != 0 || blockType != kIODDCBlockTypeEDID || !blockNumber || !data || !length ||
	    *length < kEdidBlockBytes)
		return kIOReturnBadArgument;
	IOLockLock(stateLock);
	bool ok = haveDisplay && makeEdid(blockNumber - 1, data);
	IOLockUnlock(stateLock);
	FBTRACE(16, "getDDCBlock %d block %u -> %d", static_cast<int>(connectIndex), blockNumber, ok);
	if (!ok)
		return kIOReturnUnsupported;
	*length = kEdidBlockBytes;
	return kIOReturnSuccess;
}

// MARK: - Power

// The framebuffer stays out of power management, as the stock framebuffer does: it registers no
// power states, so it and its AppleDisplay stay at power state 0 while the display wrangler idles
// and wakes. IOFramebuffer then never turns the display's sleep into one of the framebuffer's:
// WindowServer hears of no display sleep and takes no sleep image, and goes on presenting. The
// framebuffer hears of the display's sleep from the wrangler's own power messages instead, and the
// host's panel goes dark with it ("The display's panel", above). With IOFBDependentID published,
// IOFramebuffer counts the framebuffer usable from its start without a power driver.

// MARK: - IOFramebuffer: the hardware cursor

// IOFramebuffer converts the image into the slot as packed little-endian
// 0xAARRGGBB words, premultiplied: BGRA8 in memory, the format SET_CURSOR
// takes. The command's answer means the host has the image, so the slot is
// free for the next one: every display's framebuffer holds the slot's lock
// from its convert to that answer (lockCursorSlot).
IOReturn ReimsGraphics::setCursorImage(void *cursorImage)
{
	if (!device || !device->ready)
		return kIOReturnNotReady;
	IOHardwareCursorDescriptor desc;
	bzero(&desc, sizeof(desc));
	desc.majorVersion = kHardwareCursorDescriptorMajorVersion;
	desc.minorVersion = kHardwareCursorDescriptorMinorVersion;
	desc.width = kCursorMax;
	desc.height = kCursorMax;
	desc.bitDepth = 32;
	IOHardwareCursorInfo info;
	bzero(&info, sizeof(info));
	info.majorVersion = kHardwareCursorInfoMajorVersion;
	info.minorVersion = kHardwareCursorInfoMinorVersion;
	info.hardwareCursorData = cursorPixels;
	lockCursorSlot();
	if (!convertCursorImage(cursorImage, &desc, &info) || !info.cursorWidth || !info.cursorHeight) {
		unlockCursorSlot();
		return kIOReturnUnsupported;
	}
	RgfxSetCursor c = {};
	c.display = displayId;
	c.width = info.cursorWidth;
	c.height = info.cursorHeight;
	c.hot_x = info.cursorHotSpotX;
	c.hot_y = info.cursorHotSpotY;
	c.offset = regionSize - kCursorSlot;
	IOReturn r = command(RGFX_CMD_SET_CURSOR, &c, sizeof(c));
	unlockCursorSlot();
	if (r == kIOReturnSuccess) {
		hotX = info.cursorHotSpotX;
		hotY = info.cursorHotSpotY;
	}
	return r;
}

// IOFramebuffer gives the image's top-left corner; MOVE_CURSOR takes the
// hotspot's place. On x86-64, the displays' rectangles that changed follow it
// (tellBounds). Never blocks.
IOReturn ReimsGraphics::setCursorState(SInt32 x, SInt32 y, bool visible)
{
	RgfxMoveCursor m = {};
	m.display = displayId;
	m.x = x + static_cast<SInt32>(hotX);
	m.y = y + static_cast<SInt32>(hotY);
	m.visible = visible ? 1u : 0u;
	const bool posted = tryPost(RGFX_CMD_MOVE_CURSOR, &m, sizeof(m), nullptr);
#if defined(__x86_64__)
	(isHead() ? device : this)->tellBounds();
#endif
	return posted ? kIOReturnSuccess : kIOReturnBusy;
}

// MARK: - IOFramebuffer: vblank and connect interrupts

// A registration starts enabled. The VBLANK events follow the vblank one:
// the work loop sends SET_VBLANK when IOFramebuffer turns it on or off.
IOReturn ReimsGraphics::registerForInterruptType(IOSelect interruptType, IOFBInterruptProc proc,
                                                 OSObject *target, void *ref, void **interruptRef)
{
	Interrupt *i = interruptType == kIOFBVBLInterruptType       ? &vblank
	               : interruptType == kIOFBConnectInterruptType ? &connect
	                                                            : nullptr;
	FBTRACE(8, "registerForInterruptType '%c%c%c%c'", static_cast<char>(interruptType >> 24),
	        static_cast<char>(interruptType >> 16), static_cast<char>(interruptType >> 8),
	        static_cast<char>(interruptType));
	if (!i)
		return kIOReturnUnsupported;
	IOSimpleLockLock(interruptLock);
	*i = {proc, target, ref, true};
	if (i == &vblank)
		vblankWanted = true;
	IOSimpleLockUnlock(interruptLock);
	if (interruptRef)
		*interruptRef = i;
	kickWorkLoop();
	return kIOReturnSuccess;
}

IOReturn ReimsGraphics::unregisterInterrupt(void *interruptRef)
{
	if (interruptRef != &vblank && interruptRef != &connect)
		return kIOReturnBadArgument;
	Interrupt *i = static_cast<Interrupt *>(interruptRef);
	IOSimpleLockLock(interruptLock);
	*i = {};
	if (i == &vblank)
		vblankWanted = false;
	IOSimpleLockUnlock(interruptLock);
	kickWorkLoop();
	return kIOReturnSuccess;
}

IOReturn ReimsGraphics::setInterruptState(void *interruptRef, UInt32 state)
{
	if (interruptRef != &vblank && interruptRef != &connect)
		return kIOReturnBadArgument;
	Interrupt *i = static_cast<Interrupt *>(interruptRef);
	IOSimpleLockLock(interruptLock);
	i->enabled = state == kEnabledInterruptState;
	if (i == &vblank)
		vblankWanted = i->enabled && i->proc;
	IOSimpleLockUnlock(interruptLock);
	kickWorkLoop();
	return kIOReturnSuccess;
}
#endif

// MARK: - The display pipe

IOReturn ReimsGraphics::postPresent(UInt32 surfaceId, UInt32 transactionId, UInt32 flags,
                                   UInt64 *seqno)
{
	// A surface whose GPU copy is the host's device cache carries its CPU generation, so the
	// display shows what the CPU wrote under its read-write locks too.
	struct {
		RgfxPresentSurface present;
		RgfxPresentSurfaceGen gen;
	} p = {};
	static_assert(sizeof(RgfxPresentSurface) == RGFX_PRESENT_SURFACE_GEN_OFFSET,
	              "the generation follows the present");
	p.present.display = displayId;
	p.present.iosurface_id = surfaceId;
	p.present.transaction_id = transactionId;
	p.present.flags = flags;
	const bool kept = (flags & RGFX_PRESENT_KEEP) != 0;
	const bool cached = !kept && rgfxSurfaceCacheGeneration(surfaceId, &p.gen.cpu_gen);
	// Until the boot screen is cleared, a surface's present takes the clear's seqno, written
	// before the host can answer it (handleEvent).
	UInt64 *clearsBootScreen =
	    !isHead() && !kept && surfaceId != 0 &&
	            !__atomic_load_n(&bootScreenCleared, __ATOMIC_ACQUIRE)
	        ? &bootScreenSeqno
	        : nullptr;
	// Never waits for room: the caller does, with its lock let go (waitForRoom).
	IOReturn r = kIOReturnSuccess;
	if (!tryPost(RGFX_CMD_PRESENT_SURFACE, &p, cached ? sizeof(p) : sizeof(p.present), seqno,
	             clearsBootScreen))
		r = device && device->ready ? kIOReturnNoSpace : kIOReturnNotReady;
	if (r == kIOReturnSuccess && !kept) {
		IOSimpleLockLock(interruptLock);
		pipes.shows(surfaceId);
		IOSimpleLockUnlock(interruptLock);
	}
	return r;
}

IOReturn ReimsGraphics::postDisplayColor(UInt32 transactionId, UInt32 stage, UInt32 count,
                                         const UInt8 *entries)
{
	static_assert(kRgfxColorPartMax <= kLifecycleMessageMax, "a part fits a control message");
	UInt8 *part = static_cast<UInt8 *>(IOMalloc(kRgfxColorPartMax));
	if (!part)
		return kIOReturnNoMemory;
	IOReturn r = kIOReturnSuccess;
	const UInt32 parts = rgfxColorPartCount(count);
	for (UInt32 k = 0; k < parts && r == kIOReturnSuccess; k++) {
		const UInt32 size =
		    rgfxColorPart(part, displayId, transactionId, stage, count, entries, k);
		r = post(RGFX_CMD_DISPLAY_COLOR, part, size, nullptr);
	}
	IOFree(part, kRgfxColorPartMax);
	return r;
}

bool ReimsGraphics::addPipe(OSObject *client, PipeVblankHook vblankHook, PipePresentHook presentHook)
{
	if (!client)
		return false;
	// Retained before it is published; let go again where it was held already or has no room.
	client->retain();
	IOSimpleLockLock(interruptLock);
	bool already = pipes.holds(client);
	bool held = already || pipes.add(client);
	if (held) {
		pipeVblankHook = vblankHook;
		pipePresentHook = presentHook;
	}
	IOSimpleLockUnlock(interruptLock);
	if (already || !held)
		client->release();
	return held;
}

void ReimsGraphics::removePipe(OSObject *client)
{
	bool showScanout = false;
	IOSimpleLockLock(interruptLock);
	bool held = pipes.remove(client, &showScanout);
	IOSimpleLockUnlock(interruptLock);
	if (!held)
		return;
	client->release();
	if (showScanout) {
		// The last client went with a surface shown: the scanout again, so whatever draws into
		// it next is seen, and black till then: the boot screen was cleared at the first
		// surface's present (clearBootScreen). Its answer goes to no client. It comes between no
		// transaction's colour and present (lockPresents).
		RgfxPresentSurface p = {};
		p.display = displayId;
		lockPresents();
		IOReturn r = post(RGFX_CMD_PRESENT_SURFACE, &p, sizeof(p), nullptr);
		unlockPresents();
		if (r != kIOReturnSuccess)
			IOLog("ReimsGraphics: the last display pipe client went; PRESENT_SURFACE 0 not sent: "
			      "0x%x\n", r);
	}
	kickWorkLoop();
}

void ReimsGraphics::setQueueInterrupt(OSObject *target, QueueInterruptHook hook,
                                      QueueInterruptHook filter)
{
	if (!hook)
		target = nullptr;
	if (target)
		target->retain();
	// The filter holds no reference of its own: it lets go of the old target before the
	// reference below goes.
	if (queueFilterLock) {
		IOInterruptState is = IOSimpleLockLockDisableInterrupt(queueFilterLock);
		queueFilterTarget = target;
		queueFilter = target ? filter : nullptr;
		IOSimpleLockUnlockEnableInterrupt(queueFilterLock, is);
	}
	IOSimpleLockLock(interruptLock);
	OSObject *old = queueTarget;
	queueTarget = target;
	queueHook = target ? hook : nullptr;
	IOSimpleLockUnlock(interruptLock);
	if (old)
		old->release();
}

void ReimsGraphics::setReleaseAnswer(OSObject *target, ReleaseAnswerHook hook)
{
	if (!hook)
		target = nullptr;
	if (target)
		target->retain();
	IOSimpleLockLock(interruptLock);
	OSObject *old = releaseTarget;
	releaseTarget = target;
	releaseHook = target ? hook : nullptr;
	IOSimpleLockUnlock(interruptLock);
	if (old)
		old->release();
}

IOReturn ReimsGraphics::postAnswered(UInt32 type, const void *message, UInt32 size,
                                     UInt64 *waiterSeqno)
{
	return post(type, message, size, nullptr, waiterSeqno);
}

IOReturn ReimsGraphics::postReleases(const RgfxBlockRelease *releases, UInt32 count,
                                     UInt64 *const *waiterSeqnos, UInt32 *posted)
{
	static_assert(sizeof(RgfxBlockRelease) % kMsgAlign == 0 &&
	                  sizeof(RgfxBlockRelease) <= kLifecycleMessageMax,
	              "a release is not a whole message");
	return postRun(RGFX_CMD_BLOCK_RELEASE, releases, sizeof(*releases), count, waiterSeqnos,
	               posted);
}

IOReturn ReimsGraphics::postRun(UInt32 type, const void *messages, UInt32 size, UInt32 count,
                                UInt64 *const *waiterSeqnos, UInt32 *posted)
{
	*posted = 0;
	const UInt8 *bytes = static_cast<const UInt8 *>(messages);
	// Each message's type and size, the run's or, with `type` 0, its own header's.
	auto at = [&](size_t offset, UInt32 *t, UInt32 *n) {
		*t = type;
		*n = size;
		if (type == 0) {
			RgfxMsgHeader h;
			memcpy(&h, bytes + offset, sizeof(h));
			*t = h.type;
			*n = h.size;
		}
	};
	size_t length = 0;
	for (UInt32 i = 0; i < count; i++) {
		UInt32 t = 0, n = 0;
		at(length, &t, &n);
		if (n < kHeaderBytes || n % kMsgAlign || n > kLifecycleMessageMax)
			return kIOReturnBadArgument;
		length += n;
	}
	uint64_t deadline = 0;
	clock_interval_to_deadline(kPostTimeoutMs, kMillisecondScale, &deadline);
	// As many as fit, under one hold of the ring's lock and with one doorbell at most: whether
	// all are posted. `next` is where the first not yet posted lies.
	size_t next = 0;
	auto look = [&]() {
		UInt32 n = 0;
		IOSimpleLockLock(submitLock);
		while (*posted + n < count) {
			UInt32 t = 0, m = 0;
			at(next, &t, &m);
			if (!writeLocked(t, bytes + next, m, nullptr,
			                 waiterSeqnos ? waiterSeqnos[*posted + n] : nullptr))
				break;
			next += m;
			n++;
		}
		const bool bell = n && publishLocked();
		IOSimpleLockUnlock(submitLock);
		if (bell)
			ringControl();
		*posted += n;
		return *posted == count;
	};
	while (*posted < count) {
		if (!ready)
			return kIOReturnNotReady;
		const UInt64 mark = roomMark();
		if (look() || (askForRoom() && look()))
			break;
		if (!waitForRoom(mark, deadline)) {
			UInt32 t = 0, m = 0;
			at(next, &t, &m);
			static char site;
			if (rgfxFirstCalls(&site, t, 1))
				IOLog("ReimsGraphics: command %u: the control ring stayed full\n", t);
			return ready ? kIOReturnTimeout : kIOReturnNotReady;
		}
	}
	return kIOReturnSuccess;
}

void ReimsGraphics::setPipeVblankEnabled(OSObject *client, bool enabled)
{
	IOSimpleLockLock(interruptLock);
	pipes.setVblank(client, enabled);
	IOSimpleLockUnlock(interruptLock);
	kickWorkLoop();
}

#if RGFX_FB_TRACE && defined(__x86_64__)
// MARK: - The trace build's forwarding overrides

IOReturn ReimsGraphics::open()
{
	IOReturn r = super::open();
	FBTRACE(8, "open -> 0x%x", r);
	return r;
}

void ReimsGraphics::close()
{
	FBTRACE(8, "close");
	super::close();
}

IOReturn ReimsGraphics::setGammaTable(UInt32 channelCount, UInt32 dataCount, UInt32 dataWidth,
                                      void *data)
{
	IOReturn r = super::setGammaTable(channelCount, dataCount, dataWidth, data);
	FBTRACE(4, "setGammaTable %u x %u x %u bits -> 0x%x", channelCount, dataCount, dataWidth, r);
	return r;
}

IOReturn ReimsGraphics::setPowerState(unsigned long powerStateOrdinal, IOService *whatDevice)
{
	IOReturn r = super::setPowerState(powerStateOrdinal, whatDevice);
	FBTRACE(16, "setPowerState %lu -> 0x%x", powerStateOrdinal, r);
	return r;
}

IOReturn ReimsGraphics::powerStateWillChangeTo(IOPMPowerFlags flags, unsigned long state,
                                               IOService *whatDevice)
{
	IOReturn r = super::powerStateWillChangeTo(flags, state, whatDevice);
	FBTRACE(16, "powerStateWillChangeTo flags 0x%lx state %lu -> 0x%x",
	        static_cast<unsigned long>(flags), state, r);
	return r;
}

IOReturn ReimsGraphics::powerStateDidChangeTo(IOPMPowerFlags flags, unsigned long state,
                                              IOService *whatDevice)
{
	IOReturn r = super::powerStateDidChangeTo(flags, state, whatDevice);
	FBTRACE(16, "powerStateDidChangeTo flags 0x%lx state %lu -> 0x%x",
	        static_cast<unsigned long>(flags), state, r);
	return r;
}

OSObject *ReimsGraphics::copyProperty(const OSSymbol *aKey) const
{
	OSObject *o = super::copyProperty(aKey);
	rgfxTracePropertyRead("fb", aKey ? aKey->getCStringNoCopy() : nullptr, o != nullptr);
	return o;
}

OSObject *ReimsGraphics::copyProperty(const OSString *aKey) const
{
	OSObject *o = super::copyProperty(aKey);
	rgfxTracePropertyRead("fb", aKey ? aKey->getCStringNoCopy() : nullptr, o != nullptr);
	return o;
}

OSObject *ReimsGraphics::copyProperty(const char *aKey) const
{
	OSObject *o = super::copyProperty(aKey);
	rgfxTracePropertyRead("fb", aKey, o != nullptr);
	return o;
}

IOReturn ReimsGraphics::requestProbe(IOOptionBits options)
{
	IOReturn r = super::requestProbe(options);
	FBTRACE(8, "requestProbe 0x%x -> 0x%x", static_cast<unsigned>(options), r);
	return r;
}

IOReturn ReimsGraphics::message(UInt32 type, IOService *provider, void *argument)
{
	IOReturn r = super::message(type, provider, argument);
	FBTRACE(16, "message 0x%x -> 0x%x", type, r);
	return r;
}

bool ReimsGraphics::isConsoleDevice()
{
	bool r = super::isConsoleDevice();
	FBTRACE(8, "isConsoleDevice -> %d", r);
	return r;
}

IOReturn ReimsGraphics::setCLUTWithEntries(IOColorEntry *colors, UInt32 index, UInt32 numEntries,
                                           IOOptionBits options)
{
	IOReturn r = super::setCLUTWithEntries(colors, index, numEntries, options);
	FBTRACE(4, "setCLUTWithEntries %u+%u -> 0x%x", index, numEntries, r);
	return r;
}

#endif
