/*
 * ReimsGraphics' arm64e front end: the IOMobileFramebufferLegacy subclass an arm64 WindowServer
 * drives (ReimsGraphics.hpp). The device, its rings, its display and its pipe clients are
 * ReimsGraphics.cpp's, as on x86-64; this file is what the class asks of a subclass.
 *
 * Each override logs its first calls (kLogFirst a boot), and the swaps a line a minute. The class
 * queues the swaps a process submits, and swap_begin_gated takes them off its queue as Apple's
 * paravirtual display does: the device presents a swap's layer-0 surface, and the swap completes
 * once the host answers the present. The device's refreshes reach the class as its vblank note.
 * Each completed swap's presentation time reaches WindowServer as frame info, which the paravirtual
 * display has none of: supported_frame_info answers the tags the device fills, and a record of the
 * swap goes to each notify request's client, through its shared data queue
 * (RgfxLegacySwapInfo.hpp). The class's other pure methods answer what a display with no factory
 * configuration and no CRC answers.
 *
 * None of the class's methods a subclass overrides is forwarded to the class: what the class
 * implements there is for no display at all, on every arm64 release from 13 to 27.2.1 (read from
 * each release's IOMobileGraphicsFamily). Its start_hardware answers false, which fails its start
 * ("start_hardware failed"); its stop_hardware_gated and swap_begin_gated do nothing; its
 * verify_swap answers false, which fails every swap ("verify_swap failed for swap id"); and its
 * swap_layer_map, surface_layer_map and surface_layer_unmap map a layer's surface for the display
 * hardware's DMA, through the mapper an AppleARMIODevice provider names. Apple's paravirtual
 * display, the class's subclass in a VM (AppleParavirtDisplay), overrides each of the seven: its
 * start_hardware starts its display and joins power management, its verify_swap answers true, and
 * its three maps map nothing. ReimsGraphics does the same: the device reads a surface by its
 * IOSurface ID, so no layer's surface is mapped. Its swap_begin_gated begins each swap the class
 * queued, in the class's own fields at each release's offsets (RgfxLegacySwapLayout.hpp), and
 * the class's own methods, which the paravirtual display calls, clean the queue, drop a swap and
 * complete one.
 *
 * Of what the class implements for every subclass, ReimsGraphics overrides what reads the
 * class's provider as an AppleARMIODevice unchecked where a process reaches it: get_dot_pitch. And
 * as the paravirtual display does, it overrides set_digital_out_mode, which the class answers
 * kIOReturnUnsupported, to set the mode WindowServer picks of those it publishes: a timing for each
 * mode the device lists, each in one colour mode where the paravirtual display publishes three.
 * The display is external and plugged in from its start, as the paravirtual display's are, so
 * WindowServer reads its modes, and sets one, at its start and at each change (start_hardware).
 * And it overrides swap_set_color_matrix, which the class answers kIOReturnUnsupported, so
 * WindowServer, which sets its accessibility matrix at each swap until the call succeeds, sets it
 * once: it answers 0 and the display shows the matrix (RgfxMobileColor.hpp). And it overrides
 * set_block, which the class answers kIOReturnUnsupported, to take the ICC blocks that leave the
 * display's colour chain the identity, the chain it shows, and, where the host converts the
 * cursor (CURSOR_COLOR), the cursor layer's chain, which the swaps post to the host
 * (RgfxMobileICC.hpp).
 *
 * A process finds the display as IOMobileFramebuffer.framework counts displays: by a node of the
 * device tree (attachMobileNode), then the framebuffer's service and the properties it publishes
 * (publishMobileDisplay).
 */

#include "ReimsGraphics.hpp"

#include <IOKit/IODeviceTreeSupport.h>
#include <IOKit/IOLib.h>
#include <kern/clock.h>
#include <kern/task.h>
#include <libkern/libkern.h>
#include <libkern/version.h>

#include "RgfxDisplayIdentity.hpp"
#include "RgfxIOSurfaceKPI.hpp"
#include "RgfxMobileColor.hpp"
#include "RgfxMobileICC.hpp"
#include "RgfxMobileModes.hpp"

#if defined(__arm64e__)

#define super IOMobileFramebufferLegacy

// An IOReturn as a word: its 32 bits, which a caller of a method returning IOReturn reads.
static constexpr RgfxIOMFBWord word(IOReturn r)
{
	return static_cast<uint32_t>(r);
}

// IOSurface's global ID (IOSurface.kext's exported member, as RgfxIOSurfaceKPI.hpp declares the
// others): the ID PRESENT_SURFACE names a surface by.
extern "C" uint32_t rgfxIOSurfaceSurfaceID(const OSObject *surface)
    __asm__("__ZNK9IOSurface12getSurfaceIDEv");
// And what the cursor reads of layer 1's surface (RgfxMobileCursor.hpp), as the paravirtual
// display's program_hardware_cursor_gated reads it: its size in pixels, bytes per row, pixel format
// and bytes per element, each read as a word, and its image origin and extents, 24 bytes returned
// through x8.
extern "C" uint32_t rgfxIOSurfaceWidth(const OSObject *surface) __asm__("__ZNK9IOSurface8getWidthEv");
extern "C" uint32_t rgfxIOSurfaceHeight(const OSObject *surface)
    __asm__("__ZNK9IOSurface9getHeightEv");
extern "C" uint32_t rgfxIOSurfaceBytesPerRow(const OSObject *surface)
    __asm__("__ZNK9IOSurface14getBytesPerRowEv");
extern "C" uint32_t rgfxIOSurfacePixelFormat(const OSObject *surface)
    __asm__("__ZNK9IOSurface14getPixelFormatEv");
extern "C" uint32_t rgfxIOSurfaceBytesPerElement(const OSObject *surface)
    __asm__("__ZNK9IOSurface18getBytesPerElementEv");
extern "C" RgfxSurfaceImageExtents rgfxIOSurfaceImageExtents(OSObject *surface)
    __asm__("__ZN9IOSurface24getImageOriginAndExtentsEv");

// IOMobileFramebufferLegacy's own methods for its swap queue, which the paravirtual display's
// swap_begin_gated and clean_queue_gated call and ReimsGraphics overrides none of: called directly,
// as the SDK stand-in's note_vbl_ISR is, under the names every release from 14 to 27.2.1 exports.
// Each runs in the class's gate. dropAbortedSwaps_gated takes a bool from macOS 15 on and none
// on 14; Graft binds this import to either (graft-arm64e.json), and 14's ignores the bool.
extern "C" void rgfxLegacySwapComplete(IOMobileFramebufferLegacy *self)
    __asm__("__ZN25IOMobileFramebufferLegacy19swap_complete_gatedEv");
extern "C" void rgfxLegacyDropSwap(IOMobileFramebufferLegacy *self, void *swap, bool field_1)
    __asm__("__ZN25IOMobileFramebufferLegacy14dropSwap_gatedEP18IOMFBSwapIORequestb");
extern "C" void rgfxLegacyUpdateSwapInfoState(IOMobileFramebufferLegacy *self, void *swap,
                                              uint32_t state)
    __asm__("__ZN25IOMobileFramebufferLegacy28update_swap_info_state_gatedEP18IOMFBSwapIORequest24IOMFBSwapCompletionState");
extern "C" uint32_t rgfxLegacyDropObsoleteSwaps(IOMobileFramebufferLegacy *self)
    __asm__("__ZN25IOMobileFramebufferLegacy23dropObsoleteSwaps_gatedEv");
extern "C" void rgfxLegacyDropNoOpSwaps(IOMobileFramebufferLegacy *self)
    __asm__("__ZN25IOMobileFramebufferLegacy19dropNoOpSwaps_gatedEv");
extern "C" void rgfxLegacyDropAbortedSwaps(IOMobileFramebufferLegacy *self, bool field_1)
    __asm__("__ZN25IOMobileFramebufferLegacy22dropAbortedSwaps_gatedEb");
extern "C" void rgfxLegacyDropDummySwaps(IOMobileFramebufferLegacy *self)
    __asm__("__ZN25IOMobileFramebufferLegacy20dropDummySwaps_gatedEv");
// The class's own dispatch of a swap-info record to each notify request it holds, through the
// display's do_swap_info_notify_gated (RgfxLegacySwapInfo.hpp), which the paravirtual display's
// notify_swap_done_gated calls: called directly, under the name every release from 14 to 27.2.1
// exports, in the class's gate.
extern "C" void rgfxLegacySwapInfoNotifyDispatch(IOMobileFramebufferLegacy *self,
                                                 RgfxSwapInfoRecord *record)
    __asm__("__ZN25IOMobileFramebufferLegacy31swap_info_notify_dispatch_gatedEPNS_12SwapInfoBlobE");
// The class's own set_parameter, which the display's override hands each parameter it does not
// take (set_parameter): called directly, under the name every release from 14 to 27.2.1 exports,
// as the paravirtual display's override hands the class those it does not take.
extern "C" RgfxIOMFBWord rgfxLegacySetParameter(IOMobileFramebufferLegacy *self,
                                                IOMFBParameterName name, const uint64_t *values,
                                                uint32_t count)
    __asm__("__ZN25IOMobileFramebufferLegacy13set_parameterE18IOMFBParameterNamePKyj");
// The class's hot-plug notice: records the display's state (1 plugged in, 0 not) where the
// class's get_digital_out_state_gated answers it, and sends it to each of the class's hot-plug
// clients, both in the class's gate. The paravirtual display calls it, as its own class's, once
// it has published a display's attributes (1) and as it removes them (0) (read from 26.6.2's and
// 27.0.1's AppleParavirtGPU and IOMobileGraphicsFamily): called directly, under the name every
// release from 14 to 27.0.1 exports.
extern "C" void rgfxLegacyHotPlugNotify(IOMobileFramebufferLegacy *self, uint64_t state)
    __asm__("__ZN25IOMobileFramebufferLegacy14hotPlug_notifyEy");

// IOMobileFramebufferUserClient's enqueue of `bytes` bytes at `words` in its shared data queue,
// which IOMobileFramebuffer.framework reads a frame info record from (RgfxLegacySwapInfo.hpp):
// called directly, under the name every release from 14 to 27.2.1 exports, on the user client a
// notify request is for. Answers kIOReturnSuccess, or an error where the queue holds no room.
extern "C" IOReturn rgfxUserClientEnqueueFrameInfo(void *client, uint64_t *words, uint32_t bytes)
    __asm__("__ZN29IOMobileFramebufferUserClient26enqueueInIOSharedDataQueueEPyj");

// IOAVFamily's constructors of a timing element and of a colour element, and a timing's colour
// elements, which the paravirtual display calls to make the elements it publishes
// (RgfxMobileModes.hpp): called directly, under the names every release from 14 to 27.2.1 exports.
// IOAVFamily is a library of IOMobileGraphicsFamily's on each of them, so it is loaded before the
// kext, and Graft binds each (graft-arm64e.json). Each constructor answers a retained element, or
// null. setColorElements retains the array it is given.
extern "C" OSObject *rgfxIOAVTimingWithData(const RgfxIOAVTimingData *data, uint32_t standardType,
                                            uint32_t timingStandard)
    __asm__("__ZN22IOAVVideoTimingElement8withDataEPK19IOAVVideoTimingData16IOAVStandardType23IOAVVideoTimingStandard");
extern "C" OSObject *rgfxIOAVColorWithCapabilities(
    uint32_t standardType, uint32_t depth, uint32_t pixelEncoding, uint32_t dynamicRange,
    uint32_t eotf, uint32_t colorimetry, bool supportsDsc, const OSDictionary *chromaticity,
    const OSDictionary *whitePoint, const OSDictionary *displayLuminance,
    const OSSet *hdrStaticMetadataTypes)
    __asm__("__ZN21IOAVVideoColorElement16withCapabilitiesE16IOAVStandardTypej22IOAVVideoPixelEncoding26IOAVVideoColorDynamicRange18IOAVVideoColorEOTF20IOAVVideoColorimetrybPK12OSDictionaryS7_S7_PK5OSSet");
extern "C" void rgfxIOAVTimingSetColorElements(OSObject *timing, OSArray *colors)
    __asm__("__ZN22IOAVVideoTimingElement16setColorElementsEP7OSArray");

// The IOMFBSwapCompletionState the paravirtual display gives a swap as it begins it.
constexpr uint32_t kSwapStateAtBegin = 2;

namespace {

// The methods whose calls are logged, each counted apart.
enum MobileCall : unsigned {
	kSetNotifyTagMask,
	kSupportedFrameInfo,
	kFactoryPortal,
	kExecuteFactoryConfigurations,
	kSetFrameInfoNotificationState,
	kDoSwapInfoNotify,
	kNotifySwapDone,
	kNotifyCrcReady,
	kAreTimingsEnabled,
	kStartHardware,
	kStopHardware,
	kSwapBegin,
	kVerifySwap,
	kSwapLayerMap,
	kSurfaceLayerMap,
	kSurfaceLayerUnmap,
	kGetDotPitch,
	kSetDigitalOutMode,
	kSwapSetColorMatrix,
	kSetParameter,
	kSetBlock,
	kVblank,
	kPresented,
	kSwapShown,
	kSwapDropped,
	kSwapCursor,
	kCursorRefused,
	kCursorColor,
	kDisplayChanged,
	kMobileCalls,
};

constexpr UInt32 kLogFirst = 16;
UInt32 callCounts[kMobileCalls];

// Whether this call of `call` is one to log: the first kLogFirst a boot, the bring-up's trace. A
// call that comes at every swap or vblank logs nothing after them (docs/conventions.md).
bool logged(MobileCall call)
{
	const UInt32 n = __atomic_fetch_add(&callCounts[call], 1, __ATOMIC_RELAXED);
	return n < kLogFirst;
}

} // namespace

bool ReimsGraphics::startMobile()
{
	mobilePresentSeqno = 0;
	mobileTransaction = 0;
	mobileSwapShowing = nullptr;
	mobileSwapRate.clear();
	mobileSwapRateWindow = 0;
	mobileShownAt = 0;
	mobileShownPeriod = 0;
	mobilePresentedAt = 0;
	mobileFrameClock = RgfxFrameInfoClock();
	mobileSwapInfoKept.head = 0;
	mobileSwapInfoKept.tail = 0;
	mobileCursor = RgfxMobileCursor();
	mobileListChanged = false;
	mobileHotPlugged = false;
	mobileTimingId = 0;
	// The ICC pairs, held from nothing at each start, with the release's numbering of the blocks
	// by the kernel's major version; without them every block is refused.
	if (!mobileICCLock)
		mobileICCLock = IOLockAlloc();
	if (!mobileICC)
		mobileICC = static_cast<RgfxICCState *>(IOMalloc(sizeof(RgfxICCState)));
	RgfxICCRelease iccRelease{};
	const bool iccKnown = rgfxICCReleaseOf(version_major, &iccRelease);
	if (mobileICC && mobileICCLock) {
		IOLockLock(mobileICCLock);
		*mobileICC = RgfxICCState();
		if (iccKnown)
			mobileICC->release = iccRelease;
		// The cursor layer's chain is the host's to apply where it took CURSOR_COLOR.
		mobileICC->cursor.host = cursorColorTaken;
		IOLockUnlock(mobileICCLock);
	}
	if (!iccKnown)
		IOLog("ReimsGraphics: no ICC numbering for Darwin %d: every colour block is refused\n",
		      version_major);
	mobileChangeCall = thread_call_allocate(mobileDisplayChanged, this);
	if (!mobileChangeCall) {
		IOLog("ReimsGraphics: no thread call for the display's changes\n");
		return false;
	}
	// The release, by the size of the class this one derives from as the kernel has it.
	const uint32_t legacySize = IOMobileFramebufferLegacy::gMetaClass.getClassSize();
	mobileSwapLayout = rgfxLegacySwapLayoutOf(legacySize);
	if (mobileSwapLayout)
		IOLog("ReimsGraphics: the swap queue as macOS %s lays it out\n", mobileSwapLayout->release);
	else
		IOLog("ReimsGraphics: IOMobileFramebufferLegacy is 0x%x bytes, no release's size, so no "
		      "swap is begun\n",
		      legacySize);
	mobilePipe = addPipe(this, mobileVblank, mobilePresented);
	if (!mobilePipe) {
		IOLog("ReimsGraphics: no pipe for the mobile framebuffer\n");
		return false;
	}
	mobilePowerJoined = false;
	IOLog("ReimsGraphics: mobile framebuffer, display %u\n", displayId);
	// The display has a cursor plane, layer 1, as the paravirtual display's start says of its own
	// (beginMobileSwaps, RgfxMobileCursor.hpp).
	setProperty("CursorPlane", 1ull, 32);
	publishMobileDisplay();
	attachMobileNode();
	return true;
}

void ReimsGraphics::stopMobile()
{
	// No change of the display's is taken from here: one under way ends first, and one the
	// device's work loop asks for until quiesce finds the framebuffer stopped (mobileDisplayChanged).
	if (mobileChangeCall)
		thread_call_cancel_wait(mobileChangeCall);
	removeProperty("CursorPlane");
	detachMobileNode();
	if (mobilePipe)
		removePipe(this);
	mobilePipe = false;
	// The answer's event source leaves the class's work loop; free lets it go, once no pipe hook
	// can still signal it.
	if (IOInterruptEventSource *answer = mobileSwapAnswer) {
		answer->disable();
		if (mobileSwapLoop)
			mobileSwapLoop->removeEventSource(answer);
	}
}

// The thread call of the display's changes, once the device's work loop can ask for none: after
// quiesce, in stop and where start fails.
void ReimsGraphics::freeMobileChanges()
{
	thread_call_t call = mobileChangeCall;
	mobileChangeCall = nullptr;
	if (!call)
		return;
	thread_call_cancel_wait(call);
	thread_call_free(call);
}

// MARK: - The services' registration

// The class's start registers the service as it ends (read from macOS 27.0.1's
// IOMobileGraphicsFamily: IOMobileFramebufferLegacy::start's last call, virtual). Where display 0's
// start holds the displays' registrations (RgfxRegisterHold.hpp), it is recorded instead, and
// display 0's start registers it with the others (releaseRegistrations).
void ReimsGraphics::registerService(IOOptionBits options)
{
	ReimsGraphics *owner = isHead() ? device : this;
	const UInt32 display = isHead() ? displayId : 0;
	if (owner->holdRegistration(display, options)) {
		IOLog("ReimsGraphics: display %u: its service registers with the other displays'\n",
		      display);
		return;
	}
	IOMobileFramebufferLegacy::registerService(options);
}

bool ReimsGraphics::holdRegistration(UInt32 display, IOOptionBits options)
{
	if (!stateLock)
		return false;
	IOLockLock(stateLock);
	const bool held = registerHold.hold(display, options);
	IOLockUnlock(stateLock);
	return held;
}

void ReimsGraphics::releaseRegistrations()
{
	IOLockLock(stateLock);
	const uint32_t held = registerHold.release();
	uint32_t options[RGFX_DISPLAYS_MAX];
	for (UInt32 d = 0; d < RGFX_DISPLAYS_MAX; d++)
		options[d] = registerHold.options[d];
	IOLockUnlock(stateLock);
	if (!held)
		return;
	// The window opens before the first service registers, so no process can read a property of
	// one between its notification and the others' (RgfxRegisterHold.hpp).
	if (registerLock && registerCall) {
		uint64_t due = 0;
		clock_interval_to_deadline(static_cast<uint32_t>(kRgfxRegisterWindowNs / 1000000),
		                           kMillisecondScale, &due);
		IOLockLock(registerLock);
		releasedDisplays |= held;
		for (UInt32 d = 0; d < RGFX_DISPLAYS_MAX; d++)
			if (held & (1u << d))
				releasedOptions[d] = options[d];
		registerWindow.begin(due, releasedDisplays);
		IOLockUnlock(registerLock);
		// The call holds display 0's framebuffer; one pending already takes these too.
		retain();
		if (thread_call_enter(registerCall))
			release();
		return;
	}
	UInt32 registered = 0;
	for (UInt32 d = 0; d < RGFX_DISPLAYS_MAX; d++) {
		if (!(held & (1u << d)))
			continue;
		ReimsGraphics *fb = copyDisplay(d);
		if (!fb)
			continue;
		fb->IOMobileFramebufferLegacy::registerService(options[d]);
		fb->release();
		registered++;
	}
	IOLog("ReimsGraphics: %u displays' services registered together, with no window\n",
	      registered);
}

void ReimsGraphics::registrationsReleased(thread_call_param_t self, thread_call_param_t)
{
	ReimsGraphics *fb = static_cast<ReimsGraphics *>(self);
	fb->registerReleased();
	fb->release();
}

// The released services registered one at a time, by display: each waited for until it has matched
// (its busy state back to 0, its notifications delivered), and the next registered only once a
// process has taken it or the window's deadline has passed (RgfxRegisterWindow::registerWaits);
// then the window closes and the reads waiting in it go on.
void ReimsGraphics::registerReleased()
{
	IOLockLock(registerLock);
	const uint32_t held = releasedDisplays;
	releasedDisplays = 0;
	uint32_t options[RGFX_DISPLAYS_MAX];
	for (UInt32 d = 0; d < RGFX_DISPLAYS_MAX; d++)
		options[d] = releasedOptions[d];
	const uint64_t deadline = registerWindow.deadline;
	IOLockUnlock(registerLock);
	UInt32 n = 0, nMatched = 0, nTaken = 0;
	for (UInt32 d = 0; d < RGFX_DISPLAYS_MAX; d++) {
		if (!(held & (1u << d)))
			continue;
		ReimsGraphics *fb = copyDisplay(d);
		if (fb) {
			fb->IOMobileFramebufferLegacy::registerService(options[d]);
			n++;
			const uint64_t now = mach_absolute_time();
			uint64_t ns = 0;
			if (now < deadline)
				absolutetime_to_nanoseconds(deadline - now, &ns);
			if (ns && fb->waitQuiet(ns) == kIOReturnSuccess)
				nMatched++;
			fb->release();
		}
		// A display that could not be had counts as matched and taken, so neither the reads of
		// the one before nor the next registration waits on it.
		IOLockLock(registerLock);
		registerWindow.matched |= 1u << d;
		if (!fb)
			registerWindow.take(d);
		IOLockWakeup(registerLock, &registerWindow, false);
		while (registerWindow.registerWaits(d, mach_absolute_time())) {
			if (IOLockSleepDeadline(registerLock, &registerWindow.taken, deadline, THREAD_UNINT) ==
			    THREAD_TIMED_OUT)
				break;
		}
		if (fb && (registerWindow.taken & (1u << d)))
			nTaken++;
		IOLockUnlock(registerLock);
	}
	IOLockLock(registerLock);
	registerWindow.end();
	IOLockWakeup(registerLock, &registerWindow, false);
	IOLockUnlock(registerLock);
	IOLog("ReimsGraphics: %u displays' services registered in turn, %u matched and %u taken in the "
	      "window\n",
	      n, nMatched, nTaken);
}

// A process's read of a key of display `display`'s service: the display taken, the release
// waiting to register the next woken, and the read held until the next display's service has
// matched (RgfxRegisterWindow::readWaits), no longer than the window's deadline.
void ReimsGraphics::waitRegistrations(UInt32 display)
{
	if (!registerLock)
		return;
	IOLockLock(registerLock);
	if (registerWindow.waits(true, mach_absolute_time())) {
		registerWindow.take(display);
		IOLockWakeup(registerLock, &registerWindow.taken, false);
	}
	while (registerWindow.readWaits(display, true, mach_absolute_time())) {
		if (IOLockSleepDeadline(registerLock, &registerWindow, registerWindow.deadline,
		                        THREAD_UNINT) == THREAD_TIMED_OUT)
			break;
	}
	IOLockUnlock(registerLock);
}

// The keys IOMobileFramebuffer.framework reads of each service it takes, before it asks for the
// next (read from macOS 27.0.1's iomfb_match_callback): "dfr", "AppleTV" and "external". Only a read
// of one of these waits: a matching dictionary names none of them, so no process's matching, which
// reads properties with the registry's notification lock held, waits on the services' own.
static bool rgfxFrameworkKey(const char *key)
{
	return key && (!strcmp(key, "dfr") || !strcmp(key, "AppleTV") || !strcmp(key, "external"));
}

// A process reads a service's property through io_registry_entry_get_property_bin_buf, which asks
// the service for the key by its C string, copyProperty(const char *), before any other overload
// (read from macOS 14.6.1's and 27.0.1's kernels); IORegistryEntry's C-string overload reads its
// table itself, not through the OSSymbol one, so this is the overload that waits.
OSObject *ReimsGraphics::copyProperty(const char *aKey) const
{
	const ReimsGraphics *owner = isHead() ? device : this;
	if (__atomic_load_n(&owner->registerWindow.open, __ATOMIC_ACQUIRE) &&
	    current_task() != kernel_task && rgfxFrameworkKey(aKey))
		const_cast<ReimsGraphics *>(owner)->waitRegistrations(isHead() ? displayId : 0);
	return IOMobileFramebufferLegacy::copyProperty(aKey);
}

// Display 0's, as its framebuffer stops or its start fails: the release's thread call waited for
// and let go, the reads waiting in its window let go, and the lock freed once nothing can sleep on
// it.
void ReimsGraphics::freeRegistrations()
{
	if (thread_call_t call = registerCall) {
		registerCall = nullptr;
		if (thread_call_cancel_wait(call))
			release();
		thread_call_free(call);
	}
	if (registerLock) {
		IOLockLock(registerLock);
		registerWindow.end();
		releasedDisplays = 0;
		IOLockWakeup(registerLock, &registerWindow, false);
		IOLockWakeup(registerLock, &registerWindow.taken, false);
		IOLockUnlock(registerLock);
	}
}

// MARK: - The display as a process finds it

namespace {

// A dictionary's entries, each left out where it cannot be made.
void putNumber(OSDictionary *dict, const char *key, uint32_t value)
{
	if (OSNumber *n = OSNumber::withNumber(value, 32)) {
		dict->setObject(key, n);
		n->release();
	}
}

void putString(OSDictionary *dict, const char *key, const char *value)
{
	if (OSString *s = OSString::withCString(value)) {
		dict->setObject(key, s);
		s->release();
	}
}

// Puts `value` (which may be null) and lets it go.
void putDictionary(OSDictionary *dict, const char *key, OSDictionary *value)
{
	if (value) {
		dict->setObject(key, value);
		value->release();
	}
}

// A colour's point as DisplayAttributes gives it: X and Y in 16.16 fixed point, and a Gamma of 1.0
// in 16.16, as Apple's paravirtual display gives its own (read from macOS 27.0.1's
// AppleParavirtGPU, createColorPointDict).
OSDictionary *colorPoint(RgfxDisplayChromaticity c)
{
	OSDictionary *dict = OSDictionary::withCapacity(3);
	if (!dict)
		return nullptr;
	putNumber(dict, "X", (c.x * 65536 + 500) / 1000);
	putNumber(dict, "Y", (c.y * 65536 + 500) / 1000);
	putNumber(dict, "Gamma", 0x10000);
	return dict;
}

// What the device tree node's device_type holds: IOMobileFramebuffer.framework counts a child of
// /arm-io whose device_type begins with these 17 bytes as one display.
constexpr char kDisplayNodeType[] = "display-subsystem";

} // namespace

// The display's node in the device tree. A process waits for as many IOMobileFramebuffer services
// as IOMobileFramebuffer.framework counts displays (iomfb_populate_all_display_infos), and it
// counts the children of IODeviceTree:/arm-io whose device_type is "display-subsystem" or
// "ext-display-subsystem", and the DisplayPortCount of an AppleParavirtGPU where a child's
// compatible names Apple's paravirtual GPU (read from macOS 14.6.1's and 27.0.1's framework). A
// VM's device tree has no such child for this device: the framework counted no display, and
// WindowServer ran headless ("FB Count = 0").
//
// The framework counts once in a process (dispatch_once), and only a count above 0 starts its wait,
// up to 30 seconds, for the IOMobileFramebuffer services. The kexts load from the auxiliary kernel
// collection, after userspace starts: WindowServer counts before start runs, so a node attached
// here is counted only by the processes that start after it. A node the firmware placed at the same
// path, before the kernel started, is counted by every process: start uses it as it stands, and
// attaches a node of its own only where the firmware placed none. Nothing in the kernel reads the
// node: no driver matches its name or its device_type.
void ReimsGraphics::attachMobileNode()
{
	mobileNode = nullptr;
	mobileNodeAttached = false;
	char name[32];
	snprintf(name, sizeof(name), "reims-display%u", displayId);
	char path[48];
	snprintf(path, sizeof(path), "/arm-io/%s", name);
	if (IORegistryEntry *placed = IORegistryEntry::fromPath(path, gIODTPlane)) {
		mobileNode = placed;
		IOLog("ReimsGraphics: display %u has the firmware's IODeviceTree:%s\n", displayId, path);
		return;
	}
	IORegistryEntry *armIO = IORegistryEntry::fromPath("/arm-io", gIODTPlane);
	if (!armIO) {
		IOLog("ReimsGraphics: no /arm-io in the device tree, so no process counts display %u\n",
		      displayId);
		return;
	}
	OSDictionary *props = OSDictionary::withCapacity(2);
	OSData *nameData = OSData::withBytes(name, static_cast<unsigned>(strlen(name) + 1));
	OSData *typeData = OSData::withBytes(kDisplayNodeType, sizeof(kDisplayNodeType));
	IORegistryEntry *node = OSTypeAlloc(IORegistryEntry);
	bool attached = false;
	if (props && nameData && typeData && node) {
		props->setObject("name", nameData);
		props->setObject("device_type", typeData);
		if (node->init(props)) {
			node->setName(name);
			attached = node->attachToParent(armIO, gIODTPlane);
		}
	}
	if (attached) {
		mobileNode = node;
		mobileNodeAttached = true;
		node = nullptr;
	}
	OSSafeReleaseNULL(node);
	OSSafeReleaseNULL(typeData);
	OSSafeReleaseNULL(nameData);
	OSSafeReleaseNULL(props);
	armIO->release();
	IOLog("ReimsGraphics: display %u %s IODeviceTree:/arm-io/%s, a %s\n", displayId,
	      attached ? "attached" : "could not attach", name, kDisplayNodeType);
}

UInt32 ReimsGraphics::countMobileNodes()
{
	UInt32 n = 0;
	for (; n < RGFX_DISPLAYS_MAX; n++) {
		char path[48];
		snprintf(path, sizeof(path), "/arm-io/reims-display%u", n);
		IORegistryEntry *node = IORegistryEntry::fromPath(path, gIODTPlane);
		if (!node)
			break;
		node->release();
	}
	return n;
}

void ReimsGraphics::detachMobileNode()
{
	if (!mobileNode)
		return;
	if (mobileNodeAttached)
		mobileNode->detachAbove(gIODTPlane);
	mobileNodeAttached = false;
	OSSafeReleaseNULL(mobileNode);
}

// The framebuffer's properties a process reads of the display, as Apple's paravirtual display
// publishes its own (read from macOS 27.0.1's AppleParavirtGPU, AppleParavirtDisplay's
// createDisplayAttributes), with the values the x86-64 framebuffer's EDID gives
// (RgfxDisplayIdentity.hpp):
// - external: true, as the paravirtual display publishes it of every display (read from 14.6.1's,
//   15.6.1's, 26.6.2's and 27.0.1's AppleParavirtGPU), which IOMobileFramebuffer.framework then
//   names external-N. WindowServer asks for the hot-plug notices of an external display, and of an
//   internal one only on 27.0.1, where the machine is virtual (14.6.1's, 15.6.1's, 26.6.2's and
//   27.0.1's QuartzCore, AccelServer's constructor): so a change of the device's modes reaches
//   WindowServer on every release (republishMobileDisplay);
// - IOMFBUUID: the display's UUID, a fixed one of ours: "RVG" in ASCII, the product code, the
//   version and variant bits of RFC 9562's custom UUIDs (8), and the serial;
// - DisplayAttributes: the product (manufacturer, product code, serial, name, year), sRGB's
//   primaries and D65 white, sRGB the default colour space, no PQ transfer function, and the
//   native mode's size in pixels, in whole centimetres and as an aspect ratio in 16.16;
// - Transport: "Other" upstream and downstream, as no link carries the pixels;
// - IOMFBMaxSrcPixels: the largest source buffer and source rectangle a layer takes, the largest
//   mode's size; and its MaxSrcRectTotal and IOMFBMaxCompressedSizeInBytes 0, as the paravirtual
//   display gives them;
// - IOMFBScalingLimits: no layer scaled, up (RGBLayer_MaxScale 1) or down
//   (RGBLayer_MinScaleFraction 1), where the paravirtual display gives 4 each way: the device shows
//   layer 0's whole surface, whatever rectangles the swap gives it;
// - TimingElements and ColorElements: the device's modes (publishMobileModes).
// Of the rest the paravirtual display publishes, CursorPlane is the framebuffer's from its start
// (startMobile); its own ParavirtDisplayPrefs and ParavirtBrightnessCaps are not published, nor
// the DisplayContainerID its host may give it. A change of the device's modes publishes them all
// again (republishMobileDisplay).
void ReimsGraphics::publishMobileDisplay()
{
	IOLockLock(stateLock);
	const Mode native = nativeMode(Mode{});
	const UInt32 id = displayId;
	const UInt32 scale = displayScale;
	IOLockUnlock(stateLock);
	const uint32_t serial = rgfxDisplaySerial(id);

	setProperty("external", true);
	char uuid[40];
	snprintf(uuid, sizeof(uuid), "52564700-%04X-8000-8000-%012X", kRgfxDisplayProduct, serial);
	setProperty("IOMFBUUID", uuid);

	OSDictionary *attributes = OSDictionary::withCapacity(12);
	if (attributes) {
		OSDictionary *product = OSDictionary::withCapacity(6);
		if (product) {
			putString(product, "ManufacturerID", kRgfxDisplayManufacturer);
			putNumber(product, "ProductID", kRgfxDisplayProduct);
			putNumber(product, "SerialNumber", serial);
			putString(product, "ProductName", kRgfxDisplayName);
			putNumber(product, "WeekOfManufacture", 0);
			putNumber(product, "YearOfManufacture", kRgfxDisplayYear);
		}
		putDictionary(attributes, "ProductAttributes", product);
		OSDictionary *chromaticity = OSDictionary::withCapacity(3);
		if (chromaticity) {
			putDictionary(chromaticity, "Red", colorPoint(kRgfxDisplayRed));
			putDictionary(chromaticity, "Green", colorPoint(kRgfxDisplayGreen));
			putDictionary(chromaticity, "Blue", colorPoint(kRgfxDisplayBlue));
		}
		putDictionary(attributes, "Chromaticity", chromaticity);
		putDictionary(attributes, "DefaultWhitePoint", colorPoint(kRgfxDisplayWhite));
		attributes->setObject("DefaultColorSpaceIsSRGB", kOSBooleanTrue);
		attributes->setObject("SupportsPQEOTF", kOSBooleanFalse);
		if (native.width && native.height) {
			putNumber(attributes, "MaxHorizontalImageSize",
			          (rgfxDisplayMillimetres(native.width, scale) + 9) / 10);
			putNumber(attributes, "MaxVerticalImageSize",
			          (rgfxDisplayMillimetres(native.height, scale) + 9) / 10);
			putNumber(attributes, "NativeFormatHorizontalPixels", native.width);
			putNumber(attributes, "NativeFormatVerticalPixels", native.height);
			putNumber(attributes, "PreciseAspectRatio",
			          static_cast<uint32_t>((static_cast<uint64_t>(native.width) << 16) /
			                                native.height));
		}
		setProperty("DisplayAttributes", attributes);
		attributes->release();
	}

	if (OSDictionary *transport = OSDictionary::withCapacity(2)) {
		putString(transport, "Upstream", "Other");
		putString(transport, "Downstream", "Other");
		setProperty("Transport", transport);
		transport->release();
	}

	if (OSDictionary *source = OSDictionary::withCapacity(5)) {
		putNumber(source, "MaxSrcBufferWidth", kRgfxDisplayMaxDimension);
		putNumber(source, "MaxSrcBufferHeight", kRgfxDisplayMaxDimension);
		putNumber(source, "MaxSrcRectWidth", kRgfxDisplayMaxDimension);
		putNumber(source, "MaxSrcRectTotal", 0);
		putNumber(source, "IOMFBMaxCompressedSizeInBytes", 0);
		setProperty("IOMFBMaxSrcPixels", source);
		source->release();
	}

	if (OSDictionary *scaling = OSDictionary::withCapacity(2)) {
		putNumber(scaling, "RGBLayer_MinScaleFraction", 1);
		putNumber(scaling, "RGBLayer_MaxScale", 1);
		setProperty("IOMFBScalingLimits", scaling);
		scaling->release();
	}
	publishMobileModes();
	IOLog("ReimsGraphics: display %u is external, %ux%u native, UUID %s\n", id, native.width,
	      native.height, uuid);
}

namespace {

// Writes an IOAVFamily element's ID and Score (RgfxMobileModes.hpp).
void setElementId(OSObject *element, uint32_t id, uint32_t score)
{
	uint8_t *bytes = reinterpret_cast<uint8_t *>(element);
	*reinterpret_cast<uint64_t *>(bytes + kRgfxIOAVElementId) = id;
	*reinterpret_cast<uint32_t *>(bytes + kRgfxIOAVElementScore) = score;
}

} // namespace

// The display's modes as IOMobileFramebuffer.framework reads them, as the paravirtual display
// publishes its own (RgfxMobileModes.hpp): ColorElements, the one colour mode, and TimingElements,
// a timing for each mode the device lists, with the reduced blanking the x86-64 framebuffer's
// detailed timing gives it (timingFor) at the device's rate, and the colour mode as its ColorModes.
// WindowServer sets one of them with set_digital_out_mode where it has two to pick from.
void ReimsGraphics::publishMobileModes()
{
	Mode modes[kMaxModes];
	IOLockLock(stateLock);
	const UInt32 n = modeSet.modeCount;
	for (UInt32 i = 0; i < n; i++)
		modes[i] = modeSet.modes[i];
	const int32_t preferred = modeSet.preferredId;
	const UInt32 id = displayId;
	IOLockUnlock(stateLock);
	RgfxMobileTiming timings[kMaxModes];
	const uint32_t count = rgfxMobileTimings(modes, n, preferred, timings);

	OSObject *color =
	    rgfxIOAVColorWithCapabilities(kRgfxIOAVStandardType, kRgfxColorDepth, 0, 0, 0,
	                                  kRgfxIOAVColorimetry, false, nullptr, nullptr, nullptr, nullptr);
	OSArray *colors = color ? OSArray::withCapacity(1) : nullptr;
	OSArray *timingElements = colors ? OSArray::withCapacity(count) : nullptr;
	if (!timingElements) {
		IOLog("ReimsGraphics: display %u: no colour element, so no mode is published\n", id);
		OSSafeReleaseNULL(colors);
		OSSafeReleaseNULL(color);
		return;
	}
	setElementId(color, kRgfxColorElementId, kRgfxColorElementId);
	colors->setObject(color);
	uint32_t published = 0;
	for (uint32_t i = 0; i < count; i++) {
		const RgfxMobileTiming &t = timings[i];
		Timing timing;
		timingFor(t.mode, &timing);
		const RgfxIOAVTimingData data = rgfxIOAVTimingData(timing, t.mode.refreshMhz);
		OSObject *element = rgfxIOAVTimingWithData(&data, kRgfxIOAVStandardType,
		                                           kRgfxIOAVTimingStandard);
		// A timing's own array, as the paravirtual display gives each of its timings.
		OSArray *modeColors = element ? OSArray::withCapacity(1) : nullptr;
		if (!modeColors) {
			IOLog("ReimsGraphics: display %u: mode %ux%u has no timing element\n", id, t.mode.width,
			      t.mode.height);
			OSSafeReleaseNULL(element);
			continue;
		}
		setElementId(element, t.id, t.score);
		modeColors->setObject(color);
		rgfxIOAVTimingSetColorElements(element, modeColors);
		timingElements->setObject(element);
		published++;
		modeColors->release();
		element->release();
	}
	setProperty("ColorElements", colors);
	setProperty("TimingElements", timingElements);
	IOLog("ReimsGraphics: display %u publishes %u timings (preferred %u) and colour mode %u\n", id,
	      published, count ? timings[0].id : 0, kRgfxColorElementId);
	timingElements->release();
	colors->release();
	color->release();
}

// A change of the device's modes for the display, as a resize of the host's window makes one
// (the device's DISPLAY_CHANGED, whose refresh parseDisplays takes): the display publishes its
// attributes and modes again and tells the processes, as the paravirtual display takes its host's
// change of a display (its handleHostInterrupt, read from 26.6.2's and 27.0.1's AppleParavirtGPU
// and IOMobileGraphicsFamily). That removes the display's attributes and tells the class's
// hot-plug clients it is unplugged (hotPlug_notify 0) where it told them it was plugged in, makes
// them again from its host's modes and tells them it is plugged in (hotPlug_notify 1), and on 27.0.1
// sends its own clients kIOMessageServicePropertyChange. The display here does the same, in that
// order, but keeps its attributes published while it makes them again; a display that has told no
// hot-plug client it is plugged in, as none has before start_hardware, tells them only that.
// WindowServer then reads the new modes and sets one (set_digital_out_mode). Before it tells
// anyone, a display whose timing the device no longer lists shows the new start timing, as
// start_hardware does, so the display shows a mode it publishes until WindowServer sets one. On a
// thread call: the mode's set waits for the device's answers, which the device's work loop, where
// the change is found, takes.
void ReimsGraphics::mobileDisplayChanged(thread_call_param_t self, thread_call_param_t)
{
	static_cast<ReimsGraphics *>(self)->republishMobileDisplay();
}

void ReimsGraphics::republishMobileDisplay()
{
	if (!hasStarted())
		return;
	const bool wasPlugged = mobileHotPlugged;
	if (wasPlugged)
		rgfxLegacyHotPlugNotify(this, 0);
	publishMobileDisplay();
	IOLockLock(stateLock);
	Mode kept{};
	const uint32_t shownTiming = __atomic_load_n(&mobileTimingId, __ATOMIC_RELAXED);
	const bool listed = shownTiming && rgfxMobileModeFor(kRgfxColorElementId, shownTiming,
	                                                     modeSet.modes, modeSet.modeCount, &kept);
	const uint32_t startTiming =
	    rgfxMobileStartTimingId(modeSet.modes, modeSet.modeCount, modeSet.preferredId);
	IOLockUnlock(stateLock);
	Mode shown = kept;
	IOReturn set = kIOReturnSuccess;
	if (!listed)
		set = startTiming ? setMobileMode(kRgfxColorElementId, startTiming, &shown)
		                  : kIOReturnNotReady;
	rgfxLegacyHotPlugNotify(this, 1);
	mobileHotPlugged = true;
	messageClients(kIOMessageServicePropertyChange);
	if (logged(kDisplayChanged))
		IOLog("ReimsGraphics: display %u changed: %s timing %u, %ux%u at %u.%03u Hz (0x%x); "
		      "hot-plug clients told %s\n",
		      displayId, listed ? "keeps" : "shows", listed ? shownTiming : startTiming,
		      shown.width, shown.height, shown.refreshMhz / 1000, shown.refreshMhz % 1000, set,
		      wasPlugged ? "0, then 1" : "1");
}

void ReimsGraphics::mobileVblank(OSObject *client, UInt64 count, UInt64 time, UInt64 next)
{
	ReimsGraphics *self = static_cast<ReimsGraphics *>(client);
	if (logged(kVblank))
		IOLog("ReimsGraphics: vblank %llu at %llu, next %llu\n", count, time, next);
	self->note_vbl_ISR(static_cast<uint32_t>(count));
}

void ReimsGraphics::mobilePresented(OSObject *client, UInt64 seqno, UInt32 status, UInt64 time)
{
	ReimsGraphics *self = static_cast<ReimsGraphics *>(client);
	if (seqno != __atomic_load_n(&self->mobilePresentSeqno, __ATOMIC_ACQUIRE))
		return;
	if (logged(kPresented))
		IOLog("ReimsGraphics: present %llu shown, status %u at %llu\n", seqno, status, time);
	// The refresh it showed in, and the display's period, for the swap's frame info
	// (completeMobileSwap), read where the VBLANKs set it.
	UInt64 period = 0;
	nanoseconds_to_absolutetime(self->vblankClock.period(), &period);
	__atomic_store_n(&self->mobileShownPeriod, period, __ATOMIC_RELAXED);
	__atomic_store_n(&self->mobileShownAt, time, __ATOMIC_RELEASE);
	// The swap it shows completes in the class's gate (completeMobileSwap).
	if (IOInterruptEventSource *answer = __atomic_load_n(&self->mobileSwapAnswer, __ATOMIC_ACQUIRE))
		answer->interruptOccurred(nullptr, nullptr, 0);
}

// MARK: - The swaps

void ReimsGraphics::beginMobileSwaps()
{
	if (!mobileSwapLayout)
		return;
	RgfxLegacySwapQueue queue(this, *mobileSwapLayout);
	for (;;) {
		// The queue cleaned as the paravirtual display's clean_queue_gated cleans it, once no swap
		// is shown and one waits: none begins where the class keeps an obsolete swap's turn.
		if (queue.current() || !queue.first())
			return;
		if (rgfxLegacyDropObsoleteSwaps(this) != 0)
			return;
		rgfxLegacyDropNoOpSwaps(this);
		rgfxLegacyDropAbortedSwaps(this, false);
		rgfxLegacyDropDummySwaps(this);
		void *swap = queue.first();
		if (!swap)
			return;
		if (!queue.firstLinked()) {
			// Where the paravirtual display stops the kernel: the queue is left as it is.
			IOLog("ReimsGraphics: swap %p is not linked as the queue's first; no swap is begun\n",
			      swap);
			return;
		}
		if (!queue.begins(swap)) {
			// The class's dropSwap_gated takes the swap off the queue and completes it.
			if (logged(kSwapDropped))
				IOLog("ReimsGraphics: swap %p dropped at its state\n", swap);
			const UInt64 now = mach_absolute_time();
			noteMobileSwapRate(now);
			mobileSwapRate.drop(now);
			rgfxLegacyDropSwap(this, swap, false);
			continue;
		}
		queue.setCurrent(swap);
		rgfxLegacyUpdateSwapInfoState(this, swap, kSwapStateAtBegin);
		queue.removeFirst();
		// Layer 0's surface, by its IOSurface ID. The swap completes when the host answers its
		// present (mobilePresented), or here where nothing is presented or no answer can reach
		// the gate. The present's seqno is written before the host can answer it. Layer 1, where
		// the swap gives it, is the display's cursor; a layer-1 surface with no image is shown in
		// place of layer 0's, as the paravirtual display's program_hardware_gated has it
		// (RgfxMobileCursor.hpp). The cursor layer's colour chain, where it changed, goes to the
		// host first, so the cursor's image is converted from this swap on.
		OSObject *surface = static_cast<OSObject *>(queue.surface(swap, 0));
		postMobileCursorColor();
		if (queue.hasLayer(swap, 1)) {
			OSObject *cursor = static_cast<OSObject *>(queue.surface(swap, 1));
			int32_t x = 0, y = 0;
			queue.cursorPosition(swap, &x, &y);
			if (showMobileCursor(cursor, x, y))
				surface = cursor;
		}
		const uint32_t id = surface ? rgfxIOSurfaceSurfaceID(surface) : 0;
		IOReturn presented = kIOReturnNotReady;
		if (id) {
			const UInt32 transaction = ++mobileTransaction;
			mobileSwapShowing = mobileSwapAnswer ? swap : nullptr;
			presented = postPresent(id, transaction, 0, &mobilePresentSeqno);
			if (presented != kIOReturnSuccess)
				mobileSwapShowing = nullptr;
		}
		if (logged(kSwapShown))
			IOLog("ReimsGraphics: swap %p begun: surface %u, present 0x%x seqno %llu\n", swap, id,
			      presented, __atomic_load_n(&mobilePresentSeqno, __ATOMIC_RELAXED));
		const UInt64 now = mach_absolute_time();
		noteMobileSwapRate(now);
		mobileSwapRate.begin(now, id, queue.surface(swap, 1) != nullptr,
		                     presented == kIOReturnSuccess);
		if (mobileSwapShowing)
			return;
		// Nothing was shown: its frame info says so (notify_swap_done_gated).
		mobilePresentedAt = 0;
		rgfxLegacySwapComplete(this);
		mobileSwapRate.complete(now);
	}
}

// A swap's layer 1 as the display's cursor (RgfxMobileCursor.hpp), in the class's gate: no surface
// hides the cursor; the surface and seed taken last move it; another is taken, and its image set
// on the device's cursor (SET_CURSOR, from the cursor's slot, whose answer frees the slot) before
// the cursor moves to it. True where the surface has no image, which the swap shows in place of
// layer 0's.
bool ReimsGraphics::showMobileCursor(OSObject *surface, int32_t x, int32_t y)
{
	if (!surface) {
		postMobileCursorMove(x, y, false);
		return false;
	}
	const uint32_t id = rgfxIOSurfaceSurfaceID(surface);
	const uint32_t seed = rgfxIOSurfaceLockSeed(surface);
	if (!mobileCursor.same(id, seed)) {
		const RgfxSurfaceImageExtents extents = rgfxIOSurfaceImageExtents(surface);
		const uint32_t width = rgfxIOSurfaceWidth(surface);
		const uint32_t height = rgfxIOSurfaceHeight(surface);
		const uint32_t format = rgfxIOSurfacePixelFormat(surface);
		RgfxMobileCursorImage image = {};
		const RgfxCursorTake take =
		    rgfxMobileCursorImage(width, height, format, rgfxIOSurfaceBytesPerElement(surface),
		                          extents, kCursorMax, &image);
		mobileCursor.record(id, seed, take, image);
		IOReturn set = kIOReturnSuccess;
		if (take == RgfxCursorTake::Image) {
			set = setMobileCursorImage(surface, image);
			if (set != kIOReturnSuccess)
				mobileCursor.forget();
		}
		if ((take != RgfxCursorTake::Image || set != kIOReturnSuccess) && logged(kCursorRefused))
			IOLog("ReimsGraphics: cursor surface %u (%ux%u, format 0x%08x): image %ux%u from "
			      "(%u, %u), hot spot (%u, %u): %s, set 0x%x\n",
			      id, width, height, format, extents.width, extents.height, extents.originX,
			      extents.originY, extents.hotX, extents.hotY,
			      take == RgfxCursorTake::None     ? "no image, shown as the swap's surface"
			      : take == RgfxCursorTake::Format ? "refused: not BGRA of 4 bytes an element"
			      : take == RgfxCursorTake::Origin ? "refused: the origin is past the surface"
			      : take == RgfxCursorTake::HotSpot ? "refused: the hot spot is outside the image"
			                                         : "not set",
			      set);
		else if (logged(kSwapCursor))
			IOLog("ReimsGraphics: cursor surface %u seed %u: %ux%u from (%u, %u), hot spot (%u, "
			      "%u)\n",
			      id, seed, image.width, image.height, image.x, image.y, image.hotX, image.hotY);
		if (set != kIOReturnSuccess)
			return false;
	}
	switch (mobileCursor.take) {
	case RgfxCursorTake::Image:
		postMobileCursorMove(x, y, true);
		return false;
	case RgfxCursorTake::None:
		return true;
	default:
		// Refused: the cursor stays as it was.
		return false;
	}
}

// The cursor surface's image into the cursor's slot, its rows read through a read-only mapping of
// the surface's memory as the paravirtual display reads them, and set on the device's cursor.
IOReturn ReimsGraphics::setMobileCursorImage(OSObject *surface, const RgfxMobileCursorImage &image)
{
	IOMemoryDescriptor *memory = rgfxIOSurfaceMemory(surface);
	const uint64_t bytesPerRow = rgfxIOSurfaceBytesPerRow(surface);
	uint64_t offset = 0, length = 0;
	if (!memory || !cursorPixels ||
	    !rgfxMobileCursorSpan(image, bytesPerRow, memory->getLength(), &offset, &length))
		return kIOReturnBadArgument;
	IOMemoryMap *map =
	    memory->createMappingInTask(kernel_task, 0, kIOMapAnywhere | kIOMapReadOnly);
	if (!map)
		return kIOReturnNoMemory;
	if (map->getLength() < offset + length) {
		map->release();
		return kIOReturnBadArgument;
	}
	// The slot is every display's: held from the copy to the command's answer (lockCursorSlot).
	lockCursorSlot();
	rgfxMobileCursorCopy(image, bytesPerRow,
	                     reinterpret_cast<const uint8_t *>(map->getVirtualAddress()) + offset,
	                     cursorPixels);
	map->release();
	RgfxSetCursor c = {};
	c.display = displayId;
	c.width = image.width;
	c.height = image.height;
	c.hot_x = image.hotX;
	c.hot_y = image.hotY;
	c.offset = regionSize - kCursorSlot;
	const IOReturn r = command(RGFX_CMD_SET_CURSOR, &c, sizeof(c));
	unlockCursorSlot();
	return r;
}

// CURSOR_COLOR where the cursor layer's ICC chain changed since the host was last sent it
// (RgfxMobileICC.hpp, rgfxICCCursorColor), in the class's gate, before the swap's cursor: the
// host converts the cursor's image through it from then on, as a display engine latches a layer's
// colour stages with the swap. Never waits: a post the ring has no room for is left, and the next
// swap posts the chain again.
void ReimsGraphics::postMobileCursorColor()
{
	if (!mobileICC || !mobileICCLock || !rgfxICCCursorDue(mobileICC))
		return;
	RgfxCursorColor c = {};
	uint32_t changes = 0;
	IOLockLock(mobileICCLock);
	const bool due = rgfxICCCursorColor(mobileICC, &c, &changes);
	IOLockUnlock(mobileICCLock);
	if (!due)
		return;
	c.display = displayId;
	if (!tryPost(RGFX_CMD_CURSOR_COLOR, &c, sizeof(c), nullptr))
		return;
	IOLockLock(mobileICCLock);
	rgfxICCCursorPosted(mobileICC, changes);
	IOLockUnlock(mobileICCLock);
	if (logged(kCursorColor))
		IOLog("ReimsGraphics: the cursor's colour chain (%u changes) posted: %s\n", changes,
		      c.on ? "on" : "off");
}

// MOVE_CURSOR where the cursor's place or visibility changes: the hot spot at the swap's position
// plus the image's hot spot in its surface. Never waits: a post the ring has no room for is
// left, and the next swap's layer 1 posts it again. Once posted, the cursor shown is the landing
// of display 0's post of a move, if one is out, and each display's place that changed is told
// the host (ReimsGraphicsPointer.cpp).
bool ReimsGraphics::postMobileCursorMove(int32_t x, int32_t y, bool visible)
{
	int32_t mx = 0, my = 0;
	if (!mobileCursor.move(x, y, visible, &mx, &my))
		return true;
	RgfxMoveCursor m = {};
	m.display = displayId;
	m.x = mx;
	m.y = my;
	m.visible = visible ? 1u : 0u;
	if (!tryPost(RGFX_CMD_MOVE_CURSOR, &m, sizeof(m), nullptr))
		return false;
	mobileCursor.posted(mx, my, visible);
	ReimsGraphics *owner = isHead() ? device : this;
	mobileCursor.seq = __atomic_add_fetch(&owner->cursorMoves, 1, __ATOMIC_ACQ_REL);
	if (visible)
		owner->cursorLanded(displayId, mx, my);
	owner->tellBounds();
	return true;
}

// The line of the minute of swaps just over, once a swap comes after it: none while the display
// is idle. A summary, at most once a minute (docs/conventions.md).
void ReimsGraphics::noteMobileSwapRate(UInt64 now)
{
	if (!mobileSwapRateWindow)
		nanoseconds_to_absolutetime(60000000000ull, &mobileSwapRateWindow);
	const RgfxSwapRate &r = mobileSwapRate;
	if (!r.due(now, mobileSwapRateWindow))
		return;
	uint64_t ns = 0;
	absolutetime_to_nanoseconds(now - r.start, &ns);
	IOLog("ReimsGraphics: swaps over %llu ms: %u begun, %u completed, %u dropped, %u not shown, "
	      "%u with layer 1; layer 0: %u x%u, %u x%u, %u x%u, %u x%u, others x%u\n",
	      ns / 1000000, r.begun, r.completed, r.dropped, r.unshown, r.layer1, r.ids[0], r.counts[0],
	      r.ids[1], r.counts[1], r.ids[2], r.counts[2], r.ids[3], r.counts[3], r.others);
	mobileSwapRate.clear();
}

void ReimsGraphics::completeMobileSwap()
{
	void *swap = mobileSwapShowing;
	if (!swap || !mobileSwapLayout)
		return;
	mobileSwapShowing = nullptr;
	// The class may have finished the swap itself meanwhile (an abort or a stop).
	RgfxLegacySwapQueue queue(this, *mobileSwapLayout);
	if (queue.current() != swap)
		return;
	// The swap's presentation time, the refresh the host answered in, a refresh after the swap's
	// before where that refresh has come by now, in mach_continuous_time's clock, which its frame
	// info carries (notify_swap_done_gated, which the class's swap_complete_gated calls).
	const UInt64 shown = __atomic_exchange_n(&mobileShownAt, 0, __ATOMIC_ACQ_REL);
	const UInt64 period = __atomic_load_n(&mobileShownPeriod, __ATOMIC_RELAXED);
	rgfxReadClocks([] { return mach_absolute_time(); }, [] { return mach_continuous_time(); },
	               mobileFrameClock);
	mobilePresentedAt = mobileFrameClock.time(shown, period, mach_absolute_time());
	rgfxLegacySwapComplete(this);
	const UInt64 now = mach_absolute_time();
	noteMobileSwapRate(now);
	mobileSwapRate.complete(now);
	beginMobileSwaps();
}

void ReimsGraphics::mobileSwapAnswered(OSObject *owner, IOInterruptEventSource *, int)
{
	static_cast<ReimsGraphics *>(owner)->completeMobileSwap();
}

// MARK: - The class's own pure methods

// A notify request's tag mask, for the swap-info notification alone, as the paravirtual display
// sets it; any other type is answered kIOReturnBadArgument, as the paravirtual display answers it
// (RgfxLegacySwapInfo.hpp).
RgfxIOMFBWord ReimsGraphics::set_notify_tag_mask_gated(IOMFB_NotificationType type,
                                                       IOMFBNotifyRequest *request, uint32_t mask)
{
	IOReturn r = kIOReturnBadArgument;
	if (static_cast<uint32_t>(type) == kRgfxSwapInfoNotification && request) {
		*reinterpret_cast<uint32_t *>(reinterpret_cast<uint8_t *>(request) +
		                              kRgfxNotifyRequestMask) = mask;
		r = kIOReturnSuccess;
	}
	if (logged(kSetNotifyTagMask))
		IOLog("ReimsGraphics: set_notify_tag_mask_gated(%u, %p, 0x%x) = 0x%x\n",
		      static_cast<uint32_t>(type), request, mask, r);
	return word(r);
}

// The frame info tags the device fills (RgfxLegacySwapInfo.hpp), one a call: the count, and tag
// `index`'s name in `names[0]`, which IOMobileFramebuffer.framework asks for each index below the
// count it is given at index 0. The records go through the client's shared data queue
// (`dataQueue` 1, which the user client keeps and makes the queue at its frame info port by), as
// the class adds frame info requests with no async reference (RgfxLegacySwapInfo.hpp).
RgfxIOMFBWord ReimsGraphics::supported_frame_info(uint32_t index, uint32_t *count, char (*names)[64],
                                                  uint32_t *dataQueue)
{
	IOReturn r = kIOReturnBadArgument;
	const char *tag = rgfxFrameInfoTag(index);
	if (count)
		*count = kRgfxFrameInfoTagCount;
	if (dataQueue)
		*dataQueue = 1;
	if (tag && names) {
		strlcpy(names[0], tag, sizeof(names[0]));
		r = kIOReturnSuccess;
	}
	if (logged(kSupportedFrameInfo))
		IOLog("ReimsGraphics: supported_frame_info(%u) = 0x%x: %s\n", index, r, tag ? tag : "none");
	return word(r);
}

RgfxIOMFBWord ReimsGraphics::factory_portal(void *field_0, task *owner)
{
	if (logged(kFactoryPortal))
		IOLog("ReimsGraphics: factory_portal(%p, %p)\n", field_0, owner);
	return word(kIOReturnUnsupported);
}

RgfxIOMFBWord ReimsGraphics::executeFactoryConfigurations_gated()
{
	if (logged(kExecuteFactoryConfigurations))
		IOLog("ReimsGraphics: executeFactoryConfigurations_gated()\n");
	return word(kIOReturnSuccess);
}

RgfxIOMFBWord ReimsGraphics::set_frame_info_notification_state_gated(IOMFBNotifyRequest *request,
                                                                     bool on)
{
	if (logged(kSetFrameInfoNotificationState))
		IOLog("ReimsGraphics: set_frame_info_notification_state_gated(%p, %d)\n", request, on);
	return word(kIOReturnSuccess);
}

// A swap's frame info record sent to one notify request's client: the values the request's tag
// mask asks for (rgfxFrameInfoRecord), enqueued in the shared data queue of the user client the
// request is for, where the client's library reads them (RgfxLegacySwapInfo.hpp), answering the
// enqueue's result: an error where the queue holds no room, or kIOReturnNotAttached where the
// request names no client. WindowServer learns its swaps' presentation times from them.
RgfxIOMFBWord ReimsGraphics::do_swap_info_notify_gated(IOMFBNotifyRequest *request,
                                                       const IOMobileFramebufferLegacy::SwapInfoBlob *blob)
{
	IOReturn r = kIOReturnBadArgument;
	if (request && blob) {
		uint8_t *bytes = reinterpret_cast<uint8_t *>(request);
		void *client = *reinterpret_cast<void *const *>(bytes + kRgfxNotifyRequestClient);
		uint64_t words[kRgfxSwapInfoMaxArgs + 1];
		const uint32_t n = rgfxFrameInfoRecord(
		    bytes, *reinterpret_cast<const RgfxSwapInfoRecord *>(blob), words);
		r = client ? rgfxUserClientEnqueueFrameInfo(client, words,
		                                            static_cast<uint32_t>(n * sizeof(words[0])))
		           : kIOReturnNotAttached;
	}
	if (logged(kDoSwapInfoNotify))
		IOLog("ReimsGraphics: do_swap_info_notify_gated(%p, %p) = 0x%x\n", request, blob, r);
	return word(r);
}

// The class's swap_complete_gated calls this with the completed swap's ID. As the paravirtual
// display does, the swap's record (rgfxSwapInfoRecord) is made, here from its presentation time
// (completeMobileSwap) and the swap's own fields, at the release's offsets
// (RgfxLegacySwapLayout.hpp), and dispatched to each notify request
// (swap_info_notify_dispatch_gated), after the records kept while the class held them. A swap
// whose state word is not 0 gets none, answered kIOReturnUnsupported.
RgfxIOMFBWord ReimsGraphics::notify_swap_done_gated(uint32_t field_0, ::SwapInfoBlob *blob,
                                                    uint32_t *field_2, uint32_t field_3)
{
	IOReturn r = kIOReturnUnsupported;
	const RgfxLegacySwapLayout *l = mobileSwapLayout;
	const uint8_t *swap =
	    l ? static_cast<const uint8_t *>(RgfxLegacySwapQueue(this, *l).current()) : nullptr;
	if (swap && *reinterpret_cast<const uint32_t *>(swap + l->state) == 0) {
		const uint8_t *self = reinterpret_cast<const uint8_t *>(this);
		RgfxSwapInfoRecord record = rgfxSwapInfoRecord(
		    field_0, mobilePresentedAt,
		    *reinterpret_cast<const uint64_t *>(swap + l->swapRecordField00),
		    *reinterpret_cast<const uint32_t *>(swap + l->swapFlags));
		if (*reinterpret_cast<const uint16_t *>(self + l->notifyHeld) != 0) {
			mobileSwapInfoKept.keep(record);
		} else {
			mobileSwapInfoKept.flush([this](RgfxSwapInfoRecord &kept) {
				rgfxLegacySwapInfoNotifyDispatch(this, &kept);
			});
			rgfxLegacySwapInfoNotifyDispatch(this, &record);
		}
		r = kIOReturnSuccess;
	}
	if (logged(kNotifySwapDone))
		IOLog("ReimsGraphics: notify_swap_done_gated(%u, %p, %p, %u) = 0x%x\n", field_0, blob,
		      field_2, field_3, r);
	return word(r);
}

RgfxIOMFBWord ReimsGraphics::notify_crc_ready_gated(uint32_t field_0)
{
	if (logged(kNotifyCrcReady))
		IOLog("ReimsGraphics: notify_crc_ready_gated(%u)\n", field_0);
	return word(kIOReturnSuccess);
}

bool ReimsGraphics::are_timings_enabled() const
{
	if (logged(kAreTimingsEnabled))
		IOLog("ReimsGraphics: are_timings_enabled()\n");
	return true;
}

// MARK: - What a subclass implements for its display

namespace {

// The power states the display registers, as Apple's paravirtual display registers its own: off,
// and on and usable.
IOPMPowerState mobilePowerStates[] = {
	{kIOPMPowerStateVersion1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	{kIOPMPowerStateVersion1, kIOPMDeviceUsable, kIOPMPowerOn, kIOPMPowerOn, 0, 0, 0, 0, 0, 0, 0, 0},
};

} // namespace

RgfxIOMFBWord ReimsGraphics::start_hardware()
{
	// The class's start calls this last, and fails unless it answers true. The device runs
	// already (start). Power management's state reaches the class through its setPowerState,
	// which records it: the class drops every swap submitted while the display is off. The
	// vblanks start here, once the class has its work loop and swap queue.
	PMinit();
	if (IOService *provider = getProvider())
		provider->joinPMtree(this);
	const IOReturn power = registerPowerDriver(this, mobilePowerStates,
	                                           sizeof(mobilePowerStates) / sizeof(mobilePowerStates[0]));
	mobilePowerJoined = true;
	// The present's answer reaches the class's gate through an event source on its work loop.
	if (!mobileSwapAnswer && mobileSwapLayout) {
		IOWorkLoop *loop = getWorkLoop();
		IOInterruptEventSource *answer =
		    loop ? IOInterruptEventSource::interruptEventSource(this, mobileSwapAnswered) : nullptr;
		if (answer && loop->addEventSource(answer) == kIOReturnSuccess) {
			loop->retain();
			mobileSwapLoop = loop;
			answer->enable();
			__atomic_store_n(&mobileSwapAnswer, answer, __ATOMIC_RELEASE);
		} else {
			IOLog("ReimsGraphics: no event source on the framebuffer's work loop; no swap is "
			      "begun\n");
			OSSafeReleaseNULL(answer);
		}
	}
	// The display starts in its preferred mode, as a panel does, and is plugged in, as the
	// paravirtual display tells the class's hot-plug clients once it has published a display
	// (hotPlug_notify 1, its createDisplayAttributes): WindowServer reads an external display's
	// modes only while the class's get_digital_out_state answers it plugged in (14.6.1's
	// QuartzCore, IOMFBDisplay's update_framebuffer_locked), and then sets one of them.
	IOLockLock(stateLock);
	const uint32_t startTiming =
	    rgfxMobileStartTimingId(modeSet.modes, modeSet.modeCount, modeSet.preferredId);
	IOLockUnlock(stateLock);
	Mode start{};
	const IOReturn shown = startTiming ? setMobileMode(kRgfxColorElementId, startTiming, &start)
	                                   : kIOReturnNotReady;
	IOLog("ReimsGraphics: display %u starts in timing %u: 0x%x, %ux%u at %u.%03u Hz\n", displayId,
	      startTiming, shown, start.width, start.height, start.refreshMhz / 1000,
	      start.refreshMhz % 1000);
	if (mobilePipe)
		setPipeVblankEnabled(this, true);
	rgfxLegacyHotPlugNotify(this, 1);
	mobileHotPlugged = true;
	if (logged(kStartHardware))
		IOLog("ReimsGraphics: start_hardware(): power driver 0x%x, vblanks on\n", power);
	return 1;
}

RgfxIOMFBWord ReimsGraphics::stop_hardware_gated()
{
	if (mobilePipe)
		setPipeVblankEnabled(this, false);
	if (mobilePowerJoined)
		PMstop();
	mobilePowerJoined = false;
	if (logged(kStopHardware))
		IOLog("ReimsGraphics: stop_hardware_gated()\n");
	return 0;
}

RgfxIOMFBWord ReimsGraphics::swap_begin_gated()
{
	if (logged(kSwapBegin))
		IOLog("ReimsGraphics: swap_begin_gated()\n");
	beginMobileSwaps();
	return 0;
}

RgfxIOMFBWord ReimsGraphics::verify_swap(IOMFBSwapIORequest *request)
{
	if (logged(kVerifySwap))
		IOLog("ReimsGraphics: verify_swap(%p) = 1\n", request);
	return 1;
}

RgfxIOMFBWord ReimsGraphics::swap_layer_map(IOMFBSwapIORequest *request, uint32_t layer)
{
	if (logged(kSwapLayerMap))
		IOLog("ReimsGraphics: swap_layer_map(%p, %u)\n", request, layer);
	return word(kIOReturnSuccess);
}

RgfxIOMFBWord ReimsGraphics::surface_layer_map(IOMFB::AP::DisplayedData *data, uint32_t layer,
                                               IOSurface *surface)
{
	// Nothing to map: the swap's begin presents its surface by ID.
	const RgfxIOMFBWord r = word(kIOReturnSuccess);
	if (logged(kSurfaceLayerMap))
		IOLog("ReimsGraphics: surface_layer_map(%p, %u, %p: surface %u) = 0x%llx\n", data, layer,
		      surface, surface ? rgfxIOSurfaceSurfaceID(reinterpret_cast<const OSObject *>(surface)) : 0,
		      r);
	return r;
}

RgfxIOMFBWord ReimsGraphics::surface_layer_unmap(IOMFB::AP::DisplayedData *data, uint32_t layer)
{
	if (logged(kSurfaceLayerUnmap))
		IOLog("ReimsGraphics: surface_layer_unmap(%p, %u)\n", data, layer);
	return 0;
}

// IOMobileFramebufferLegacy's start keeps its provider as an AppleARMIODevice, NULL where the
// provider is not one, as a PCI device is not, and leaves nothing else unset. Of the class's
// functions that read it, get_dot_pitch alone calls through it unchecked: it reads the provider's
// "dot-pitch" property, and IOMobileFramebufferUserClient's s_get_dot_pitch reaches it from any
// process, so the class's own faulted (macOS 26.6.2 and 27.0.1, from photolibraryd). The others
// do not fault: the thread find_swap_function_gated starts hands the provider to
// AppleARMFunction::withProvider, which answers none for a NULL provider, and allocate_carveout
// reads it only under a flag the family never sets (read from the IOMobileGraphicsFamily of
// macOS 14.6.1, 15.6.1, 26.6.2, 27.0.1 and 27.2.1; tests/legacy_overrides_test.cpp). The display's
// dot pitch is its pixels per inch, as the paravirtual display answers from its own size.
RgfxIOMFBWord ReimsGraphics::get_dot_pitch(uint32_t *pitch)
{
	if (!pitch)
		return word(kIOReturnBadArgument);
	IOLockLock(stateLock);
	const UInt32 scale = displayScale;
	IOLockUnlock(stateLock);
	*pitch = rgfxDisplayPixelsPerInch(scale);
	if (logged(kGetDotPitch))
		IOLog("ReimsGraphics: get_dot_pitch() = %u\n", *pitch);
	return word(kIOReturnSuccess);
}

// The mode WindowServer picks of the timings and colour modes the display publishes
// (publishMobileModes), by their IDs: the colour mode's, then the timing's, as
// IOMobileFramebufferUserClient passes them from IOMobileFramebufferSetDigitalOutMode (read from
// macOS 14.6.1's QuartzCore and IOMobileFramebuffer.framework, and 27.0.1's AppleParavirtGPU, whose
// set_digital_out_mode looks the second up among its timings and the first among that timing's
// colour modes). The device shows the mode, as the x86-64 framebuffer's setDisplayMode has it
// shown; then, as the paravirtual display does, the class's own fields get the mode's size, in the
// class's gate (RgfxLegacySwapLayout.hpp), which its get_display_size answers and its swap_submit
// and default framebuffer surface read, and the framebuffer publishes the size and the timing ID:
// DisplayWidth, DisplayHeight and DPTimingModeId. A pair the display does not publish is answered
// kIOReturnUnsupported, as the paravirtual display leaves it to the class, which answers that.
// start_hardware sets the display's first mode the same way (setMobileMode).
RgfxIOMFBWord ReimsGraphics::set_digital_out_mode(uint32_t colorId, uint32_t timingId)
{
	Mode mode{};
	const IOReturn r = setMobileMode(colorId, timingId, &mode);
	if (logged(kSetDigitalOutMode))
		IOLog("ReimsGraphics: set_digital_out_mode(%u, %u) = 0x%x: %ux%u at %u.%03u Hz\n", colorId,
		      timingId, r, mode.width, mode.height, mode.refreshMhz / 1000, mode.refreshMhz % 1000);
	return word(r);
}

// The colour matrix WindowServer sets with a swap, by IOMobileFramebufferSwapSetColorMatrix:
// QuartzCore sets its accessibility matrix so (function 2) at each swap until the call succeeds
// (RgfxMobileColor.hpp). Any function and field are answered 0, NULL sets the identity, and the
// display shows the matrix from the next present: the device's DISPLAY_COLOR matrix stage, which
// the host stages for the next PRESENT_SURFACE it takes and keeps until it is set again, as the
// x86-64 display pipe sets it (RgfxPipeColor.hpp); an identity turns the stage off. The user
// client calls it ungated, in WindowServer's thread, so the post may wait for the ring's room. A
// host without RGFX_FEATURE_DISPLAY_COLOR shows no matrix, and the call is still answered 0:
// WindowServer's matrix is set, whatever the host shows of it.
RgfxIOMFBWord ReimsGraphics::swap_set_color_matrix(IOMFBColorFixedMatrix *matrix,
                                                   IOMFBColorMatrixFunction function,
                                                   uint32_t field_2)
{
	RgfxColorEntry rows[kRgfxMobileMatrixRows];
	rgfxMobileColorMatrix(reinterpret_cast<const int64_t *>(matrix), rows);
	// A swap's colour has no pipe transaction: its parts carry 0, which the host only logs.
	const IOReturn posted =
	    displayColor() ? postDisplayColor(0, RGFX_COLOR_MATRIX, kRgfxMobileMatrixRows,
	                                      reinterpret_cast<const UInt8 *>(rows))
	                   : kIOReturnUnsupported;
	if (logged(kSwapSetColorMatrix))
		IOLog("ReimsGraphics: swap_set_color_matrix(%s, %u, %u): rows %08x %08x %08x / %08x %08x "
		      "%08x / %08x %08x %08x, posted 0x%x\n",
		      matrix ? "matrix" : "NULL", static_cast<uint32_t>(function), field_2, rows[0].x,
		      rows[0].y, rows[0].z, rows[1].x, rows[1].y, rows[1].z, rows[2].x, rows[2].y, rows[2].z,
		      posted);
	return word(kIOReturnSuccess);
}

// The colour filter scale WindowServer sets after its accessibility matrix, by
// IOMobileFramebufferSetParameter (RgfxMobileColor.hpp): a scale of 1.0 is answered 0, the matrix
// shown as swap_set_color_matrix shows it. Every other parameter, and another scale, goes to the
// class, which answers as it does for the paravirtual display. The user client calls it ungated,
// in WindowServer's thread, as it calls swap_set_color_matrix.
RgfxIOMFBWord ReimsGraphics::set_parameter(IOMFBParameterName name, const uint64_t *values,
                                           uint32_t count)
{
	const uint32_t parameter = static_cast<uint32_t>(name);
	const bool one = rgfxColorFilterScaleIsOne(parameter, values, count);
	const RgfxIOMFBWord answer = one ? word(kIOReturnSuccess)
	                                 : rgfxLegacySetParameter(this, name, values, count);
	if (parameter == kRgfxColorFilterScaleParameter && logged(kSetParameter))
		IOLog("ReimsGraphics: set_parameter(%u, %u values, first 0x%llx) = 0x%x%s\n", parameter,
		      count, (values && count) ? static_cast<unsigned long long>(values[0]) : 0ull,
		      static_cast<uint32_t>(answer), one ? "" : ", the class's answer");
	return answer;
}

// The ICC matrices and curves WindowServer sets by IOMobileFramebufferSetBlock (RgfxMobileICC.hpp):
// a block that leaves the display's chain the identity, which is what the display shows, is
// answered 0, and so is a block of the cursor layer's chain the display reads where the host
// converts the cursor; the rest kIOReturnUnsupported, as the class answers every block. The
// cursor's chain goes to the host at the next swap (postMobileCursorColor); nothing else is
// posted: the host's colour stages stay as they are. The user client calls it ungated, in
// WindowServer's thread, as it calls swap_set_color_matrix (measured on 27.0.1); the pairs it
// holds are the framebuffer's, under their lock, and a framebuffer without them refuses every
// block.
RgfxIOMFBWord ReimsGraphics::set_block(task *owner, uint32_t type, uint32_t offset,
                                       const uint64_t *scalars, uint32_t count, const uint8_t *data,
                                       size_t size)
{
	bool took = false;
	if (mobileICC && mobileICCLock) {
		IOLockLock(mobileICCLock);
		took = rgfxICCTake(mobileICC, type, offset, scalars, count, data, size);
		IOLockUnlock(mobileICCLock);
	}
	if (logged(kSetBlock))
		IOLog("ReimsGraphics: set_block(0x%x, offset %u, %u scalars: 0x%llx 0x%llx 0x%llx 0x%llx, "
		      "%zu bytes) %s\n",
		      type, offset, count, (scalars && count > 0) ? scalars[0] : 0ull,
		      (scalars && count > 1) ? scalars[1] : 0ull, (scalars && count > 2) ? scalars[2] : 0ull,
		      (scalars && count > 3) ? scalars[3] : 0ull, size, took ? "taken" : "refused");
	return word(took ? kIOReturnSuccess : kIOReturnUnsupported);
}

IOReturn ReimsGraphics::setMobileMode(uint32_t colorId, uint32_t timingId, Mode *shown)
{
	IOLockLock(stateLock);
	Mode mode{};
	const bool published =
	    rgfxMobileModeFor(colorId, timingId, modeSet.modes, modeSet.modeCount, &mode);
	IOLockUnlock(stateLock);
	*shown = mode;
	IOReturn r = kIOReturnUnsupported;
	if (published) {
		r = setScanout(mode);
		if (r == kIOReturnSuccess && mobileSwapLayout) {
			IOWorkLoop::Action write = [](OSObject *owner, void *layout, void *width, void *height,
			                              void *) -> IOReturn {
				rgfxLegacySetDisplaySize(owner, *static_cast<const RgfxLegacySwapLayout *>(layout),
				                         static_cast<uint32_t>(reinterpret_cast<uintptr_t>(width)),
				                         static_cast<uint32_t>(reinterpret_cast<uintptr_t>(height)));
				return kIOReturnSuccess;
			};
			void *layout = const_cast<RgfxLegacySwapLayout *>(mobileSwapLayout);
			void *width = reinterpret_cast<void *>(static_cast<uintptr_t>(mode.width));
			void *height = reinterpret_cast<void *>(static_cast<uintptr_t>(mode.height));
			if (IOWorkLoop *loop = getWorkLoop())
				loop->runAction(write, this, layout, width, height);
			else
				write(this, layout, width, height, nullptr);
		}
		if (r == kIOReturnSuccess) {
			setProperty("DisplayWidth", mode.width, 32);
			setProperty("DisplayHeight", mode.height, 32);
			setProperty("DPTimingModeId", timingId, 64);
			__atomic_store_n(&mobileTimingId, timingId, __ATOMIC_RELAXED);
		}
	}
	return r;
}

#endif // __arm64e__
