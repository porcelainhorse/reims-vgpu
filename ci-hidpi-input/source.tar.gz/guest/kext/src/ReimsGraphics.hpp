/*
 * ReimsGraphics: the reims-graphics device's display driver for x86-64 macOS
 * guests, an IOFramebuffer on the PCI device (docs/graphics-kext/design.md,
 * Decided 12 and "Stage 2 wire protocol").
 *
 * It drives one display, the first the device lists. WindowServer composites
 * in software into the scanout buffer, which sits in BAR2 at the start of the
 * guest's allocations; the device presents it, so the driver itself never
 * touches pixels. Everything else is the control ring: modes, scanout,
 * cursor, vblank and display changes.
 *
 * Several displays (design.md, "Multiple displays"; RgfxDisplayTable.hpp): the
 * framebuffer the kext's personality starts owns the device and drives display
 * 0. Where it took MULTI_DISPLAY and the device lists more displays, its start
 * makes a framebuffer of this class for each display from 1, a head, attached
 * to the PCI device and registered after display 0's, all of one GPU
 * (IOFBDependentID display 0's registry ID, IOFBDependentIndex the display's):
 * each with its own modes, timings, EDID, cursor, interrupts, scanout room and
 * server connection, posting on display 0's control ring under its lock and
 * handed its display's events by display 0's work loop. Display 0's is the
 * device (`device` is itself); a head's `device` is display 0's.
 *
 * Threads: IOFramebuffer calls in on its own threads. Commands with an answer
 * wait for it, and commands without one (MOVE_CURSOR, SET_VBLANK) never
 * block, since IOFramebuffer may move the cursor with a spin lock held. The
 * driver's work loop is the control completion ring's only consumer: it
 * drains it on MSI-X vector 0, hands answers to the waiting threads, and
 * turns VBLANK and DISPLAY_CHANGED into IOFramebuffer's interrupts.
 *
 * The control ring is the guest's one ring to the device besides the command
 * queues' own, so the accelerator posts the Metal processes' object lifecycle
 * on it too (postLifecycle), under the same lock; the work loop hands each of
 * those its answer (a COMPLETE, a pipeline's reflection, a heap texture
 * size, a sampler's resource id) by seqno.
 */

#ifndef REIMS_GRAPHICS_HPP_
#define REIMS_GRAPHICS_HPP_

#include <IOKit/IOCommandGate.h>
#include <IOKit/IOFilterInterruptEventSource.h>
#include <IOKit/IOInterruptEventSource.h>
#include <IOKit/IOLocks.h>
#include <IOKit/IOWorkLoop.h>
#include <IOKit/graphics/IOFramebuffer.h>
#include <IOKit/pci/IOPCIDevice.h>
#if defined(__arm64e__)
#include <graft/IOMobileFramebufferLegacy.h>
// The Graft SDK stand-in's methods answer graft_iomfb_word, a uint64_t; the arm64e front end
// (ReimsGraphicsMobile.cpp) names it RgfxIOMFBWord.
typedef graft_iomfb_word RgfxIOMFBWord;
#include "RgfxLegacySwapInfo.hpp"
#include "RgfxLegacySwapLayout.hpp"
#include "RgfxMobileCursor.hpp"
#include "RgfxMobileICC.hpp"
#include "RgfxRegisterHold.hpp"
#include "RgfxSwapRate.hpp"
#endif
#include <kern/thread_call.h>

#include "RgfxAnswerWait.hpp"
#include "RgfxBootConsole.hpp"
#include "RgfxDeferredAnswers.hpp"
#include "RgfxDisplayBounds.hpp"
#include "RgfxDisplayModes.hpp"
#include "RgfxDisplayPlaces.hpp"
#include "RgfxDisplayTable.hpp"
#include "RgfxPipeClients.hpp"
#include "RgfxPointerOver.hpp"
#include "RgfxRingRoom.hpp"
#include "RgfxScanoutOwner.hpp"
#include "RgfxSharedPipelines.hpp"
#include "RgfxVblankClock.hpp"
#include "reims_graphics_wire.h"

// The IOReturn of a wait for the host's answer that ended as `end` (RgfxAnswerWait.hpp).
inline IOReturn rgfxWaitReturn(RgfxWaitEnd end)
{
	return end == kRgfxWaitAnswered  ? kIOReturnSuccess
	       : end == kRgfxWaitTimedOut ? kIOReturnTimeout
	       : end == kRgfxWaitAborted  ? kIOReturnAborted
	                                  : kIOReturnNotReady;
}

class RgfxAccelerator;
class RgfxPointerDevice;
class AppleVideoToolboxParavirtualizationDriver;

// The display front end each architecture's WindowServer drives: an IOFramebuffer on x86-64, and
// on arm64, where WindowServer opens no IOFramebuffer, an IOMobileFramebuffer, the subclass of
// IOMobileFramebufferLegacy that Apple's own paravirtual display is (docs/graphics-kext/design.md,
// Decided 13). The device, its rings and its pipe clients are one for both.
#if defined(__x86_64__)
class ReimsGraphics : public IOFramebuffer {
#else
class ReimsGraphics : public IOMobileFramebufferLegacy {
#endif
	OSDeclareDefaultStructors(ReimsGraphics);

public:
	// IOService
	bool start(IOService *provider) override;
	void stop(IOService *provider) override;
	void free() override;
#if defined(__arm64e__)
	// The class's start registers the service as it ends; display 0's start holds each display's
	// registration until the heads have started, so every display's service registers together
	// (RgfxRegisterHold.hpp, holdRegistration).
	void registerService(IOOptionBits options = 0) override;
	// IORegistryEntry: a process's read of a property waits while the released services match
	// (RgfxRegisterWindow, waitRegistrations); the kernel's reads never wait. A process's read
	// asks for its key by its C string first (ReimsGraphicsMobile.cpp, copyProperty).
	OSObject *copyProperty(const char *aKey) const override;
#endif

#if defined(__x86_64__)
	// IOFramebuffer: the device and its modes
	IOReturn enableController() override;
	IODeviceMemory *getApertureRange(IOPixelAperture aperture) override;
	IODeviceMemory *getVRAMRange() override;
	const char *getPixelFormats() override;
	IOItemCount getDisplayModeCount() override;
	IOReturn getDisplayModes(IODisplayModeID *allDisplayModes) override;
	IOReturn getInformationForDisplayMode(IODisplayModeID displayMode,
	                                      IODisplayModeInformation *info) override;
	UInt64 getPixelFormatsForDisplayMode(IODisplayModeID displayMode, IOIndex depth) override;
	IOReturn getPixelInformation(IODisplayModeID displayMode, IOIndex depth,
	                             IOPixelAperture aperture, IOPixelInformation *pixelInfo) override;
	IOReturn getCurrentDisplayMode(IODisplayModeID *displayMode, IOIndex *depth) override;
	IOReturn setDisplayMode(IODisplayModeID displayMode, IOIndex depth) override;
	IOReturn getStartupDisplayMode(IODisplayModeID *displayMode, IOIndex *depth) override;
	IOReturn setStartupDisplayMode(IODisplayModeID displayMode, IOIndex depth) override;
	IOReturn getTimingInfoForDisplayMode(IODisplayModeID displayMode,
	                                     IOTimingInformation *info) override;
	// IODisplay: a mode's valid, safe and default flags, which IOFramebuffer gives in place of
	// those getInformationForDisplayMode answers (modeFlags).
	IOReturn connectFlags(IOIndex connectIndex, IODisplayModeID displayMode,
	                      IOOptionBits *flags) override;

	// IOFramebuffer: the timings the OS programs, under the framebuffer's
	// kIOFBTimingRangeKey. The driver takes a timing whose size and rate are a
	// mode the device lists, and lists the programmed ones in place of its own.
	IOReturn validateDetailedTiming(void *description, IOByteCount descripSize) override;
	IOReturn setDetailedTimings(OSArray *array) override;

	// IOFramebuffer: attributes and the display's connection
	IOReturn getAttribute(IOSelect attribute, uintptr_t *value) override;
	IOReturn setAttribute(IOSelect attribute, uintptr_t value) override;
	IOItemCount getConnectionCount() override;
	IOReturn getAttributeForConnection(IOIndex connectIndex, IOSelect attribute,
	                                   uintptr_t *value) override;
	IOReturn setAttributeForConnection(IOIndex connectIndex, IOSelect attribute,
	                                   uintptr_t value) override;

	// IOFramebuffer: the display's EDID, made by the driver from the display's id, host screen's
	// scale and native mode (makeEdid), which IODisplay reads for the display's identity and size.
	bool hasDDCConnect(IOIndex connectIndex) override;
	IOReturn getDDCBlock(IOIndex connectIndex, UInt32 blockNumber, IOSelect blockType,
	                     IOOptionBits options, UInt8 *data, IOByteCount *length) override;

	// IOFramebuffer: the hardware cursor
	IOReturn setCursorImage(void *cursorImage) override;
	IOReturn setCursorState(SInt32 x, SInt32 y, bool visible) override;

	// IOFramebuffer: vblank and connect interrupts
	IOReturn registerForInterruptType(IOSelect interruptType, IOFBInterruptProc proc,
	                                  OSObject *target, void *ref,
	                                  void **interruptRef) override;
	IOReturn unregisterInterrupt(void *interruptRef) override;
	IOReturn setInterruptState(void *interruptRef, UInt32 state) override;

	// IOService: the user clients IOFramebuffer makes. The task a server connection
	// (kIOFBServerConnectType) is made for owns the scanout from then on (ownsScanout).
	IOReturn newUserClient(task_t owningTask, void *securityID, UInt32 type,
	                       IOUserClient **clientH) override;
	// IOFramebuffer's setup for the current mode, which gets no VRAM range (getVRAMRange).
	IOReturn setupForCurrentConfig() override;

#if RGFX_FB_TRACE
	// A trace build (make TRACE=1) logs what IOFramebuffer and its clients call on the
	// driver, forwarding each of these to IOFramebuffer.
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Woverloaded-virtual"
	IOReturn open() override;
	void close() override;
	IOReturn setGammaTable(UInt32 channelCount, UInt32 dataCount, UInt32 dataWidth,
	                       void *data) override;
#pragma clang diagnostic pop
	IOReturn setPowerState(unsigned long powerStateOrdinal, IOService *whatDevice) override;
	IOReturn powerStateWillChangeTo(IOPMPowerFlags flags, unsigned long state,
	                                IOService *whatDevice) override;
	IOReturn powerStateDidChangeTo(IOPMPowerFlags flags, unsigned long state,
	                               IOService *whatDevice) override;
	IOReturn requestProbe(IOOptionBits options) override;
	IOReturn message(UInt32 type, IOService *provider, void *argument = 0) override;
	bool isConsoleDevice() override;
	IOReturn setCLUTWithEntries(IOColorEntry *colors, UInt32 index, UInt32 numEntries,
	                            IOOptionBits options) override;
	// And the properties processes read of it.
	using IOFramebuffer::copyProperty;
	OSObject *copyProperty(const OSSymbol *aKey) const override;
	OSObject *copyProperty(const OSString *aKey) const override;
	OSObject *copyProperty(const char *aKey) const override;
#endif
#else
	// IOMobileFramebufferLegacy (ReimsGraphicsMobile.cpp): the class's own pure methods.
	RgfxIOMFBWord set_notify_tag_mask_gated(IOMFB_NotificationType type, IOMFBNotifyRequest *request,
	                                        uint32_t mask) override;
	RgfxIOMFBWord supported_frame_info(uint32_t index, uint32_t *count, char (*names)[64],
	                                   uint32_t *dataQueue) override;
	RgfxIOMFBWord factory_portal(void *field_0, task *owner) override;
	RgfxIOMFBWord executeFactoryConfigurations_gated() override;
	RgfxIOMFBWord set_frame_info_notification_state_gated(IOMFBNotifyRequest *request,
	                                                      bool on) override;
	RgfxIOMFBWord do_swap_info_notify_gated(IOMFBNotifyRequest *request,
	                                        const IOMobileFramebufferLegacy::SwapInfoBlob *blob) override;
	RgfxIOMFBWord notify_swap_done_gated(uint32_t field_0, ::SwapInfoBlob *blob, uint32_t *field_2,
	                                     uint32_t field_3) override;
	RgfxIOMFBWord notify_crc_ready_gated(uint32_t field_0) override;
	bool are_timings_enabled() const override;
	// And what a subclass implements for its display, none of it forwarded to the class, whose own
	// is for no display (ReimsGraphicsMobile.cpp): the hardware's start and stop, and a swap's
	// steps; a layer's surface map also presents it.
	RgfxIOMFBWord start_hardware() override;
	RgfxIOMFBWord stop_hardware_gated() override;
	RgfxIOMFBWord swap_begin_gated() override;
	RgfxIOMFBWord verify_swap(IOMFBSwapIORequest *request) override;
	RgfxIOMFBWord swap_layer_map(IOMFBSwapIORequest *request, uint32_t layer) override;
	RgfxIOMFBWord surface_layer_map(IOMFB::AP::DisplayedData *data, uint32_t layer,
	                                IOSurface *surface) override;
	RgfxIOMFBWord surface_layer_unmap(IOMFB::AP::DisplayedData *data, uint32_t layer) override;
	// And what the class reads of its provider as an AppleARMIODevice, which a PCI device is not
	// (ReimsGraphicsMobile.cpp): the dot pitch.
	RgfxIOMFBWord get_dot_pitch(uint32_t *pitch) override;
	// And the mode WindowServer sets of those the display publishes, by its colour and timing IDs
	// (ReimsGraphicsMobile.cpp), which the class answers kIOReturnUnsupported.
	RgfxIOMFBWord set_digital_out_mode(uint32_t colorId, uint32_t timingId) override;
	// And the colour matrix WindowServer sets with a swap (ReimsGraphicsMobile.cpp,
	// RgfxMobileColor.hpp), which the class answers kIOReturnUnsupported.
	RgfxIOMFBWord swap_set_color_matrix(IOMFBColorFixedMatrix *matrix,
	                                    IOMFBColorMatrixFunction function, uint32_t field_2) override;
	// And the colour filter scale WindowServer sets after that matrix (ReimsGraphicsMobile.cpp,
	// RgfxMobileColor.hpp), which the class answers kIOReturnUnsupported: its other parameters
	// go to the class.
	RgfxIOMFBWord set_parameter(IOMFBParameterName name, const uint64_t *values,
	                            uint32_t count) override;
	// And the ICC blocks WindowServer sets (ReimsGraphicsMobile.cpp, RgfxMobileICC.hpp), which the
	// class answers kIOReturnUnsupported: the display takes those that leave its chain the
	// identity.
	RgfxIOMFBWord set_block(task *owner, uint32_t type, uint32_t offset, const uint64_t *scalars,
	                        uint32_t count, const uint8_t *data, size_t size) override;
#endif

	// The display pipe (RgfxDisplayPipeUserClient, on the accelerator) presents through the
	// framebuffer, which owns the control ring. postPresent puts PRESENT_SURFACE for the
	// IOSurface of global ID `surfaceId` on the ring without waiting (thread context only),
	// answering kIOReturnNoSpace where the ring has no room: the caller waits for room with no
	// lock of the work loop's held (roomMark, waitForRoom), as the work loop hands the present's
	// answer over under the caller's lock. The host answers it once the display shows the
	// surface. addPipe adds an associated pipe client
	// (retained; RgfxPipeClients.hpp: IOPresentment associates several), and the hooks, both
	// called on the work loop for each client: `present(client, seqno, status, time)` for every
	// COMPLETE (each pipe client picks its own seqnos), `time` that of the refresh whose answer
	// it is, and, while the client's setPipeVblankEnabled is on, `vblank(client, count, time,
	// next)` for each VBLANK, `time` the refresh's and `next` the next one's. Times are the
	// guest's mach_absolute_time, the host's stamps mapped into it (RgfxVblankClock.hpp).
	// removePipe lets one go; the last one's going shows the scanout again where the pipe
	// showed a surface (thread context only).
	// The scanout as it is now (setScanout): its shape, bytes per row and offset in the region.
	// False before a mode is set.
	bool currentScanout(UInt32 *width, UInt32 *height, UInt32 *bytesPerRow, UInt64 *offset);
	// Whether `task` owns the scanout: it holds the framebuffer's server connection, or its open
	// of one is in flight (RgfxScanoutOwner.hpp). Only the owner reaches the display's pixels.
	bool ownsScanout(task_t task);
	// The scanout's owner moved to `owner`: the accelerator takes every other task's hold of the
	// scanout back (RgfxAccelerator::scanoutOwnerMoved). With no lock held.
	void scanoutOwnerMoved(task_t owner);
	// The accelerator on our PCI device, retained for the caller, or nullptr before it started.
	RgfxAccelerator *copyAccelerator();
	// Whether the framebuffer has started: its start has taken the device and brought its rings
	// up, and is in the class's start or has returned true, and its stop has not begun. The rings
	// then carry the accelerator's messages. Before, after a start that failed (which resets the
	// device) and from the stop on (which resets it at its end), the device holds nothing of any
	// process's context (design.md, "Reset").
	bool hasStarted() const { return __atomic_load_n(&started, __ATOMIC_ACQUIRE); }
	// Whether this framebuffer is a head: it drives a display past display 0, and display 0's
	// framebuffer owns the device for it.
	bool isHead() const { return device && device != this; }
	// The displays the device's framebuffers drive (rgfxDisplaysDriven): 1 where the framebuffer
	// did not take MULTI_DISPLAY; 0 before display 0's start has read the device's displays.
	UInt32 drivenDisplays() const { return (isHead() ? device : this)->displayCount; }
	// Whether the device answers asks: started, and not stopped since (quiesce). A wait for the
	// host's answer ends where it does not.
	bool answers() const
	{
		return __atomic_load_n(&(isHead() ? device : this)->ready, __ATOMIC_ACQUIRE);
	}
	// The framebuffer that drives display `display` (0 is display 0's, the device's), retained for
	// the caller, or nullptr where none does.
	ReimsGraphics *copyDisplay(UInt32 display);
	// Names the accelerator by its service-plane `path` (IOAccelTypes) on display 0's framebuffer
	// and every head, where the name each holds is stale (rgfxAccelTypesStale).
	void nameAccelerator(const char *path);

	typedef void (*PipeVblankHook)(OSObject *client, UInt64 count, UInt64 time, UInt64 next);
	typedef void (*PipePresentHook)(OSObject *client, UInt64 seqno, UInt32 status, UInt64 time);
	// `flags` RGFX_PRESENT_KEEP, with `surfaceId` 0, keeps what the display shows: the present
	// shows only the colour posted before it.
	IOReturn postPresent(UInt32 surfaceId, UInt32 transactionId, UInt32 flags, UInt64 *seqno);
	// The display pipe's colour (RgfxPipeColor.hpp): displayColor is whether the host took
	// RGFX_FEATURE_DISPLAY_COLOR; postDisplayColor puts stage `stage`'s `count` entries (16
	// bytes each at `entries`) for transaction `transactionId` on the control ring as
	// DISPLAY_COLOR parts, in order, each waiting for room as post does: thread context only,
	// with no lock of the work loop's held. The host stages them for the next PRESENT_SURFACE.
	bool displayColor() const { return displayColorTaken; }
	// Whether IOAcceleratorFamily2 exports IOAccelMemoryMap::getAssignedGPUVirtualAddressLength()
	// const, which ReimsGraphics references weakly and never calls; read once at start. It picks
	// a display pipe client's completion word count (RgfxPipeNotifications.hpp).
	bool assignedLengthExported() const { return assignedLength; }
	IOReturn postDisplayColor(UInt32 transactionId, UInt32 stage, UInt32 count,
	                          const UInt8 *entries);
	// A pipe client's transaction posts its colour, then its present, holding the presents lock
	// across both, so no other client's post comes between them: the host applies the colour
	// parts to the next present it takes, and drops a stage whose parts a present cuts short.
	// Thread context only; the work loop never takes it.
	void lockPresents() { IOLockLock(presentsLock); }
	void unlockPresents() { IOLockUnlock(presentsLock); }
	// The cursor slot's lock, display 0's (`cursorLock`): held from a framebuffer's write of its
	// cursor image into the one slot to its SET_CURSOR's answer. Thread context only.
	void lockCursorSlot() { IOLockLock((isHead() ? device : this)->cursorLock); }
	void unlockCursorSlot() { IOLockUnlock((isHead() ? device : this)->cursorLock); }
	// Room on the control ring for a post that found it full (RgfxRingRoom.hpp): roomMark, read
	// before the post's look, is the work loop's passes so far; waitForRoom sleeps until a pass
	// after `mark` (each device interrupt makes one: the host has moved on), its backstop or
	// `deadline` (mach_absolute_time), and answers false once `deadline` has passed or the
	// device is not ready. Thread context only, never on the work loop.
	UInt64 roomMark() const;
	bool waitForRoom(UInt64 mark, uint64_t deadline);
	// Where the host took SUBMIT_ROOM: tells it that a post waits for room on the control ring
	// (producer_waiting 1, then a full fence), so its next take posts RGFX_EVT_SUBMIT_ROOM, whose
	// pass wakes the post. The caller then looks once more before waitForRoom: either that look
	// finds what the host took, or the host's take finds the flag. False, nothing done, where the
	// host did not take it.
	bool askForRoom();
	bool addPipe(OSObject *client, PipeVblankHook vblank, PipePresentHook present);
	void removePipe(OSObject *client);
	void setPipeVblankEnabled(OSObject *client, bool enabled);

	// The device's one MSI-X vector also carries the command queues' completion interrupts
	// (each QUEUE_CREATE names it). setQueueInterrupt names the accelerator (retained) and its
	// hooks: `hook`, which the work loop calls after each pass over the control ring, and
	// `filter`, which the vector's filter calls as each interrupt arrives, at primary interrupt
	// context with interrupts disabled and queueFilterLock held, so it takes only spin locks
	// taken with interrupts disabled elsewhere, and neither blocks nor allocates. So the
	// accelerator looks at its queues' completion rings twice per interrupt (RgfxQueueWakes.hpp).
	// nullptr clears both; once it returns, no filter call holds the old target.
	typedef void (*QueueInterruptHook)(OSObject *target);
	void setQueueInterrupt(OSObject *target, QueueInterruptHook hook, QueueInterruptHook filter);

	// The accelerator's block releases, which no thread waits for. postReleases puts `count`
	// BLOCK_RELEASEs on the control ring in order, as many at a time as fit, under one hold of
	// its lock and with one doorbell at most, waiting for room as post does; it writes each one's
	// seqno into *waiterSeqnos[i] before the message is published, and counts those posted in
	// *posted, which is `count` on success. setReleaseAnswer names the accelerator (retained) and
	// its hook, which the work loop calls with each COMPLETE no lifecycle waiter takes, before the
	// display's; the hook answers whether the seqno was a release of its own. nullptr clears it.
	typedef bool (*ReleaseAnswerHook)(OSObject *target, UInt64 seqno, UInt32 status);
	void setReleaseAnswer(OSObject *target, ReleaseAnswerHook hook);
	IOReturn postReleases(const RgfxBlockRelease *releases, UInt32 count,
	                      UInt64 *const *waiterSeqnos, UInt32 *posted);
	// `count` messages of `type`, each `size` bytes at `messages` back to back, or, with `type`
	// 0 (the pad's, never a command's), each of the type and size its own header names, which no
	// thread waits for: on the control ring in order as postReleases puts its releases (each
	// one's seqno into *waiterSeqnos[i] where `waiterSeqnos` is not null), *posted those posted.
	// A process's batch (kRgfxAccelMethodSubmitBatch) and the block releases go so.
	IOReturn postRun(UInt32 type, const void *messages, UInt32 size, UInt32 count,
	                 UInt64 *const *waiterSeqnos, UInt32 *posted);
	// A lifecycle message (a CONTEXT_CLOSE) no thread waits for here, its COMPLETE handed to the
	// setReleaseAnswer hook: as postLifecycle with `replyType` 0, but it writes the seqno into
	// *waiterSeqno before the message is published, so the answer, however soon it comes, finds
	// the caller's entry. Thread context only.
	IOReturn postAnswered(UInt32 type, const void *message, UInt32 size, UInt64 *waiterSeqno);

	// The accelerator's object lifecycle (a create or destroy, QUEUE_CREATE, CONTEXT_CLOSE) on
	// the control ring: `message` is the whole message in kernel memory, at most
	// kLifecycleMessageMax bytes, whose header is stamped here with `type`, its size and the
	// seqno (*seqno, when not null). With `replyType` 0 it returns once the message is on the
	// ring; else it takes a waiter of the type's kind (rgfxWaiterKind) and waits for the device's
	// answer of that type to this seqno, in `timeoutMs`'s mode (RgfxAnswerWait.hpp), and copies
	// it, header and all, into `reply` (*replyLength its bytes, at most `replyCapacity`). Both
	// waits, for a free waiter and for the answer, end unanswered at the device's stop
	// (kIOReturnNotReady), at a deadline where the mode has one, and in kLifecycleUntilAnswered
	// at the thread's abort. A wait for a waiter that ends so returns kIOReturnBusy, the message
	// not posted; one for the answer kIOReturnTimeout or kIOReturnAborted, the message posted and
	// the host's, answered or not. Thread context only, never on the work loop.
	static constexpr UInt32 kLifecycleMessageMax = RGFX_CONTROL_RING_DATA_SIZE / 2;
	static constexpr UInt32 kLifecycleReplyMax = 128;
	// The `timeoutMs` modes with no deadline (RgfxAnswerWait.hpp): THREAD_UNINT, for an ask
	// whose context's close waits for it (a pool block's, RgfxPoolBlocks.hpp), and
	// THREAD_INTERRUPTIBLE, for the processes' asks that wait behind the host's compiles.
	static constexpr UInt32 kLifecycleNoDeadline = kRgfxWaitNoDeadline;
	static constexpr UInt32 kLifecycleUntilAnswered = kRgfxWaitUntilAnswered;
	// Where `seedOrder` is not null, the waiter is a seed's (LifecycleWaiter), its first
	// PIPELINE_REFLECTION the *seedOrder th newest.
	IOReturn postLifecycle(UInt32 type, const void *message, UInt32 size, UInt32 replyType,
	                       void *reply, UInt32 replyCapacity, UInt32 *replyLength, UInt64 *seqno,
	                       UInt32 timeoutMs, const UInt32 *seedOrder = nullptr);

	// A pipeline create of context `context` posted without waiting for its answer, which the
	// device's answer then waits for in a slot of the deferred answers (RgfxDeferredAnswers.hpp)
	// until takeDeferred takes it: as postLifecycle with `replyType` 0, but for its slot.
	// kIOReturnNoResources, posting nothing, where no slot is free: the caller posts the create
	// as postLifecycle does, and waits. `key`, where not null, is the pipeline key whose kept
	// answer answered the create (findSharedPipeline): where the device does not make its
	// pipeline, that answer is forgotten. Thread context only.
	IOReturn postDeferred(UInt32 context, UInt32 type, const void *message, UInt32 size,
	                      UInt64 *seqno, const UInt8 *key = nullptr);
	// Copies context `context`'s answers to its deferred creates into the `capacity` bytes at
	// `out`, each whole, in their seqnos' order, while they fit, and frees their slots: the bytes
	// in `*length`, the answers in `*count`. Where `waitFor` is the seqno of one of its creates
	// still waiting, waits for its answer first, in `timeoutMs`'s mode (postLifecycle): the
	// answers taken all the same where that wait ends unanswered, its end returned
	// (kIOReturnNotReady, kIOReturnTimeout or kIOReturnAborted). Thread context only.
	IOReturn takeDeferred(UInt32 context, UInt64 waitFor, UInt32 timeoutMs, UInt8 *out,
	                      UInt32 capacity, UInt32 *length, UInt32 *count);
	// Frees context `context`'s deferred slots, at its close, and lets its waiters go.
	void dropDeferred(UInt32 context);
	// The answer the kext keeps for the pipeline create of `key` (32 bytes), stamped with
	// `seqno` and `objId` (RgfxSharedPipelines.hpp), into `*out`: false where none is kept.
	bool findSharedPipeline(const UInt8 *key, UInt64 seqno, UInt64 objId,
	                        RgfxPipelineReflection *out);
	// Keeps the device's answer to a pipeline create, the `length` bytes of `reply`, where it
	// carries a made pipeline's key, for every process's equal creates.
	void learnSharedPipeline(const UInt8 *reply, UInt32 length);
	// Seeds the shared pipelines, where the host took PIPELINE_ANSWERS, with the answers the
	// device kept of keyed creates of its earlier runs (RGFX_CMD_PIPELINE_ANSWERS), newest first,
	// until the device has no more or the table's size is asked. Thread context only, at start.
	void seedSharedPipelines();
	// Frees the deferred slot of the create at `seqno`, posted after its context closed.
	void forgetDeferred(UInt64 seqno);

private:
#if RGFX_FB_TRACE
	IOReturn connectionAttribute(IOIndex connectIndex, IOSelect attribute, uintptr_t *value);
	IOReturn setConnectionAttribute(IOIndex connectIndex, IOSelect attribute, uintptr_t value);
#endif

	// The display's modes. IDs stay with a mode (its size and rate) for the
	// driver's life, as IOFramebuffer asks, and are never reused.
	// (RgfxDisplayModes.hpp: the list IOFramebuffer sees, the mode set and the startup mode.)
	using Mode = RgfxMode;
	static constexpr UInt32 kMaxModes = 64;
	using Modes = RgfxDisplayModes<IODetailedTimingInformationV2, kMaxModes>;
	// The most display pipe clients served at once (RgfxPipeClients.hpp).
	static constexpr UInt32 kMaxPipeClients = 8;

	// A mode's timing: the active size with reduced blanking (VESA CVT's second reduced
	// blanking: a fixed 80-pixel horizontal blank and at least 460 us of vertical blank),
	// its pixel clock in 10 kHz steps, as an EDID carries it. getTimingInfoForDisplayMode
	// gives it, and so do the arm64e front end's timing elements (publishMobileModes).
	struct Timing {
		UInt64 pixelClock;
		UInt32 hActive, hBlank, hFront, hSync;
		UInt32 vActive, vBlank, vFront, vSync;
	};
	static void timingFor(const Mode &mode, Timing *timing);

	// The display's EDID: one base block, with no timings (rgfxDisplayEdid). makeEdid fills
	// block `index` (0, the base) and returns false past it. Call with stateLock held.
	static constexpr UInt32 kEdidBlockBytes = kRgfxDisplayEdidBytes;
	bool makeEdid(UInt32 index, UInt8 *block) const;

	static UInt32 refreshMhzOf(const IODetailedTimingInformationV2 &timing);
	// The device's preferred mode, the display's native one; `mode` where the device lists
	// none. Call with stateLock held.
	Mode nativeMode(const Mode &mode) const;
	// The physical size of a mode's display, in millimetres: its native mode's at the display's
	// density (RgfxDisplayIdentity.hpp).
	void imageSize(const Mode &mode, UInt16 *width, UInt16 *height) const;
	// The IODisplayModeInformation flags of a mode, the preferred one or not.
	static UInt32 modeFlags(const Mode &mode, bool preferred, UInt32 scale120ths);

	// One of IOFramebuffer's interrupt registrations.
	struct Interrupt {
		IOFBInterruptProc proc;
		OSObject *target;
		void *ref;
		bool enabled;
	};

	// A thread waiting in command() for a display-control message's answer (a COMPLETE or a
	// DISPLAYS), keyed by seqno as the lifecycle waiters are. A burst of PRESENT_SURFACE
	// completions, which also answer on the control ring, then matches no waiter and is dropped,
	// rather than evicting a control answer from a fixed ring before its thread reads it. Free
	// while `waiting` is false; `seqno` is 0 until the message is on the ring, then the answer's
	// thread fills `status`, sets `done`, and wakes this waiter alone.
	struct ControlWaiter {
		UInt64 seqno;
		UInt32 status;
		bool waiting;
		bool done;
	};
	static constexpr UInt32 kControlWaiters = 8;

	// A thread waiting for a lifecycle message's answer: free while replyType is 0; its seqno
	// is 0 until the message is on the ring. Split by kind, each kind taking only its own
	// (rgfxFreeWaiter, RgfxAnswerWait.hpp): 32 for the processes' creates and queries, which wait
	// with no deadline behind the host's compiles, 16 for the surfaces' pages and copies, and 16
	// for the device's own asks (a queue's create, a close, a pool's take), so the creates never
	// take the waiters WindowServer's asks need. A seed's (`seed`, seedSharedPipelines) takes the
	// PIPELINE_REFLECTIONs of its seqno before its answer into the shared pipelines, the next one
	// the `order`th newest the device hands.
	struct LifecycleWaiter {
		UInt64 seqno;
		UInt32 replyType;
		UInt32 length;
		bool done;
		bool seed;
		UInt32 order;
		UInt8 reply[kLifecycleReplyMax];
	};
	static constexpr UInt32 kLifecycleWaiters = kRgfxLifecycleWaiters;

	// The deferred creates' answers (postDeferred): 256 slots, at most 64 a context.
	static constexpr UInt32 kDeferredAnswers = 256;
	static constexpr UInt32 kDeferredPerContext = 64;
	typedef RgfxDeferredAnswers<kDeferredAnswers, kDeferredPerContext, kLifecycleReplyMax>
	    DeferredAnswers;
	// The answers kept by pipeline key (findSharedPipeline): 256 sets of 8, 2,048 answers.
	typedef RgfxSharedPipelines<256, 8> SharedPipelines;

	// Registers and the control rings.
	UInt32 readRegister(UInt32 offset) const;
	void writeRegister(UInt32 offset, UInt32 value);
	volatile UInt8 *ring(UInt32 offset) const;
	// A message is a full struct (RgfxSetScanout and the like) whose header
	// tryPost stamps with the type, size and seqno; the caller fills the rest.
	// `waiterSeqno`, when not null, gets the seqno before the message is
	// published, so its answer finds its waiter.
	bool tryPost(UInt32 type, const void *message, UInt32 size, UInt64 *seqno,
	             UInt64 *waiterSeqno = nullptr);
	IOReturn post(UInt32 type, const void *message, UInt32 size, UInt64 *seqno,
	              UInt64 *waiterSeqno = nullptr);
	// tryPost's halves, submitLock held: writeLocked writes one message where it fits, and
	// publishLocked publishes what was written, answering whether ring 0's doorbell is to be
	// rung, which ringControl does once the lock is let go.
	bool writeLocked(UInt32 type, const void *message, UInt32 size, UInt64 *seqno,
	                 UInt64 *waiterSeqno);
	bool publishLocked();
	void ringControl();
	IOReturn command(UInt32 type, const void *message, UInt32 size);
	void kickWorkLoop();

	// The work loop: the completion ring and what follows from it.
	static void serviceAction(OSObject *owner, IOInterruptEventSource *sender, int count);
	// The vector's filter, at primary interrupt context: the accelerator's look at its queues'
	// completion rings (queueFilter), and then the work loop's pass, as for every interrupt.
	static bool filterAction(OSObject *owner, IOFilterInterruptEventSource *sender);
	void service();
	// What service() sends for one display's framebuffer `fb`: the connect interrupt a change
	// waited with, its SET_VBLANK and its SET_DISPLAY_POWER.
	void serviceDisplay(ReimsGraphics *fb);
	// Display 0's framebuffer and the heads, each retained, into `out` (RGFX_DISPLAYS_MAX of room),
	// by display: their count. releaseDisplays lets them go.
	UInt32 copyDisplays(ReimsGraphics **out);
	static void releaseDisplays(ReimsGraphics **fbs, UInt32 n);
	// The driven display an event's display id names: the id itself where several are driven, and
	// display 0 where one is, whatever id the device gives it.
	UInt32 drivenIndex(UInt32 id) const { return displayCount > 1 ? id : 0; }
	void takeCompletions();
	static IOReturn takeAction(OSObject *owner, void *, void *, void *, void *);
	void lookForAnswer(const LifecycleWaiter *w);
	// Takes the completion ring's records up to the producer `end`, and stores the consumer where
	// it moved.
	void drainEvents(UInt64 end);
	void handleEvent(UInt32 type, UInt64 seqno, const volatile UInt8 *payload, UInt32 size);
	UInt32 parseDisplays(const volatile UInt8 *payload, UInt32 size);
	// This framebuffer's display from the `n` displays a DISPLAYS answer listed (payload
	// `payload`), with stateLock held: its modes, connection and scale.
	void takeListing(const RgfxListedDisplay *listed, UInt32 n, const volatile UInt8 *payload);
	void answer(UInt64 seqno, UInt32 status);
	bool answerLifecycle(UInt32 type, UInt64 seqno, const volatile UInt8 *payload, UInt32 size);

	// Ending: no more work loop actions, then the device and mappings go.
	void quiesce();
	void teardown();

	// The boot framebuffer the OS had at the start, published (RgfxBootConsole.hpp).
	void publishBootConsole();

	// The heads (display 0's): made, attached to the PCI device and started once display 0's
	// framebuffer has started (startHeads, display by display with startHeadAt, which answers
	// whether the display's head started), and terminated as it stops (stopHeads). A head's own
	// start and stop (startHead, stopHead); dropHead takes `head` out of display 0's table.
	void startHeads();
	bool startHeadAt(UInt32 display);
	void stopHeads();
	bool startHead(IOService *provider);
	void stopHead(IOService *provider);
	void dropHead(ReimsGraphics *head);
	// The framebuffer's properties, display 0's and each head's: the accelerator it names, and on
	// x86-64 its dependent ID and index, the timings the OS may program and its class name.
	void publishFramebuffer();

	// Modes and scanout.
	static UInt32 strideFor(UInt32 width);
	// This framebuffer's display's scanout room (rgfxDisplayRoom), and its length.
	RgfxRoom scanoutRoom() const;
	UInt64 scanoutLimit() const;
	IOReturn setScanout(const Mode &mode);
	// The boot screen in the scanout, black, once the display first shows a surface (handleEvent).
	void clearBootScreen();
	// The scanout's room, zeroed for a task that is not its last owner (newUserClient): false
	// where the kernel would not map it.
	bool zeroScanoutRoom();

	IOPCIDevice *pci;
	IOMemoryMap *registerMap;
	volatile UInt8 *registers;
	IODeviceMemory *region;
	UInt64 regionSize;
	IOMemoryMap *ringMap;
	volatile UInt8 *rings;
	// Ring 0's submit data from kRgfxControlWcFrom, write-combined (RgfxControlRing.hpp): null
	// where it is not mapped so.
	IOMemoryMap *controlDataMap;
	volatile UInt8 *controlData;
	// The cursor image's slot, at the region's end: kCursorMax x kCursorMax BGRA8, the largest
	// image the hardware cursor takes (RGFX_CURSOR_MAX_SIZE). A larger one is IOFramebuffer's to
	// draw on x86-64; on arm64 the display shows its top left corner.
	static constexpr UInt32 kCursorMax = RGFX_CURSOR_MAX_SIZE;
	static constexpr UInt64 kCursorSlot = static_cast<UInt64>(kCursorMax) * kCursorMax * 4;
	IOMemoryMap *cursorMap;
	UInt8 *cursorPixels;
	IOWorkLoop *workLoop;
	IOInterruptEventSource *msix;
	IOInterruptEventSource *kick;
	// The work loop's gate as a waiter takes it, never waiting for it (lookForAnswer); none where
	// it was not made, and waiters then only sleep.
	IOCommandGate *lookGate;

	// The submission ring, under submitLock: the bytes produced and the
	// next seqno.
	IOSimpleLock *submitLock;
	UInt64 produced;
	UInt64 nextSeqno;

	// The cursor image's hotspot, which MOVE_CURSOR adds: set once
	// SET_CURSOR is answered.
	UInt32 hotX;
	UInt32 hotY;

	// The completion ring's bytes consumed, and the count at which its last arm found it empty
	// (RgfxCompletionArm.hpp): the work loop's alone.
	UInt64 consumed;
	UInt64 armedAt;

	// The control ring's room (roomMark, waitForRoom): the work loop's passes, which it moves
	// at each, and the posts waiting for room, which a pass wakes under stateLock. Atomic.
	RgfxRingRoom room;
	// The host took SUBMIT_ROOM (askForRoom), set before `ready`.
	bool submitRoom;
	// The host took DISPLAY_COLOR (displayColor), set before `ready`.
	bool displayColorTaken;
#if defined(__arm64e__)
	// The host took CURSOR_COLOR: it converts the cursor's image through the cursor layer's ICC
	// chain, which set_block then takes (RgfxMobileICC.hpp); set before `ready`.
	bool cursorColorTaken;
#endif
	// The host took DISPLAY_SCALE: its DISPLAYS answers carry each display's scale
	// (parseDisplays), set before `ready`.
	bool displayScaleTaken;
	// The host took HOST_TIME: each VBLANK reads the host's clock for the refreshes' times
	// (vblankClock), set before `ready`.
	bool hostTime;
	// The host took GUEST_TIMES: each VBLANK's reading of the host's clock goes in ring 0's header
	// as the clocks' offset, for the host to map the bundle's stamps (vblankClock.offsetAt), set
	// before `ready`.
	bool guestTimes;
	// The host took DISPLAY_POWER: the work loop tells it the display's panel (panelWanted), set
	// before `ready`.
	bool displayPowerTaken;
	// The host took PIPELINE_KEYS and PIPELINE_ANSWERS: the start seeds the shared pipelines
	// (seedSharedPipelines), set before `ready`.
	bool pipelineAnswersTaken;
	// The sleeps for room (waitForRoom), under stateLock, and the SUBMIT_ROOM records the work
	// loop took (atomic), for the log line waitForRoom writes at most every kRoomLogMs.
	RgfxRingRoomStats roomStats;
	UInt64 roomRecords;

	// assignedLengthExported, set at start.
	bool assignedLength;

	// The display pipe's presents (lockPresents), taken before stateLock where both are.
	IOLock *presentsLock;
	// Under stateLock: answers, the lifecycle's waiters, the display and its modes, the mode
	// set, and the scanout's owner (its task referenced, its connection retained).
	IOLock *stateLock;
	RgfxScanoutOwner scanoutOwner;
	ControlWaiter controlWaiters[kControlWaiters];
	LifecycleWaiter lifecycleWaiters[kLifecycleWaiters];
	// The deferred creates' answers; its waiters (takeDeferred) sleep on it, and each answer or
	// drop wakes them all.
	DeferredAnswers deferredAnswers;
	// The answers kept by pipeline key, allocated at start (null where it could not be: none is
	// kept, and every create waits), under stateLock.
	SharedPipelines *sharedPipelines;
	bool haveDisplay;
	UInt32 displayId;
	bool connected;
	// The scale of the host screen that shows the display, in 120ths (RgfxDisplayScale): 0 where
	// the host gives none.
	UInt32 displayScale;
	Modes modeSet;
	RgfxModeConfig modeConfig;
	UInt32 reportedCount;

	// kIOWindowServerActiveAttribute's value as WindowServer last set it: 0
	// (kIOWSAA_Unaccelerated) before any set. IOFramebuffer gets and sets it under its gate.
	UInt32 windowServerActive;

	// Under interruptLock: IOFramebuffer's registrations, whether it wants
	// VBLANK events, and a display change waiting for its connect interrupt.
	IOSimpleLock *interruptLock;
	Interrupt vblank;
	Interrupt connect;
	RgfxConnectChange displayChange;
	bool vblankWanted;
	// The display pipe's clients (each retained), which want VBLANK, and the surface shown; the
	// hooks every client takes.
	RgfxPipeClients<OSObject *, kMaxPipeClients> pipes;
	PipeVblankHook pipeVblankHook;
	PipePresentHook pipePresentHook;
	// The accelerator (retained) and its queue-interrupt hook; and, the same, its release hook.
	OSObject *queueTarget;
	QueueInterruptHook queueHook;
	// Under queueFilterLock, which the vector's filter takes at primary interrupt context and
	// every other holder with interrupts disabled: the accelerator queueTarget holds, for the
	// filter, and its filter hook. Display 0's framebuffer's alone, which owns the vector.
	IOSimpleLock *queueFilterLock;
	OSObject *queueFilterTarget;
	QueueInterruptHook queueFilter;
	OSObject *releaseTarget;
	ReleaseAnswerHook releaseHook;

	// The display's panel (RgfxDisplayPower.hpp): on x86-64, the notification of the display
	// wrangler's publication and the general interest in it the framebuffer registers, under
	// stateLock; and the panel the framebuffer wants lit, under interruptLock.
	IONotifier *wranglerNotifier;
	IONotifier *wranglerInterest;
	bool panelWanted;
	// Sets the panel the framebuffer wants lit, and has the work loop tell the host where it
	// changed: whether it changed.
	bool wantPanel(bool lit);
	void startDisplayPower();
	void stopDisplayPower();
	static bool wranglerPublished(void *target, void *refCon, IOService *wrangler,
	                              IONotifier *notifier);
	static IOReturn wranglerMessage(void *target, void *refCon, UInt32 type, IOService *wrangler,
	                                void *argument, vm_size_t size);

	// The work loop's alone, each framebuffer's for its display: what SET_VBLANK last asked, what
	// SET_DISPLAY_POWER last told and the refreshes' times; and, display 0's, the displays whose
	// DISPLAY_CHANGED asked for a refresh, waiting to be sent or answered (RgfxDisplayRefresh).
	bool vblankSent;
	bool panelTold;
	RgfxVblankClock vblankClock;
	RgfxDisplayRefresh refreshes;

	// Several displays (the file's head; design.md, "Multiple displays"). `device` is the
	// framebuffer that owns the device: this one on display 0's, set at its start, and display 0's,
	// retained, on a head, set before the head is attached. Display 0's alone: the heads by display
	// (heads[0] unused; each retained, under interruptLock), the displays driven (displayCount: 1
	// without MULTI_DISPLAY, the device's count with it, fixed at the start's first DISPLAYS
	// answer), whether the host took MULTI_DISPLAY, and the cursor slot's lock, which a framebuffer
	// holds from its write into the slot to its SET_CURSOR's answer, as the host copies the image
	// before it answers (design.md, "One cursor slot"). A head shares display 0's stateLock,
	// interruptLock and presentsLock, and frees none of them.
	ReimsGraphics *device;
	ReimsGraphics *heads[RGFX_DISPLAYS_MAX];
	UInt32 displayCount;
	bool multiDisplayTaken;
	IOLock *cursorLock;

	// The guest's own mouse, which the host's POINTER_MOTION drives (RgfxPointerDevice.hpp),
	// display 0's alone: whether the host took POINTER_MOTION, set at the start's features; the
	// device, made once the framebuffer has started where it took it (startPointerDevice) and
	// stopped and let go in the stop once the work loop hands it nothing more
	// (stopPointerDevice); and handleEvent's POINTER_MOTION, which hands it the event's reports
	// on the work loop. The device is stored and read atomically: the work loop may take an
	// event while the start makes it.
	bool pointerMotionTaken;
	RgfxPointerDevice *pointerDevice;
	void startPointerDevice();
	void stopPointerDevice();
	void pointerMotion(const volatile UInt8 *payload, UInt32 size);
#if defined(__arm64e__)
	// The arm64e kext's VideoToolbox service (RgfxVtService.hpp), display 0's alone: whether the
	// host took VT_MESSAGES, set at the start's features; the service, published once the
	// framebuffer has started where it took it and the caps list a decoder (startVtService), and
	// stopped in the stop once the work loop hands it nothing more (stopVtService); and
	// handleEvent's VT_MESSAGE, which hands it the host's message on the work loop. The service
	// is stored and read atomically, as the mouse is.
	bool vtMessagesTaken;
	AppleVideoToolboxParavirtualizationDriver *vtService;
	void startVtService();
	void stopVtService();
	void vtMessage(const volatile UInt8 *payload, UInt32 size);
	// The VideoToolbox ring (RGFX_FEATURE_VT_RING, RgfxVtRing.hpp): the count the work loop has
	// taken it through, read from its header at the start as the control rings' counts are; and
	// handleEvent's VT_RING, which takes it through the event's count on the work loop, handing
	// each message to vtMessage as a VT_MESSAGE event's.
	UInt64 vtConsumed;
	void vtRing(const volatile UInt8 *payload, UInt32 size);
#endif

	// The boot screen the scanout holds until clearBootScreen: the boot framebuffer the OS had at
	// the start (publishBootConsole); the largest span a mode's scanout has had (setScanout, under
	// stateLock); the seqno of the latest present of a surface before the clear, which tryPost
	// writes before the host sees the present; and whether it was cleared (the work loop's).
	RgfxBootConsole bootConsole;
	UInt64 largestScanout;
	UInt64 bootScreenSeqno;
	bool bootScreenCleared;

	// The host's pointer over another display (POINTER_OVER, ReimsGraphicsPointer.cpp), display
	// 0's alone: the latest display, point and buttons the work loop took, under interruptLock,
	// and the thread call that moves the cursor there, off the work loop, as IOHIDSystem's
	// command gate may wait. Made in the start (startPointer), and waited for and let go once the
	// work loop can ask for it no more (freePointer).
	RgfxPointerAt pointerAt;
	thread_call_t pointerCall;
	bool startPointer();
	void freePointer();
	void pointerOver(const volatile UInt8 *payload, UInt32 size);
	static void movePointer(thread_call_param_t self, thread_call_param_t);
	// Each driven display's rectangle in WindowServer's global space that the host may be told,
	// by display id (`placed`): on x86-64 each framebuffer's bounding rectangle, where WindowServer
	// placed it; on arm64 each one a landing of the cursor confirmed (RgfxDisplayPlaces.hpp).
	// Display 0's.
	void displayPlaces(RgfxGlobalRect *rects, bool *placed);

	// Each display's rectangle in the global space, told the host (DISPLAY_BOUNDS,
	// RgfxDisplayBounds.hpp), display 0's alone: whether the host took DISPLAY_BOUNDS with
	// POINTER_OVER and MULTI_DISPLAY, set at the start's features, and the rectangles it was
	// told, under interruptLock, forgotten at each start. tellBounds, from any display's move of
	// the cursor, posts each driven display's that changed. Never blocks.
	bool displayBoundsTaken;
	RgfxBoundsTold boundsTold;
	void tellBounds();
	void tellPlaces(const RgfxGlobalRect *rects, const bool *placed);
#if defined(__arm64e__)
	// The arm64 crossing (ReimsGraphicsPointer.cpp, RgfxDisplayPlaces.hpp), display 0's alone,
	// under interruptLock: each display's place as the cursor's landings showed it, the crossing
	// under way, and the count of POINTER_OVERs the work loop took (pointerTold), when it took the
	// last (pointerToldAt, after the host's hold began), and of those the thread call began a
	// crossing for (pointerCrossed), which is dated from pointerToldAt. landingCall gives up a
	// post's landing after kRgfxLandingWaitNs. cursorLanded takes each display's MOVE_CURSOR that shows the
	// cursor, from the swap, in the class's gate. Crossings that ended with the cursor elsewhere
	// are counted (crossingsMissed), the first logged. cursorMoves counts the MOVE_CURSORs every
	// display posted (each display's last numbered in its mobileCursor.seq), so a post's deadline
	// tells the cursor shown after the post from the cursor shown before it (crossing.postSeq).
	RgfxDisplayPlaces places;
	RgfxCrossing crossing;
	UInt64 pointerTold;
	UInt64 pointerToldAt;
	UInt64 pointerCrossed;
	UInt64 cursorMoves;
	UInt32 crossingsMissed;
	thread_call_t landingCall;
	static void landingWaited(thread_call_param_t self, thread_call_param_t);
	void crossingMissed(UInt32 display, UInt32 posts);
	void cursorLanded(UInt32 display, int32_t x, int32_t y);
#endif

#if defined(__arm64e__)
	// The arm64e front end's (ReimsGraphicsMobile.cpp): set up in start before the class's own
	// start, which it is the pipe client of, and let go in stop. The present of the latest swap's
	// surface waits for its answer; the transactions it posts are numbered from 1.
	bool startMobile();
	void stopMobile();
	// The display as IOMobileFramebuffer.framework finds it: its node in the device tree
	// (attachMobileNode, detachMobileNode) and the properties it reads of the framebuffer
	// (publishMobileDisplay).
	void attachMobileNode();
	void detachMobileNode();
	void publishMobileDisplay();
	void publishMobileModes();
	// Shows the mode of a published colour and timing ID (set_digital_out_mode), and writes its
	// size where the class reads it; kIOReturnUnsupported for a pair it does not publish.
	IOReturn setMobileMode(uint32_t colorId, uint32_t timingId, Mode *mode);
	static void mobileVblank(OSObject *client, UInt64 count, UInt64 time, UInt64 next);
	static void mobilePresented(OSObject *client, UInt64 seqno, UInt32 status, UInt64 time);
	// The swaps (ReimsGraphicsMobile.cpp, swap_begin_gated): the next one begun, and the swap
	// whose surface the display is to show completed once the host answers its present, both in
	// the class's gate.
	void beginMobileSwaps();
	void completeMobileSwap();
	static void mobileSwapAnswered(OSObject *owner, IOInterruptEventSource *sender, int count);
	bool mobilePipe;
	// The display's node under /arm-io in the device tree (retained): the firmware's, or one start
	// attached (mobileNodeAttached), which stop detaches.
	IORegistryEntry *mobileNode;
	bool mobileNodeAttached;
	// Whether start_hardware joined power management, which stop_hardware_gated leaves.
	bool mobilePowerJoined;
	// The latest present's seqno, written before the host can answer it; the refresh its answer
	// came in (mach_absolute_time's, 0 until it comes) and the display's period then (its ticks),
	// which the swap's completion takes; and that swap's presentation time as its frame info
	// carries it (mach_continuous_time's, 0 where it showed nothing), which mobileFrameClock gives
	// (RgfxLegacySwapInfo.hpp), in the class's gate.
	UInt64 mobilePresentSeqno;
	UInt64 mobileShownAt;
	UInt64 mobileShownPeriod;
	UInt64 mobilePresentedAt;
	RgfxFrameInfoClock mobileFrameClock;
	UInt32 mobileTransaction;
	// The release's swap queue (RgfxLegacySwapLayout.hpp), null where the class's size is no
	// release's; the swap whose present waits for its answer, null where none does; and the event
	// source on the class's work loop (retained, with the work loop) that the answer signals.
	const RgfxLegacySwapLayout *mobileSwapLayout;
	void *mobileSwapShowing;
	IOInterruptEventSource *mobileSwapAnswer;
	IOWorkLoop *mobileSwapLoop;
	// What the swaps did over the minute now running, logged once it is over (RgfxSwapRate.hpp),
	// and a minute in mach_absolute_time's ticks.
	RgfxSwapRate mobileSwapRate;
	UInt64 mobileSwapRateWindow;
	void noteMobileSwapRate(UInt64 now);
	// The swap-info records notify_swap_done_gated keeps while the class holds them
	// (RgfxLegacySwapInfo.hpp), in the class's gate.
	RgfxSwapInfoKept mobileSwapInfoKept;
	// The cursor a swap's layer 1 gives (RgfxMobileCursor.hpp): shown, moved or hidden in the
	// class's gate, as the swap begins (beginMobileSwaps). True where layer 1's surface has no
	// image, which the swap then shows in place of layer 0's.
	bool showMobileCursor(OSObject *surface, int32_t x, int32_t y);
	IOReturn setMobileCursorImage(OSObject *surface, const RgfxMobileCursorImage &image);
	bool postMobileCursorMove(int32_t x, int32_t y, bool visible);
	void postMobileCursorColor();
	RgfxMobileCursor mobileCursor;
	// A change of the device's modes for the display (parseDisplays), taken to the processes as
	// the paravirtual display takes its host's (mobileDisplayChanged): set where the last list
	// taken changed them, read and cleared at a refresh's answer, the device's work loop's alone.
	bool mobileListChanged;
	// The thread call that republishes the display and tells the processes, off the device's work
	// loop, whose answers its mode set waits for: made in startMobile, waited for in stopMobile,
	// and let go once the work loop can ask for it no more (freeMobileChanges).
	thread_call_t mobileChangeCall;
	static void mobileDisplayChanged(thread_call_param_t self, thread_call_param_t);
	void freeMobileChanges();
	void republishMobileDisplay();
	// Whether the display last told the class's hot-plug clients it is plugged in (hotPlug_notify),
	// as the paravirtual display records it; and the timing the display shows (setMobileMode).
	bool mobileHotPlugged;
	uint32_t mobileTimingId;
	// The ICC pairs set_block holds (RgfxMobileICC.hpp), the framebuffer's own, under
	// mobileICCLock: both allocated in startMobile and let go in free; null where they could not
	// be, and then every block is refused.
	RgfxICCState *mobileICC;
	IOLock *mobileICCLock;
	// The registrations display 0's start holds while it starts the heads (RgfxRegisterHold.hpp),
	// display 0's alone, under stateLock: holdRegistration records display `display`'s where the
	// hold is open, and answers whether it did; releaseRegistrations ends the hold and registers
	// what it held, display 0's service first, then the heads' by display. With no lock held.
	RgfxRegisterHold registerHold;
	bool holdRegistration(UInt32 display, IOOptionBits options);
	void releaseRegistrations();
	// What the release hands its thread call (registerCall, display 0's, made in start): the
	// displays released and their options, and the window from the release until their services
	// have matched (RgfxRegisterWindow), under registerLock, which waitRegistrations and
	// registerReleased sleep on. registerReleased registers them one at a time, each once a
	// process has taken the one before, then closes the window. With no thread call, the release
	// registers them itself, with no window.
	IOLock *registerLock;
	thread_call_t registerCall;
	uint32_t releasedDisplays;
	uint32_t releasedOptions[RGFX_DISPLAYS_MAX];
	RgfxRegisterWindow registerWindow;
	static void registrationsReleased(thread_call_param_t self, thread_call_param_t);
	void registerReleased();
	void waitRegistrations(UInt32 display);
	void freeRegistrations();
	// The displays whose node the firmware placed under /arm-io, counted from display 0 to the
	// first without one (countMobileNodes, as display 0's start takes the device): MULTI_DISPLAY
	// is taken only where display 1 has one (RgfxFeatures.hpp), and only displays with one get a
	// framebuffer (rgfxFramebuffersOf). Display 0's alone.
	static UInt32 countMobileNodes();
	UInt32 mobileNodes;
#endif

	bool ready;
	// start's and stop's alone: whether start reset the device to take it. Only a device taken is
	// reset when the kext lets it go; one refused before stays as the firmware left it.
	bool taken;
	// hasStarted's: set as start calls the class's start, cleared where the start fails and as
	// stop begins.
	bool started;
};

#endif // REIMS_GRAPHICS_HPP_
