/*
 * RgfxIOSurface: see RgfxIOSurface.h. Our own ObjC++.
 */

#import "RgfxIOSurface.h"
#include "RgfxLog.hpp"
#include "RgfxLogOnce.hpp"

#import "RgfxBuffer.h"

#include <algorithm>
#include <atomic>
#include <cstddef>
#include <cstring>
#include <dispatch/dispatch.h>
#include <map>
#include <mutex>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <time.h>
#include <tuple>
#include <utility>

#include "RgfxEncoder.hpp"
#include "RgfxManagedLayout.hpp"
#include "RgfxMemoryShadow.hpp"
#include "RgfxRegion.hpp"
#include "RgfxSerializer.hpp"
#include "../../kext/src/RgfxSurfaceRefill.hpp"
#include "../../kext/src/RgfxUserClientABI.hpp"

namespace {

/// The row pitch of a copy: a multiple of every linear-texture row alignment a host
/// GPU asks for.
const uint64_t kShadowRowAlign = 256;

/// The guest's page, which the kext wires a surface's allocation in whole of for its GPU view in
/// place.
const uint64_t kSurfacePage = 0x1000;

/// What a plane's offset and rows in place are a multiple of where the device caches every
/// surface in place (gCacheEvery): no host texture lies over the pages then, each a view of an
/// image the host fills from the plane's place and pitch in the cache, and writes back there, by
/// copies that address them in texels of the view's format (design.md, "Every surface cached").
/// 16 bytes, the largest texel of a format of texels (RGBA32Float's), so every view's copies
/// address the plane whatever format of texels a view of it takes.
const uint64_t kShapeCopyAlign = 16;

uint64_t alignUp(uint64_t v, uint64_t a)
{
	return (v + a - 1) & ~(a - 1);
}

/// The shape of one plane of a surface, as its CPU mapping lays it out.
struct PlaneShape {
	uint64_t rowBytes;        // bytes from one row of elements to the next
	uint64_t rows;            // rows of elements
	uint64_t bytesPerElement; // bytes of one element
	uint64_t elementWidth;    // pixels across one element
	uint64_t elementHeight;   // pixels down one element
};

/// The shape of plane `plane` of `s`; a surface of no planes has the one plane 0.
/// False when the surface has no such plane.
bool planeShape(IOSurfaceRef s, size_t plane, PlaneShape *out)
{
	size_t planes = IOSurfaceGetPlaneCount(s);
	size_t height;
	if (planes == 0) {
		if (plane != 0) {
			return false;
		}
		out->rowBytes = IOSurfaceGetBytesPerRow(s);
		height = IOSurfaceGetHeight(s);
		out->bytesPerElement = IOSurfaceGetBytesPerElement(s);
		out->elementWidth = IOSurfaceGetElementWidth(s);
		out->elementHeight = IOSurfaceGetElementHeight(s);
	} else {
		if (plane >= planes) {
			return false;
		}
		out->rowBytes = IOSurfaceGetBytesPerRowOfPlane(s, plane);
		height = IOSurfaceGetHeightOfPlane(s, plane);
		out->bytesPerElement = IOSurfaceGetBytesPerElementOfPlane(s, plane);
		out->elementWidth = IOSurfaceGetElementWidthOfPlane(s, plane);
		out->elementHeight = IOSurfaceGetElementHeightOfPlane(s, plane);
	}
	uint64_t eh = std::max<uint64_t>(out->elementHeight, 1);
	out->rows = (height + eh - 1) / eh;
	return out->rowBytes != 0 && out->rows != 0;
}

/// Where a region of a texture over a plane lies in the plane's rows, in the blocks of the
/// texture's format (RgfxIOSurfaceTexture's CPU access).
struct RgfxSurfaceCpuSpan {
	uint64_t row;   // the plane's row of the region's first row of blocks
	uint64_t byte;  // the region's first byte in each of those rows
	uint64_t rows;  // rows of blocks
	uint64_t bytes; // bytes of each row of blocks
};

/// Where `region` of a texture of `format` over a plane of shape `s` lies in the plane's rows:
/// row j of the texture's blocks (rgfxPixelFormatBlock) at the plane's row j, as Metal lays a
/// texture over a surface's plane out, whatever the plane's own elements. False for a format of
/// no block there, and for a region whose blocks pass the plane's rows or a row's bytes.
bool cpuSpan(MTLPixelFormat format, const PlaneShape &s, MTLRegion region,
             RgfxSurfaceCpuSpan *span)
{
	RgfxFormatBlock b = {};
	if (!rgfxPixelFormatBlock(static_cast<uint32_t>(format), &b))
		return false;
	const uint64_t x = region.origin.x / b.width, y = region.origin.y / b.height;
	const uint64_t across = (region.origin.x + region.size.width + b.width - 1) / b.width - x;
	const uint64_t down = (region.origin.y + region.size.height + b.height - 1) / b.height - y;
	if (y + down > s.rows || (x + across) * b.bytes > s.rowBytes)
		return false;
	*span = {y, x * b.bytes, down, across * b.bytes};
	return true;
}

/// The CPU address of plane `plane` of `s` in this process (null when unmapped).
uint8_t *planeBase(IOSurfaceRef s, size_t plane)
{
	void *p = IOSurfaceGetPlaneCount(s) == 0 ? IOSurfaceGetBaseAddress(s)
	                                         : IOSurfaceGetBaseAddressOfPlane(s, plane);
	return static_cast<uint8_t *>(p);
}

/// One plane of a surface's GPU view: its shape on the CPU, and where its rows lie in the view (in
/// a copy, both kShadowRowAlign multiples).
struct ShadowPlane {
	PlaneShape shape = {};
	uint64_t pitch = 0;  // the view's row pitch
	uint64_t offset = 0; // the plane's first byte in the view
};

/// printf into a std::string.
std::string format(const char *fmt, ...) __attribute__((format(printf, 1, 2)));
std::string format(const char *fmt, ...)
{
	char line[512];
	va_list ap;
	va_start(ap, fmt);
	int n = vsnprintf(line, sizeof(line), fmt, ap);
	va_end(ap);
	return n > 0 ? std::string(line) : std::string();
}

/// The planes of `s` where its own memory holds them, for its GPU view in place: each at its
/// offset from the surface's base (CoreVideo's planar buffers start plane 0 past a header), with
/// its own rows. False, saying why in `*why`, where the host's textures cannot lie over them: the
/// base is not a page's, a plane's offset or rows are not a multiple of `align` (0: none known;
/// the host's linear texture alignment, or kShapeCopyAlign where every surface is cached), or a
/// plane passes the allocation.
bool placeInPlace(IOSurfaceRef s, std::vector<ShadowPlane> *planes, uint64_t align,
                  std::string *why)
{
	uintptr_t base = reinterpret_cast<uintptr_t>(IOSurfaceGetBaseAddress(s));
	if (align == 0) {
		*why = "the host's linear texture alignment is not known";
		return false;
	}
	if (base == 0 || base % kSurfacePage != 0) {
		*why = format("its base 0x%lx is not a page's", static_cast<unsigned long>(base));
		return false;
	}
	uint64_t alloc = IOSurfaceGetAllocSize(s);
	for (size_t k = 0; k < planes->size(); k++) {
		ShadowPlane &p = (*planes)[k];
		uintptr_t at = reinterpret_cast<uintptr_t>(planeBase(s, k));
		if (at < base) {
			*why = format("plane %zu lies before its base", k);
			return false;
		}
		p.offset = at - base;
		p.pitch = p.shape.rowBytes;
		if (p.offset % align != 0 || p.pitch % align != 0) {
			*why = format("plane %zu's offset %llu or rows of %llu bytes are not a multiple of "
			              "the host's %llu",
			              k, (unsigned long long)p.offset, (unsigned long long)p.pitch,
			              (unsigned long long)align);
			return false;
		}
		if (p.offset > alloc || p.pitch * p.shape.rows > alloc - p.offset) {
			*why = format("plane %zu (%llu bytes at %llu) passes its %llu-byte allocation", k,
			              (unsigned long long)(p.pitch * p.shape.rows),
			              (unsigned long long)p.offset, (unsigned long long)alloc);
			return false;
		}
	}
	return true;
}

/// The layout of `s` whose planes lie in its own memory as `planes` places them (placeInPlace),
/// as an ask whether its block needs a device cache sends it (RgfxSurfacePagesLayout): each plane's
/// offset and rows, and the bytes of a row's elements, its width over its elements' rounded up,
/// at most its rows' pitch. A surface of more planes than the layout holds sends none.
bool pagesLayout(IOSurfaceRef s, const std::vector<ShadowPlane> &planes,
                 RgfxSurfacePagesLayout *out)
{
	if (planes.empty() || planes.size() > RGFX_SURFACE_PAGES_PLANES) {
		return false;
	}
	*out = {};
	out->plane_count = static_cast<uint32_t>(planes.size());
	const bool flat = IOSurfaceGetPlaneCount(s) == 0;
	for (size_t k = 0; k < planes.size(); k++) {
		const ShadowPlane &p = planes[k];
		const uint64_t width = flat ? IOSurfaceGetWidth(s) : IOSurfaceGetWidthOfPlane(s, k);
		const uint64_t ew = std::max<uint64_t>(p.shape.elementWidth, 1);
		const uint64_t texels = (width + ew - 1) / ew * p.shape.bytesPerElement;
		out->planes[k] = {p.offset, p.pitch, std::min(texels, p.pitch), p.shape.rows};
	}
	return true;
}

/// The surface's facts for a log line: its id, OSType, size, allocation and each plane's size
/// and rows.
std::string describe(IOSurfaceRef s)
{
	if (s == nullptr) {
		return "no IOSurface";
	}
	uint32_t f = IOSurfaceGetPixelFormat(s);
	char fourcc[5] = {char(f >> 24), char(f >> 16), char(f >> 8), char(f), 0};
	bool printable = true;
	for (int i = 0; i < 4; i++)
		printable = printable && fourcc[i] >= 0x20 && fourcc[i] < 0x7f;
	std::string out =
	    format("IOSurface %u ", IOSurfaceGetID(s)) +
	    (printable ? format("'%s'", fourcc) : format("0x%08x", f)) +
	    format(" %zux%zu, %zu bytes, %zu planes", IOSurfaceGetWidth(s), IOSurfaceGetHeight(s),
	           IOSurfaceGetAllocSize(s), IOSurfaceGetPlaneCount(s));
	size_t planes = std::max<size_t>(IOSurfaceGetPlaneCount(s), 1);
	for (size_t k = 0; k < planes && k < 4; k++) {
		PlaneShape shape = {};
		if (planeShape(s, k, &shape)) {
			out += format("%s plane %zu: %llu rows of %llu bytes", k == 0 ? ";" : ",", k,
			              (unsigned long long)shape.rows, (unsigned long long)shape.rowBytes);
		}
	}
	return out;
}

/// The textures over surfaces answered nil, by surface and cause: how many, and the line logged
/// for the first (rgfxIOSurfaceNilLog). A surface is known by its id, its object, its OSType and
/// its allocation together, since IOSurface gives a freed surface's id to the next.
struct NilLog {
	using Key = std::tuple<uint32_t, uintptr_t, uint32_t, size_t, std::string>;
	std::mutex lock;
	std::map<Key, std::pair<uint64_t, std::string>> seen;

	static Key key(IOSurfaceRef s, const char *cause)
	{
		if (s == nullptr) {
			return Key(0, 0, 0, 0, cause);
		}
		return Key(IOSurfaceGetID(s), reinterpret_cast<uintptr_t>(s), IOSurfaceGetPixelFormat(s),
		           IOSurfaceGetAllocSize(s), cause);
	}
};

NilLog &nilLog()
{
	static NilLog *l = new NilLog(); // never destroyed: textures are made at any time
	return *l;
}

/// newTextureWithDescriptor:iosurface:plane: answers nil for `surface`, as Metal does a texture
/// it cannot make, for `cause`, which `detail` says more of: counted per surface and cause, and
/// logged once per cause and pixel format in the process (docs/conventions.md), so a texture
/// asked for every frame, over a surface new each frame or not, logs once.
void logNoTexture(IOSurfaceRef surface, const char *cause, const std::string &detail)
{
	std::string line = describe(surface) + ": no texture (" + cause + "): " + detail;
	NilLog &l = nilLog();
	{
		std::lock_guard<std::mutex> g(l.lock);
		// Bounded: a long session's surfaces come and go.
		if (l.seen.size() >= 4096) {
			l.seen.clear();
		}
		auto &entry = l.seen[NilLog::key(surface, cause)];
		if (entry.first++ != 0) {
			return;
		}
		entry.second = line;
	}
	static char site;
	const uint32_t format = surface != nullptr ? IOSurfaceGetPixelFormat(surface) : 0;
	if (rgfxLogFirst(&site, rgfxLogKindOf(cause) ^ format))
		rgfxLogLine(@"RGFX: %s", line.c_str());
}

/// The surface's YCbCr matrix as one of RGFX_YCBCR_MATRIX_*. CoreVideo keeps a pixel buffer's
/// propagated kCVImageBufferYCbCrMatrixKey attachment on its surface as the value
/// "IOSurfaceYCbCrMatrix", the attachment's string (measured on the M3 Max under macOS 27.0.1
/// with IOSurfaceCopyAllValues, for each of CoreVideo's six matrix constants). Read from the
/// surface itself: a CVPixelBuffer made over the surface reads it back too, but holds the
/// surface in use (IOSurfaceIsInUse, a use count of 1) while it lives, which Metal does not.
uint32_t ycbcrMatrix(IOSurfaceRef s)
{
	CFTypeRef value = IOSurfaceCopyValue(s, CFSTR("IOSurfaceYCbCrMatrix"));
	if (value == nullptr) {
		return RGFX_YCBCR_MATRIX_NONE;
	}
	static const struct {
		CFStringRef name;
		uint32_t code;
	} kMatrices[] = {
	    {CFSTR("ITU_R_601_4"), RGFX_YCBCR_MATRIX_ITU_R_601_4},
	    {CFSTR("ITU_R_709_2"), RGFX_YCBCR_MATRIX_ITU_R_709_2},
	    {CFSTR("ITU_R_2020"), RGFX_YCBCR_MATRIX_ITU_R_2020},
	    {CFSTR("SMPTE_240M_1995"), RGFX_YCBCR_MATRIX_SMPTE_240M_1995},
	    {CFSTR("DCI_P3"), RGFX_YCBCR_MATRIX_DCI_P3},
	    {CFSTR("P3_D65"), RGFX_YCBCR_MATRIX_P3_D65},
	};
	uint32_t code = RGFX_YCBCR_MATRIX_OTHER;
	if (CFGetTypeID(value) == CFStringGetTypeID()) {
		for (const auto &m : kMatrices) {
			if (CFEqual(value, m.name)) {
				code = m.code;
				break;
			}
		}
	}
	CFRelease(value);
	return code;
}

/// The process's copies between surfaces' pages and the GPU's view of them, by direction: a
/// diagnostic, an os_log line (info) at most every kCopyReportNs while copies run.
struct CopyCount {
	std::atomic<uint64_t> count{0};
	std::atomic<uint64_t> bytes{0};
	std::atomic<uint64_t> ns{0};
};

CopyCount gUploads;    // pages -> the GPU's view
CopyCount gWriteBacks; // the GPU's view -> pages

/// The GPU views the process made of surfaces: in place, or copies, by why.
std::atomic<uint64_t> gInPlace{0};
std::atomic<uint64_t> gCached{0};            // of them, cached on the host (their blocks')

/// The views alive in the process whose blocks are cached: a command buffer looks for its uses of
/// cached surfaces only while one lives (rgfxIOSurfaceNoteUse).
std::atomic<uint64_t> gCachedLive{0};
/// The process names its command buffers' order over IOSurfaces (rgfxIOSurfaceSetOrder): every
/// surface a buffer uses is noted, and its commit names the buffers of other queues it runs after.
std::atomic<bool> gSurfaceOrder{false};
/// The process has the host fill a cached surface's device cache again once the read-write lock
/// that moved its generation has been let go (rgfxIOSurfaceSetRefill): each commit's use of the
/// surface reads the record in its block's header (RgfxSurfaceShadow::refillAt).
std::atomic<bool> gRefill{false};
/// The RgfxAskUncachedScopes alive on this thread.
thread_local unsigned tAskUncached = 0;

/// The views' locks (RgfxSurfaceShadow::lock) this thread holds, and the CPU locks of a surface
/// taken while a thread held one (rgfxIOSurfaceLocksUnderView), which stay none: a view's lock is
/// taken after its surface's lock, never before. A buffer's write-back at its completion takes
/// the view's lock before the buffer's writes retire, and a CPU lock of the surface waits for
/// them in the kext, so a surface lock taken under the view's lock waited for its own thread's
/// lock until the kext's wait gave up, then went on without the buffer's results.
thread_local unsigned tViewLocks = 0;
std::atomic<uint64_t> gLocksUnderView{0};

/// A view's lock, held for the scope, as the views' lock order counts it.
class ViewLock {
public:
	explicit ViewLock(std::mutex &m) : m_lock(m)
	{
		m_lock.lock();
		tViewLocks++;
	}
	~ViewLock()
	{
		tViewLocks--;
		m_lock.unlock();
	}
	ViewLock(const ViewLock &) = delete;
	ViewLock &operator=(const ViewLock &) = delete;

private:
	std::mutex &m_lock;
};

/// IOSurfaceLock, counted where this thread holds a view's lock (rgfxIOSurfaceLocksUnderView).
IOReturn lockSurface(IOSurfaceRef s, IOSurfaceLockOptions options, uint32_t *seed)
{
	if (tViewLocks != 0)
		gLocksUnderView.fetch_add(1, std::memory_order_relaxed);
	return IOSurfaceLock(s, options, seed);
}

/// A CPU write lock of a surface whose GPU view is a copy (`copy`), for a write through the
/// copy (replaceRegion), taken before the view's lock: let go by unlock(), which answers the
/// seed its unlock leaves, or at its end. None where the view is not a copy, or the lock failed.
class CopyWriteLock {
public:
	CopyWriteLock(IOSurfaceRef surface, bool copy) : m_surface(copy ? surface : nullptr)
	{
		if (m_surface != nullptr && lockSurface(m_surface, 0, &m_seed) != kIOReturnSuccess)
			m_surface = nullptr;
	}
	~CopyWriteLock() { unlock(); }
	CopyWriteLock(const CopyWriteLock &) = delete;
	CopyWriteLock &operator=(const CopyWriteLock &) = delete;

	bool held() const { return m_surface != nullptr; }

	/// Unlocks, once: the seed the unlock leaves.
	uint32_t unlock()
	{
		if (m_surface != nullptr) {
			IOSurfaceUnlock(m_surface, 0, &m_seed);
			m_surface = nullptr;
		}
		return m_seed;
	}

private:
	IOSurfaceRef m_surface;
	uint32_t m_seed = 0;
};
std::atomic<uint64_t> gCopied[kRgfxSurfaceCopyReasons] = {};
/// The device caches every surface the kext gives in place (rgfxIOSurfaceSetCacheEvery): a view
/// that is a copy is then a fallback, the first of each reason logged at the default level, and
/// the copies' summary too where any was made since the last.
std::atomic<bool> gCacheEvery{false};
// The copies made: in the surface's shared block, or, where the kext gave none, in a block of
// the process's own, which no other holder shares (its GPU sees theirs only through the pages).
std::atomic<uint64_t> gCopyShared{0};
std::atomic<uint64_t> gCopyOwn{0};
// Of the uploads, those made while a CPU held the surface locked for writing, each synced again
// at the CPU's unlock.
std::atomic<uint64_t> gUploadsMidWrite{0};
// The uploads made because such a CPU had let go of its lock (the unlock seed moved).
std::atomic<uint64_t> gSyncsAtUnlock{0};
// The commits that asked the kext whether such a CPU had let go of its lock yet.
std::atomic<uint64_t> gUnlockAsks{0};
// For a cached surface (gRefill): the uses named while the read-write CPU lock that moved their
// generation was held, or being taken, whose device cache the host may fill mid-write; the uses
// that asked the host to fill it again because that lock had been let go
// (RGFX_SURFACE_USE_REFILL); and the uses that asked the kext for the surface's seeds for it.
std::atomic<uint64_t> gNamedMidWrite{0};
std::atomic<uint64_t> gRefillsAtUnlock{0};
std::atomic<uint64_t> gRefillAsks{0};
// Whether the kext answers surfaces' lock and unlock seeds to this process's device
// (rgfxIOSurfaceNoteSurfaceSeeds): -1 where no device said yet.
std::atomic<int> gSurfaceSeeds{-1};

// A summary, at most once a minute (docs/conventions.md).
const uint64_t kCopyReportNs = 60ull * 1000 * 1000 * 1000;

uint64_t nowNs()
{
	return clock_gettime_nsec_np(CLOCK_UPTIME_RAW);
}

/// Logs the copies and the views made since the last report, once kCopyReportNs has passed
/// since it.
void reportCopies(uint64_t now)
{
	static std::mutex lock;
	static uint64_t last = 0, upCount = 0, upBytes = 0, upNs = 0, upMidWrite = 0, syncsAtUnlock = 0,
	                unlockAsks = 0, wbCount = 0, wbBytes = 0, wbNs = 0, inPlace = 0, cached = 0,
	                forAlignment = 0, unsupported = 0, refused = 0, noRoom = 0, shared = 0, own = 0,
	                namedMidWrite = 0, refills = 0, refillAsks = 0;
	std::unique_lock<std::mutex> g(lock, std::try_to_lock);
	if (!g.owns_lock()) {
		return;
	}
	if (last == 0) {
		last = now;
		return;
	}
	if (now - last < kCopyReportNs) {
		return;
	}
	uint64_t uc = gUploads.count, ub = gUploads.bytes, un = gUploads.ns, um = gUploadsMidWrite,
	         ul = gSyncsAtUnlock, ua = gUnlockAsks;
	const int seeds = gSurfaceSeeds.load(std::memory_order_relaxed);
	uint64_t wc = gWriteBacks.count, wb = gWriteBacks.bytes, wn = gWriteBacks.ns;
	uint64_t ip = gInPlace, cc = gCached, ca = gCopied[kRgfxSurfaceCopiedAlignment],
	         cu = gCopied[kRgfxSurfaceCopiedUnsupported], cr = gCopied[kRgfxSurfaceCopiedRefused],
	         cn = gCopied[kRgfxSurfaceCopiedNoRoom], cs = gCopyShared, co = gCopyOwn;
	uint64_t nm = gNamedMidWrite, rf = gRefillsAtUnlock, ra = gRefillAsks;
	// Where every surface the kext gives in place is cached, a copy is a fallback: the line
	// reaches the default level once copies were made since the last.
	const bool fallback = gCacheEvery.load(std::memory_order_relaxed) &&
	                      ca + cu + cr + cn != forAlignment + unsupported + refused + noRoom;
	// The process's id and name are the log's own.
	os_log_with_type(rgfxLog(), fallback ? OS_LOG_TYPE_DEFAULT : OS_LOG_TYPE_INFO,
	                 "RGFX: surface copies, %.1f s, unlock seeds %{public}s: %llu uploads %.1f MiB "
	                 "%.2f ms (%llu mid-write, %llu synced again at the unlock, %llu asks for it), "
	                 "%llu write-backs %.1f MiB %.2f ms; views made: %llu in place (%llu cached), "
	                 "copies %llu for alignment, %llu unsupported, %llu refused by the kext, %llu "
	                 "with no room in the kext; copy blocks: %llu shared, %llu own; cached "
	                 "surfaces: %llu named mid-write, %llu filled again at the unlock, %llu asks "
	                 "for it",
	                 (now - last) / 1e9, seeds > 0 ? "on" : seeds == 0 ? "off" : "unknown",
	                 uc - upCount, (ub - upBytes) / 1048576.0, (un - upNs) / 1e6, um - upMidWrite,
	                 ul - syncsAtUnlock, ua - unlockAsks, wc - wbCount, (wb - wbBytes) / 1048576.0,
	                 (wn - wbNs) / 1e6, ip - inPlace, cc - cached, ca - forAlignment,
	                 cu - unsupported, cr - refused, cn - noRoom, cs - shared, co - own,
	                 nm - namedMidWrite, rf - refills, ra - refillAsks);
	last = now;
	upCount = uc, upBytes = ub, upNs = un, upMidWrite = um, syncsAtUnlock = ul, unlockAsks = ua;
	wbCount = wc, wbBytes = wb, wbNs = wn;
	inPlace = ip, cached = cc, forAlignment = ca, unsupported = cu, refused = cr, noRoom = cn;
	shared = cs, own = co;
	namedMidWrite = nm, refills = rf, refillAsks = ra;
}

/// Counts a copy of `bytes` that started at `start`.
void countCopy(CopyCount &c, uint64_t bytes, uint64_t start)
{
	uint64_t now = nowNs();
	c.count.fetch_add(1, std::memory_order_relaxed);
	c.bytes.fetch_add(bytes, std::memory_order_relaxed);
	c.ns.fetch_add(now - start, std::memory_order_relaxed);
	reportCopies(now);
}

/// Counts a view of a surface made.
void countView(std::atomic<uint64_t> &c)
{
	c.fetch_add(1, std::memory_order_relaxed);
	reportCopies(nowNs());
}

const char *const kCopyReasonNames[kRgfxSurfaceCopyReasons] = {
    "alignment", "unsupported", "refused by the kext", "no room in the kext"};

/// Counts a view of `surface` made as a copy for `reason`. Where every surface the kext gives in
/// place is cached (gCacheEvery), the copy is a fallback: the first of each reason in the process
/// is logged at the default level, with the surface's format and shape.
void countCopy(RgfxSurfaceCopyReason reason, IOSurfaceRef surface)
{
	countView(gCopied[reason]);
	static char site;
	if (gCacheEvery.load(std::memory_order_relaxed) && rgfxLogFirst(&site, reason + 1))
		rgfxLogLine(@"RGFX: every surface in place is cached, but a view of %s is a copy (%s): "
		            @"its reason's count is in the surface copies line",
		            describe(surface).c_str(), kCopyReasonNames[reason]);
}

} // namespace

/// A CPU's write lock of a surface as a copy was synced with its pages: `held` where a CPU held the
/// surface locked for writing then, and `unlockSeed` the surface's unlock seed then
/// (RgfxRegion::surfaceSeeds), which the lock's unlock moves.
struct SyncedWrite {
	bool held = false;
	uint32_t unlockSeed = 0;
};

/// What every process holding a surface's shared block agrees on, in the block past the planes'
/// rows, or at its start in place (RgfxSurfaceShadow::header): for a copy, the surface's seed
/// when the block last matched the surface's pages, valid where `serial` is the block's own (a
/// block made again holds an older one's bytes until its first holder writes it); for a cached
/// block in place, the surface's CPU generation, which the kext writes at each read-write CPU
/// lock of the surface (its kRgfxSurfaceCpuGenOffset) and each command buffer that uses the
/// surface names (rgfxIOSurfaceUses), and how many processes hold the surface, which the kext
/// writes as it caches the block, as a process holds the block again and as each client of the
/// surface goes (its kRgfxSurfaceClientsOffset; 0 where it wrote none), which WindowServer's keep
/// reads. And for a copy synced while a CPU held the surface locked for writing (its lock seed
/// past its unlock seed, RgfxRegion::surfaceSeeds), `writeHeld` is 1 and `unlockSeed` the unlock
/// seed then: the copy holds the pages as they were mid-write, and syncs again once the unlock
/// seed moves (RgfxSurfaceShadow::changed). A cached block in place, which holds no copy, keeps
/// its refill record in `unlockSeed` and `writeHeld`, one 64-bit word at the kext's
/// kRgfxSurfaceRefillOffset (RgfxSurfaceRefill.hpp, RgfxSurfaceShadow::refillAt), which the kext
/// writes as it caches the block and at each read-write CPU lock.
struct RgfxSurfaceHeader {
	uint64_t serial;
	uint32_t seed;
	uint32_t clients;
	uint64_t cpuGen;
	uint32_t unlockSeed;
	uint32_t writeHeld;
};

static_assert(offsetof(RgfxSurfaceHeader, cpuGen) == kRgfxSurfaceCpuGenOffset,
              "where the kext writes the CPU generation");
static_assert(offsetof(RgfxSurfaceHeader, clients) == kRgfxSurfaceClientsOffset,
              "where the kext writes the surface's clients");

static_assert(offsetof(RgfxSurfaceHeader, unlockSeed) == kRgfxSurfaceRefillOffset &&
                  offsetof(RgfxSurfaceHeader, writeHeld) == kRgfxSurfaceRefillOffset + 4 &&
                  kRgfxSurfaceRefillOffset % 8 == 0,
              "where the kext writes a cached block's refill record, one aligned word");
static_assert(sizeof(RgfxSurfaceHeader) % alignof(RgfxSurfaceWriters) == 0,
              "the writers follow the header, aligned");

/// The GPU's view of one surface, every plane of it: the surface's own pages, used in place,
/// where the host can (`inPlace`, RgfxRegion::acquireSurfacePages), else a copy in a block of the
/// device region: the surface's shared block, which every process holding the surface draws and
/// samples (the kext's, RgfxRegion::acquireSurface), or this process's own block where the kext
/// gives none. Its planes lie in it in order, as the surface's do in its own memory, each at its
/// own offset, so a texture over one plane that reads another (a two-plane YCbCr texture over
/// plane 0 reads plane 1's chroma) finds both in the one buffer, and every texture over the
/// surface reads and writes the same bytes, as Metal's over one surface do. In place, the shared
/// block holds only the header and the writers.
struct RgfxSurfaceShadow {
	IOSurfaceRef surface = nullptr; // retained
	uint32_t surfaceId = 0;
	std::vector<ShadowPlane> planes; // by plane; a surface without planes has the one plane 0
	// The surface as the view was made of it, for the line a view that no longer describes its
	// surface logs (describes): its IOSurfaceGetPlaneCount, allocation and OSType, and when.
	size_t madePlaneCount = 0;
	uint64_t madeAlloc = 0;
	uint32_t madeFormat = 0;
	uint64_t madeNs = 0;
	RgfxRegion::Block block = {};
	RgfxRegion *region = nullptr; // where the block goes back at the copy's end
	id<MTLBuffer> buffer = nil; // the Shared buffer over the view: the pages, or the block
	std::mutex lock;            // one sync at a time in this process
	// Held by the thread that makes the view, from its entry in the registry until its buffer,
	// and a copy's first upload, are made: a thread that finds the view meanwhile waits for it
	// (shadowFor), as its texture names the buffer.
	std::mutex making;
	bool shared = false;        // the plane's shared block, else this process's own
	bool inPlace = false;       // the GPU uses the surface's pages; the block holds no copy
	bool cached = false;        // in place, and its GPU copy is the host's device cache
	std::atomic<bool> keepVolatile{false}; // a texture over it set it volatile or empty: unkept
	// The keep stamps (RgfxEncoder::keepStamp) of the command buffers that last named the view
	// as used (a cached one, rgfxIOSurfaceNoteUse) and as synced at its commit (a copy): each
	// command buffer names it once. Relaxed: a lost write only names it once more.
	std::atomic<uint64_t> usedBy{0};
	std::atomic<uint64_t> syncedBy{0};
	uint64_t serial = 0;        // the shared block's
	RgfxSurfaceHeader *header = nullptr; // the shared block's, past the planes' rows of a copy
	uint32_t seed = 0;          // this process's own block: the seed when it last matched
	SyncedWrite ownWrite;       // and the write lock held then (RgfxSurfaceHeader::writeHeld)
	RgfxSurfaceWriters *writers = nullptr; // past the header: the buffers a present waits for
	uint64_t writersAt = 0;                 // their offset in the block
	std::mutex writersLock;                 // one change of this process's slots at a time
	// By slot: the queue this process named there (0: none), and that queue while it lives.
	uint64_t slotQueue[RGFX_SURFACE_WRITER_SLOTS] = {};
	__weak id slotOwner[RGFX_SURFACE_WRITER_SLOTS];
	// Past the writers, in every block (shadowFor): each queue's latest buffer that only reads
	// the view, the same record, which only the bundles read (gSurfaceOrder); and this process's
	// slots of it, as the writers'.
	RgfxSurfaceWriters *readers = nullptr;
	uint64_t readerQueue[RGFX_SURFACE_WRITER_SLOTS] = {};
	__weak id readerOwner[RGFX_SURFACE_WRITER_SLOTS];

	~RgfxSurfaceShadow();

	/// Names the buffer at `seqno` on `queue` (id `queueId`) among the copy's writers, which
	/// ran after the buffers `named` (its post's SURFACE_ORDER, rgfxIOSurfaceNameOrder). Where no
	/// slot is left, it takes one of this process's whose buffer it runs after (takeOver).
	void noteWriter(id queue, uint64_t queueId, uint64_t seqno,
	                const std::vector<RgfxSurfaceOrderWait> &named)
	{
		std::lock_guard<std::mutex> g(writersLock);
		if (!noteIn(writers, slotQueue, slotOwner, queue, queueId, seqno) &&
		    !takeOver(writers, slotQueue, slotOwner, queue, queueId, seqno, named)) {
			static std::atomic<bool> logged{false};
			if (!logged.exchange(true)) {
				rgfxLogLine(@"RGFX: IOSurface %u: no writer slot left for queue 0x%llx: a present of "
				            @"the surface may show it before the queue's command buffers finish",
				            surfaceId, (unsigned long long)queueId);
			}
		}
	}

	/// Names the buffer at `seqno` on `queue` (id `queueId`) among the copy's readers, which
	/// ran after the buffers `named` (rgfxIOSurfaceNameOrder). Where no reader slot is left, it
	/// is named among the writers instead, whose every slot a later buffer that uses the surface
	/// names, a write as a read would: in the queue's writer slot, a free one, or one of this
	/// process's whose buffer it runs after (takeOver). A read named so is waited for by a later
	/// read too, and by a present, which is later than a Mac would and never sooner.
	void noteReader(id queue, uint64_t queueId, uint64_t seqno,
	                const std::vector<RgfxSurfaceOrderWait> &named)
	{
		std::lock_guard<std::mutex> g(writersLock);
		if (noteIn(readers, readerQueue, readerOwner, queue, queueId, seqno))
			return;
		if (writers != nullptr &&
		    (noteIn(writers, slotQueue, slotOwner, queue, queueId, seqno) ||
		     takeOver(writers, slotQueue, slotOwner, queue, queueId, seqno, named)))
			return;
		static std::atomic<bool> logged{false};
		if (!logged.exchange(true)) {
			rgfxLogLine(@"RGFX: IOSurface %u: no reader or writer slot left for queue 0x%llx: a later "
			            @"write of the surface by another queue may not wait for its reads",
			            surfaceId, (unsigned long long)queueId);
		}
	}

	/// Where `queue` finds no slot of `rec` (noteIn): gives it a slot of this process's that
	/// names a buffer of another of its queues which the buffer at `seqno` runs after on the GPU,
	/// its post having named that queue at the slot's seqno or later (`named`): a buffer that
	/// names the slot from then on runs after both, as it would have run after each. A slot of
	/// another process's is never written here, and one raised past what `named` holds is kept.
	/// False where none is. Under writersLock.
	static bool takeOver(RgfxSurfaceWriters *rec, uint64_t (&queues)[RGFX_SURFACE_WRITER_SLOTS],
	                     __weak id (&owners)[RGFX_SURFACE_WRITER_SLOTS], id queue,
	                     uint64_t queueId, uint64_t seqno,
	                     const std::vector<RgfxSurfaceOrderWait> &named)
	{
		for (uint32_t i = 0; i < RGFX_SURFACE_WRITER_SLOTS; i++) {
			const uint64_t holder = queues[i];
			if (holder == 0 || holder == queueId)
				continue;
			// Only this process writes the slot.
			const uint64_t held = __atomic_load_n(&rec->writers[i].seqno, __ATOMIC_RELAXED);
			auto it = std::find_if(named.begin(), named.end(),
			                       [holder](const auto &w) { return w.queue_obj_id == holder; });
			if (it == named.end() || it->seqno < held)
				continue;
			give(rec, queues, owners, i, queue, queueId, seqno);
			return true;
		}
		return false;
	}

	/// Raises `queue`'s slot of `rec` to `seqno`: the slot it holds, else one of ours whose queue
	/// is gone, else an empty one; false where none is left. Under writersLock.
	static bool noteIn(RgfxSurfaceWriters *rec, uint64_t (&queues)[RGFX_SURFACE_WRITER_SLOTS],
	                   __weak id (&owners)[RGFX_SURFACE_WRITER_SLOTS], id queue, uint64_t queueId,
	                   uint64_t seqno)
	{
		for (uint32_t i = 0; i < RGFX_SURFACE_WRITER_SLOTS; i++) {
			if (queues[i] == queueId) {
				// Only this process writes the slot: its seqno only rises.
				uint64_t *s = &rec->writers[i].seqno;
				if (__atomic_load_n(s, __ATOMIC_RELAXED) < seqno)
					__atomic_store_n(s, seqno, __ATOMIC_RELEASE);
				return true;
			}
		}
		for (uint32_t i = 0; i < RGFX_SURFACE_WRITER_SLOTS; i++) {
			if (queues[i] != 0 && owners[i] == nil) {
				// A queue of ours that is gone, its buffers all finished: the slot is ours to give.
				give(rec, queues, owners, i, queue, queueId, seqno);
				return true;
			}
		}
		for (uint32_t i = 0; i < RGFX_SURFACE_WRITER_SLOTS; i++) {
			uint64_t empty = 0;
			if (queues[i] == 0 &&
			    __atomic_compare_exchange_n(&rec->writers[i].queue_obj_id, &empty, queueId, false,
			                                __ATOMIC_ACQ_REL, __ATOMIC_RELAXED)) {
				__atomic_store_n(&rec->writers[i].seqno, seqno, __ATOMIC_RELEASE);
				queues[i] = queueId;
				owners[i] = queue;
				return true;
			}
		}
		return false;
	}

	/// Gives slot `i` of `rec`, ours, to `queue`: its seqno emptied, then the queue, then the
	/// seqno.
	static void give(RgfxSurfaceWriters *rec, uint64_t (&queues)[RGFX_SURFACE_WRITER_SLOTS],
	                 __weak id (&owners)[RGFX_SURFACE_WRITER_SLOTS], uint32_t i, id queue,
	                 uint64_t queueId, uint64_t seqno)
	{
		__atomic_store_n(&rec->writers[i].seqno, 0, __ATOMIC_RELEASE);
		__atomic_store_n(&rec->writers[i].queue_obj_id, queueId, __ATOMIC_RELEASE);
		__atomic_store_n(&rec->writers[i].seqno, seqno, __ATOMIC_RELEASE);
		queues[i] = queueId;
		owners[i] = queue;
	}

	/// Empties this process's slots, of the writers and the readers: the seqno, then the queue.
	void emptyWriters()
	{
		std::lock_guard<std::mutex> g(writersLock);
		emptyIn(writers, slotQueue, slotOwner);
		emptyIn(readers, readerQueue, readerOwner);
	}

	/// Empties the slots of queue `queueId`, of the writers and the readers, that still name its
	/// buffer at `seqno`, which the host has finished: a buffer that named it would wait for
	/// nothing, so the slot is free for a queue of any process to take, and a slot is held only
	/// while the buffer it names runs. A slot a later buffer of the queue raised stays.
	void noteFinished(uint64_t queueId, uint64_t seqno)
	{
		std::lock_guard<std::mutex> g(writersLock);
		finishIn(writers, slotQueue, slotOwner, queueId, seqno);
		finishIn(readers, readerQueue, readerOwner, queueId, seqno);
	}

	static void finishIn(RgfxSurfaceWriters *rec, uint64_t (&queues)[RGFX_SURFACE_WRITER_SLOTS],
	                     __weak id (&owners)[RGFX_SURFACE_WRITER_SLOTS], uint64_t queueId,
	                     uint64_t seqno)
	{
		for (uint32_t i = 0; i < RGFX_SURFACE_WRITER_SLOTS; i++) {
			// Only this process writes the slot.
			if (queues[i] == queueId &&
			    __atomic_load_n(&rec->writers[i].seqno, __ATOMIC_RELAXED) == seqno) {
				emptySlot(rec, queues, owners, i);
				return;
			}
		}
	}

	static void emptyIn(RgfxSurfaceWriters *rec, uint64_t (&queues)[RGFX_SURFACE_WRITER_SLOTS],
	                    __weak id (&owners)[RGFX_SURFACE_WRITER_SLOTS])
	{
		for (uint32_t i = 0; i < RGFX_SURFACE_WRITER_SLOTS; i++) {
			if (queues[i] != 0)
				emptySlot(rec, queues, owners, i);
		}
	}

	/// Empties slot `i` of `rec`, ours: the seqno, then the queue.
	static void emptySlot(RgfxSurfaceWriters *rec, uint64_t (&queues)[RGFX_SURFACE_WRITER_SLOTS],
	                      __weak id (&owners)[RGFX_SURFACE_WRITER_SLOTS], uint32_t i)
	{
		__atomic_store_n(&rec->writers[i].seqno, 0, __ATOMIC_RELEASE);
		__atomic_store_n(&rec->writers[i].queue_obj_id, 0, __ATOMIC_RELEASE);
		queues[i] = 0;
		owners[i] = nil;
	}

	uint8_t *copy() const { return const_cast<uint8_t *>(block.ptr); }

	/// What the planes' offsets count from: the surface's base in place, else the copy's.
	uint8_t *pixels() const
	{
		return inPlace ? static_cast<uint8_t *>(IOSurfaceGetBaseAddress(surface)) : copy();
	}

	/// The bytes of the surface's planes, as its CPU mapping lays them out.
	uint64_t planeBytes() const
	{
		uint64_t n = 0;
		for (const ShadowPlane &p : planes) {
			n += p.shape.rowBytes * p.shape.rows;
		}
		return n;
	}

	/// What a texture over the surface tells the host of it (RgfxSurfaceFacts), its YCbCr
	/// matrix as it is now.
	RgfxSurfaceFacts facts() const
	{
		RgfxSurfaceFacts f = {};
		f.surface_pixel_format = IOSurfaceGetPixelFormat(surface);
		f.plane_count = static_cast<uint32_t>(IOSurfaceGetPlaneCount(surface));
		f.width = static_cast<uint32_t>(IOSurfaceGetWidth(surface));
		f.height = static_cast<uint32_t>(IOSurfaceGetHeight(surface));
		if (planes.size() >= 2) {
			f.chroma_offset = planes[1].offset;
			f.chroma_bytes_per_row = planes[1].pitch;
		}
		f.ycbcr_matrix = ycbcrMatrix(surface);
		return f;
	}

	/// The surface's seed when the block last matched its pages, and the write lock a CPU held
	/// then; false where it never has.
	bool syncedSeed(uint32_t *out, SyncedWrite *write = nullptr) const
	{
		if (!shared) {
			*out = seed;
			if (write != nullptr)
				*write = ownWrite;
			return true;
		}
		if (__atomic_load_n(&header->serial, __ATOMIC_ACQUIRE) != serial) {
			return false;
		}
		*out = __atomic_load_n(&header->seed, __ATOMIC_ACQUIRE);
		if (write != nullptr) {
			write->held = __atomic_load_n(&header->writeHeld, __ATOMIC_ACQUIRE) != 0;
			write->unlockSeed = __atomic_load_n(&header->unlockSeed, __ATOMIC_ACQUIRE);
		}
		return true;
	}

	/// The block matches the surface's pages as of seed `s`, a CPU holding the surface locked
	/// for writing then where `write.held` (until the unlock seed moves past `write.unlockSeed`).
	void setSynced(uint32_t s, SyncedWrite write = {})
	{
		if (!shared) {
			seed = s;
			ownWrite = write;
			return;
		}
		// The write lock first: a holder that reads the new seed reads the lock with it.
		__atomic_store_n(&header->unlockSeed, write.unlockSeed, __ATOMIC_RELEASE);
		__atomic_store_n(&header->writeHeld, write.held ? 1u : 0u, __ATOMIC_RELEASE);
		__atomic_store_n(&header->seed, s, __ATOMIC_RELEASE);
		__atomic_store_n(&header->serial, serial, __ATOMIC_RELEASE);
	}

	/// The write lock a CPU holds on the surface now, as the kext reads its seeds: held where the
	/// lock seed is past the unlock seed (IOSurface moves the first at a write lock, the second at
	/// its unlock, both at a GPU write). None known without the kext's seeds.
	SyncedWrite writeNow() const
	{
		uint32_t lockSeed = 0, unlockSeed = 0;
		if (region == nullptr || !region->surfaceSeeds(surfaceId, &lockSeed, &unlockSeed))
			return {};
		return {lockSeed != unlockSeed, unlockSeed};
	}

	/// Why the block no longer matches the surface's pages, in any process that holds the
	/// block: the surface's seed moved since it last did (a CPU wrote the surface under a lock),
	/// or it was synced while a CPU held its write lock, which the CPU has let go since (the
	/// unlock seed moved): the copy holds the pages as they were mid-write. Caller holds `lock`.
	enum class Change { None, Seed, Unlock };
	Change change() const
	{
		uint32_t synced = 0;
		SyncedWrite write = {};
		if (!syncedSeed(&synced, &write) || IOSurfaceGetSeed(surface) != synced)
			return Change::Seed;
		if (!write.held)
			return Change::None;
		gUnlockAsks.fetch_add(1, std::memory_order_relaxed);
		uint32_t lockSeed = 0, unlockSeed = 0;
		return region != nullptr && region->surfaceSeeds(surfaceId, &lockSeed, &unlockSeed) &&
		               unlockSeed != write.unlockSeed
		           ? Change::Unlock
		           : Change::None;
	}
	bool changed() const { return change() != Change::None; }

	/// At a commit that names the cached surface at CPU generation `gen` (rgfxIOSurfaceNameUses),
	/// where the process has the host fill caches again (gRefill): whether the use asks the host to
	/// fill the device cache again at the generation it holds (RGFX_SURFACE_USE_REFILL), as copy
	/// mode syncs a copy again (change), by the generation's refill record in the shared block's
	/// header (RgfxSurfaceRefill.hpp): the first commit once the surface's unlock seed has moved
	/// past the record's, the read-write lock that moved the generation let go, asks, in any
	/// process, whatever filled the cache meanwhile. A commit whose record is settled asks the kext
	/// nothing; any other asks it for the surface's seeds. Without them the record settles at
	/// once: a fill made mid-write stands until the next read-write lock.
	bool refillAt(uint64_t gen)
	{
		auto *at = reinterpret_cast<uint64_t *>(reinterpret_cast<char *>(header) +
		                                        kRgfxSurfaceRefillOffset);
		uint64_t word = __atomic_load_n(at, __ATOMIC_ACQUIRE);
		if (rgfxRefillSettled(word, gen))
			return false;
		gRefillAsks.fetch_add(1, std::memory_order_relaxed);
		uint32_t lockSeed = 0, unlockSeed = 0;
		const bool seeds =
		    region != nullptr && region->surfaceSeeds(surfaceId, &lockSeed, &unlockSeed);
		const RgfxRefillStep step = rgfxRefillStep(word, gen, seeds, lockSeed, unlockSeed);
		// Never over a record another holder or the kext wrote since it was read.
		if (step.write)
			__atomic_compare_exchange_n(at, &word, step.word, false, __ATOMIC_ACQ_REL,
			                            __ATOMIC_ACQUIRE);
		if (step.midWrite)
			gNamedMidWrite.fetch_add(1, std::memory_order_relaxed);
		if (step.refill)
			gRefillsAtUnlock.fetch_add(1, std::memory_order_relaxed);
		if (step.midWrite || step.refill)
			reportCopies(nowNs());
		return step.refill;
	}

	/// Pages -> copy, under a read lock of the surface taken before `lock` (the views' lock
	/// order, ViewLock), where `always` or the seed moved (changed) as `lock` is taken; records
	/// the seed. Caller holds neither. Nothing in place.
	void upload(bool always)
	{
		if (inPlace) {
			return;
		}
		uint32_t s = 0;
		uint64_t start = nowNs();
		if (lockSurface(surface, kIOSurfaceLockReadOnly, &s) != kIOReturnSuccess) {
			return;
		}
		ViewLock g(lock);
		const Change why = always ? Change::Seed : change();
		const bool copies = why != Change::None;
		// A CPU that holds the surface locked for writing as the copy is made may not have
		// written all of it yet: the copy is synced again at its unlock (changed). One that
		// locks it later moves the seed past `s`.
		const SyncedWrite write = copies ? writeNow() : SyncedWrite{};
		for (size_t k = 0; copies && k < planes.size(); k++) {
			const ShadowPlane &p = planes[k];
			const uint8_t *src = planeBase(surface, k);
			if (src != nullptr) {
				copyRows(p, copy() + p.offset, p.pitch, src, p.shape.rowBytes);
			}
		}
		IOSurfaceUnlock(surface, kIOSurfaceLockReadOnly, &s);
		if (copies) {
			setSynced(s, write);
			countCopy(gUploads, planeBytes(), start);
			if (write.held)
				gUploadsMidWrite.fetch_add(1, std::memory_order_relaxed);
			if (why == Change::Unlock)
				gSyncsAtUnlock.fetch_add(1, std::memory_order_relaxed);
		}
	}

	/// Copy -> pages. A GPU's write, at its buffer's completion, takes no lock: a lock would wait
	/// for the buffer's own writes, which the kext retires only after this, and the seed stays
	/// where the buffer's commit moved it, which the copy recorded then
	/// (rgfxIOSurfaceWritesPosted). A CPU's write goes under the write lock `cpu` holds, taken
	/// before `lock`, and records the seed its unlock leaves, so the next commit does not read
	/// our own write back. Caller holds `lock`. Nothing in place.
	void writeBack(CopyWriteLock *cpu = nullptr)
	{
		if (inPlace || (cpu != nullptr && !cpu->held())) {
			return;
		}
		uint64_t start = nowNs();
		for (size_t k = 0; k < planes.size(); k++) {
			const ShadowPlane &p = planes[k];
			uint8_t *dst = planeBase(surface, k);
			if (dst != nullptr) {
				copyRows(p, dst, p.shape.rowBytes, copy() + p.offset, p.pitch);
			}
		}
		if (cpu != nullptr) {
			const uint32_t s = cpu->unlock();
			// Another process's CPU may hold its own write lock still.
			setSynced(s, writeNow());
		}
		countCopy(gWriteBacks, planeBytes(), start);
	}

	/// Uploads where the block no longer matches the surface's pages (changed): a CPU wrote the
	/// surface under a lock since, or let go of the write lock it held as the block was last
	/// synced. Nothing in place.
	void uploadIfChanged()
	{
		if (inPlace) {
			return;
		}
		{
			ViewLock g(lock);
			if (!changed()) {
				return;
			}
		}
		upload(false);
	}

	/// Plane `p`'s rows from `src` to `dst`, each at its pitch.
	static void copyRows(const ShadowPlane &p, uint8_t *dst, uint64_t dstPitch, const uint8_t *src,
	                     uint64_t srcPitch)
	{
		if (dstPitch == srcPitch) {
			std::memcpy(dst, src, p.shape.rowBytes * p.shape.rows);
			return;
		}
		for (uint64_t r = 0; r < p.shape.rows; r++) {
			std::memcpy(dst + r * dstPitch, src + r * srcPitch, p.shape.rowBytes);
		}
	}
};

namespace {

/// The process's copies by IOSurfaceID. A dead copy's block goes back to the region
/// (RgfxRegion::release), which hands it to the accelerator kext to give out again.
struct Registry {
	std::mutex lock;
	std::map<uint32_t, std::weak_ptr<RgfxSurfaceShadow>> shadows;
};

Registry &registry()
{
	static Registry *r = new Registry(); // never destroyed: copies die at any time
	return *r;
}

} // namespace

RgfxSurfaceShadow::~RgfxSurfaceShadow()
{
	// The buffers that wrote the copy hold it until they finish, so none is left to wait for.
	if (writers != nullptr)
		emptyWriters();
	if (cached)
		gCachedLive.fetch_sub(1, std::memory_order_relaxed);
	// The buffer gives the block back once the host has dropped it (its deallocator); one
	// never made leaves the block to give back here.
	if (buffer != nil)
		buffer = nil;
	else if (block.ok && region != nullptr && shared)
		region->releaseSurface(block.offset);
	else if (block.ok && region != nullptr)
		region->release(block.offset);
	if (surface != nullptr) {
		CFRelease(surface);
	}
}

namespace {

/// Whether `view` lays out the planes of `s` as they are now: as many planes, each of the shape
/// the view was made of. A view the registry holds for the surface's id that does not is not given
/// for the surface (shadowFor), and a texture over a plane past a view's planes is none
/// (RgfxIOSurfaceTexture): the view's planes are where the texture's message says the plane lies,
/// and a plane it does not hold would be sent at offset 0, rows 0 bytes apart.
bool describes(const RgfxSurfaceShadow &view, IOSurfaceRef s)
{
	if (view.planes.size() != std::max<size_t>(IOSurfaceGetPlaneCount(s), 1))
		return false;
	for (size_t k = 0; k < view.planes.size(); k++) {
		const PlaneShape &was = view.planes[k].shape;
		PlaneShape now = {};
		if (!planeShape(s, k, &now) || now.rowBytes != was.rowBytes || now.rows != was.rows ||
		    now.bytesPerElement != was.bytesPerElement || now.elementWidth != was.elementWidth ||
		    now.elementHeight != was.elementHeight)
			return false;
	}
	return true;
}

/// An OSType as its four characters where each is printable, else in hex.
std::string fourCharacters(uint32_t f)
{
	const char c[4] = {char(f >> 24), char(f >> 16), char(f >> 8), char(f)};
	for (char k : c)
		if (k < 0x20 || k >= 0x7f)
			return format("0x%08x", f);
	return format("'%c%c%c%c'", c[0], c[1], c[2], c[3]);
}

/// The views this process found not to describe their surface (describes).
std::atomic<uint64_t> gStaleViews{0};

/// Counts a view that does not describe `asked`, a surface of its id, found `where`, and logs the
/// first few of the process: the surface as the view was made of it, the view's own surface now,
/// and `asked`.
void logStaleView(const RgfxSurfaceShadow &view, IOSurfaceRef asked, const char *where)
{
	const uint64_t n = gStaleViews.fetch_add(1, std::memory_order_relaxed) + 1;
	if (n > 8)
		return;
	IOSurfaceRef own = view.surface;
	rgfxLogLine(@"RGFX: a view does not describe its surface (%s; %llu in the process): made of "
	            @"IOSurface %u, %zu planes, %llu bytes, %s, %llu ms ago, laid out as %zu planes; "
	            @"its surface now %u, %zu planes, %llu bytes, %s; the surface asked is %s, %u, "
	            @"%zu planes, %llu bytes, %s",
	            where, (unsigned long long)n, view.surfaceId, view.madePlaneCount,
	            (unsigned long long)view.madeAlloc, fourCharacters(view.madeFormat).c_str(),
	            (unsigned long long)((nowNs() - view.madeNs) / 1000000), view.planes.size(),
	            IOSurfaceGetID(own), IOSurfaceGetPlaneCount(own),
	            (unsigned long long)IOSurfaceGetAllocSize(own),
	            fourCharacters(IOSurfaceGetPixelFormat(own)).c_str(),
	            asked == own ? "its object" : "another object", IOSurfaceGetID(asked),
	            IOSurfaceGetPlaneCount(asked), (unsigned long long)IOSurfaceGetAllocSize(asked),
	            fourCharacters(IOSurfaceGetPixelFormat(asked)).c_str());
}

/// The process's GPU view of every plane of `surface`, made (and, a copy, synced) on first use.
std::shared_ptr<RgfxSurfaceShadow> shadowFor(IOSurfaceRef surface, RgfxRegion *region,
                                             id<MTLDevice> device, RgfxSerializer *serializer)
{
	// Every holder lays a copy out alike, from the surface's shape alone: each plane's rows in
	// plane order, then the header, then the writers.
	std::vector<ShadowPlane> planes(std::max<size_t>(IOSurfaceGetPlaneCount(surface), 1));
	uint64_t end = 0;
	for (size_t k = 0; k < planes.size(); k++) {
		ShadowPlane &p = planes[k];
		if (!planeShape(surface, k, &p.shape) || planeBase(surface, k) == nullptr) {
			logNoTexture(surface, "plane shape",
			             format("plane %zu has no rows, or no CPU mapping in this process", k));
			return nullptr;
		}
		p.pitch = alignUp(p.shape.rowBytes, kShadowRowAlign);
		p.offset = alignUp(end, kShadowRowAlign);
		end = p.offset + p.pitch * p.shape.rows;
	}
	// In place, the planes stay where the surface's memory holds them, and the block holds the
	// header and the writers alone.
	std::vector<ShadowPlane> own = planes;
	const uint64_t ownWritersAt = sizeof(RgfxSurfaceHeader);
	const uint64_t ownSize =
	    alignUp(ownWritersAt + sizeof(RgfxSurfaceWriters), RgfxRegion::kDefaultBlockAlign);
	const uint64_t ownLength = alignUp(IOSurfaceGetAllocSize(surface), kSurfacePage);
	uint32_t surfaceId = IOSurfaceGetID(surface);
	Registry &r = registry();
	// A view the registry held for the id that does not describe the surface (describes); before
	// `shadow`, so it is let go after the registry's lock.
	std::shared_ptr<RgfxSurfaceShadow> stale;
	std::shared_ptr<RgfxSurfaceShadow> shadow;
	// The new view's `making`, held from its entry in the registry until this returns; after
	// `shadow`, so it is let go before a view not made dies.
	std::unique_lock<std::mutex> making;
	{
		std::unique_lock<std::mutex> g(r.lock);
		// A live copy holds its surface, so its id still names that surface. One that does not
		// lay out the surface's planes as they are now is not given: a new view takes its place
		// in the registry, and it lives on for the textures that hold it.
		for (int found = 0; found < 2; found++) {
			auto it = r.shadows.find(surfaceId);
			shadow = it != r.shadows.end() ? it->second.lock() : nullptr;
			if (shadow == nullptr || shadow == stale)
				break;
			// Its maker may be making its buffer still: once it lets go, the buffer is made,
			// or never will be (the maker logged why), and no view is given.
			g.unlock();
			{
				std::lock_guard<std::mutex> made(shadow->making);
				if (shadow->buffer == nil)
					return nullptr;
			}
			if (describes(*shadow, surface))
				return shadow;
			logStaleView(*shadow, surface, "found for its id");
			stale = std::move(shadow);
			g.lock();
		}
		shadow = std::make_shared<RgfxSurfaceShadow>();
		shadow->surface = (IOSurfaceRef)CFRetain(surface);
		shadow->surfaceId = surfaceId;
		shadow->region = region;
		shadow->madePlaneCount = IOSurfaceGetPlaneCount(surface);
		shadow->madeAlloc = IOSurfaceGetAllocSize(surface);
		shadow->madeFormat = IOSurfaceGetPixelFormat(surface);
		shadow->madeNs = nowNs();
		// The GPU uses the surface's own pages where the host's textures lie over its planes and
		// the kext gives the surface's block in place; else it copies them, as every holder of
		// the surface then does (the kext gives a surface's blocks in one mode).
		RgfxRegion::SurfaceBlock sharedBlock = {};
		std::string notInPlace; // why the view is a copy
		if (!region->hasSurfacePages()) {
			countCopy(kRgfxSurfaceCopiedUnsupported, surface);
			notInPlace = "the device uses no surface in place";
		} else if (!placeInPlace(surface, &own,
		                         gCacheEvery.load(std::memory_order_relaxed)
		                             ? kShapeCopyAlign
		                             : region->surfacePagesAlignment(),
		                         &notInPlace)) {
			countCopy(kRgfxSurfaceCopiedAlignment, surface);
		} else {
			// The bundle asks a device cache for every surface, of any planes and format, as a
			// GPU of its own memory keeps a copy of each surface it uses: a video frame the GPU
			// writes stays in its memory as a window does (design.md, "The device cache"). The
			// outputs of the bundle's own video decoder ask none where the host lands no picture
			// in a cache (RgfxAskUncachedScope), its decode writing their pages.
			// Its layout goes with the ask, by which a host whose GPU shares the CPU's memory
			// keeps a device cache only of a surface its textures cannot use in place.
			const bool cacheable = tAskUncached == 0;
			RgfxSurfacePagesLayout layout = {};
			const bool laidOut = pagesLayout(surface, own, &layout);
			RgfxRegion::PagesAnswer answer = RgfxRegion::kPagesRefused;
			sharedBlock = region->acquireSurfacePages(IOSurfaceGetBaseAddress(surface), ownLength,
			                                          ownSize, surfaceId, cacheable,
			                                          laidOut ? &layout : nullptr, &answer);
			if (sharedBlock.block.ok) {
				shadow->inPlace = true;
				// Whoever made the block decided: a block another holder made cached is cached
				// for this process too.
				shadow->cached = sharedBlock.cached;
				if (shadow->cached) {
					gCachedLive.fetch_add(1, std::memory_order_relaxed);
					gCached.fetch_add(1, std::memory_order_relaxed);
				}
				countView(gInPlace);
			} else if (answer == RgfxRegion::kPagesUnsupported) {
				countCopy(kRgfxSurfaceCopiedUnsupported, surface);
				notInPlace = "the device uses no surface in place, or refused its pages";
			} else if (answer == RgfxRegion::kPagesNoRoom) {
				countCopy(kRgfxSurfaceCopiedNoRoom, surface);
				notInPlace = "the kext had no room for its block in place";
			} else {
				countCopy(kRgfxSurfaceCopiedRefused, surface);
				notInPlace = "the kext gave no block in place";
			}
		}
		uint64_t headerAt = 0, writersAt = ownWritersAt;
		if (shadow->inPlace) {
			shadow->planes = own;
		} else {
			shadow->planes = planes;
			headerAt = alignUp(end, alignof(RgfxSurfaceHeader));
			writersAt = headerAt + sizeof(RgfxSurfaceHeader);
			uint64_t size =
			    alignUp(writersAt + sizeof(RgfxSurfaceWriters), RgfxRegion::kDefaultBlockAlign);
			// The kext finds the surface's shared block by plane 0's pages, which no other
			// surface holds.
			const PlaneShape &first = planes[0].shape;
			sharedBlock =
			    region->acquireSurface(planeBase(surface, 0), first.rowBytes * first.rows, size);
			if (!sharedBlock.block.ok) {
				shadow->block = region->allocate(size);
			}
			if (sharedBlock.block.ok)
				gCopyShared.fetch_add(1, std::memory_order_relaxed);
			else if (shadow->block.ok)
				gCopyOwn.fetch_add(1, std::memory_order_relaxed);
			if (!shadow->block.ok && !sharedBlock.block.ok) {
				uint64_t free = 0;
				std::string room = region->freeBytes(&free)
				                       ? format("%llu bytes free", (unsigned long long)free)
				                       : std::string("the kext keeps its free bytes");
				logNoTexture(surface, "region",
				             format("not in place (%s); the kext gave no shared copy block of "
				                    "%llu bytes; and the region has no room for one of the "
				                    "process's own (%s)",
				                    notInPlace.c_str(), (unsigned long long)size, room.c_str()));
			}
		}
		if (sharedBlock.block.ok) {
			shadow->block = sharedBlock.block;
			shadow->shared = true;
			shadow->serial = sharedBlock.serial;
			shadow->header = reinterpret_cast<RgfxSurfaceHeader *>(shadow->copy() + headerAt);
		}
		if (!shadow->block.ok) {
			return nullptr;
		}
		// A block made for this ask holds an older one's bytes: its writers start empty, before
		// any holder's texture names them.
		shadow->writersAt = writersAt;
		shadow->writers = reinterpret_cast<RgfxSurfaceWriters *>(shadow->copy() + writersAt);
		// The readers follow the writers. Every holder asks the block's size from the writers'
		// end alone, so a holder of a bundle without readers asks the same block, and the
		// readers fit in it whatever the surface's shape: the header starts on kShadowRowAlign
		// (a copy's planes start and end on it; in place, at the block's start), the header and
		// both records fit in that much, and the block ends on a multiple of it.
		static_assert(sizeof(RgfxSurfaceHeader) + 2 * sizeof(RgfxSurfaceWriters) <=
		                  kShadowRowAlign,
		              "the header, the writers and the readers fit in one row alignment");
		static_assert(RgfxRegion::kDefaultBlockAlign % kShadowRowAlign == 0,
		              "a block ends on a row alignment");
		shadow->readers = shadow->writers + 1;
		if (!shadow->shared || sharedBlock.fresh)
			std::memset(static_cast<void *>(shadow->writers), 0, 2 * sizeof(RgfxSurfaceWriters));
		making = std::unique_lock<std::mutex>(shadow->making);
		r.shadows[surfaceId] = shadow;
	}
	uint64_t offset = shadow->block.offset;
	bool shared = shadow->shared;
	void (^letGo)(void) = ^{
		if (shared)
			region->releaseSurface(offset);
		else
			region->release(offset);
	};
	if (shadow->inPlace) {
		// Over the surface's own pages, from its base; the host's span is the block's.
		shadow->buffer = [RgfxBuffer bufferOverSurfacePagesWithContents:shadow->pixels()
		                                                    blockOffset:offset
		                                                      blockSize:shadow->block.size
		                                                         length:ownLength
		                                                        options:MTLResourceStorageModeShared
		                                                    deallocator:letGo
		                                                         device:device
		                                                     serializer:serializer];
	} else {
		shadow->buffer = [RgfxBuffer bufferOverHostMemoryWithContents:shadow->copy()
		                                                regionOffset:offset
		                                                      length:shadow->block.size
		                                                     options:MTLResourceStorageModeShared
		                                                 deallocator:letGo
		                                                      device:device
		                                                  serializer:serializer];
	}
	if (shadow->buffer == nil) {
		logNoTexture(surface, "buffer",
		             format("no buffer over its %s", shadow->inPlace ? "pages" : "copy block"));
		return nullptr;
	}
	// In place, the GPU's view is the pages: nothing to sync. This process's own block takes
	// the pages now; a shared one where no holder has synced it with them since their last CPU
	// write.
	if (shadow->inPlace) {
		return shadow;
	}
	if (shared) {
		shadow->uploadIfChanged();
	} else {
		shadow->upload(true);
	}
	return shadow;
}

/// The wire shape of `d`, as RgfxTexture maps a descriptor.
RgfxTextureDescriptor wireDescriptor(MTLTextureDescriptor *d)
{
	RgfxTextureDescriptor out = {};
	out.pixel_format = static_cast<uint32_t>(d.pixelFormat);
	out.texture_type = static_cast<uint32_t>(d.textureType);
	out.width = static_cast<uint32_t>(d.width);
	out.height = static_cast<uint32_t>(d.height);
	out.depth = static_cast<uint32_t>(d.depth);
	out.mipmap_level_count = static_cast<uint32_t>(d.mipmapLevelCount);
	out.array_length = static_cast<uint32_t>(d.arrayLength);
	out.sample_count = static_cast<uint32_t>(d.sampleCount);
	out.usage = static_cast<uint32_t>(d.usage);
	out.options = static_cast<uint32_t>(d.resourceOptions);
	MTLTextureSwizzleChannels sw = d.swizzle;
	out.swizzle = static_cast<uint32_t>(sw.red) | (static_cast<uint32_t>(sw.green) << 8) |
	              (static_cast<uint32_t>(sw.blue) << 16) | (static_cast<uint32_t>(sw.alpha) << 24);
	return out;
}

/// An IOSurface lock of `options` of a cached view's surface, held for its scope, around the
/// texture's own CPU access: the kext's control function brings the GPU's writes from the
/// device cache into the pages, and a read-write lock moves the surface's CPU generation. Nothing
/// for a view not cached, whose pages are the GPU's.
class CachedLock {
public:
	CachedLock(const RgfxSurfaceShadow &s, IOSurfaceLockOptions options)
	    : m_surface(s.cached ? s.surface : nullptr), m_options(options)
	{
		if (m_surface != nullptr &&
		    lockSurface(m_surface, m_options, &m_seed) != kIOReturnSuccess)
			m_surface = nullptr;
	}
	~CachedLock()
	{
		if (m_surface != nullptr)
			IOSurfaceUnlock(m_surface, m_options, &m_seed);
	}
	CachedLock(const CachedLock &) = delete;
	CachedLock &operator=(const CachedLock &) = delete;

private:
	IOSurfaceRef m_surface;
	IOSurfaceLockOptions m_options;
	uint32_t m_seed = 0;
};

} // namespace

namespace {

// The keep: the views in place the process holds past their textures, so a texture made over the
// same surface soon after finds its view, and the view's block, held, and asks the kext for
// nothing. A compositor makes a texture over its flattened layers' surface each composite and
// lets it go at its end; without the keep each such texture asks the kext for the surface's block
// again, which wires and walks every page of the surface before it finds the block it holds
// (about 140 us for 12 MiB, measured on the RTX 5080 boot, 1.3 asks a composite). WebKit's WebGL
// makes a texture over its drawing buffer each frame (ANGLE's bindTexImage) and lets it go as the
// buffer goes to the display, and the buffer comes back for drawing two or more frames later. A
// block let go sleeps in the kext, but the buffer's trip to the display ends the sleep (as each
// other process lets go of the surface: the kext's dormant blocks, RgfxSurfaceBlocks.hpp), so
// without the keep each frame's texture makes the surface's block anew and waits for the host to
// map its pages (about 40 ms a frame for the 3840x2054 buffer, 15 frames a second, on the RTX
// 5080 boot).
//
// A view stays kept until kKeepNs past its last texture's making, three composites at 60 Hz, and
// while anything else in the process holds its surface (its retain count past the view's own),
// until kKeepHeldNs past it: a ring of buffers turning at a few frames a second keeps its views.
// A surface the view alone holds goes at the first sweep past kKeepNs, so the keep outlives
// neither the surface's last texture nor the process's last other hold of it by much more than
// kKeepNs. The process's commitAndWaitUntilSubmitted calls count no composites: WindowServer makes
// about three a composite (measured on that boot). The keep holds at most kKeepMaxViews views and
// kKeepMaxBytes of their surfaces, the least recently textured let go first, lets go of all of
// them at the process's memory pressure and where the kext has no room for a block (the region's
// reclaim, rgfxIOSurfaceKeepReclaim), and keeps none a texture over it set volatile or empty
// (setPurgeableState:). A kept view holds its surface (CFRetain) as a texture over it does, so
// its IOSurfaceID names no other surface, and its block, so the kext keeps the process's wire of
// the surface's pages as for a live texture: the pages the host maps are the surface's while the
// view is kept, and a texture made over it again is as one made while the last still lived. The
// surface's use count is never touched, so IOSurfaceIsInUse answers as before.
//
// WindowServer's keep also keeps a view of a cached block while another process holds its surface,
// by the kext's count of the surface's clients in the block's header (past WindowServer's own
// one), and lets it go as above once the count is down to WindowServer alone. WindowServer lets a
// layer's contents go as the next ones replace them, and takes them again when they come back: a
// ring of three 3840x2054 buffers turning at 30 Hz came back every 99 ms, and each texture asked
// the kext for the block again, 0.46 to 0.58 ms a frame, while the views went 50 ms past their
// textures (measured on the RTX 5080 boot). The other processes keep by their own holds alone:
// two processes that each kept a view while the other held the surface would keep each other's,
// each view the last hold of the surface in its process, until their caps let them go. A view of
// WindowServer's that another process's kept view alone holds goes once that keep lets go; while
// another process holds the surface of every view WindowServer keeps, its sweep comes kKeepHeldNs
// apart, not kKeepNs. Such views go at the region's reclaim as every kept view does, so the keep
// costs no block a refusal: a texture over one of their surfaces then asks the kext for its block
// again.
constexpr size_t kKeepMaxViews = 8;
constexpr uint64_t kKeepMaxBytes = 256ull << 20;
constexpr uint64_t kKeepNs = 50ull * 1000 * 1000;
constexpr uint64_t kKeepHeldNs = 1000ull * 1000 * 1000;

struct Kept {
	std::shared_ptr<RgfxSurfaceShadow> view;
	uint64_t until = 0;     // nowNs() at which it goes where the view alone holds its surface
	uint64_t heldUntil = 0; // nowNs() at which it goes all the same, unless heldElsewhere
	uint64_t bytes = 0;     // its surface's
};

/// Whether nothing in the process but `view` holds its surface: the view's is its one retain
/// (the textures over it hold the view, not the surface).
bool viewAloneHolds(const RgfxSurfaceShadow &view)
{
	return CFGetRetainCount(view.surface) <= 1;
}

/// Whether the keep keeps a cached block's view while another process holds its surface: in
/// WindowServer, or as the tests set it (rgfxIOSurfaceKeepCountClients); -1 until first asked.
std::atomic<int> gCountsClients{-1};

bool countsClients()
{
	int on = gCountsClients.load(std::memory_order_relaxed);
	if (on < 0) {
		const char *name = getprogname();
		on = name != nullptr && strcmp(name, "WindowServer") == 0;
		int unset = -1;
		if (!gCountsClients.compare_exchange_strong(unset, on, std::memory_order_relaxed))
			on = unset;
	}
	return on != 0;
}

/// Whether another process holds `view`'s surface, where the keep counts them: the kext's count
/// of its clients in the block's header (RgfxSurfaceHeader::clients) is past this process's one.
/// A block not cached has no count.
bool heldElsewhere(const RgfxSurfaceShadow &view)
{
	return countsClients() && view.cached && view.header != nullptr &&
	       __atomic_load_n(&view.header->clients, __ATOMIC_ACQUIRE) > 1;
}

/// Whether `kept` is due to go at `now` (the keep).
bool keepDue(const Kept &kept, uint64_t now)
{
	const RgfxSurfaceShadow &view = *kept.view;
	if (heldElsewhere(view))
		return false;
	return now >= kept.heldUntil || (now >= kept.until && viewAloneHolds(view));
}

struct Keep {
	std::mutex lock;
	std::vector<Kept> views; // the least recently textured first
	uint64_t bytes = 0;
	bool sweeping = false; // a sweep is due
	dispatch_source_t pressure = nil;
};

Keep &keep()
{
	static Keep *k = new Keep(); // never destroyed: views go at any time
	return *k;
}

/// Moves out of `k` (locked) into `gone` the views due to go at `now`, or all of them.
void expire(Keep &k, uint64_t now, bool all, std::vector<std::shared_ptr<RgfxSurfaceShadow>> *gone)
{
	for (auto it = k.views.begin(); it != k.views.end();) {
		if (all || keepDue(*it, now) || it->view->keepVolatile.load(std::memory_order_relaxed)) {
			k.bytes -= it->bytes;
			gone->push_back(std::move(it->view));
			it = k.views.erase(it);
		} else {
			++it;
		}
	}
}

/// Lets go of the views due to go at `now`, or all of them; their blocks go back outside the
/// keep's lock, as the views die.
void sweep(uint64_t now, bool all)
{
	Keep &k = keep();
	std::vector<std::shared_ptr<RgfxSurfaceShadow>> gone;
	{
		std::lock_guard<std::mutex> g(k.lock);
		expire(k, now, all, &gone);
	}
}

/// Schedules a sweep kKeepNs on, where `k` (locked) holds views and none is due, or kKeepHeldNs
/// on where another process holds the surface of every view it holds: a process that stops making
/// textures lets its kept views go all the same.
void armSweep(Keep &k)
{
	if (k.sweeping || k.views.empty())
		return;
	k.sweeping = true;
	const bool allElsewhere = std::all_of(k.views.begin(), k.views.end(),
	                                      [](const Kept &e) { return heldElsewhere(*e.view); });
	const uint64_t in = allElsewhere ? kKeepHeldNs : kKeepNs;
	dispatch_after(dispatch_time(DISPATCH_TIME_NOW, static_cast<int64_t>(in)),
	               dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
		Keep &kk = keep();
		std::vector<std::shared_ptr<RgfxSurfaceShadow>> gone;
		{
			std::lock_guard<std::mutex> g(kk.lock);
			kk.sweeping = false;
			expire(kk, nowNs(), false, &gone);
			armSweep(kk);
		}
	});
}

/// Keeps `view`, whose texture was just made, past its textures (the keep); a copy is not kept.
void keepView(const std::shared_ptr<RgfxSurfaceShadow> &view)
{
	if (!view->inPlace)
		return;
	Keep &k = keep();
	std::vector<std::shared_ptr<RgfxSurfaceShadow>> gone;
	std::lock_guard<std::mutex> g(k.lock);
	const uint64_t now = nowNs();
	auto held = std::find_if(k.views.begin(), k.views.end(),
	                         [&](const Kept &e) { return e.view == view; });
	if (held != k.views.end()) {
		k.bytes -= held->bytes;
		gone.push_back(std::move(held->view));
		k.views.erase(held);
	}
	const uint64_t bytes = IOSurfaceGetAllocSize(view->surface);
	if (!view->keepVolatile.load(std::memory_order_relaxed) && bytes <= kKeepMaxBytes) {
		k.views.push_back({view, now + kKeepNs, now + kKeepHeldNs, bytes});
		k.bytes += bytes;
	}
	expire(k, now, false, &gone);
	while (k.views.size() > kKeepMaxViews || k.bytes > kKeepMaxBytes) {
		k.bytes -= k.views.front().bytes;
		gone.push_back(std::move(k.views.front().view));
		k.views.erase(k.views.begin());
	}
	if (k.pressure == nil) {
		k.pressure = dispatch_source_create(
		    DISPATCH_SOURCE_TYPE_MEMORYPRESSURE, 0,
		    DISPATCH_MEMORYPRESSURE_WARN | DISPATCH_MEMORYPRESSURE_CRITICAL,
		    dispatch_get_global_queue(QOS_CLASS_UTILITY, 0));
		if (k.pressure != nil) {
			dispatch_source_set_event_handler(k.pressure, ^{
				rgfxIOSurfaceKeepFlush();
			});
			dispatch_resume(k.pressure);
		}
	}
	armSweep(k);
	// `gone` may hold the views' last references: they die once the lock is released (its
	// guard goes first, as it was declared last).
}

} // namespace

void rgfxIOSurfaceKeepFlush(void)
{
	sweep(0, true);
}

bool rgfxIOSurfaceKeepReclaim(void)
{
	Keep &k = keep();
	std::vector<std::shared_ptr<RgfxSurfaceShadow>> gone;
	{
		std::lock_guard<std::mutex> g(k.lock);
		expire(k, 0, true, &gone);
	}
	// The views die here, the least recently textured first, each giving its block back.
	const bool any = !gone.empty();
	for (auto &view : gone)
		view.reset();
	return any;
}

void rgfxIOSurfaceKeepSweepAt(uint64_t now)
{
	sweep(now, false);
}

void rgfxIOSurfaceKeepCountClients(bool on)
{
	gCountsClients.store(on ? 1 : 0, std::memory_order_relaxed);
}

void rgfxIOSurfaceNoteSurfaceSeeds(bool on)
{
	gSurfaceSeeds.store(on ? 1 : 0, std::memory_order_relaxed);
}

@interface RgfxIOSurfaceTexture ()
- (std::shared_ptr<RgfxSurfaceShadow>)rgfxShadow;
- (uint64_t)rgfxOffsetInPlane;
@end

@implementation RgfxIOSurfaceTexture {
	std::shared_ptr<RgfxSurfaceShadow> _shadow;
	// One of `_shadow`'s planes: the texture is made only where its view holds the plane, and a
	// view's planes never change, so `_shadow->planes[_plane]` is always the view's own.
	NSUInteger _plane;
	// Bytes from the plane's first byte to the texture's (textureWithDescriptor:...origin:).
	uint64_t _offset;
}

+ (instancetype)textureWithDescriptor:(MTLTextureDescriptor *)descriptor
                            iosurface:(IOSurfaceRef)surface
                                plane:(NSUInteger)plane
                               region:(RgfxRegion *)region
                               device:(id<MTLDevice>)device
                           serializer:(RgfxSerializer *)serializer
{
	return [self textureWithDescriptor:descriptor
	                         iosurface:surface
	                             plane:plane
	                            origin:MTLOriginMake(0, 0, 0)
	                            region:region
	                            device:device
	                        serializer:serializer];
}

+ (instancetype)textureWithDescriptor:(MTLTextureDescriptor *)descriptor
                            iosurface:(IOSurfaceRef)surface
                                plane:(NSUInteger)plane
                               origin:(MTLOrigin)origin
                               region:(RgfxRegion *)region
                               device:(id<MTLDevice>)device
                           serializer:(RgfxSerializer *)serializer
{
	if (descriptor == nil || surface == nullptr || region == nullptr || serializer == nullptr) {
		logNoTexture(surface, "arguments",
		             descriptor == nil  ? "no descriptor"
		             : surface == nullptr ? "no surface"
		                                  : "no device region or transport");
		return nil;
	}
	if (plane >= std::max<size_t>(IOSurfaceGetPlaneCount(surface), 1)) {
		logNoTexture(surface, "plane", format("plane %lu, past its planes", (unsigned long)plane));
		return nil;
	}
	// shadowFor logs why it made no view.
	std::shared_ptr<RgfxSurfaceShadow> shadow = shadowFor(surface, region, device, serializer);
	if (shadow == nullptr) {
		return nil;
	}
	// The plane lies where the view's own planes say, so the view, not the surface's count,
	// bounds it (describes): a view made of the surface as it no longer is gives way to a new
	// one, once; one that still does not lay out the surface's planes makes no texture.
	if (!describes(*shadow, surface)) {
		logStaleView(*shadow, surface, "at a texture's make");
		shadow = shadowFor(surface, region, device, serializer);
		if (shadow == nullptr) {
			return nil;
		}
	}
	if (plane >= shadow->planes.size() || !describes(*shadow, surface)) {
		logNoTexture(surface, "view",
		             format("plane %lu of a view of %zu planes that are not the surface's",
		                    (unsigned long)plane, shadow->planes.size()));
		return nil;
	}
	// The guest sees the shape it asked for; the host's texture lies over the Shared
	// buffer of its view, so it is Shared.
	RgfxTextureDescriptor desc = wireDescriptor(descriptor);
	RgfxTextureDescriptor hostDesc = desc;
	hostDesc.options = (hostDesc.options & ~static_cast<uint32_t>(MTLResourceStorageModeMask)) |
	                   static_cast<uint32_t>(MTLResourceStorageModeShared);
	const ShadowPlane &p = shadow->planes[plane];
	// A texture inside its plane lies in the view, in the plane's rows and elements, each pixel
	// an element.
	const uint64_t offset = origin.y * p.pitch + origin.x * p.shape.bytesPerElement;
	const uint64_t width = descriptor.width, height = descriptor.height;
	if (offset != 0 &&
	    (width == 0 || height == 0 || p.shape.elementWidth != 1 || p.shape.elementHeight != 1 ||
	     origin.y + height > p.shape.rows ||
	     (origin.x + width) * p.shape.bytesPerElement > p.shape.rowBytes)) {
		logNoTexture(surface, "origin",
		             format("%llux%llu at (%lu, %lu) of plane %lu, past the plane",
		                    (unsigned long long)width, (unsigned long long)height,
		                    (unsigned long)origin.x, (unsigned long)origin.y, (unsigned long)plane));
		return nil;
	}
	RgfxCreated created = serializer->createTextureFromIOSurface(
	    [(RgfxResource *)shadow->buffer rgfxObjId], p.offset + offset, p.pitch, shadow->surfaceId,
	    static_cast<uint32_t>(plane), hostDesc, shadow->writersAt, shadow->facts());
	if (created.resource_id == 0) {
		// No resource id left: no texture, as Metal answers one it cannot make.
		logNoTexture(surface, "resource id", "every texture resource id is taken");
		return nil;
	}
	if (serializer->refused(created)) {
		logNoTexture(surface, "create", "the device never got its create");
		return nil;
	}
	RgfxIOSurfaceTexture *t = [[RgfxIOSurfaceTexture alloc] initWithObjId:created.obj_id
	                                                           gpuAddress:0
	                                                           resourceId:created.resource_id
	                                                           descriptor:desc
	                                                               device:device
	                                                           serializer:serializer];
	if (t == nil) {
		logNoTexture(surface, "texture", "the texture object was not made");
		return nil;
	}
	keepView(shadow);
	t->_shadow = std::move(shadow);
	t->_plane = plane;
	t->_offset = offset;
	t->_rgfxSurfaceRoot = t;
	[t rgfxTakeDescriptor:descriptor];
	return t;
}

// The state answers as any texture's (RgfxTexture); a volatile or empty one, which lets the
// surface's pages be purged, also lets its view go from the keep at once, and keeps it out until
// a texture over the surface is set non-volatile again.
- (MTLPurgeableState)setPurgeableState:(MTLPurgeableState)state
{
	if (_shadow != nullptr &&
	    (state == MTLPurgeableStateVolatile || state == MTLPurgeableStateEmpty ||
	     state == MTLPurgeableStateNonVolatile)) {
		_shadow->keepVolatile.store(state != MTLPurgeableStateNonVolatile,
		                            std::memory_order_relaxed);
		if (state != MTLPurgeableStateNonVolatile)
			sweep(nowNs(), false);
	}
	return [super setPurgeableState:state];
}

- (std::shared_ptr<RgfxSurfaceShadow>)rgfxShadow
{
	return _shadow;
}

// The view of `t`, read with no message and no copy, for the encoders' notes below.
static const std::shared_ptr<RgfxSurfaceShadow> &rgfxShadowOfRoot(
    __unsafe_unretained RgfxIOSurfaceTexture *t)
{
	return t->_shadow;
}

- (IOSurfaceRef)iosurface
{
	return _shadow->surface;
}

// The texture lies at its plane's offset in its view's buffer, in the buffer's allocation, so the
// textures over one plane share both, as Metal's over one surface do (measured on the M3 Max under
// macOS 27: one allocationID and one gpuAddress for two textures and a view over a surface, of any
// storage mode); plane 0's lie at the buffer's start, and one inside its plane past the plane's
// offset by its own. A buffer over the surface's pages in place has no GPU address (its create
// names none), and nor do its textures.
- (uint64_t)gpuAddress
{
	uint64_t base = _shadow->buffer.gpuAddress;
	return base == 0 ? 0 : base + _shadow->planes[_plane].offset + _offset;
}

- (uint64_t)rgfxAllocationId
{
	return static_cast<RgfxResource *>(_shadow->buffer).rgfxAllocationId;
}

- (NSUInteger)iosurfacePlane
{
	return _plane;
}

// Bytes from the plane's first byte to the texture's: 0 for a texture over its whole plane.
- (uint64_t)rgfxOffsetInPlane
{
	return _offset;
}

// The bytes the texture takes: its copy of the surface in the region, or the surface's pages its
// buffer lies over in place (SecurityAgent's RenderBox asks as it accounts a surface's texture).
- (NSUInteger)allocatedSize
{
	return _shadow->inPlace ? _shadow->buffer.length : static_cast<NSUInteger>(_shadow->block.size);
}

// The texture's own CPU access reads and writes its view at level 0 / slice 0, in the texels of
// the texture's own format: the copy, a write also going to the surface's pages, or in place the
// pages alone. Row j of the texture's blocks lies at row j of its plane, as Metal lays a texture
// over a surface's plane out (a block-compressed one's rows of blocks on the AMD 5300M and the
// Intel 630 too: oracle_surftex, Q20), whatever the plane's own elements. A texture inside its
// plane (the video driver's, which nothing reads on the CPU) has none, nor has one of a format
// rgfxPixelFormatBlock gives no block (a depth or stencil one, which is Private over a surface).

- (void)getBytes:(void *)pixelBytes
      bytesPerRow:(NSUInteger)bytesPerRow
    bytesPerImage:(NSUInteger)bytesPerImage
       fromRegion:(MTLRegion)region
      mipmapLevel:(NSUInteger)level
            slice:(NSUInteger)slice
{
	RgfxSurfaceCpuSpan span = {};
	if (_offset != 0 || level != 0 || slice != 0 ||
	    !cpuSpan(self.pixelFormat, _shadow->planes[_plane].shape, region, &span)) {
		return;
	}
	_shadow->uploadIfChanged();
	// A cached surface's GPU writes are in the host's device cache: a read lock has the kext
	// bring them into the pages first. Taken before the view's own lock, which a completion
	// takes while the lock may wait for that completion's writes.
	CachedLock cpu(*_shadow, kIOSurfaceLockReadOnly);
	ViewLock g(_shadow->lock);
	const ShadowPlane &p = _shadow->planes[_plane];
	const uint8_t *rows = _shadow->pixels() + p.offset;
	for (uint64_t r = 0; r < span.rows; r++) {
		std::memcpy(static_cast<uint8_t *>(pixelBytes) + r * bytesPerRow,
		            rows + (span.row + r) * p.pitch + span.byte, span.bytes);
	}
}

- (void)getBytes:(void *)pixelBytes
     bytesPerRow:(NSUInteger)bytesPerRow
      fromRegion:(MTLRegion)region
     mipmapLevel:(NSUInteger)level
{
	[self getBytes:pixelBytes
	      bytesPerRow:bytesPerRow
	    bytesPerImage:0
	       fromRegion:region
	      mipmapLevel:level
	            slice:0];
}

- (void)replaceRegion:(MTLRegion)region
          mipmapLevel:(NSUInteger)level
                slice:(NSUInteger)slice
            withBytes:(const void *)pixelBytes
          bytesPerRow:(NSUInteger)bytesPerRow
        bytesPerImage:(NSUInteger)bytesPerImage
{
	RgfxSurfaceCpuSpan span = {};
	if (_offset != 0 || level != 0 || slice != 0 ||
	    !cpuSpan(self.pixelFormat, _shadow->planes[_plane].shape, region, &span)) {
		return;
	}
	_shadow->uploadIfChanged();
	// A cached surface's GPU copy is the host's device cache: a read-write lock brings the
	// GPU's writes into the pages, and has the next command buffer that uses the surface take
	// the CPU's. Taken before the view's own lock, as in getBytes. So is a copy's write lock,
	// under which the copy's rows go into the pages: a buffer's write-back of the copy takes the
	// view's lock before its writes retire, which the lock waits for.
	CachedLock cpu(*_shadow, 0);
	CopyWriteLock write(_shadow->surface, !_shadow->inPlace);
	ViewLock g(_shadow->lock);
	const ShadowPlane &p = _shadow->planes[_plane];
	uint8_t *rows = _shadow->pixels() + p.offset;
	for (uint64_t r = 0; r < span.rows; r++) {
		std::memcpy(rows + (span.row + r) * p.pitch + span.byte,
		            static_cast<const uint8_t *>(pixelBytes) + r * bytesPerRow, span.bytes);
	}
	_shadow->writeBack(&write);
}

- (void)replaceRegion:(MTLRegion)region
          mipmapLevel:(NSUInteger)level
            withBytes:(const void *)pixelBytes
          bytesPerRow:(NSUInteger)bytesPerRow
{
	[self replaceRegion:region
	        mipmapLevel:level
	              slice:0
	          withBytes:pixelBytes
	        bytesPerRow:bytesPerRow
	      bytesPerImage:0];
}

@end

void rgfxIOSurfaceSyncBeforeCommit(RgfxEncoder *enc)
{
	for (const std::shared_ptr<void> &p : enc->takeSurfaceSyncs())
		static_cast<RgfxSurfaceShadow *>(p.get())->uploadIfChanged();
}

RgfxAskUncachedScope::RgfxAskUncachedScope()
{
	tAskUncached++;
}

RgfxAskUncachedScope::~RgfxAskUncachedScope()
{
	tAskUncached--;
}

// The view of the texture over an IOSurface that `resource` is, or views through any views (the
// root each texture records as it is made); null for any other.
static const std::shared_ptr<RgfxSurfaceShadow> *rgfxSurfaceView(__unsafe_unretained id resource)
{
	if (!RgfxIsResource(resource))
		return nullptr;
	__unsafe_unretained RgfxResource *r = (RgfxResource *)resource;
	__unsafe_unretained RgfxIOSurfaceTexture *root = r->_rgfxSurfaceRoot;
	return root != nil ? &rgfxShadowOfRoot(root) : nullptr;
}

// Records on `enc`, once its command buffer, that its commit syncs `view` where it is a copy.
static void rgfxNoteSync(RgfxEncoder *enc, const std::shared_ptr<RgfxSurfaceShadow> &view)
{
	if (view->inPlace)
		return;
	const uint64_t stamp = enc->keepStamp();
	if (view->syncedBy.load(std::memory_order_relaxed) == stamp)
		return;
	view->syncedBy.store(stamp, std::memory_order_relaxed);
	enc->noteSurfaceSync(view);
}

uint64_t rgfxPlaneRowsHeld(const uint64_t *offsets, size_t count, size_t plane, uint64_t pitch,
                           uint64_t end)
{
	if (plane >= count || pitch == 0)
		return 0;
	const uint64_t first = offsets[plane];
	for (size_t k = 0; k < count; k++) {
		if (offsets[k] > first && offsets[k] < end)
			end = offsets[k];
	}
	return end > first ? (end - first) / pitch : 0;
}

uint64_t rgfxIOSurfaceRowsHeld(__unsafe_unretained id texture)
{
	if (!RgfxIsResource(texture))
		return 0;
	__unsafe_unretained RgfxIOSurfaceTexture *root = ((RgfxResource *)texture)->_rgfxSurfaceRoot;
	if (root == nil || root != texture)
		return 0;
	const std::shared_ptr<RgfxSurfaceShadow> &view = rgfxShadowOfRoot(root);
	if (view == nullptr || !view->inPlace || [root rgfxOffsetInPlane] != 0)
		return 0;
	std::vector<uint64_t> offsets;
	for (const ShadowPlane &p : view->planes)
		offsets.push_back(p.offset);
	const size_t plane = root.iosurfacePlane;
	if (plane >= view->planes.size())
		return 0;
	return rgfxPlaneRowsHeld(offsets.data(), offsets.size(), plane, view->planes[plane].pitch,
	                         IOSurfaceGetAllocSize(view->surface));
}

void rgfxIOSurfaceNoteWrite(RgfxEncoder *enc, __unsafe_unretained id texture)
{
	if (enc == nullptr)
		return;
	if (const std::shared_ptr<RgfxSurfaceShadow> *view = rgfxSurfaceView(texture)) {
		enc->noteSurfaceWrite(*view);
		rgfxNoteSync(enc, *view);
	}
}

void rgfxIOSurfaceNoteUse(RgfxEncoder *enc, __unsafe_unretained id resource)
{
	if (enc == nullptr)
		return;
	const std::shared_ptr<RgfxSurfaceShadow> *view = rgfxSurfaceView(resource);
	if (view == nullptr)
		return;
	rgfxNoteSync(enc, *view);
	const uint64_t stamp = enc->keepStamp();
	const bool named = (*view)->cached || gSurfaceOrder.load(std::memory_order_relaxed);
	if (named && (*view)->usedBy.load(std::memory_order_relaxed) != stamp) {
		(*view)->usedBy.store(stamp, std::memory_order_relaxed);
		enc->noteSurfaceUse(*view);
	}
}

void rgfxIOSurfaceSetOrder(bool on)
{
	gSurfaceOrder.store(on, std::memory_order_relaxed);
}

void rgfxIOSurfaceSetRefill(bool on)
{
	gRefill.store(on, std::memory_order_relaxed);
}

void rgfxIOSurfaceSetCacheEvery(bool on)
{
	gCacheEvery.store(on, std::memory_order_relaxed);
}

uint64_t rgfxIOSurfaceCopiedViews(RgfxSurfaceCopyReason reason)
{
	return reason < kRgfxSurfaceCopyReasons ? gCopied[reason].load(std::memory_order_relaxed) : 0;
}

/// Each slot of `rec` that names a queue other than `own`, read as the host reads a writer (its
/// queue, its seqno, then its queue again, a slot whose queue changed between reading as free),
/// added to `waits`: once a queue, at its highest seqno.
static void nameSlots(const RgfxSurfaceWriters *rec, uint64_t own,
                      std::vector<RgfxSurfaceOrderWait> &waits)
{
	for (uint32_t i = 0; i < RGFX_SURFACE_WRITER_SLOTS; i++) {
		const RgfxSurfaceWriter &slot = rec->writers[i];
		const uint64_t queue = __atomic_load_n(&slot.queue_obj_id, __ATOMIC_ACQUIRE);
		if (queue == 0 || queue == own)
			continue;
		const uint64_t seqno = __atomic_load_n(&slot.seqno, __ATOMIC_ACQUIRE);
		if (seqno == 0 || __atomic_load_n(&slot.queue_obj_id, __ATOMIC_ACQUIRE) != queue)
			continue;
		auto it = std::find_if(waits.begin(), waits.end(), [queue](const RgfxSurfaceOrderWait &w) {
			return w.queue_obj_id == queue;
		});
		if (it == waits.end())
			waits.push_back({queue, seqno});
		else if (it->seqno < seqno)
			it->seqno = seqno;
	}
}

std::vector<std::shared_ptr<void>> rgfxIOSurfaceNameUses(
    RgfxEncoder *enc, const std::vector<std::shared_ptr<void>> &writes)
{
	std::vector<std::shared_ptr<void>> uses = enc->takeSurfaceUses();
	if (gCachedLive.load(std::memory_order_relaxed) == 0)
		return uses;
	std::vector<RgfxSurfaceShadow *> named;
	std::vector<RgfxOpSurfaceUse> ops;
	auto name = [&](const std::shared_ptr<void> &p, bool writes) {
		auto *s = static_cast<RgfxSurfaceShadow *>(p.get());
		if (!s->cached)
			return;
		auto it = std::find(named.begin(), named.end(), s);
		if (it != named.end()) {
			if (writes)
				ops[it - named.begin()].flags |= RGFX_SURFACE_USE_WRITES;
			return;
		}
		named.push_back(s);
		RgfxOpSurfaceUse op = {};
		op.block_offset = s->block.offset;
		// As the kext left it at the surface's last read-write CPU lock, in any process.
		op.cpu_gen = __atomic_load_n(&s->header->cpuGen, __ATOMIC_ACQUIRE);
		op.flags = writes ? RGFX_SURFACE_USE_WRITES : 0;
		// The read-write lock that moved the surface to this generation has been let go since its
		// record settled: the host fills the cache again (refillAt).
		if (gRefill.load(std::memory_order_relaxed) && s->refillAt(op.cpu_gen))
			op.flags |= RGFX_SURFACE_USE_REFILL;
		ops.push_back(op);
	};
	for (const auto &w : writes)
		name(w, true);
	for (const auto &u : uses)
		name(u, false);
	if (!ops.empty())
		enc->prependSurfaceUses(ops.data(), ops.size());
	return uses;
}

std::vector<std::shared_ptr<void>> rgfxIOSurfaceNameOrder(
    RgfxEncoder *enc, const std::vector<std::shared_ptr<void>> &writes,
    const std::vector<std::shared_ptr<void>> &uses, uint64_t queueObjId,
    std::vector<RgfxSurfaceOrderWait> *named)
{
	std::vector<std::shared_ptr<void>> reads;
	named->clear();
	if (!gSurfaceOrder.load(std::memory_order_relaxed) || (uses.empty() && writes.empty()))
		return reads;
	// The buffers of other queues it runs after, as the surfaces' blocks name them now: of each
	// surface it writes, the writers and the readers; of each it only reads, the writers. Each
	// was posted before its slot named it, so before this post.
	std::vector<RgfxSurfaceShadow *> seen;
	std::vector<RgfxSurfaceOrderWait> waits;
	for (const auto &w : writes) {
		auto *s = static_cast<RgfxSurfaceShadow *>(w.get());
		if (std::find(seen.begin(), seen.end(), s) != seen.end())
			continue;
		seen.push_back(s);
		if (s->writers != nullptr)
			nameSlots(s->writers, queueObjId, waits);
		nameSlots(s->readers, queueObjId, waits);
	}
	for (const auto &u : uses) {
		auto *s = static_cast<RgfxSurfaceShadow *>(u.get());
		if (std::find(seen.begin(), seen.end(), s) != seen.end())
			continue;
		seen.push_back(s);
		if (s->writers != nullptr)
			nameSlots(s->writers, queueObjId, waits);
		reads.push_back(u);
	}
	enc->prependSurfaceOrder(waits.data(), waits.size());
	*named = std::move(waits);
	return reads;
}

void RgfxSurfaceBindings::rebind(NSUInteger index, __unsafe_unretained id texture, bool overSurface)
{
	auto it = std::find_if(m_bound.begin(), m_bound.end(),
	                       [index](const Bound &b) { return b.index == index; });
	if (!overSurface) {
		if (it != m_bound.end()) {
			m_bound.erase(it);
		}
		return;
	}
	if (it == m_bound.end()) {
		m_bound.push_back({index, texture, false});
		m_changed = true;
	} else if (it->texture != texture) {
		it->texture = texture;
		it->noted = false;
		m_changed = true;
	}
}

void RgfxSurfaceBindings::resident(__unsafe_unretained id resource)
{
	if (resource == nil)
		return;
	if (rgfxSurfaceView(resource) == nullptr &&
	    !(RgfxMemoryShadow::anyLive() && rgfxShadowOf(resource) != nullptr))
		return;
	for (const Resident &r : m_resident) {
		if (r.resource == resource)
			return;
	}
	const bool texture = [resource conformsToProtocol:@protocol(MTLTexture)];
	m_resident.push_back({resource, texture, false});
	m_changed = true;
}

void RgfxSurfaceBindings::noteChangedWrites(RgfxEncoder *enc, const RgfxAirFunction *fn)
{
	m_changed = false;
	m_lastFn = fn;
	if (m_bound.empty() && m_resident.empty())
		return;
	const bool anywhere = fn != nullptr && rgfxAirWritesTextureAnywhere(*fn);
	for (Bound &b : m_bound) {
		if (b.noted) {
			continue;
		}
		bool writes = fn != nullptr && rgfxAirWritesTexture(*fn, static_cast<uint32_t>(b.index));
		if (!writes && (fn == nullptr || anywhere)) {
			const MTLTextureUsage usage = [(id<MTLTexture>)b.texture usage];
			writes = usage == MTLTextureUsageUnknown || (usage & MTLTextureUsageShaderWrite) != 0;
		}
		if (writes) {
			rgfxIOSurfaceNoteWrite(enc, b.texture);
			b.noted = true;
		}
	}
	if (m_resident.empty())
		return;
	bool textures = fn == nullptr, buffers = fn == nullptr;
	if (fn != nullptr) {
		for (const RgfxAirArgument &a : fn->arguments) {
			if (a.kind == RgfxAirKind::IndirectBuffer) {
				buffers = true;
				textures = textures || a.writesTextures;
			}
		}
	}
	for (Resident &r : m_resident) {
		if (r.noted || !(r.texture ? textures : buffers))
			continue;
		rgfxIOSurfaceNoteWrite(enc, r.resource);
		if (enc != nullptr && RgfxMemoryShadow::anyLive()) {
			if (std::shared_ptr<RgfxMemoryShadow> shadow = rgfxShadowOf(r.resource))
				enc->noteShadowUse(shadow, true);
		}
		r.noted = true;
	}
}

RgfxRegion *rgfxIOSurfaceWritesRegion(const std::vector<std::shared_ptr<void>> &writes)
{
	for (const auto &w : writes) {
		auto *s = static_cast<RgfxSurfaceShadow *>(w.get());
		if (s->shared && s->region != nullptr && s->region->hasSurfaceWrites()) {
			return s->region;
		}
	}
	return nullptr;
}

void rgfxIOSurfaceWritesPosted(RgfxRegion *region, const std::vector<std::shared_ptr<void>> &writes,
                               uint64_t queueObjId, uint64_t seqno)
{
	// Two words a surface: its shared block and its IOSurfaceID. A process's own block names no
	// surface the kext knows, and no other process reads it.
	std::vector<RgfxSurfaceShadow *> named;
	std::vector<uint64_t> words;
	words.reserve(writes.size() * 2);
	for (const auto &w : writes) {
		auto *s = static_cast<RgfxSurfaceShadow *>(w.get());
		if (!s->shared || s->region != region ||
		    std::find(named.begin(), named.end(), s) != named.end()) {
			continue;
		}
		named.push_back(s);
		words.push_back(s->block.offset);
		words.push_back(s->surfaceId);
	}
	region->noteSurfaceWrites(queueObjId, seqno, words.data(),
	                          static_cast<uint32_t>(words.size() / 2));
	// The kext moved each surface's seed for the GPU's write, which a copy holds: the copy now
	// stands for the surface as of that seed, over any write a CPU's lock held meanwhile is for.
	for (RgfxSurfaceShadow *s : named) {
		if (s->inPlace) {
			continue;
		}
		ViewLock g(s->lock);
		s->setSynced(IOSurfaceGetSeed(s->surface));
	}
}

void rgfxIOSurfaceRetire(RgfxRegion *region, uint64_t queueObjId, uint64_t seqno)
{
	region->retireSurfaceWrites(queueObjId, seqno);
}

void rgfxIOSurfaceNoteCommitted(const std::vector<std::shared_ptr<void>> &writes, id queue,
                                uint64_t queueObjId, uint64_t seqno,
                                const std::vector<RgfxSurfaceOrderWait> &named)
{
	std::vector<RgfxSurfaceShadow *> done;
	for (const auto &w : writes) {
		auto *s = static_cast<RgfxSurfaceShadow *>(w.get());
		if (std::find(done.begin(), done.end(), s) != done.end()) {
			continue;
		}
		done.push_back(s);
		s->noteWriter(queue, queueObjId, seqno, named);
	}
}

void rgfxIOSurfaceNoteRead(const std::vector<std::shared_ptr<void>> &reads, id queue,
                           uint64_t queueObjId, uint64_t seqno,
                           const std::vector<RgfxSurfaceOrderWait> &named)
{
	for (const auto &r : reads)
		static_cast<RgfxSurfaceShadow *>(r.get())->noteReader(queue, queueObjId, seqno, named);
}

void rgfxIOSurfaceNoteFinished(const std::vector<std::shared_ptr<void>> &writes,
                               const std::vector<std::shared_ptr<void>> &reads,
                               uint64_t queueObjId, uint64_t seqno)
{
	for (const std::vector<std::shared_ptr<void>> *views : {&writes, &reads}) {
		for (const auto &v : *views)
			static_cast<RgfxSurfaceShadow *>(v.get())->noteFinished(queueObjId, seqno);
	}
}

uint64_t rgfxIOSurfaceLocksUnderView(void)
{
	return gLocksUnderView.load(std::memory_order_relaxed);
}

uint64_t rgfxIOSurfaceStaleViews(void)
{
	return gStaleViews.load(std::memory_order_relaxed);
}

void rgfxIOSurfaceKeepViewPlanesForTests(IOSurfaceRef surface, size_t keep)
{
	Registry &r = registry();
	std::lock_guard<std::mutex> g(r.lock);
	auto it = r.shadows.find(IOSurfaceGetID(surface));
	std::shared_ptr<RgfxSurfaceShadow> view = it != r.shadows.end() ? it->second.lock() : nullptr;
	// A vector of its own, so that the planes past `keep` are not held at all.
	if (view != nullptr && keep < view->planes.size())
		view->planes = std::vector<ShadowPlane>(view->planes.begin(), view->planes.begin() + keep);
}

uint64_t rgfxIOSurfaceNilLog(IOSurfaceRef surface, const char *cause, std::string *line)
{
	NilLog &l = nilLog();
	std::lock_guard<std::mutex> g(l.lock);
	auto it = l.seen.find(NilLog::key(surface, cause));
	if (it == l.seen.end()) {
		line->clear();
		return 0;
	}
	*line = it->second.second;
	return it->second.first;
}

bool rgfxIOSurfaceWritesInPlace(const std::vector<std::shared_ptr<void>> &writes)
{
	for (const auto &w : writes) {
		if (!static_cast<RgfxSurfaceShadow *>(w.get())->inPlace) {
			return false;
		}
	}
	return true;
}

void rgfxIOSurfaceWriteBack(const std::vector<std::shared_ptr<void>> &writes)
{
	std::vector<RgfxSurfaceShadow *> done;
	for (const auto &w : writes) {
		auto *s = static_cast<RgfxSurfaceShadow *>(w.get());
		if (std::find(done.begin(), done.end(), s) != done.end()) {
			continue;
		}
		done.push_back(s);
		ViewLock g(s->lock);
		s->writeBack();
	}
}
