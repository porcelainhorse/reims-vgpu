/*
 * RgfxMetalDevice (Unsupported): see the header. Our own ObjC++.
 */

#import "RgfxMetalDevice+Unsupported.h"

#import "RgfxBlockCall.h"
#import "RgfxUnsupported.h"

namespace {
constexpr const char *kRayTracing = "ray tracing";
constexpr const char *kFunctionPointers = "function pointers";
constexpr const char *kMetal4 = "the Metal 4 API";
constexpr const char *kArgumentLayouts = "argument buffers of a layout object";

// Metal's refusal of a Metal 4 member on a device that answers NO to supportsFamily: of
// MTLGPUFamilyMetal4, as this one does: MTLDeviceErrorDomain's MTLDeviceErrorNotSupported (measured:
// newArchiveWithURL:error: at every URL, nil among them, macOS 26.7.1, the AMD Radeon Pro 5300M and
// the Intel UHD 630, tools/oracle/oracle_urls.m). The domain is named by its string: its symbol is
// macOS 26.4's, and the bundle loads from macOS 11 on.
NSError *metal4Refusal()
{
	return [NSError errorWithDomain:@"MTLDeviceErrorDomain"
	                           code:1 // MTLDeviceErrorNotSupported
	                       userInfo:@{NSLocalizedDescriptionKey : @"Device does not support Metal 4."}];
}
} // namespace

@implementation RgfxMetalDevice (Unsupported)

// --- ray tracing ---------------------------------------------------------------------

- (id<MTLAccelerationStructure>)newAccelerationStructureWithSize:(NSUInteger)size
{
	RGFX_UNSUPPORTED(kRayTracing);
	return nil;
}

- (id<MTLAccelerationStructure>)newAccelerationStructureWithDescriptor:
    (MTLAccelerationStructureDescriptor *)descriptor
{
	RGFX_UNSUPPORTED(kRayTracing);
	return nil;
}

// --- function pointers and dynamic libraries ------------------------------------------

- (id<MTLFunctionHandle>)functionHandleWithBinaryFunction:(id<MTL4BinaryFunction>)function
{
	RGFX_UNSUPPORTED(kFunctionPointers);
	return nil;
}

// --- pipelines the wire does not create -----------------------------------------------

- (id<MTLRenderPipelineState>)
    newRenderPipelineStateWithTileDescriptor:(MTLTileRenderPipelineDescriptor *)descriptor
                                     options:(MTLPipelineOption)options
                                  reflection:(MTLAutoreleasedRenderPipelineReflection *)reflection
                                       error:(NSError **)error
{
	if (reflection)
		*reflection = nil;
	RGFX_UNSUPPORTED_ERROR(error, "tile pipelines (no tile pipeline create on the wire)");
	return nil;
}

- (void)newRenderPipelineStateWithTileDescriptor:(MTLTileRenderPipelineDescriptor *)descriptor
                                         options:(MTLPipelineOption)options
                               completionHandler:
                                   (MTLNewRenderPipelineStateWithReflectionCompletionHandler)
                                       completionHandler
{
	NSError *error = nil;
	RGFX_UNSUPPORTED_ERROR(&error, "tile pipelines (no tile pipeline create on the wire)");
	completionHandler = [completionHandler copy];
	RgfxRunCreation(^{
		if (completionHandler)
			completionHandler(nil, nil, error);
	});
}

// --- resources the device does not make -----------------------------------------------

- (id<MTLBuffer>)newBufferWithLength:(NSUInteger)length
                             options:(MTLResourceOptions)options
             placementSparsePageSize:(MTLSparsePageSize)placementSparsePageSize
{
	RGFX_UNSUPPORTED("placement sparse buffers");
	return nil;
}

// Textures shared with another process by handle: the wire names no texture across processes
// (IOSurface-backed textures are the shared ones it carries).
- (id<MTLTexture>)newSharedTextureWithDescriptor:(MTLTextureDescriptor *)descriptor
{
	RGFX_UNSUPPORTED("shared textures (no cross-process texture handle on the wire)");
	return nil;
}

- (id<MTLTexture>)newSharedTextureWithHandle:(MTLSharedTextureHandle *)sharedHandle
{
	RGFX_UNSUPPORTED("shared textures (no cross-process texture handle on the wire)");
	return nil;
}

- (id<MTLTensor>)newTensorWithDescriptor:(MTLTensorDescriptor *)descriptor
                                   error:(NSError **)error
{
	RGFX_UNSUPPORTED_ERROR_IN(error, "tensors", MTLTensorDomain, MTLTensorErrorInternalError);
	return nil;
}

- (id<MTLTensor>)newTensorWithDescriptor:(MTLTensorDescriptor *)descriptor
                             attachments:(MTLTensorBufferAttachments *)attachments
                                   error:(NSError **)error
{
	RGFX_UNSUPPORTED_ERROR_IN(error, "tensors", MTLTensorDomain, MTLTensorErrorInternalError);
	return nil;
}

// --- counters and shader logging ------------------------------------------------------

- (id<MTLCounterSampleBuffer>)newCounterSampleBufferWithDescriptor:
                                  (MTLCounterSampleBufferDescriptor *)descriptor
                                                             error:(NSError **)error
{
	RGFX_UNSUPPORTED_ERROR_IN(error, "counter sampling", MTLCounterErrorDomain,
	                          MTLCounterSampleBufferErrorInvalid);
	return nil;
}

- (id<MTLLogState>)newLogStateWithDescriptor:(MTLLogStateDescriptor *)descriptor
                                       error:(NSError **)error
{
	RGFX_UNSUPPORTED_ERROR_IN(error, "shader log states (none on the wire or in the host's runtime)",
	                          MTLLogStateErrorDomain, MTLLogStateErrorInvalid);
	return nil;
}

// --- the Metal 4 API ---------------------------------------------------------------------

- (id<MTL4CommandQueue>)newMTL4CommandQueue
{
	RGFX_UNSUPPORTED(kMetal4);
	return nil;
}

- (id<MTL4CommandQueue>)newMTL4CommandQueueWithDescriptor:(MTL4CommandQueueDescriptor *)descriptor
                                                    error:(NSError **)error
{
	RGFX_UNSUPPORTED_ERROR(error, kMetal4);
	return nil;
}

- (id<MTL4CommandBuffer>)newCommandBuffer
{
	RGFX_UNSUPPORTED(kMetal4);
	return nil;
}

- (id<MTL4CommandAllocator>)newCommandAllocator
{
	RGFX_UNSUPPORTED(kMetal4);
	return nil;
}

- (id<MTL4CommandAllocator>)newCommandAllocatorWithDescriptor:
                                (MTL4CommandAllocatorDescriptor *)descriptor
                                                        error:(NSError **)error
{
	RGFX_UNSUPPORTED_ERROR(error, kMetal4);
	return nil;
}

- (id<MTL4Compiler>)newCompilerWithDescriptor:(MTL4CompilerDescriptor *)descriptor
                                        error:(NSError **)error
{
	RGFX_UNSUPPORTED_ERROR(error, kMetal4);
	return nil;
}

- (id<MTL4ArgumentTable>)newArgumentTableWithDescriptor:(MTL4ArgumentTableDescriptor *)descriptor
                                                  error:(NSError **)error
{
	RGFX_UNSUPPORTED_ERROR(error, kMetal4);
	return nil;
}

// Metal's refusal of a device without Metal 4, at every URL (metal4Refusal).
- (id<MTL4Archive>)newArchiveWithURL:(NSURL *)url error:(NSError **)error
{
	(void)url;
	RGFX_UNSUPPORTED(kMetal4);
	if (error)
		*error = metal4Refusal();
	return nil;
}

- (id<MTL4CounterHeap>)newCounterHeapWithDescriptor:(MTL4CounterHeapDescriptor *)descriptor
                                              error:(NSError **)error
{
	RGFX_UNSUPPORTED_ERROR(error, kMetal4);
	return nil;
}

- (id<MTL4PipelineDataSetSerializer>)newPipelineDataSetSerializerWithDescriptor:
    (MTL4PipelineDataSetSerializerDescriptor *)descriptor
{
	RGFX_UNSUPPORTED(kMetal4);
	return nil;
}

- (id<MTLTextureViewPool>)newTextureViewPoolWithDescriptor:(MTLResourceViewPoolDescriptor *)descriptor
                                                     error:(NSError **)error
{
	RGFX_UNSUPPORTED_ERROR(error, kMetal4);
	return nil;
}

// --- the base classes' creators no header declares --------------------------------------
//
// Creators IOGPUMetalDevice and _MTLDevice implement, measured with their type encodings by
// enumerating both classes on macOS 27's x86-64 slice and on the guest's macOS 26 (each of the
// guest's is on macOS 27's list). Inherited, they build on the base device's compiler, IOGPU
// objects or OpenGL state, none of which the device has, and answer nil without an error; so
// each answers as the bundle's other unsupported members do. tests/inherited_tests.mm keeps every
// base-class creator either answered by the device or in its list of those left to the base.

// Ray tracing: acceleration structures over a buffer (`@32@0:8@16Q24`, `@40@0:8@16Q24Q32`), of a
// size at a resource index (`@32@0:8Q16Q24`) or with a descriptor (`@32@0:8Q16@24`), and
// intersection function tables (`@24@0:8@16`).
- (id<MTLAccelerationStructure>)newAccelerationStructureWithBuffer:(id<MTLBuffer>)buffer
                                                            offset:(NSUInteger)offset
{
	RGFX_UNSUPPORTED(kRayTracing);
	return nil;
}

- (id<MTLAccelerationStructure>)newAccelerationStructureWithBuffer:(id<MTLBuffer>)buffer
                                                            offset:(NSUInteger)offset
                                                     resourceIndex:(NSUInteger)resourceIndex
{
	RGFX_UNSUPPORTED(kRayTracing);
	return nil;
}

- (id<MTLAccelerationStructure>)newAccelerationStructureWithSize:(NSUInteger)size
                                                   resourceIndex:(NSUInteger)resourceIndex
{
	RGFX_UNSUPPORTED(kRayTracing);
	return nil;
}

- (id<MTLAccelerationStructure>)newAccelerationStructureWithSize:(NSUInteger)size
                                                  withDescriptor:(id)descriptor
{
	RGFX_UNSUPPORTED(kRayTracing);
	return nil;
}

- (id<MTLIntersectionFunctionTable>)newIntersectionFunctionTableWithDescriptor:(id)descriptor
{
	RGFX_UNSUPPORTED(kRayTracing);
	return nil;
}

// Dynamic libraries (`@40@0:8@16@24^@32`, `@32@0:8@16^@24` twice, `@40@0:8@16Q24^@32`) and binary
// libraries (`@40@0:8Q16@24^@32`).
- (id<MTLDynamicLibrary>)newDynamicLibrary:(id<MTLLibrary>)library
                         computeDescriptor:(id)descriptor
                                     error:(NSError **)error
{
	RGFX_UNSUPPORTED_ERROR_IN(error, "dynamic libraries", MTLDynamicLibraryDomain,
	                          MTLDynamicLibraryErrorUnsupported);
	return nil;
}

- (id<MTLDynamicLibrary>)newDynamicLibraryWithDescriptor:(id)descriptor error:(NSError **)error
{
	RGFX_UNSUPPORTED_ERROR_IN(error, "dynamic libraries", MTLDynamicLibraryDomain,
	                          MTLDynamicLibraryErrorUnsupported);
	return nil;
}

- (id<MTLDynamicLibrary>)newDynamicLibraryFromURL:(NSURL *)url error:(NSError **)error
{
	RGFX_UNSUPPORTED_ERROR_IN(error, "dynamic libraries", MTLDynamicLibraryDomain,
	                          MTLDynamicLibraryErrorUnsupported);
	return nil;
}

- (id<MTLDynamicLibrary>)newDynamicLibraryWithURL:(NSURL *)url
                                          options:(NSUInteger)options
                                            error:(NSError **)error
{
	RGFX_UNSUPPORTED_ERROR_IN(error, "dynamic libraries", MTLDynamicLibraryDomain,
	                          MTLDynamicLibraryErrorUnsupported);
	return nil;
}

// No options is refused before the URL is looked at, at every URL, nil among them, with "At least
// one option must be set." (MTLBinaryArchiveDomain 2, measured: macOS 26.7.1, the AMD Radeon Pro
// 5300M and the Intel UHD 630, and macOS 27.0.1, the M3 Max, alike, tools/oracle/oracle_urls.m).
- (id)newBinaryLibraryWithOptions:(NSUInteger)options url:(NSURL *)url error:(NSError **)error
{
	(void)url;
	if (options != 0) {
		RGFX_UNSUPPORTED_ERROR(error, "binary libraries");
		return nil;
	}
	RgfxLogUnsupported([self class], _cmd, "binary libraries");
	if (error)
		*error = [NSError errorWithDomain:MTLBinaryArchiveDomain
		                             code:MTLBinaryArchiveErrorUnexpectedElement
		                         userInfo:@{NSLocalizedDescriptionKey : @"At least one option must be set."}];
	return nil;
}

// Argument buffers of a layout (`@24@0:8@16` each): the host lays arguments out
// (RgfxArgumentEncoder.h), from their descriptors, never from a layout object of the base's.
- (id<MTLArgumentEncoder>)newArgumentEncoderWithLayout:(id)layout
{
	RGFX_UNSUPPORTED(kArgumentLayouts);
	return nil;
}

- (id<MTLArgumentEncoder>)newIndirectArgumentEncoderWithLayout:(id)layout
{
	RGFX_UNSUPPORTED(kArgumentLayouts);
	return nil;
}

- (id)newIndirectArgumentBufferLayoutWithStructType:(id)structType
{
	RGFX_UNSUPPORTED(kArgumentLayouts);
	return nil;
}

// Queues, allocators, events and assertions the wire has nothing for (`@16@0:8` each but the
// assertion's `@32@0:8q16^@24`).
- (id)newCommandQueue4
{
	RGFX_UNSUPPORTED("newCommandQueue4's queue (none on the wire)");
	return nil;
}

- (id)newDevicePoolAliasedCommandAllocator
{
	RGFX_UNSUPPORTED("aliased command allocators (none on the wire)");
	return nil;
}

- (id)newLateEvalEvent
{
	RGFX_UNSUPPORTED("late-evaluated events (none on the wire)");
	return nil;
}

- (id)newPerformanceStateAssertion:(NSInteger)state error:(NSError **)error
{
	RGFX_UNSUPPORTED_ERROR(error, "performance state assertions (none on the wire)");
	return nil;
}

// Pipeline libraries of a file (`@32@0:8@16^@24`) and profiles (`@24@0:8Q16`).
- (id)newPipelineLibraryWithFilePath:(NSString *)filePath error:(NSError **)error
{
	RGFX_UNSUPPORTED_ERROR(error, "pipeline libraries");
	return nil;
}

- (id)newProfileWithExecutionSize:(NSUInteger)executionSize
{
	RGFX_UNSUPPORTED("profiles");
	return nil;
}

// Counters' resolve (`@40@0:8@16{_NSRange=QQ}24`) and textures shared by handle at a resource
// index (`@32@0:8@16Q24`), as their public forms above.
- (NSData *)resolveCounters:(id<MTLCounterSampleBuffer>)buffer withRange:(NSRange)range
{
	RGFX_UNSUPPORTED("counter sampling");
	return nil;
}

- (id<MTLTexture>)newSharedTextureWithHandle:(MTLSharedTextureHandle *)sharedHandle
                           withResourceIndex:(NSUInteger)resourceIndex
{
	RGFX_UNSUPPORTED("shared textures (no cross-process texture handle on the wire)");
	return nil;
}

@end
