/*
 * RgfxGLLowering: a GL shader's IR lowered to an AIR module, and that module to a .metallib of
 * one function (RgfxMetallibWriter.hpp), in the process that compiles the shader.
 *
 * macOS's OpenGL renderer over Metal (AppleMetalOpenGLRenderer) hands a Metal device each shader
 * as GL IR (newFunctionWithGLCoreIR:inputsDescription:functionType:) and each variant of it as
 * plugin data (newFunctionWithPluginData:bitcodeType:). Metal's own devices lower the two to AIR
 * in their compiler service, through the GL code generator the system ships beside the renderer
 * (AppleMetalOpenGLRenderer.bundle/Contents/PlugIns/libGLDPlugin<V>.dylib, V the version of
 * GPUCompiler.framework, whose libLLVM.dylib it runs on). The device has no compiler service, so
 * it calls the same generator here, in place, through its C entry points:
 *   - oglCodeGenServiceInitialize(), once per process;
 *   - oglCodeGenServiceGenerateIRWithPluginDataAndPluginReturnData(context, ir, irLength,
 *     plugin, pluginLength, &returnData, &returnLength), which answers the llvm::Module of the
 *     variant in `context` (an LLVMContextRef), and its return data: a binary property list,
 *     malloc'ed, that Metal answers as the pipeline reflection's vertexPluginReturnData,
 *     fragmentPluginReturnData or pluginReturnData (measured: macOS 26.7.1, the same bytes).
 * The module is standard AIR (measured: macOS 26.7.1, AIR 2.3, entry point `__main`, the
 * language "OpenGL GLSL"), which the system's LLVM writes as bitcode through its C API. The
 * module and its context are disposed of before the call returns.
 *
 * Two things in the generator's stage metadata make Metal refuse a pipeline of its functions, so
 * a vertex or fragment variant's metadata is first made what `metal` writes
 * (RgfxGLNormalizeStageText, over the module's text, which the system's LLVM parses again):
 *   - an integer varying's type name is the signed one in a fragment input and the unsigned one
 *     in the vertex output for the same GLSL `flat int` (measured: macOS 26.7.1, "int" and
 *     "uint" for user(slot8)), and Metal fails the pipeline's link on the difference ("The type
 *     of fragment input user(slot8) does not match the type of the corresponding vertex shader
 *     output"); the renderer then draws the shader in software. An integer varying is named
 *     unsigned on both sides: AIR holds no signedness, and the bits pass as they are;
 *   - an output without air.arg_type_name (measured: a fragment output of air.depth, from
 *     gl_FragDepth) makes Metal's reflection reader dereference a null string and end the
 *     process. Such a node gets the type name of its value's LLVM type and, where it has none, an
 *     air.arg_name "#<kind>", as the generator names air.position ("#air_position").
 * A node that has both, or only lacks air.arg_name (each fragment's air.render_target, measured
 * to make pipelines), is left as it is.
 *
 * More in the generator's module is not in the AIR `metal` writes. Metal's devices take it, but
 * the Vulkan host's runtime reads AIR's metadata as a closed grammar and refuses a pipeline of a
 * function with any of it (metal2vulkan's AIR decoder): every GL pipeline was refused on a 5080
 * host ("UnknownKey" at gld.plugin_info, macOS 26.6.1), and the rest was found by compiling the
 * pipelines of tools/gl_cases.m, dumped through tools/gl_inject.mm on the Intel 630, with the
 * decoder's compile API (macOS 26.7.1: 6 of 29 still refused after the first rule). The
 * generator links its builtins (GLDBuiltins.metal and the like, compiled as AIR 2.8 and Metal
 * 4.0) into a shader that uses them, so their lists' entries follow the module's own. Every
 * variant's module, a kernel's too, is made what one compile of `metal` writes:
 *   - the generator's own named lists (gld.plugin_info, which holds the plugin return data the
 *     generator also answers apart) are dropped;
 *   - air.version and air.language_version hold the module's own entry alone, the first, and the
 *     language, "OpenGL GLSL" 1.0.0, is "Metal" at the AIR version's major and minor (2.3, the
 *     language `metal -mmacosx-version-min=11.0` writes with AIR 2.3);
 *   - air.compile_options holds the module's own option of each kind (fast math, framebuffer
 *     fetch, denormals), the first, and no air.compile.native_double_disable, which `metal` does
 *     not write; llvm.module.flags holds the first flag of each name (the module's own limits,
 *     4096 buffers, not the builtins' 31);
 *   - an input's attribute name, a bare string after its air.location_index's two operands, is
 *     dropped (the input keeps its air.arg_name, which holds the same name), in a vertex
 *     function's inputs and a kernel's alike, and so is a patch control point input's field's.
 *     Where such a field's air.arg_type_name holds the key itself in place of a type name, it
 *     gets the Metal name of its member of the control point function's result (`metal` writes
 *     one field per member, in order). The kernel the renderer makes for a tessellated draw, of
 *     its vertex and control shaders, takes the draw's vertices as a patch control point input
 *     whose field has both ("attrib_0", and the key for its type): metal2vulkan refused that
 *     kernel's compute pipeline ("UnknownKey" at its argument 0, "attrib_0"), and the renderer
 *     drew the draw's vertices in software (measured: macOS 27.0.1 arm64, a quad patch through a
 *     tessellation control and evaluation shader, m3-max-30129 and m3-max-30158). The draw's
 *     post-tessellation vertex function takes the control points' gl_Position as a field with the
 *     key air.position after its location, which `metal` writes in no field; it goes too, as
 *     everything between a field's location and its type name does: metal2vulkan refused the
 *     draw's render pipeline at it ("UnknownKey", key air.position at its argument 1,
 *     m3-max-30327);
 *   - a flat fragment input has no sampling key: `metal` writes [[flat]] as air.flat alone, and
 *     the generator writes air.center before it;
 *   - a buffer input has the air.address_space `metal` writes, its parameter's pointer's, and,
 *     where it lacks them, the air.arg_type_size and air.arg_type_align_size of the pointer's
 *     pointee (an integer, half, float or double, or a vector or array of them; no size is added
 *     for any other). The generator writes no address space for a uniform buffer, and no pointee
 *     size for one with air.buffer_size, whose pointer it types <4 x float> addrspace(2)* and
 *     names "uchar" (measured: macOS 26.7.1, gl_cases' block case). The device's reflection reads
 *     both: without them a pipeline had no reflection, and on the RTX 5080 host gl_cases'
 *     uniforms and block cases read black, as did its texture cases, whose fragments have such
 *     a buffer (m3-max-3831; with them, they pass, m3-max-3947). metal2vulkan refuses a size
 *     other than the pointee's allocation size: the type name's size made it refuse the block
 *     case's pipelines, and the renderer drew that case in software (m3-max-3947).
 * The kernel of a tessellated draw is one Metal compiles in no kernel: its patch control point
 * input names a control point function the generator declares and Metal's own devices define from
 * the compute pipeline's stage input descriptor, and Metal refuses a pipeline of the kernel as it
 * is (measured: macOS 27.0.1, the M3 Max, m3-max-30197), so the renderer drew the draw's vertex
 * and control stages in software. The variant keeps its module's normalized text
 * (RgfxGLLowered::stageInText), and its pipeline is one of the kernel made a kernel without the
 * input under the pipeline's descriptor (RgfxGLSpecializeStageIn).
 * The generator declares the AIR functions a variant calls in an order that can change from one
 * lowering of the variant to the next, in one process and across runs (measured: macOS 26.7.2,
 * Heaven run twice in one boot on an RTX 3090: 24 of its 135 fragment variants, their
 * air.sample_texture_* declarations in another order, no other line changed), and the bitcode
 * writes the module's functions in its order. The declarations are put in the order of their
 * names (RgfxGLSortDeclarations), so each lowering of a variant writes the same bytes.
 * Measured on an x86 Mac (macOS 26.7.1, Intel UHD 630 and AMD 5300M): the .metallib of each of
 * a vertex and a fragment shader's variants loads with newLibraryWithData:, makes a render
 * pipeline, and draws what the renderer's own pipeline draws (tools/gld_lower.m).
 *
 * Our own C++. It calls the system's libraries in place; nothing of them is copied.
 */
#ifndef RGFX_GL_LOWERING_HPP_
#define RGFX_GL_LOWERING_HPP_

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

#include "RgfxMetallibWriter.hpp"

/// A GL shader variant, lowered.
struct RgfxGLLowered {
	std::vector<uint8_t> metallib;   // a .metallib of the one function (RgfxWriteMetallib)
	std::string entry;               // its entry point
	RgfxMetallibStage stage = RgfxMetallibStage::Vertex;
	std::vector<uint8_t> returnData; // the generator's return data (empty where it gave none)
	// A kernel whose entry takes a patch control point input: its module's normalized text, which
	// RgfxGLSpecializeStageIn makes a kernel of under each stage input descriptor (empty for any
	// other variant).
	std::string stageInText;
};

/// A compute pipeline's stage input descriptor (MTLStageInputOutputDescriptor), as the fetch reads
/// it: each attribute's MTLAttributeFormat, offset and buffer index, each buffer layout's stride,
/// MTLStepFunction and step rate, the MTLIndexType and the index buffer's index.
struct RgfxGLStageIn {
	struct Attribute {
		uint32_t format = 0, offset = 0, bufferIndex = 0;
	};
	struct Layout {
		uint32_t stride = 0, stepFunction = 1, stepRate = 1;
	};
	Attribute attributes[31];
	Layout layouts[31];
	uint32_t indexType = 0, indexBufferIndex = 0;
	/// Every field above, as one string: two descriptors fetch alike where their keys are equal.
	std::string key() const;
};

/// Lowers the `irLength` bytes of GL IR at `ir` (the renderer's IR after its u32 length) with
/// the `pluginLength` bytes of plugin data at `plugin` to `out`. False, with `why`, where the
/// system's libraries are not there, the generator makes no module, the module names no entry
/// point, or the system's LLVM refuses the module's normalized text. Calls are serialised: the generator is one per process.
bool RgfxLowerGLIR(const uint8_t *ir, size_t irLength, const uint8_t *plugin, size_t pluginLength,
                   RgfxGLLowered &out, std::string &why);

/// The Metal type names (as `metal` writes air.arg_type_name: "float", "half4", "uint2", "bool";
/// integers unsigned; "" for a type with none) of an AIR entry point's outputs, its result's
/// members in order (or its one result), and of its parameters.
struct RgfxGLSignature {
	std::vector<std::string> outputs, parameters;
};

/// Makes `text`, a module as LLVM prints it, follow the rules above: the module's (no gld.*
/// lists; one version, its language Metal's; its own compile options and module flags, once
/// each), and those of the stage metadata of its vertex, fragment or kernel entry point where it
/// has one: an integer user() varying's air.arg_type_name is the unsigned name, an input or a
/// patch control point input's field has no bare attribute name (and such a field its member's
/// type name), a flat fragment input no sampling key, a buffer input its address space and
/// pointee size, and an output or input node without air.arg_type_name gets the name
/// `signature` gives its value (an input's by its parameter index), and an air.arg_name where it
/// has none. True where it changed `text`; `text` is unchanged otherwise.
bool RgfxGLNormalizeStageText(std::string &text, const RgfxGLSignature &signature);

/// Puts the function declarations of `text`, a module as LLVM prints it (its lines that start
/// "declare "), in the order of their names, each in the place of one of them, and leaves every
/// other line where it was. True where it changed `text`; `text` is unchanged otherwise.
bool RgfxGLSortDeclarations(std::string &text);

/// Makes `text`, a GL kernel variant's normalized module (RgfxGLLowered::stageInText), a kernel
/// that takes no patch control point input, under the stage input descriptor `in`, as the rules
/// at RgfxGLSpecializeStageIn say. False, with `why` and `text` unchanged, where the module has no
/// such input or `in` does not describe one of its fields.
bool RgfxGLSpecializeStageInText(std::string &text, const RgfxGLStageIn &in, std::string &why);

/// A GL kernel variant's module (`stageInText`) made a .metallib of a kernel under the stage input
/// descriptor `in`, in `out` (its metallib, entry and stage):
///   - the control point function the input names, which the generator declares and Metal's
///     drivers define from the descriptor, is defined here from it. The kernel calls it with an
///     index i in the stage input region's size, and it answers each field's attribute fetched at
///     the element: the region's origin.x + i for a layout stepping by thread position in X,
///     index[i] + origin.x for one stepping by indexed position in X (the index buffer of the
///     descriptor's type at its index), thread position in Y / step rate for one stepping by Y,
///     and 0 for a constant one (measured: macOS 27.0.1, the M3 Max's GL draws of first 4 and of
///     base vertex 4, m3-max-30212). The attribute is read at the layout's buffer, element times
///     the layout's stride plus the attribute's offset, in its MTLAttributeFormat as Metal's
///     [[stage_in]] fetch reads it (bit for bit on the M3 Max, every format: tests/gl_tests.mm's
///     stage input oracle), and converted to its field's type, components it lacks 0, 0, 0 and 1;
///   - the kernel becomes an internal function, and a kernel of the same name takes its arguments
///     but the input, and a device buffer at each buffer index the fields read (the index
///     buffer's too where a layout steps by index), save where the kernel has a buffer at that
///     index already (the renderer's indexed variants have the index buffer), which serves. It
///     passes the function the address of a record of those buffers, the region's origin and the
///     thread position in place of the input. Its entry node keeps the kernel's other inputs and
///     operands (air.max_work_group_size).
/// Metal compiles no kernel with a patch control point input; it compiles this one, and reads the
/// region's origin (air.stage_in_grid_origin) from the encoder's setStageInRegion: with no stage
/// input descriptor (measured: macOS 27.0.1, the M3 Max, m3-max-30229).
bool RgfxGLSpecializeStageIn(const std::string &stageInText, const RgfxGLStageIn &in, RgfxGLLowered &out,
                             std::string &why);

/// Everything outside a variant's IR and plugin data that its lowering reads, as text, for the
/// key a lowered variant is kept under (RgfxGLStore.hpp), in `identity`:
///   - the build of the image that holds this code (the bundle's LC_UUID, its slice's);
///   - the GL code generator's and the system's LLVM's paths and LC_UUIDs (the libraries
///     RgfxLowerGLIR calls);
///   - the OS's build (kern.osversion): the generator's own libraries (libGLVMPlugin) and its
///     builtins, which it reads from AppleMetalOpenGLRenderer.bundle's GLDBuiltins.bc, are the
///     sealed system volume's, which changes only with the build; and the builtins file's size
///     and modification time besides;
///   - the environment variables the generator names (GLDPLUGIN_OPT, GLR_ABORT_ON_UNSUPPORTED,
///     GLR_BREAK_ON_UNSUPPORTED), each value or its absence.
/// The lowering takes no device: what the device answered the renderer reaches the generator
/// only through the plugin data. Computed once per process, which loads the libraries; false,
/// with `why`, where they are not there.
bool RgfxGLLoweringIdentity(std::string &identity, std::string &why);

/// The GL IR a renderer's pointer holds: the u32 length at `ir`, then that many bytes. Writes the
/// bytes' start and their length; false where `ir` is null.
bool RgfxGLIRPayload(const void *ir, const uint8_t **payload, size_t *length);

#endif // RGFX_GL_LOWERING_HPP_
