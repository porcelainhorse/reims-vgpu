/*
 * RgfxHeap: see RgfxHeap.h. Our own ObjC++; no Apple private SPI.
 */

#import "RgfxHeap.h"

#import "RgfxBuffer.h"
#import "RgfxInterop.h"
#import "RgfxMetalPrivate.h"
#import "RgfxTexture.h"
#import "RgfxUnsupported.h"

#include <algorithm>
#include <cstdio>
#include <cstring>
#include <dlfcn.h>
#include <memory>
#include <mutex>

#include "RgfxHeapRanges.hpp"
#include "RgfxHeapSizes.hpp"
#include "RgfxLog.hpp" // rgfxNoteNil
#include "RgfxRegion.hpp"
#include "RgfxSerializer.hpp" // RgfxSerializer
#include "RgfxSlabs.hpp"      // RgfxPoolSlabSource

/// Metal's page, which a heap's size is rounded up to.
static constexpr uint64_t kHeapPage = 0x4000;

MTLSizeAndAlign rgfxHeapTextureSizeAndAlign(RgfxSerializer *serializer,
                                            MTLTextureDescriptor *descriptor, Class cls, SEL cmd)
{
	if (descriptor == nil) {
		return {0, 0};
	}
	uint64_t size = 0, align = 0;
	if (serializer != nullptr &&
	    serializer->heapTextureSizeAndAlign(rgfxTextureDescriptorFromMTL(descriptor), &size,
	                                        &align)) {
		return {static_cast<NSUInteger>(size), static_cast<NSUInteger>(align)};
	}
	RgfxLogUnsupported(cls, cmd, "the host's heap texture size (no answer came back): a bound "
	                             "of Metal's is answered");
	RgfxHeapSizeAlign sa = {};
	rgfxHeapTextureBound(static_cast<uint32_t>(descriptor.pixelFormat),
	                     static_cast<uint32_t>(descriptor.textureType), descriptor.width,
	                     descriptor.height, descriptor.depth,
	                     static_cast<uint32_t>(descriptor.mipmapLevelCount),
	                     descriptor.arrayLength, descriptor.sampleCount, &sa);
	return {static_cast<NSUInteger>(sa.size), static_cast<NSUInteger>(sa.align)};
}

@interface RgfxHeap () <RgfxMetalHeapInternals>
// Returned retained, as the new… members that return them are, so no autorelease pool holds them.
- (nullable RgfxBuffer *)rgfxBufferAt:(uint64_t)offset
                               length:(NSUInteger)length
                              options:(MTLResourceOptions)options NS_RETURNS_RETAINED;
- (nullable RgfxBuffer *)rgfxPlaceBufferOfLength:(NSUInteger)length
                                         options:(MTLResourceOptions)options
                                       alignment:(uint64_t)alignment NS_RETURNS_RETAINED;
+ (nullable instancetype)heapOverPoolWithDescriptor:(MTLHeapDescriptor *)descriptor
                                               pool:(RgfxPoolSlabSource *)pool
                                             device:(nullable id<MTLDevice>)device
                                         serializer:(RgfxSerializer *)serializer;
@end

@implementation RgfxHeap {
	uint64_t _size; // the descriptor's, rounded up to kHeapPage
	MTLResourceOptions _options;
	MTLHeapType _type;
	void (^_deallocator)(void); // gives a Shared heap's region or pool block back
	uint64_t _gpuAddress;       // the GPU address its create picked, given back after its destroy
	BOOL _hostAddress;          // its address is the host's for its pool block: none to give back
	uint8_t *_contents;         // a Shared heap's bytes, its region or pool block's; null for any other
	// An Automatic heap's placements, under _rangesLock; null for a heap of another type.
	std::unique_ptr<RgfxHeapRanges> _ranges;
	std::mutex _rangesLock;
	uint64_t _traceId; // globalTraceObjectID
}

// Its trace id (RgfxInterop.h), taken as it was made.
- (uint64_t)globalTraceObjectID
{
	return _traceId;
}

// The host drops the heap as the app lets it go, after any command buffer that names it (each
// keeps it while it runs), and only then is a Shared heap's block given back. The resources placed in the heap keep it alive
// (RgfxResource's `heap`), so they went first.
- (void)dealloc
{
	void (^deallocator)(void) = _deallocator;
	RgfxSerializer *serializer = _serializer;
	uint64_t address = _hostAddress ? 0 : _gpuAddress;
	[self rgfxRetireThen:[deallocator, serializer, address] {
		if (deallocator != nil)
			deallocator();
		if (serializer != nullptr && address != 0)
			serializer->releaseAddress(address);
	}];
}

+ (instancetype)heapWithDescriptor:(MTLHeapDescriptor *)descriptor
                            device:(id<MTLDevice>)device
                        serializer:(RgfxSerializer *)serializer
{
	if (serializer == nullptr || descriptor == nil) {
		return nil; // a heap must have a route and a shape
	}
	if (descriptor.size == 0) {
		return nil; // as Metal answers a heap of no bytes
	}
	RgfxCreated created =
	    serializer->createHeap(static_cast<uint64_t>(descriptor.size),
	                           static_cast<uint32_t>(descriptor.resourceOptions),
	                           static_cast<int32_t>(descriptor.type));
	if (created.obj_id == 0) {
		return nil; // no GPU address left for it
	}
	if (serializer->refused(created))
		return nil; // the device never got it
	RgfxHeap *heap = [[RgfxHeap alloc] initWithObjId:created.obj_id
	                                          device:device
	                                      serializer:serializer];
	if (heap)
		heap->_traceId = RgfxNextTraceObjectId();
	[heap rgfxTakeDescriptor:descriptor gpuAddress:created.gpu_address];
	return heap;
}

+ (instancetype)heapForDeviceWithDescriptor:(MTLHeapDescriptor *)descriptor
                                  maxLength:(NSUInteger)maxLength
                                     region:(RgfxRegion *)region
                                       pool:(RgfxPoolSlabSource *)pool
                                     device:(id<MTLDevice>)device
                                 serializer:(RgfxSerializer *)serializer
{
	// The x86 Macs' heap descriptor validation ends the process at a Shared heap (oracle_bundle
	// heapbuffers, AMD 5300M and Intel 630, macOS 26.7.1), sending nothing; an Apple GPU makes
	// one (oracle_bundle Apple heap.shared, 11-13).
	const bool apple = rgfxAppleGPU(device);
	if (descriptor != nil && descriptor.storageMode == MTLStorageModeShared && !apple)
		RgfxMetalAssertionFailed("-[MTLHeapDescriptorInternal validateWithDevice:]",
		                         @"Heap Descriptor Validation\nShared storage mode disallowed\n");
	if (descriptor == nil || descriptor.size == 0 ||
	    (maxLength != 0 && descriptor.size > maxLength))
		return nil;
	if (descriptor.storageMode != MTLStorageModeShared)
		return [RgfxHeap heapWithDescriptor:descriptor device:device serializer:serializer];
	if (pool != nullptr && serializer != nullptr)
		return [RgfxHeap heapOverPoolWithDescriptor:descriptor
		                                       pool:pool
		                                     device:device
		                                 serializer:serializer];
	if (region == nullptr || serializer == nullptr)
		return nil;
	// A Shared one's memory is a block of the region, on the host too, whole pages of Metal's
	// 16 KiB, so the CPU and the host's GPU reach its resources in place.
	const uint64_t size = static_cast<uint64_t>(descriptor.size);
	RgfxRegion::Block block =
	    region->allocate((size + kHeapPage - 1) & ~(kHeapPage - 1), kHeapPage);
	if (!block.ok)
		return nil;
	uint8_t *bytes = const_cast<uint8_t *>(block.ptr);
	std::memset(bytes, 0, block.size);
	// The block goes back to the region once the host has dropped the heap.
	const uint64_t offset = block.offset;
	RgfxHeap *heap = [RgfxHeap heapOverHostMemoryWithDescriptor:descriptor
	                                              regionOffset:offset
	                                                  contents:bytes
	                                               deallocator:^{
		                                               region->release(offset);
	                                               }
	                                                    device:device
	                                                serializer:serializer];
	if (heap == nil)
		region->release(offset); // no heap lies over the block
	return heap;
}

// A Shared heap over a block of the Shared pool (heapForDeviceWithDescriptor:), whose bytes the
// host zeroed as it gave it: its size rounded up to the pool's 64 KiB, a block of its own, made one
// HEAP_OVER_POOL, as a slab of the pool is, of the descriptor's size, options and type. It lies at
// the block's GPU address where the host gave one, which its destroy gives nothing back for, else
// at the process's pick. The block goes back to the pool once the host has dropped the heap. Nil
// where the pool has no block for it, as Metal's heap is where memory runs out, past the longest
// block, or where the device never got the heap.
+ (instancetype)heapOverPoolWithDescriptor:(MTLHeapDescriptor *)descriptor
                                      pool:(RgfxPoolSlabSource *)pool
                                    device:(id<MTLDevice>)device
                                serializer:(RgfxSerializer *)serializer
{
	const uint64_t size = static_cast<uint64_t>(descriptor.size);
	const uint64_t unit = RgfxPoolSlabSource::kUnit;
	if (size > RgfxPoolSlabSource::kTakeMax)
		return nil;
	RgfxSlabSource::Memory memory;
	if (!pool->take((size + unit - 1) & ~(unit - 1), true, &memory))
		return nil;
	const uint32_t options = static_cast<uint32_t>(descriptor.resourceOptions);
	const int32_t type = static_cast<int32_t>(descriptor.type);
	RgfxCreated created =
	    memory.gpuAddress != 0
	        ? serializer->createHeapOverPoolAt(size, options, type, memory.regionOffset,
	                                           memory.gpuAddress)
	        : serializer->createHeapOverPool(size, options, type, memory.regionOffset);
	if (created.obj_id == 0 || serializer->refused(created)) {
		pool->give(memory); // no heap lies over the block
		return nil;
	}
	RgfxHeap *heap = [[RgfxHeap alloc] initWithObjId:created.obj_id
	                                          device:device
	                                      serializer:serializer];
	if (heap == nil)
		return nil;
	heap->_traceId = RgfxNextTraceObjectId();
	[heap rgfxTakeDescriptor:descriptor gpuAddress:created.gpu_address];
	heap->_hostAddress = memory.gpuAddress != 0;
	heap->_contents = memory.bytes;
	heap->_deallocator = ^{
		pool->give(memory);
	};
	return heap;
}

+ (instancetype)heapOverHostMemoryWithDescriptor:(MTLHeapDescriptor *)descriptor
                                    regionOffset:(uint64_t)regionOffset
                                        contents:(void *)contents
                                     deallocator:(void (^)(void))deallocator
                                          device:(id<MTLDevice>)device
                                      serializer:(RgfxSerializer *)serializer
{
	if (serializer == nullptr || descriptor == nil) {
		return nil; // a heap must have a route and a shape
	}
	if (descriptor.size == 0) {
		return nil; // as Metal answers a heap of no bytes
	}
	RgfxCreated created = serializer->createHeapOverHostMemory(
	    static_cast<uint64_t>(descriptor.size),
	    static_cast<uint32_t>(descriptor.resourceOptions),
	    static_cast<int32_t>(descriptor.type), regionOffset);
	if (created.obj_id == 0) {
		return nil; // no GPU address left for it
	}
	if (serializer->refused(created))
		return nil; // the device never got it
	RgfxHeap *heap = [[RgfxHeap alloc] initWithObjId:created.obj_id
	                                          device:device
	                                      serializer:serializer];
	if (heap) {
		heap->_traceId = RgfxNextTraceObjectId();
		[heap rgfxTakeDescriptor:descriptor gpuAddress:created.gpu_address];
		heap->_contents = static_cast<uint8_t *>(contents);
		heap->_deallocator = [deallocator copy];
	}
	return heap;
}

// The shape a factory's create made the heap with. The size, which the create checked takes an
// address, is rounded up to Metal's page, as the host's platform rounds it.
- (void)rgfxTakeDescriptor:(MTLHeapDescriptor *)descriptor gpuAddress:(uint64_t)gpuAddress
{
	const uint64_t size = static_cast<uint64_t>(descriptor.size);
	_size = size + (kHeapPage - size % kHeapPage) % kHeapPage;
	_options = descriptor.resourceOptions;
	_type = descriptor.type;
	_gpuAddress = gpuAddress;
	if (_type == MTLHeapTypeAutomatic) {
		_ranges = std::make_unique<RgfxHeapRanges>(_size);
	}
}

// --- MTLHeap shape (from the stored descriptor) ------------------------------

- (NSUInteger)size
{
	return static_cast<NSUInteger>(_size);
}

- (MTLHeapType)type
{
	return _type;
}

// The heap's options, its hazard tracking resolved as Metal's are: a Default mode is Untracked, as
// Metal documents and answers (measured on the M3 Max under macOS 27: 0x120 for a Private heap of
// either type, 0x100 for a Shared one, 0x200 for a Shared one made Tracked). Its unfiltered options
// are the same.
- (MTLResourceOptions)resourceOptions
{
	return RgfxResolveHazardTracking(_options, MTLResourceHazardTrackingModeUntracked);
}

- (MTLResourceOptions)unfilteredResourceOptions
{
	return self.resourceOptions;
}

// The heap's base: a resource placed at offset 0 lies there, as in Metal's (measured on the M3 Max
// under macOS 27, a Placement and an Automatic heap alike).
- (uint64_t)gpuAddress
{
	return _gpuAddress;
}

- (MTLStorageMode)storageMode
{
	return static_cast<MTLStorageMode>((_options & MTLResourceStorageModeMask) >>
	                                   MTLResourceStorageModeShift);
}

- (MTLCPUCacheMode)cpuCacheMode
{
	return static_cast<MTLCPUCacheMode>((_options & MTLResourceCPUCacheModeMask) >>
	                                    MTLResourceCPUCacheModeShift);
}

- (MTLHazardTrackingMode)hazardTrackingMode
{
	return static_cast<MTLHazardTrackingMode>((self.resourceOptions &
	                                           MTLResourceHazardTrackingModeMask) >>
	                                          MTLResourceHazardTrackingModeShift);
}

// An Automatic heap's placements answer what is used and what is free (RgfxHeapRanges.hpp); a
// Placement heap, whose resources the app places, answers 0 for both, as Metal's does (measured:
// M3 Max, macOS 27, with a buffer placed in it). Every heap holds its whole size.
- (NSUInteger)usedSize
{
	if (_ranges == nullptr) {
		return 0;
	}
	std::lock_guard<std::mutex> hold(_rangesLock);
	return static_cast<NSUInteger>(_ranges->used());
}

- (void *)rgfxContents
{
	return _contents;
}

- (NSUInteger)currentAllocatedSize
{
	return static_cast<NSUInteger>(_size);
}

- (NSUInteger)maxAvailableSizeWithAlignment:(NSUInteger)alignment
{
	if (_ranges == nullptr) {
		return 0;
	}
	std::lock_guard<std::mutex> hold(_rangesLock);
	return static_cast<NSUInteger>(_ranges->maxAvailable(alignment));
}

- (void)rgfxGiveRangeAt:(uint64_t)offset size:(uint64_t)size
{
	if (_ranges == nullptr) {
		return;
	}
	std::lock_guard<std::mutex> hold(_rangesLock);
	_ranges->give(offset, size);
}

// `size` bytes of an Automatic heap at `align`: the offset picked, or false where no free run
// holds them.
- (BOOL)rgfxTakeRange:(uint64_t)size align:(uint64_t)align offset:(uint64_t *)offset
{
	if (_ranges == nullptr) {
		return NO;
	}
	std::lock_guard<std::mutex> hold(_rangesLock);
	return _ranges->take(size, align, offset);
}

// --- sub-allocation (Placement: the guest names the offset) -------------------
// Only a Placement heap places at an offset: of a heap of another type, Metal's validation
// fails the call, and these answer nil, as the host refuses such a placement.
//
// Neither places a resource that runs past the heap's size: nil, sending nothing, with the
// device's note of a nil (rgfxNoteNil), as the AMD 5300M and the Intel 630 under macOS 26.7.1
// answer, their processes going on (oracle_errors bounds, in a 1 MiB Private heap: a buffer of
// 64 KiB at its last 64 KiB made, of 128 KiB there and of 1 MiB + 64 KiB at 0 nil; a texture at
// the last offset of its alignment that holds it made, one alignment on nil). The host refuses
// such a placement, so the app would otherwise hold a resource its command buffers cannot use.

// Whether `size` bytes at `offset` run past a heap of `heapSize` bytes, noted as a nil of
// `creator`'s where they do.
static bool rgfxPlacedPastHeap(const char *creator, uint64_t offset, uint64_t size,
                               uint64_t heapSize)
{
	if (offset <= heapSize && size <= heapSize - offset)
		return false;
	char asked[128];
	snprintf(asked, sizeof(asked), "%llu bytes at offset %llu of a heap of %llu",
	         static_cast<unsigned long long>(size), static_cast<unsigned long long>(offset),
	         static_cast<unsigned long long>(heapSize));
	rgfxNoteNil(creator, "past the heap's size", asked);
	return true;
}

- (id<MTLBuffer>)newBufferWithLength:(NSUInteger)length
                             options:(MTLResourceOptions)options
                              offset:(NSUInteger)offset
{
	if (_type != MTLHeapTypePlacement) {
		return nil;
	}
	if (rgfxPlacedPastHeap("MTLHeap newBufferWithLength:options:offset:", offset, length, _size))
		return nil;
	RgfxBuffer *buffer = [self rgfxBufferAt:offset length:length options:options];
	[buffer rgfxSetHeapOffset:offset];
	return buffer;
}

// A buffer of `length` bytes at `offset` in the heap, kept by it, routed as an
// RGFX_CMD_BUFFER_AT_OFFSET. Nil with no route, or past a Shared heap's bytes.
- (RgfxBuffer *)rgfxBufferAt:(uint64_t)offset
                      length:(NSUInteger)length
                     options:(MTLResourceOptions)options
{
	RgfxSerializer *ser = [self serializer];
	if (ser == nullptr) {
		return nil;
	}
	// A Shared heap's buffer is its bytes at the offset, which must lie in the heap.
	if (_contents != nullptr && (offset > _size || length > _size - offset)) {
		return nil;
	}
	RgfxCreated created = ser->createBufferAtOffset([self rgfxObjId], offset, length,
	                                                static_cast<uint32_t>(options));
	if (ser->refused(created))
		return nil; // the device never got it
	// At the heap's address plus the offset, where the host places it in the heap it pinned.
	// A Shared heap's buffer is the heap's bytes there, which the host's is too; it keeps the
	// heap, and so the bytes, alive.
	const uint64_t address = _gpuAddress + offset;
	RgfxBuffer *buffer =
	    _contents != nullptr
	        ? [[RgfxBuffer alloc] initWithObjId:created.obj_id
	                                 gpuAddress:address
	                                     length:length
	                                    options:options
	                                   contents:_contents + offset
	                                deallocator:nil
	                                     device:self.device
	                                 serializer:ser]
	        : [[RgfxBuffer alloc] initWithObjId:created.obj_id
	                                 gpuAddress:address
	                                     length:length
	                                    options:options
	                                     device:self.device
	                                 serializer:ser];
	[buffer rgfxSetHeap:self];
	return buffer;
}

- (id<MTLTexture>)newTextureWithDescriptor:(MTLTextureDescriptor *)descriptor
                                    offset:(NSUInteger)offset
{
	if (_type != MTLHeapTypePlacement) {
		return nil;
	}
	// As Metal's validation, sending nothing.
	rgfxEndAtInvalidTextureDescriptor(descriptor, self.device);
	rgfxEndAtHeapStorageMismatch(descriptor, self.storageMode, self.device);
	if (rgfxDeviceMakesNoTextureOf(descriptor, self.device))
		return nil;
	// Its bytes, as heapTextureSizeAndAlignWithDescriptor: answers them: the host's answer, which
	// the serialiser keeps per descriptor, so a texture placed at an offset the app worked out from
	// that answer asks nothing more. With no answer the host's own refusal stands, as before.
	RgfxSerializer *ser = [self serializer];
	uint64_t bytes = 0, align = 0;
	if (ser != nullptr &&
	    ser->heapTextureSizeAndAlign(rgfxTextureDescriptorFromMTL(descriptor), &bytes, &align) &&
	    rgfxPlacedPastHeap("MTLHeap newTextureWithDescriptor:offset:", offset, bytes, _size))
		return nil;
	RgfxTexture *texture = [RgfxTexture textureWithDescriptor:descriptor
	                                                     heap:[self rgfxObjId]
	                                               heapOffset:offset
	                                                   device:self.device
	                                               serializer:[self serializer]];
	[texture rgfxSetHeap:self]; // the texture keeps the heap alive
	[texture rgfxSetHeapOffset:offset];
	return texture;
}

// --- sub-allocation (Automatic: the heap picks the offset) --------------------
// The heap places each at the lowest free offset at its alignment (RgfxHeapRanges.hpp), as
// Metal's does, and nil where no free run holds it, or for a heap of another type. Its heapOffset
// answers 0, as Metal's does for a resource of an Automatic heap (measured: M3 Max, macOS 27).

- (id<MTLBuffer>)newBufferWithLength:(NSUInteger)length options:(MTLResourceOptions)options
{
	return [self rgfxPlaceBufferOfLength:length options:options alignment:1];
}

// A buffer of the descriptor's length, placed as newBufferWithLength:options: places one, at the
// descriptor's alignment where it is larger than the device's, with the heap's options whatever
// the descriptor's, as Metal's (measured on the M3 Max under macOS 27: an Automatic heap places a
// buffer of a 64 KiB alignment at the next 64 KiB and one of the default alignment of 1 at the
// device's 256 bytes, and answers a Private heap's options for one of Shared options). A Placement
// heap, which places nothing itself, answers nil, and so does a length of 0 or no descriptor. One
// over memory of its own (contents, an IOSurface, no-copy, address ranges, a pinned or parent
// address, sparse pages) the device does not make: nil, logged.
- (id<MTLBuffer>)newBufferWithDescriptor:(id)descriptor
{
	id<RgfxMetalBufferDescriptor> d = descriptor;
	if (d == nil || _ranges == nullptr || ![d respondsToSelector:@selector(length)] ||
	    d.length == 0) {
		return nil;
	}
	const bool ownMemory =
	    ([d respondsToSelector:@selector(contents)] && d.contents != nullptr) ||
	    ([d respondsToSelector:@selector(iosurface)] && d.iosurface != nullptr) ||
	    ([d respondsToSelector:@selector(noCopy)] && d.noCopy) ||
	    ([d respondsToSelector:@selector(addressRanges)] && d.addressRanges != nil) ||
	    ([d respondsToSelector:@selector(pinnedGPUAddress)] && d.pinnedGPUAddress != 0) ||
	    ([d respondsToSelector:@selector(parentGPUAddress)] && d.parentGPUAddress != 0) ||
	    ([d respondsToSelector:@selector(placementSparsePageSize)] &&
	     d.placementSparsePageSize != 0);
	if (ownMemory) {
		RGFX_UNSUPPORTED("buffers over memory of their own");
		return nil;
	}
	const uint64_t alignment = [d respondsToSelector:@selector(alignment)] ? d.alignment : 1;
	return [self rgfxPlaceBufferOfLength:d.length options:_options alignment:alignment];
}

// An Automatic heap's buffer of `length` bytes and `options`, at the device's heap buffer
// alignment or `alignment`, whichever is larger; nil where no free run holds it.
- (RgfxBuffer *)rgfxPlaceBufferOfLength:(NSUInteger)length
                                options:(MTLResourceOptions)options
                              alignment:(uint64_t)alignment
{
	// The device's heap buffer alignment (the host's, in its device info), else Metal's.
	id<MTLDevice> device = self.device;
	const uint64_t hostAlign =
	    device != nil ? [device heapBufferSizeAndAlignWithLength:length options:options].align : 0;
	const uint64_t align =
	    std::max<uint64_t>(hostAlign != 0 ? hostAlign : kRgfxHeapBufferAlign, alignment);
	uint64_t offset = 0;
	if ([self serializer] == nullptr || ![self rgfxTakeRange:length align:align offset:&offset]) {
		return nil;
	}
	RgfxBuffer *buffer = [self rgfxBufferAt:offset length:length options:options];
	if (buffer == nil) {
		[self rgfxGiveRangeAt:offset size:length];
		return nil;
	}
	[buffer rgfxHoldHeapRange:offset size:length];
	return buffer;
}

- (id<MTLTexture>)newTextureWithDescriptor:(MTLTextureDescriptor *)descriptor
{
	RgfxSerializer *ser = [self serializer];
	if (ser == nullptr || descriptor == nil || _ranges == nullptr) {
		return nil;
	}
	// As Metal's validation, before the host is asked the texture's size.
	rgfxEndAtInvalidTextureDescriptor(descriptor, self.device);
	rgfxEndAtHeapStorageMismatch(descriptor, self.storageMode, self.device);
	if (rgfxDeviceMakesNoTextureOf(descriptor, self.device))
		return nil;
	const MTLSizeAndAlign sa = rgfxHeapTextureSizeAndAlign(ser, descriptor, [self class], _cmd);
	uint64_t offset = 0;
	if (![self rgfxTakeRange:sa.size align:sa.align offset:&offset]) {
		return nil;
	}
	RgfxTexture *texture = [RgfxTexture textureWithDescriptor:descriptor
	                                                     heap:[self rgfxObjId]
	                                               heapOffset:offset
	                                                   device:self.device
	                                               serializer:ser];
	if (texture == nil) {
		[self rgfxGiveRangeAt:offset size:sa.size];
		return nil;
	}
	[texture rgfxSetHeap:self]; // the texture keeps the heap alive
	[texture rgfxHoldHeapRange:offset size:sa.size];
	return texture;
}

// --- MTLAllocation -------------------------------------------------------------------

// The bytes the heap takes: its size, all of it reserved at its create.
- (NSUInteger)allocatedSize
{
	return static_cast<NSUInteger>(_size);
}

// --- MTLHeapSPI ----------------------------------------------------------------------

// The heap's memory pool: 0, as Metal's base heap answers, which neither x86 Mac's heap overrides
// (read from code; measured on the AMD 5300M and the Intel 630, %spi-answers).
- (uint64_t)memoryPoolId
{
	return 0;
}

// Metal's base heap raises an unrecognized selector here, sending itself
// doesNotRecognizeSelector:, and neither x86 Mac's heap overrides it (read from code).
- (BOOL)detachBacking
{
	[self doesNotRecognizeSelector:_cmd];
	return NO;
}

- (BOOL)replaceBackingWithRanges:(id)ranges readOnly:(BOOL)readOnly
{
	[self doesNotRecognizeSelector:_cmd];
	return NO;
}

// The description Metal's base heap gives, which neither x86 Mac's heap overrides (read from
// code): the object's own description, then each field on a line of its own, indented by
// `indent` + 4 spaces. The hazard tracking mode and the options are worded by Metal's own
// MTLHazardTrackingModeString and MTLResourceOptionsString, where the guest's Metal has them, and
// given as numbers where it does not.
- (NSString *)formattedDescription:(NSUInteger)indent
{
	using Words = NSString *(*)(NSUInteger);
	static const Words hazardWords =
	    reinterpret_cast<Words>(dlsym(RTLD_DEFAULT, "MTLHazardTrackingModeString"));
	static const Words optionWords =
	    reinterpret_cast<Words>(dlsym(RTLD_DEFAULT, "MTLResourceOptionsString"));
	NSString *pad = [@"\n" stringByPaddingToLength:indent + 4 withString:@" " startingAtIndex:0];
	NSString *type = _type == MTLHeapTypeAutomatic   ? @"MTLHeapTypeAutomatic"
	                 : _type == MTLHeapTypePlacement ? @"MTLHeapTypePlacement"
	                                                 : @"Invalid";
	const MTLCPUCacheMode cache = self.cpuCacheMode;
	NSString *cacheWords = cache == MTLCPUCacheModeDefaultCache    ? @"MTLCPUCacheModeDefaultCache"
	                       : cache == MTLCPUCacheModeWriteCombined ? @"MTLCPUCacheModeWriteCombined"
	                                                               : @"Invalid";
	// Metal's base heap words only a Private heap's mode.
	NSString *storage = self.storageMode == MTLStorageModePrivate ? @"MTLStorageModePrivate" : @"Invalid";
	const MTLHazardTrackingMode hazard = self.hazardTrackingMode;
	const MTLResourceOptions options = self.resourceOptions;
	NSString *hazardText = hazardWords != nullptr ? hazardWords(hazard) : @(hazard).stringValue;
	NSString *optionText = optionWords != nullptr ? optionWords(options) : @(options).stringValue;
	NSArray *fields = @[
		pad, @"label =", self.label ?: @"<none>", pad, @"type =", type, pad, @"size =", @(self.size), pad,
		@"usedSize =", @(self.usedSize), pad, @"cpuCacheMode =", cacheWords, pad, @"storageMode =",
		storage, pad, @"hazardTrackingMode =", hazardText ?: @"", pad, @"resourceOptions =",
		optionText ?: @""
	];
	return [NSString stringWithFormat:@"%@%@", [super description], [fields componentsJoinedByString:@" "]];
}

// --- unsupported: the device makes no acceleration structure ------------------------

- (id<MTLAccelerationStructure>)newAccelerationStructureWithSize:(NSUInteger)size
{
	RGFX_UNSUPPORTED("ray tracing");
	return nil;
}

- (id<MTLAccelerationStructure>)newAccelerationStructureWithDescriptor:
    (MTLAccelerationStructureDescriptor *)descriptor
{
	RGFX_UNSUPPORTED("ray tracing");
	return nil;
}

- (id<MTLAccelerationStructure>)newAccelerationStructureWithSize:(NSUInteger)size
                                                          offset:(NSUInteger)offset
{
	RGFX_UNSUPPORTED("ray tracing");
	return nil;
}

- (id<MTLAccelerationStructure>)newAccelerationStructureWithDescriptor:
                                    (MTLAccelerationStructureDescriptor *)descriptor
                                                                offset:(NSUInteger)offset
{
	RGFX_UNSUPPORTED("ray tracing");
	return nil;
}

- (id<MTLAccelerationStructure>)newAccelerationStructureWithSize:(NSUInteger)size
                                                   resourceIndex:(NSUInteger)index
{
	RGFX_UNSUPPORTED("ray tracing");
	return nil;
}

@end
