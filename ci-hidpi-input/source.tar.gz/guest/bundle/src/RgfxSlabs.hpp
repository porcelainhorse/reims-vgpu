/*
 * RgfxSlabs: where the memory of the device's Shared and Managed buffers comes from
 * (docs/graphics-kext/design.md, "Shared and Managed buffers lie in slabs").
 *
 * A buffer takes no block of the kext's and no host object of its own memory: it takes a range
 * of a slab, a larger piece of memory this allocator holds, and lies there at the range's offset.
 * What a slab is and how the host sees it is its source's (RgfxSlabSource): a block of the device
 * region (RgfxRegionSlabSource), whose Shared slabs are each one placement heap over host memory
 * (HEAP_OVER_HOST_MEMORY) with every buffer a BUFFER_AT_OFFSET in it, and whose Managed slabs are
 * plain blocks with each buffer a BUFFER_OVER_HOST_MEMORY over its own range of the block, its CPU
 * copy; or 2 MiB of the process's own pages (RgfxPagesSlabSource), one heap over its guest RAM
 * (HEAP_OVER_PAGES) with its buffers placed in it the same way, or for one large Shared buffer
 * more, the buffer a BUFFER_OVER_PAGES over them. So a create is a take from a free list and one
 * post on ring 0, and a free a give back: neither calls the kext, and the region's block table
 * holds one entry per slab.
 *
 * What the buffers answer, as both x86-64 Macs' GPUs (AMD 5300M, Intel 630) agree (measured with
 * tools/shmem's align and zero cases): a buffer takes whole 4 KiB pages (kGranule; allocatedSize
 * 4096 for a 256-byte buffer), its contents and GPU address start a page, and a new buffer reads
 * zeros, whatever its memory held before.
 *
 * THE CLASSES. Buffers share a slab only where their options are the same once the hazard
 * tracking is resolved (the caller resolves it): the host's placed buffer takes its heap's
 * storage, CPU cache and hazard tracking modes, and refuses another storage or cache mode.
 *
 * MANAGED OVER A COPY. Where the device took RGFX_FEATURE_MANAGED_BUFFER_SLABS (the sources'
 * `managedOverCopy`), a Managed buffer lies in the Shared class of its cache and hazard tracking
 * modes: its range is a Shared buffer's, made as any (BUFFER_AT_OFFSET in the slab's heap, or
 * BUFFER_OVER_PAGES over a larger slab of plain pages), and the Managed buffer a
 * MANAGED_BUFFER_CREATE over it, its CPU copy. So a Managed buffer of any size lies where a Shared
 * one of its size does, the process's own pages first, on every host. Its range goes back
 * once the copy's destroy follows the buffer's. Where the device also took
 * RGFX_FEATURE_MANAGED_AT_COPY (RgfxSerializer::managedAtCopy), the Managed buffer lies at its
 * copy's GPU address, which goes back with the copy. Without the feature a Managed buffer has a
 * class of its own (below, the region's source).
 *
 * THE SIZES. A buffer of up to kSmallMax bytes takes a range of one of its class's slabs, first
 * fit over the slabs in the order they were made, so older slabs fill first and newer ones empty.
 * A class's slabs grow from kSlabFirst, doubling, to kSlabMax, and are never smaller than twice
 * the buffer that makes one. A larger buffer takes a slab of its own (dedicated), its length
 * rounded up to the source's unit; once freed, that slab is cached for a later buffer of the same
 * class that needs at least half of it, oldest let go first past a sixteenth of the source's
 * capacity, and let go after kCacheIdleMs unused. A first source, or the own source where no
 * first is set, may say larger limits of its own (smallMax, slabMax), which hold for its slabs;
 * the region's slabs keep these.
 *
 * CHUNKED SLABS GROW. Where the kext gives chunks, a class's slabs of the process's own pages
 * grow past 2 MiB, doubling, to kChunkedSlabMax (16 MiB), each one heap over its block, and a
 * buffer of up to kChunkedSmallMax (4 MiB) lies in them: the host maps one view a slab and makes
 * one import of it, which every submission of a device that lists its imports lists (RADV, and
 * ANV on i915), whatever the buffers in it; a slab of their own each would be an import each.
 * Such a slab is 256 chunks at most, one dma-buf of the host's at udmabuf's stock limits (1,024
 * runs, 64 MiB). A class's slab past 2 MiB is the kext's chunks or none, never plain pages, which
 * no one dma-buf holds past 2 MiB: where the kext gives no chunks it is the region's, of 2 MiB at
 * most.
 *
 * ZEROING. A freed range, and a slab the source did not zero, are dirty. A create zeroes only
 * the dirty part of its range, past the bytes its caller writes itself; the background thread
 * (start) zeroes dirty free bytes in pieces of kZeroPiece, so in a steady state a create finds
 * its range clean. A piece being zeroed is in no free run, so no create takes it meanwhile. So a
 * range reads zero past those bytes as it is taken, and a Managed buffer over a copy says so in
 * its create (MANAGED_BUFFER_CREATE's RgfxManagedBufferZero): where the host keeps a GPU copy of
 * it, the copy starts with zeros its GPU writes there rather than with the bytes copied over its
 * link, as a Mac's GPU copy of a buffer made with no bytes holds.
 *
 * LETTING GO. A class keeps up to two empty slabs, each for kCacheIdleMs at most; a third empty
 * one goes at once, and one left empty that long goes too, as does a cached slab past the cap or
 * idle, so a process at rest holds only the slabs its buffers lie in. A source may have none of
 * its slabs kept (keepsFreed): each goes as its last buffer does, as the Shared pool's slabs do.
 * A slab goes by its source (its heap's OBJECT_DESTROY, then its block's release, whose
 * BLOCK_RELEASE the kext waits for, or a pool block's give), on the background thread, so a
 * buffer's free never waits for the host; without the thread, at once. Every buffer in a slab had
 * its destroy posted before its range came back, so the heap's destroy follows theirs.
 *
 * CHURN. The allocator counts what keeping slabs saved its sources (Churn): slabs made, slabs of
 * small buffers emptied, the empty ones a class kept that a buffer took from again, those let go,
 * and the cached slabs large buffers took. The device logs the counts (one line a process, at most
 * every kChurnLogMs, once they changed), so a run tells how many takes and give-backs a source
 * would serve without the empty and cached slabs kept.
 *
 * THE SOURCES. The slabs have one source of their own (the constructor's), and may have a first
 * source (setFirst). A new slab comes from the first source where one is set, at its unit, and
 * from the own source only where the first serves none of the class or size, or has no memory
 * for it; a slab keeps the source it came from, which makes its buffers and takes it back, and
 * its cache's cap is a sixteenth of that source's capacity. Where the device has a Shared pool,
 * the kext maps its blocks and Managed buffers lie over copies, the pool's source
 * (RgfxPoolSlabSource) is the own source, with no first and no region behind it: a buffer of a
 * class it has no heap for, or past its longest block, or one it has no block for, is nil, as
 * Metal's newBuffer is where the memory runs out. Else the own source is the region's, and the
 * process's own pages (RgfxPagesSlabSource) are the first where the kext makes pages blocks.
 *
 * THE FALLBACKS, in order, where a buffer finds no room in its class's slabs: a new slab; then,
 * once the sources had no memory for one, the process's own empty, cached and doomed slabs let go,
 * the slabs other threads (the background's among them) were giving back at that moment waited
 * for, and a new slab asked again, round after round while a round gave some memory back; then,
 * for a small buffer, slabs of the own source half as large down to the buffer's own rounded
 * size. Only where no source has memory even for that is the answer nil: the region, or the pool,
 * is full. A slab being given back is out of the slabs' books and not yet back in its source's,
 * for as long as its block's release takes, a host round trip: without the wait, one thread's
 * let-go of a batch of slabs makes another's create nil while the memory is on its way back
 * (measured on the M3 Max: test_slab_thread's 3 MiB takes refused in 8 of 1,000 runs under
 * Rosetta, with 237 to 253 MiB of its 256 MiB source taken while the slabs held 61 to 150 MiB).
 * Without the rounds after the first, what other threads let go while the wait lasted stays
 * doomed, its memory out of the sources, where the background thread is behind on its drops, as
 * under CPU load it is: test_slab_thread's 3 MiB takes refused in 1 of 1,000 runs under Rosetta
 * beside 16 busy loops on the M3 Max's 16 CPUs, and in 6 of 3,828 beside 48 busy loops and 8 dd
 * copies, the source refusing with 240 to 253 MiB of its 256 MiB taken while 26 to 52 slabs let
 * go were not yet back in it.
 * (Where the kext's block source places blocks, WindowServer's asks may take its
 * reserve.) A slab whose heap the device never got (the kext's submit refused it) is nil at once.
 *
 * Thread-safe: Metal creates and frees buffers on the app's threads. Our own C++, free of
 * Metal's headers, so the serialiser tests build it as the bundle does.
 */

#ifndef RGFX_SLABS_HPP_
#define RGFX_SLABS_HPP_

#include <atomic>
#include <condition_variable>
#include <cstdint>
#include <functional>
#include <map>
#include <memory>
#include <mutex>
#include <set>
#include <thread>
#include <vector>

class RgfxRegion;
class RgfxSerializer;

/// Where slabs come from, and how the host sees them and the buffers in them.
class RgfxSlabSource {
public:
	/// A slab's memory: `size` bytes this process maps at `bytes`. `regionOffset` is where they
	/// lie in the device region, for a source of region blocks. `zeroed` is whether every byte
	/// reads zero as it comes.
	struct Memory {
		uint8_t *bytes = nullptr;
		uint64_t size = 0;
		uint64_t regionOffset = 0;
		bool zeroed = false;
		uint64_t blockSize = 0; // a pages block's size, for a source of the process's own pages
		bool chunked = false;   // the kext's chunks, which go with the pages block's release
		uint64_t gpuAddress = 0; // the GPU address the host gave a pool block; 0 where none
	};

	/// The host's object over a slab of a class whose buffers are placed in it (heaped): its
	/// object id and GPU address. Both 0 for a slab of a class with none.
	struct Heap {
		uint64_t objId = 0;
		uint64_t gpuAddress = 0;
		bool ownsAddress = true; // the process picked its address, which goes back at its drop
	};

	/// A buffer made in a slab: its object id, GPU address, and whether its create picked that
	/// address, which then goes back after its destroy (a heaped buffer's is its heap's).
	struct Made {
		uint64_t objId = 0;
		uint64_t gpuAddress = 0;
		bool ownsAddress = false;
	};

	virtual ~RgfxSlabSource() = default;

	/// What a slab's size is a whole multiple of (a power of two).
	virtual uint64_t unit() const = 0;

	/// Whether this source makes a slab of `size` bytes (a multiple of unit()) for buffers of
	/// `options`, one buffer's own where `dedicated`, else its class's: a first source that does
	/// not leaves it to the slabs' own source (RgfxSlabs::setFirst), and an own source that does
	/// not leaves the buffer nil.
	virtual bool serves(uint32_t options, uint64_t size, bool dedicated) const { return true; }

	/// The largest buffer that shares a slab of its class from this source, where it is the
	/// first, or the own source with no first (a larger one takes a slab of its own), and the
	/// largest slab of a class it makes.
	virtual uint64_t smallMax() const { return kSmallMax; }
	virtual uint64_t slabMax() const { return kSlabMax; }

	/// Whether the allocator keeps this source's slabs once no buffer lies in them, for a later
	/// buffer: a class's empty ones (LETTING GO) and dedicated ones (the cache). Where it answers
	/// false, each goes as its last buffer does.
	virtual bool keepsFreed() const { return true; }

	/// Whether this source's slabs are blocks of the device region, which every process
	/// shares: the region's are; the Shared pool's and the process's own pages' are not.
	virtual bool inRegion() const { return true; }

	/// What smallMax() and slabMax() answer unless a source says otherwise: 1 MiB and 2 MiB.
	static constexpr uint64_t kSmallMax = 1ull << 20;
	static constexpr uint64_t kSlabMax = 2ull << 20;

	/// The most bytes this source's slabs could ever hold, which sizes the cache of slabs.
	virtual uint64_t capacity() const = 0;

	/// Whether buffers of `options` lie in a heap over their slab (makeHeap), else each over
	/// its own range.
	virtual bool heaped(uint32_t options) const = 0;

	/// Whether a slab of `size` bytes, of a class of `options`, one buffer's own where
	/// `dedicated`, has a heap its buffers lie in (makeHeap), else each buffer over its own
	/// range: its class's answer (heaped) unless the source says otherwise of a slab.
	virtual bool heapedSlab(uint64_t size, uint32_t options, bool dedicated) const
	{
		return heaped(options);
	}

	/// The memory of a slab of `size` bytes (a multiple of unit()), which has a heap where
	/// `heap` (heapedSlab), or false where it has none.
	virtual bool take(uint64_t size, bool heap, Memory *out) = 0;

	/// Gives a slab's memory back, once no buffer lies in it and its heap is dropped.
	virtual void give(const Memory &memory) = 0;

	/// The heap of a heaped class's slab over `memory`, of `options`; false where none was made.
	virtual bool makeHeap(const Memory &memory, uint32_t options, Heap *out) = 0;

	/// Drops a heap makeHeap made, once every buffer placed in it is destroyed.
	virtual void dropHeap(const Heap &heap) = 0;

	/// A buffer of `length` bytes and `options` at `offset` in the slab of `memory`, whose heap
	/// is `heap` (0s for a class with none); false where the device never got it.
	virtual bool makeBuffer(const Memory &memory, const Heap &heap, uint64_t offset,
	                        uint64_t length, uint32_t options, Made *out) = 0;

	/// The options of the class a buffer of `options` lies in (MANAGED OVER A COPY): the Shared
	/// class's for a Managed buffer of a source over copies, else `options`.
	virtual uint32_t classOptions(uint32_t options) const { return options; }

	/// Whether a buffer of `options` is a Managed buffer over a Shared copy (makeOverCopy).
	virtual bool overCopy(uint32_t options) const { return false; }

	/// The Managed buffer of `length` bytes and `options` whose CPU copy is the Shared buffer
	/// `copy` made in a slab of this source, its bytes from `zeroFrom` to the length zero (none
	/// where `zeroFrom` is the length or more); false where the device never got it.
	virtual bool makeOverCopy(const Made &copy, uint64_t length, uint32_t options,
	                          uint64_t zeroFrom, Made *out)
	{
		return false;
	}

	/// Destroys the Shared buffer `copy` a Managed buffer lay over, once that buffer's destroy is
	/// posted, its address given back where its create picked it: `then` once the destroy is.
	virtual void dropCopy(const Made &copy, std::function<void()> then) { then(); }
};

/// Slabs of the device region: each a block of the kext's (RgfxRegion::allocate), in Metal's
/// 16 KiB pages, its bytes whatever the block held before. A Shared slab is a Placement heap over
/// host memory and its buffers BUFFER_AT_OFFSET there. A Managed buffer is, where the device took
/// RGFX_FEATURE_MANAGED_BUFFER_SLABS (`managedOverCopy`), a MANAGED_BUFFER_CREATE over a Shared
/// buffer of the Shared class (MANAGED OVER A COPY). Else Managed buffers have slabs of their own:
/// where the device took RGFX_FEATURE_MANAGED_AT_OFFSET (`managedAtOffset`), a Shared Placement
/// heap over host memory too, each buffer a BUFFER_MANAGED_AT_OFFSET at an address of its own whose
/// CPU copy the host places in the heap at its range; else a block whose buffers are each a
/// BUFFER_OVER_HOST_MEMORY over their own range, their CPU copy.
class RgfxRegionSlabSource : public RgfxSlabSource {
public:
	RgfxRegionSlabSource(RgfxRegion &region, RgfxSerializer &serializer,
	                     bool managedAtOffset = false, bool managedOverCopy = false);

	uint64_t unit() const override { return kUnit; }
	uint64_t capacity() const override;
	bool heaped(uint32_t options) const override;
	bool take(uint64_t size, bool heap, Memory *out) override;
	void give(const Memory &memory) override;
	bool makeHeap(const Memory &memory, uint32_t options, Heap *out) override;
	void dropHeap(const Heap &heap) override;
	bool makeBuffer(const Memory &memory, const Heap &heap, uint64_t offset, uint64_t length,
	                uint32_t options, Made *out) override;
	uint32_t classOptions(uint32_t options) const override;
	bool overCopy(uint32_t options) const override;
	bool makeOverCopy(const Made &copy, uint64_t length, uint32_t options, uint64_t zeroFrom,
	                  Made *out) override;
	void dropCopy(const Made &copy, std::function<void()> then) override;
	/// Whether the kext zeroes each block it gives (its kRgfxKextFeatureZeroedBlocks): a slab
	/// taken from it then reads zero as it comes, and is not zeroed again here. False until set:
	/// a block holds whatever its last holder left in it.
	void setZeroedBlocks(bool zeroed) { m_zeroedBlocks = zeroed; }

	/// Metal's page, which a heap over host memory is made of.
	static constexpr uint64_t kUnit = 0x4000;

protected:
	RgfxRegion &m_region;
	RgfxSerializer &m_serializer;
	bool m_managedAtOffset;
	bool m_managedOverCopy;
	bool m_zeroedBlocks = false;
};

/// The process's own memory a source of pages slabs takes from the kernel: calls the device wires
/// (RgfxMetalDevice: mach_vm_allocate) and the tests fake.
struct RgfxPagesMemory {
	void *context = nullptr;
	/// `size` bytes of plain pages, zero-filled, which the kext's pages block wires: 0
	/// (KERN_SUCCESS), or the kernel's refusal. Null for none.
	int (*pages)(void *context, uint64_t size, uint8_t **bytes) = nullptr;
	/// Gives back what pages made.
	void (*unmap)(void *context, uint8_t *bytes, uint64_t size) = nullptr;
};

/// Slabs of the process's own pages: the kext's chunks of 64 KiB where it gives them
/// (RgfxRegion::acquireChunkedPages), else plain pages, wired into a pages block of the kext's
/// (RgfxRegion::acquirePages; RGFX_FEATURE_PAGES_BUFFERS), so their buffers' memory is the guest's
/// RAM, not the device region's, for the classes whose buffers lie in heaps. A class's slab (2 MiB,
/// or of chunks up to 16 MiB: CHUNKED SLABS GROW) and a buffer's own slab of 2 MiB are each a
/// heap the host makes over the block's view of its runs (HEAP_OVER_PAGES;
/// RGFX_FEATURE_HEAP_OVER_PAGES), its buffers placed there as in a region slab's heap. A larger
/// slab of a buffer's own holds one dedicated Shared buffer, a BUFFER_OVER_PAGES over the block's
/// view, or a Managed buffer over such a Shared copy (MANAGED OVER A COPY); a larger Managed one
/// of a class of its
/// own, and a slab where the kernel has no pages to give or the kext no pages block, are the
/// region's. A slab goes with its heap's destroy, then its block's release (the kext's Free, which
/// waits for the device's answer), then its plain pages; chunks go with the release.
///
/// Why the process's own pages: the region is no RAM of the guest's, which the kernel maps
/// uncached under xnu's PAT, as an AMD host applies (13 MB/s for a process's stores there, against
/// 56 to 123 GB/s in a superpage of its own RAM; RgfxRegion.hpp), until the x86-64 kext sets the
/// PAT's entry 2 to write-back at its start.
///
/// Why plain pages, never superpages: the kernel's 2 MiB superpages, each one run of RAM, run out
/// within minutes of a boot (measured on an x86-64 macOS 26.7.2 guest of 8 GiB: 19 for one
/// process at boot with 2.5 GiB free, then KERN_NO_SPACE; none three minutes later), and asking
/// for one stalls the process, on whatever thread asks. The kernel searches for a contiguous
/// 2 MiB (vm_map_enter's superpage path, in cpm_allocate, which sleeps as it goes and moves pages
/// to make a run) with the process's map held: in the public xnu-12377.101.15 source, under the
/// map's interlock and with the new entry locked exclusive, which a walk of the map past it
/// (vm_map_region's shared range lock) waits for. Measured with tailspin on that guest on the
/// Radeon 780M host: a refused search took 140 to 190 ms, and while WindowServer's slabs thread
/// searched, its main thread, making a texture over a layer's image as a window was resized,
/// waited in vm_map_region for it, and Safari's page drew no frame for 179 ms. Plain pages are
/// what every slab took once superpages ran out, minutes after a boot.
///
/// Why chunks first: a 2 MiB slab of plain pages is up to 512 runs of the guest's RAM, and the
/// host maps each run of a view apart, against a budget of mappings per process (vm.max_map_count
/// on Linux): at its stock 65530, views of scattered pages, slabs' among them, used up the budget on
/// NVIDIA, and the buffers made after were copies. The kext's chunks are 64 KiB runs, so a 2 MiB slab is 32 runs at most,
/// and a run of 64 KiB is one the kernel finds at once, however long the guest has run, where
/// 2 MiB runs are as scarce as superpages (RgfxUserClientABI.hpp, kRgfxPagesChunk).
class RgfxPagesSlabSource : public RgfxRegionSlabSource {
public:
	RgfxPagesSlabSource(RgfxRegion &region, RgfxSerializer &serializer,
	                    const RgfxPagesMemory &memory, uint64_t capacity,
	                    bool managedAtOffset = false, bool managedOverCopy = false);

	uint64_t unit() const override { return kUnit; }
	bool serves(uint32_t options, uint64_t size, bool dedicated) const override;
	uint64_t smallMax() const override;
	uint64_t slabMax() const override;
	bool heapedSlab(uint64_t size, uint32_t options, bool dedicated) const override;
	uint64_t capacity() const override { return m_capacity; }
	bool inRegion() const override { return false; }
	bool take(uint64_t size, bool heap, Memory *out) override;
	void give(const Memory &memory) override;
	bool makeHeap(const Memory &memory, uint32_t options, Heap *out) override;
	bool makeBuffer(const Memory &memory, const Heap &heap, uint64_t offset, uint64_t length,
	                uint32_t options, Made *out) override;

	/// The size of a slab with a heap, and what every slab's size is a multiple of.
	static constexpr uint64_t kUnit = 2ull << 20;
	/// Where the kext gives chunks: the largest buffer that shares a slab of its class, and the
	/// largest such slab, a heap over 256 chunks (CHUNKED SLABS GROW).
	static constexpr uint64_t kChunkedSmallMax = 4ull << 20;
	static constexpr uint64_t kChunkedSlabMax = 16ull << 20;

private:
	RgfxPagesMemory m_memory;
	uint64_t m_capacity;
};

/// The Shared pool's blocks a source of pool slabs takes from the kext: calls the device wires
/// (RgfxMetalDevice: kRgfxAccelMethodPoolTake and kRgfxAccelMethodPoolGive) and the tests fake.
struct RgfxPoolMemory {
	void *context = nullptr;
	/// A block of the pool of `size` bytes, a multiple of 64 KiB, mapped into the process, its
	/// bytes zero: 0 (KERN_SUCCESS) with its address in the process at `*bytes`, its offset in
	/// the pool at `*offset` and the GPU address the host gave it at `*gpu_address`, 0 where it
	/// gave none (RGFX_FEATURE_POOL_ADDRESSES not taken), or the kext's refusal. Waits for the
	/// host's answer.
	int (*take)(void *context, uint64_t size, uint8_t **bytes, uint64_t *offset,
	            uint64_t *gpu_address) = nullptr;
	/// Gives back the block at pool offset `offset`: the kext takes it out of the process, then
	/// gives it to the host, without waiting.
	void (*give)(void *context, uint64_t offset) = nullptr;
};

/// Slabs of the device's Shared pool (RGFX_FEATURE_POOL; docs/graphics-kext/design.md, "The
/// Shared pool"): host memory past the guest's RAM that the kext maps into the process
/// write-back, a block of its own a slab, which the host zeroes as it gives it. Every slab is a
/// Shared heap over its block (HEAP_OVER_POOL), its buffers placed there as in a region slab's
/// heap (BUFFER_AT_OFFSET, BUFFER_MANAGED_AT_OFFSET), a large buffer's own slab included; a
/// Managed buffer lies over a Shared copy (MANAGED OVER A COPY) where the device makes one, else
/// in a heap where its CPU copy is placed (BUFFER_MANAGED_AT_OFFSET), else the source serves no
/// slab of its class. A class's slabs grow to kSlabMax and hold buffers of up to kSmallMax, as the
/// kext's chunks do. The device makes it the slabs' one source where Managed buffers lie over
/// copies (THE SOURCES): a buffer it has no block for is nil.
///
/// The allocator keeps none of these slabs once empty (keepsFreed): a slab goes with its last
/// buffer, its heap's destroy and then its block's give, and a later buffer takes a new block.
/// Measured on the Radeon 780M host (an x86-64 macOS guest's boot to its desktop, a window
/// dragged 31 s, and a GPU benchmark's run, the slab churn lines): the empty slabs a class kept
/// were taken from again 5 times before the desktop and never in the drag or the benchmark, and
/// no large buffer took a cached slab, so the kept slabs would save no take there.
///
/// The take waits for the host on the thread whose buffer found no room, as Metal's newBuffer
/// waits for the kernel's pages: takes() counts them and the time they took.
///
/// Where the host gives a block its GPU address (RGFX_FEATURE_POOL_ADDRESSES), the block's heap
/// lies there, picked by no one in the process's range of addresses, and its buffers at their
/// offsets from it; where it gives none, the heap's address is the process's pick, as a region
/// slab's is.
class RgfxPoolSlabSource : public RgfxRegionSlabSource {
public:
	RgfxPoolSlabSource(RgfxRegion &region, RgfxSerializer &serializer,
	                   const RgfxPoolMemory &memory, bool managedAtOffset = false,
	                   bool managedOverCopy = false);

	uint64_t unit() const override { return kUnit; }
	bool serves(uint32_t options, uint64_t size, bool dedicated) const override;
	uint64_t smallMax() const override { return kSmallMax; }
	uint64_t slabMax() const override { return kSlabMax; }
	bool keepsFreed() const override { return false; }
	bool inRegion() const override { return false; }
	/// Whatever the pool holds: the host's. Sizes no cache, as the allocator keeps none of this
	/// source's slabs.
	uint64_t capacity() const override { return UINT64_MAX; }
	bool heapedSlab(uint64_t size, uint32_t options, bool dedicated) const override;
	bool take(uint64_t size, bool heap, Memory *out) override;
	void give(const Memory &memory) override;
	bool makeHeap(const Memory &memory, uint32_t options, Heap *out) override;

	/// The pool's blocks taken and given so far, and the time the takes waited.
	struct Takes {
		uint64_t taken = 0;      // blocks taken
		uint64_t takenBytes = 0; // their bytes
		uint64_t refused = 0;    // takes the kext refused
		uint64_t waitUs = 0;     // the time every take waited, refused ones among them, in us
		uint64_t longestUs = 0;  // the longest
		uint64_t given = 0;      // blocks given back
		uint64_t addressed = 0;  // blocks whose heap lies at the GPU address the host gave
	};
	Takes takes() const;

	/// A block's size, and what every slab's size is a multiple of: the wire's
	/// RGFX_POOL_BLOCK_ALIGN.
	static constexpr uint64_t kUnit = 64ull << 10;
	/// The largest buffer that shares a slab of its class, and the largest such slab.
	static constexpr uint64_t kSmallMax = 4ull << 20;
	static constexpr uint64_t kSlabMax = 16ull << 20;
	/// The longest block: the wire's RGFX_POOL_TAKE_MAX. The source serves no larger buffer.
	static constexpr uint64_t kTakeMax = 1ull << 32;

private:
	RgfxPoolMemory m_memory;
	std::atomic<uint64_t> m_taken{0};
	std::atomic<uint64_t> m_takenBytes{0};
	std::atomic<uint64_t> m_refused{0};
	std::atomic<uint64_t> m_waitUs{0};
	std::atomic<uint64_t> m_longestUs{0};
	std::atomic<uint64_t> m_given{0};
	std::atomic<uint64_t> m_addressed{0};
};

class RgfxSlabs {
public:
	/// A range of a slab a buffer lies in: `size` bytes (allocatedSize) at `offset` of its slab,
	/// at `contents` here, whose bytes from `zeroFrom` (the take's `keep`) to its size read zero
	/// as take() answers it. `slab` names it for give().
	struct Range {
		const void *slab = nullptr;
		uint64_t offset = 0;
		uint64_t size = 0;
		uint8_t *contents = nullptr;
		uint64_t zeroFrom = UINT64_MAX; // nothing said, but by take()
	};

	/// What the allocator holds, for the tests and diagnostics.
	struct Stats {
		uint64_t slabs = 0;        // every slab held, dedicated ones and cached ones among them
		uint64_t slabBytes = 0;    // their bytes
		uint64_t emptySlabs = 0;   // small slabs with no buffer in them
		uint64_t cachedSlabs = 0;  // dedicated slabs with no buffer, kept for reuse
		uint64_t cachedBytes = 0;
		uint64_t dirtyBytes = 0;   // free bytes not yet zeroed
		uint64_t dooming = 0;      // slabs let go whose memory is not yet back in its source
		uint64_t usedBytes = 0;    // bytes taken by buffers
		uint64_t firstSlabs = 0;   // of the slabs, those the first source made
	};

	/// What the slabs' reuse saved their sources, counted since the allocator was made: each
	/// refill of an empty slab a class kept, and each cached slab a large buffer took, is a slab
	/// its source would otherwise have taken back and given again (CHURN).
	struct Churn {
		uint64_t classMade = 0;            // slabs of small buffers made
		uint64_t classMadeBytes = 0;
		uint64_t emptied = 0;              // slabs of small buffers left with no buffer in them
		uint64_t refilled = 0;             // empty slabs a class kept, taken from again
		uint64_t refilledBytes = 0;        // their sizes
		uint64_t emptyLetGo = 0;           // empty slabs of small buffers let go
		uint64_t dedicatedMade = 0;        // slabs of large buffers made
		uint64_t dedicatedReused = 0;      // cached slabs a large buffer took
		uint64_t dedicatedReusedBytes = 0; // their sizes
	};

	/// Called with the counts on the background thread (step), at most every kChurnLogMs and only
	/// where they changed since the last call.
	typedef void (*ChurnLog)(void *context, const Churn &churn);

	/// Slabs of `source`, their own (THE SOURCES): the region's, or the Shared pool's.
	/// RgfxRegion::setReclaim asks them to give room back.
	explicit RgfxSlabs(RgfxSlabSource &source);

	/// A source asked before the own source for every new slab (THE SOURCES), or null for none.
	/// Set before any take.
	void setFirst(RgfxSlabSource *first);

	/// Stops the background thread. Gives nothing back: the slabs' memory and heaps go with the
	/// process's context, as its other blocks do.
	~RgfxSlabs();

	RgfxSlabs(const RgfxSlabs &) = delete;
	RgfxSlabs &operator=(const RgfxSlabs &) = delete;

	/// Starts the background thread that zeroes freed bytes and lets slabs go. False where it
	/// could not be made: creates then zero what they take, and frees let slabs go themselves.
	bool start();

	/// A range for a buffer of `length` bytes and `options` (hazard tracking resolved), zeroed
	/// past its first `keep` bytes, which the caller writes. False where no slab can hold it.
	bool take(uint64_t length, uint32_t options, uint64_t keep, Range *out);

	/// The buffer of `length` bytes and `options` over `range` (RgfxSlabSource::makeBuffer): a
	/// Managed one of a source over copies over a Shared buffer made there first, which give()
	/// destroys (MANAGED OVER A COPY), where the Managed buffer was not made too. The Managed
	/// buffer's create says its bytes read zero from the range's `zeroFrom` (ZEROING), so the
	/// caller writes nothing past its `keep` before this.
	bool makeBuffer(const Range &range, uint64_t length, uint32_t options,
	                RgfxSlabSource::Made *out);

	/// Whether a Managed buffer of `options` lies over a Shared copy (MANAGED OVER A COPY): the
	/// device took RGFX_FEATURE_MANAGED_BUFFER_SLABS, and makes one over any Shared buffer.
	bool overCopy(uint32_t options) const { return m_source.overCopy(options); }

	/// Whether the own source is the region's (THE SOURCES): where it is not (the Shared
	/// pool's), the region is behind no buffer of the process's, an upload chunk's included
	/// (RgfxUploadPool).
	bool inRegion() const { return m_source.inRegion(); }

	/// The clock the idle times are read from, in ms: `now(context)`, for the tests; the steady
	/// clock where none is set. Set before any take.
	typedef uint64_t (*Clock)(void *context);
	void setClock(Clock now, void *context);

	/// Gives `range` back, once its buffer's destroy is posted: after the destroy of the Shared
	/// copy a Managed buffer over it lay over, where it has one.
	void give(const Range &range);

	/// Lets every empty and cached slab go, with the doomed ones, where the source had no room
	/// for another block of the process's (RgfxRegion::setReclaim, and each round of a take's
	/// fallbacks), and waits for the slabs other threads were giving back as it was called
	/// (waitForDrops): true where one went or came back. Called without the lock.
	bool reclaim();

	/// Does one piece of the background's work (a drop, a piece zeroed, an idle cached slab let
	/// go): false where there was none. The thread runs it; the tests call it.
	bool step();

	Stats stats();

	/// The reuse counts so far (CHURN).
	Churn churn();

	/// Where set, the background thread calls `log(context, counts)` once the counts changed,
	/// kChurnLogMs after its last call at the soonest. Set before start().
	void setChurnLog(ChurnLog log, void *context);

	/// How often, at most, the churn log is called, in ms.
	static constexpr uint64_t kChurnLogMs = 5000;

	/// A buffer's page: what its range is a multiple of, and its offset in its slab.
	static constexpr uint64_t kGranule = 0x1000;
	/// The largest buffer a class's slabs hold, a larger one taking a slab of its own, and a
	/// class's largest slab, unless the first source, or the own source with no first, says
	/// larger (RgfxSlabSource::smallMax, slabMax); and its first slab.
	static constexpr uint64_t kSmallMax = RgfxSlabSource::kSmallMax;
	static constexpr uint64_t kSlabMax = RgfxSlabSource::kSlabMax;
	static constexpr uint64_t kSlabFirst = 128ull << 10;
	/// The most bytes the background zeroes at a time.
	static constexpr uint64_t kZeroPiece = 256ull << 10;
	/// How long a cached slab is kept unused.
	static constexpr uint64_t kCacheIdleMs = 2000;
	/// The empty slabs a class keeps.
	static constexpr unsigned kEmptyKept = 2;

private:
	/// Runs of bytes, by start: none overlap or touch, and `bytes` is their sum.
	struct Runs {
		std::map<uint64_t, uint64_t> runs;
		uint64_t bytes = 0;
		void add(uint64_t at, uint64_t length);
		bool takeFirstFit(uint64_t length, uint64_t *at);
		bool takeAt(uint64_t at, uint64_t length);
		/// Removes the bytes of [at, at + length) it holds, and appends them to `out`.
		void cut(uint64_t at, uint64_t length, std::vector<std::pair<uint64_t, uint64_t>> *out);
	};

	struct Slab {
		RgfxSlabSource *source = nullptr; // the source it came from, which takes it back
		RgfxSlabSource::Memory memory;
		RgfxSlabSource::Heap heap;
		uint32_t options = 0;
		bool dedicated = false;
		uint64_t serial = 0;       // the order slabs were made in
		Runs free;                 // bytes no buffer takes and the background is not zeroing
		Runs dirty;                // of the free bytes, those that may not read zero
		uint64_t used = 0;         // bytes taken by buffers
		uint32_t zeroing = 0;      // pieces the background is zeroing
		bool doomed = false;       // let go: no buffer takes from it again
		uint64_t idleSince = 0;    // the time, in ms, a cached slab was cached, an empty one emptied
		// The Shared copies Managed buffers lie over, by their ranges' offsets.
		std::map<uint64_t, RgfxSlabSource::Made> copies;
	};

	struct BySerial {
		bool operator()(const Slab *a, const Slab *b) const { return a->serial < b->serial; }
	};

	struct Class {
		std::vector<Slab *> slabs;           // its slabs of small buffers
		std::set<Slab *, BySerial> open;     // of them, those with free bytes
		uint64_t nextSize = kSlabFirst;
		unsigned empty = 0;
	};

	/// A new slab of `size` bytes for buffers of `options`, through `source`; null where it gave
	/// none, with `*refused` set where it gave the memory but the device never got its heap.
	/// Called without the lock.
	Slab *makeSlab(RgfxSlabSource &source, uint64_t size, uint32_t options, bool dedicated,
	               bool *refused);
	/// The bytes of the cached slabs of `source`. Caller holds the lock.
	uint64_t cachedBytesOf(const RgfxSlabSource *source) const;
	/// Takes `size` bytes of `slab` at its first fit, zeroing past `keep` what was dirty: the
	/// pieces to zero go in `*zero`. Caller holds the lock.
	bool takeIn(Slab *slab, uint64_t size, uint64_t keep,
	            std::vector<std::pair<uint64_t, uint64_t>> *zero, uint64_t *at);
	/// Lets `slab` go: out of its class or the cache, onto the doomed list. Caller holds the lock.
	void doom(Slab *slab);
	/// Removes `slab` from the cache. Caller holds the lock.
	void uncache(Slab *slab);
	/// Drops the doomed slabs no piece is being zeroed in, and lets every empty and cached slab
	/// go first where `evict`: the process's own room given back before a create is refused.
	/// Answers how many it dropped.
	size_t dropDoomed(bool evict);
	/// Gives a slab's heap and memory back, and frees it, its serial in m_dropping meanwhile.
	/// Called without the lock.
	void drop(Slab *slab);
	/// Waits until the slabs being given back (m_dropping) and the doomed ones (m_doomed) as this
	/// is called are gone, their memory back in their sources (THE FALLBACKS): whether there were
	/// any. Called without the lock, by a thread that is giving none back, after its own
	/// dropDoomed(true). Those are the drops that call would have made itself had it come first,
	/// on the same locks and the same host answers (the heap's destroy, the block's release), so
	/// the wait holds its thread on nothing that call would not have.
	bool waitForDrops();
	/// Gives `range` back to its slab, its buffers' destroys all posted.
	void giveBack(const Range &range);
	/// The class of `options`. Caller holds the lock.
	Class &classOf(uint32_t options);
	/// Lets go the empty slabs of small buffers left empty kCacheIdleMs by `now`, and sets when
	/// the next one is due (m_emptyDue, 0 for none). Caller holds the lock.
	void decayEmpty(uint64_t now);
	/// How long the thread may wait before a cached or empty slab is due to go, in ms; -1 where
	/// none is. Caller holds the lock.
	int64_t idleWait(uint64_t now) const;
	/// How long the thread may wait before the churn log is due, in ms; -1 where it is not.
	/// Caller holds the lock.
	int64_t churnWait(uint64_t now) const;
	/// Calls the churn log where it is due. Called without the lock.
	void logChurn();
	/// Marks the counts changed: whether the thread needs waking for the log. Caller holds the
	/// lock.
	bool churned();
	void run();
	uint64_t nowMs() const;

	RgfxSlabSource &m_source;
	RgfxSlabSource *m_first = nullptr;
	std::mutex m_lock;
	std::condition_variable m_wake;
	std::map<uint32_t, Class> m_classes;
	std::set<Slab *> m_all;
	std::vector<Slab *> m_cached;          // dedicated slabs with no buffer, oldest first
	uint64_t m_cachedBytes = 0;
	uint64_t m_emptyDue = 0;               // when an empty small slab is next due to go; 0 for none
	Clock m_clock = nullptr;
	void *m_clockContext = nullptr;
	std::vector<Slab *> m_doomed;
	std::set<uint64_t> m_dropping;           // serials of the slabs being given back (drop)
	std::condition_variable m_dropped;       // a drop is done
	std::set<Slab *, BySerial> m_dirtySlabs; // slabs with dirty free bytes
	uint64_t m_nextSerial = 1;
	Churn m_churn;
	bool m_churnChanged = false;   // since the last log
	bool m_churnLogged = false;    // the log was called once
	uint64_t m_churnLoggedAt = 0;  // when, in ms
	ChurnLog m_churnLog = nullptr;
	void *m_churnLogContext = nullptr;
	std::thread m_thread;
	bool m_running = false;
	bool m_stop = false;
};

#endif // RGFX_SLABS_HPP_
