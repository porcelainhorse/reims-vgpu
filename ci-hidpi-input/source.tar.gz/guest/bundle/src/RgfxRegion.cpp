/*
 * RgfxRegion: the BAR-region bump allocator (RgfxRegion.hpp). The policy and the
 * reserved head are documented in the header.
 */

#include "RgfxRegion.hpp"

#include <mach/mach.h>
#include <mach/mach_vm.h>
#include <os/log.h>
#include <time.h>

#include <cstring>

#include "RgfxFilePages.hpp"
#include "RgfxLog.hpp"
#include "RgfxLogOnce.hpp"

RgfxRegion::RgfxRegion(volatile uint8_t *base, uint64_t size)
    : m_base(base), m_size(size), m_floor(RGFX_ALLOCATIONS_OFFSET), m_cursor(RGFX_ALLOCATIONS_OFFSET)
{
}

uint64_t RgfxRegion::alignUp(uint64_t value, uint64_t align)
{
	return (value + (align - 1)) & ~(align - 1);
}

uint64_t RgfxRegion::used() const
{
	// m_cursor only grows and never drops below the floor, so the subtraction is safe
	// without the lock (a racing allocate may make this a slight under-count; it is a
	// diagnostic).
	return m_cursor - m_floor;
}

bool RgfxRegion::freeBytes(uint64_t *bytes) const
{
	if (m_alloc != nullptr) {
		return false;
	}
	*bytes = m_size > m_cursor ? m_size - m_cursor : 0;
	return true;
}

void RgfxRegion::setBlockSource(AllocFn alloc, ReleaseFn release, void *context)
{
	std::lock_guard<std::mutex> guard(m_lock);
	m_alloc = alloc;
	m_release = release;
	m_sourceContext = context;
}

void RgfxRegion::setWriteCombinedSource(WriteCombinedAllocFn alloc)
{
	std::lock_guard<std::mutex> guard(m_lock);
	m_writeCombinedAlloc = alloc;
}

void RgfxRegion::setReclaim(ReclaimFn reclaim, void *context)
{
	std::lock_guard<std::mutex> guard(m_lock);
	m_reclaim = reclaim;
	m_reclaimContext = context;
}

bool RgfxRegion::reclaimed()
{
	return m_reclaim != nullptr && m_reclaim(m_reclaimContext);
}

void RgfxRegion::setSurfaceSource(SurfaceAcquireFn acquire, ReleaseFn release, void *context)
{
	std::lock_guard<std::mutex> guard(m_lock);
	m_surfaceAcquire = acquire;
	m_surfaceRelease = release;
	m_surfaceContext = context;
}

RgfxRegion::SurfaceBlock RgfxRegion::acquireSurface(const void *plane, uint64_t length,
                                                    uint64_t size)
{
	SurfaceBlock out = {};
	uint64_t offset = 0, serial = 0;
	bool fresh = false;
	if (m_surfaceAcquire == nullptr ||
	    !m_surfaceAcquire(m_surfaceContext, plane, length, size, &offset, &serial, &fresh)) {
		return out; // block.ok == false
	}
	if (offset < m_floor || offset > m_size || size > m_size - offset) {
		releaseSurface(offset);
		return out;
	}
	out.block = {offset, m_base + offset, size, true, 0};
	out.serial = serial;
	out.fresh = fresh;
	return out;
}

void RgfxRegion::setSurfacePagesSource(SurfacePagesFn acquire, uint64_t alignment, void *context)
{
	std::lock_guard<std::mutex> guard(m_lock);
	m_pagesAcquire = acquire;
	m_pagesAlignment = alignment;
	m_pagesContext = context;
}

RgfxRegion::SurfaceBlock RgfxRegion::acquireSurfacePages(const void *base, uint64_t length,
                                                         uint64_t size, uint32_t surfaceId,
                                                         bool cacheable,
                                                         const RgfxSurfacePagesLayout *layout,
                                                         PagesAnswer *answer)
{
	SurfaceBlock out = {};
	uint64_t offset = 0, serial = 0;
	bool fresh = false, cached = false;
	auto ask = [&] {
		return m_pagesAcquire(m_pagesContext, base, length, size, surfaceId, cacheable, layout,
		                      &offset, &serial, &fresh, &cached);
	};
	*answer = m_pagesAcquire == nullptr ? kPagesUnsupported : ask();
	if (*answer == kPagesNoRoom && reclaimed()) {
		*answer = ask();
	}
	if (*answer != kPagesGiven) {
		return out; // block.ok == false
	}
	if (offset < m_floor || offset > m_size || size > m_size - offset) {
		releaseSurface(offset);
		*answer = kPagesRefused;
		return out;
	}
	out.block = {offset, m_base + offset, size, true, 0};
	out.serial = serial;
	out.fresh = fresh;
	out.cached = cached;
	return out;
}

void RgfxRegion::setSurfaceWriteSource(SurfaceWritesFn note, SurfaceRetireFn retire,
                                       void *context)
{
	std::lock_guard<std::mutex> guard(m_lock);
	m_writesNote = note;
	m_writesRetire = retire;
	m_writesContext = context;
}

void RgfxRegion::noteSurfaceWrites(uint64_t queue, uint64_t seqno, const uint64_t *writes,
                                   uint32_t count)
{
	if (m_writesNote != nullptr && count != 0) {
		m_writesNote(m_writesContext, queue, seqno, writes, count);
	}
}

void RgfxRegion::retireSurfaceWrites(uint64_t queue, uint64_t seqno)
{
	if (m_writesRetire != nullptr) {
		m_writesRetire(m_writesContext, queue, seqno);
	}
}

void RgfxRegion::setSurfaceSeedsSource(SurfaceSeedsFn seeds, void *context)
{
	std::lock_guard<std::mutex> guard(m_lock);
	m_seeds = seeds;
	m_seedsContext = context;
}

bool RgfxRegion::surfaceSeeds(uint32_t surfaceId, uint32_t *lockSeed, uint32_t *unlockSeed)
{
	return m_seeds != nullptr && m_seeds(m_seedsContext, surfaceId, lockSeed, unlockSeed);
}

void RgfxRegion::setPagesBlockSource(PagesBlockFn acquire, void *context)
{
	std::lock_guard<std::mutex> guard(m_lock);
	m_pagesBlock = acquire;
	m_pagesBlockContext = context;
}

void RgfxRegion::setChunkedPagesSource(ChunkedPagesFn make, void *context)
{
	std::lock_guard<std::mutex> guard(m_lock);
	m_chunkedPages = make;
	m_chunkedPagesContext = context;
}

RgfxRegion::Block RgfxRegion::acquireChunkedPages(uint64_t length)
{
	Block out = {};
	uint8_t *bytes = nullptr;
	uint64_t offset = 0, size = 0;
	if (m_chunkedPages == nullptr ||
	    !m_chunkedPages(m_chunkedPagesContext, length, &bytes, &offset, &size))
		return out; // ok == false
	if (offset < m_floor || offset > m_size || size > m_size - offset) {
		release(offset);
		return out;
	}
	out.offset = offset;
	out.ptr = bytes;
	out.size = size;
	out.ok = true;
	return out;
}

bool rgfxPagesIdentity(const void *address, uint64_t length, std::vector<uint64_t> *identity)
{
	identity->clear();
	mach_vm_address_t at = reinterpret_cast<uintptr_t>(address);
	const mach_vm_address_t end = at + length;
	if (length == 0 || end < at)
		return false;
	natural_t depth = 0;
	while (at < end) {
		mach_vm_address_t base = at;
		mach_vm_size_t size = 0;
		vm_region_submap_info_data_64_t info = {};
		mach_msg_type_number_t count = VM_REGION_SUBMAP_INFO_V2_COUNT_64;
		if (mach_vm_region_recurse(mach_task_self(), &base, &size, &depth,
		                           reinterpret_cast<vm_region_recurse_info_t>(&info),
		                           &count) != KERN_SUCCESS)
			return false;
		// The region found is the one holding `at`, or the next one past a hole.
		if (base > at)
			return false;
		if (info.is_submap) {
			depth++;
			continue;
		}
		if (count < VM_REGION_SUBMAP_INFO_V2_COUNT_64 || info.object_id_full == 0)
			return false;
		const mach_vm_address_t stop = base + size < end ? base + size : end;
		identity->push_back(info.object_id_full);
		identity->push_back(info.offset + (at - base));
		identity->push_back(stop - at);
		at = stop;
		depth = 0;
	}
	return true;
}

RgfxRegion::Block RgfxRegion::acquirePages(const void *address, uint64_t length, bool writable,
                                           uint32_t join)
{
	Block out = {};
	if (m_pagesBlock == nullptr)
		return out; // ok == false
	const PagesRange range = {reinterpret_cast<uintptr_t>(address), length, writable, join};
	if (join != kPagesOwn) {
		std::vector<uint64_t> now;
		const bool known = rgfxPagesIdentity(address, length, &now);
		std::lock_guard<std::mutex> guard(m_pagesLock);
		auto it = m_joinablePages.find(range);
		if (it != m_joinablePages.end()) {
			JoinedPages &joined = m_joinedPages.at(it->second);
			if (known && now == joined.identity) {
				joined.joinable++;
				joined.held++;
				out.offset = it->second;
				out.size = joined.size;
				out.ok = true;
				out.gpuAddress = joined.gpuAddress;
				return out;
			}
			// Other memory at the bytes now: the block is joinable no longer, and stays held
			// by the objects over it until their releases.
			static char site;
			if (rgfxLogFirst(&site))
				os_log_info(rgfxLog(),
				            "RGFX: a no-copy buffer over %llu bytes takes a pages block of its own: "
				            "a live one over the same address and length lies over the memory the "
				            "process mapped there before",
				            (unsigned long long)length);
			os_log_debug(rgfxLog(),
			             "RGFX: no join of the pages block at 0x%llx for %llu bytes at %p: the "
			             "memory there is other memory now",
			             (unsigned long long)it->second, (unsigned long long)length, address);
			joined.joinable = 0;
			m_joinablePages.erase(it);
			m_rejoinsRefused++;
		}
	}
	uint64_t offset = 0, size = 0, gpuAddress = 0;
	const uint32_t how = writable ? kPagesWritable : 0;
	bool given = false;
	if (!writable && m_unchangingPages) {
		// Read-only memory, classified (RgfxFilePages.hpp): the app's own pages named unchanging
		// where they cannot change, and else with why not, which the host counts its copies by.
		const uint64_t t0 = clock_gettime_nsec_np(CLOCK_UPTIME_RAW);
		const RgfxFilePages file = rgfxFilePagesOf(address, length, m_soleHolderPages);
		const uint64_t ns = clock_gettime_nsec_np(CLOCK_UPTIME_RAW) - t0;
		uint32_t why = file.why;
		bool refused = false;
		if (file.clause != kRgfxFileNeither) {
			const bool copyOnWrite =
			    file.clause == kRgfxFileCopyOnWrite || file.clause == kRgfxAnonymousCopyOnWrite;
			const uint32_t unchanging =
			    kPagesUnchanging | (copyOnWrite ? kPagesCopyOnWrite : 0) |
			    (file.clause == kRgfxAnonymousPrivate ? kPagesSoleHolder : 0);
			given = m_pagesBlock(m_pagesBlockContext, address, length, unchanging, &offset, &size,
			                     &gpuAddress);
			refused = !given;
			why = RGFX_PAGES_WHY_REFUSED;
		}
		rgfxFilePagesNote(file, length, ns, refused);
		if (!given) {
			const uint32_t readOnly = how | (why << kPagesWhyShift);
			given = m_pagesBlock(m_pagesBlockContext, address, length, readOnly, &offset, &size,
			                     &gpuAddress);
		}
	} else {
		given = m_pagesBlock(m_pagesBlockContext, address, length, how, &offset, &size,
		                     &gpuAddress);
	}
	if (!given)
		return out; // ok == false
	if (offset < m_floor || offset > m_size || size > m_size - offset) {
		release(offset);
		return out;
	}
	// Joinable where the memory can be told, as it is now its pages are wired; a block the kext
	// gave for the same bytes on another thread meanwhile stays the one joined, and this one is
	// its own.
	std::vector<uint64_t> identity;
	if (join != kPagesOwn && rgfxPagesIdentity(address, length, &identity)) {
		std::lock_guard<std::mutex> guard(m_pagesLock);
		if (m_joinablePages.emplace(range, offset).second)
			m_joinedPages[offset] =
			    JoinedPages{range, size, 1, 1, std::move(identity), gpuAddress};
	}
	out.offset = offset;
	out.size = size;
	out.ok = true;
	out.gpuAddress = gpuAddress;
	return out;
}

uint64_t RgfxRegion::pagesRejoinsRefused() const
{
	std::lock_guard<std::mutex> guard(m_pagesLock);
	return m_rejoinsRefused;
}

void RgfxRegion::leavePages(uint64_t offset)
{
	std::lock_guard<std::mutex> guard(m_pagesLock);
	auto it = m_joinedPages.find(offset);
	if (it == m_joinedPages.end() || it->second.joinable == 0)
		return;
	if (--it->second.joinable == 0)
		m_joinablePages.erase(it->second.range);
}

void RgfxRegion::releaseSurface(uint64_t offset)
{
	if (m_surfaceRelease != nullptr) {
		m_surfaceRelease(m_surfaceContext, offset);
	}
}

void RgfxRegion::release(uint64_t offset)
{
	{
		std::lock_guard<std::mutex> guard(m_pagesLock);
		auto it = m_joinedPages.find(offset);
		if (it != m_joinedPages.end()) {
			if (--it->second.held != 0)
				return;
			if (it->second.joinable != 0)
				m_joinablePages.erase(it->second.range);
			m_joinedPages.erase(it);
		}
	}
	if (m_release != nullptr) {
		m_release(m_sourceContext, offset);
	}
}

RgfxRegion::Block RgfxRegion::allocate(uint64_t size, uint64_t align)
{
	return allocate(size, align, UINT64_MAX);
}

RgfxRegion::Block RgfxRegion::allocate(uint64_t size, uint64_t align, uint64_t writeCombinedFrom)
{
	Block out = {};
	if (!isPowerOfTwo(align)) {
		return out; // ok == false
	}

	if (m_alloc != nullptr) {
		uint64_t offset = 0;
		const bool combined = m_writeCombinedAlloc != nullptr && writeCombinedFrom < size;
		auto ask = [&] {
			return combined ? m_writeCombinedAlloc(m_sourceContext, size, align,
			                                       writeCombinedFrom, &offset)
			                : m_alloc(m_sourceContext, size, align, &offset);
		};
		const bool placed = ask() || (reclaimed() && ask());
		if (!placed || offset < m_floor || offset > m_size || size > m_size - offset) {
			return out; // no room; ok == false
		}
		out.offset = offset;
		out.ptr = m_base + offset;
		out.size = size;
		out.ok = true;
		return out;
	}

	std::lock_guard<std::mutex> guard(m_lock);

	uint64_t offset = alignUp(m_cursor, align);
	// Overflow-safe room check: the end must not pass the region's size.
	if (offset < m_cursor || offset > m_size || size > m_size - offset) {
		return out; // no room; ok == false
	}
	m_cursor = offset + size;

	out.offset = offset;
	out.ptr = m_base + offset;
	out.size = size;
	out.ok = true;
	return out;
}

RgfxRegion::RingPair RgfxRegion::allocateRingPair(uint32_t submit_data_size,
                                                  uint32_t complete_data_size)
{
	RingPair out = {};
	out.submit_data_size = submit_data_size;
	out.complete_data_size = complete_data_size;

	// Each ring's byte ring is a power of two (the host reads it with a mask); the
	// completion ring is optional (0 == none in the single-ring model).
	if (!isPowerOfTwo(submit_data_size) ||
	    (complete_data_size != 0 && !isPowerOfTwo(complete_data_size))) {
		return out; // ok == false
	}

	// Where the kext maps part of a block write-combined, the submission ring's data takes it,
	// from its block's second page, and the ring's header, which the host writes too and the
	// writer reads, ends the first page, write-back (WRITE-COMBINED PARTS).
	const bool combined = writeCombines();
	const uint64_t head = combined ? kDefaultBlockAlign - RGFX_RING_HEADER_SIZE : 0;
	Block submit = combined
	                   ? allocate(kDefaultBlockAlign + submit_data_size, kDefaultBlockAlign,
	                              kDefaultBlockAlign)
	                   : allocate(RGFX_RING_HEADER_SIZE + submit_data_size, kRingAlign);
	if (!submit.ok) {
		return out;
	}
	Block complete = {};
	if (complete_data_size != 0) {
		complete = allocate(RGFX_RING_HEADER_SIZE + complete_data_size, kRingAlign);
		if (!complete.ok) {
			release(submit.offset);
			return out;
		}
	}

	// Zero each ring's header + byte ring so a fresh RgfxRingWriter (producer 0,
	// consumer 0, consumer_idle 0, armed 0) starts clean over BAR memory whose
	// contents are otherwise undefined.
	std::memset(const_cast<uint8_t *>(submit.ptr + head), 0, submit.size - head);
	if (complete_data_size != 0) {
		std::memset(const_cast<uint8_t *>(complete.ptr), 0, complete.size);
	}

	out.submit_offset = submit.offset + head;
	out.complete_offset = complete_data_size != 0 ? complete.offset : 0;
	out.submit_block = submit.offset;
	out.complete_block = out.complete_offset;
	out.ok = true;
	return out;
}

bool RgfxRegion::contains(const void *p, uint64_t len) const
{
	if (p == nullptr) {
		return false;
	}
	const uint8_t *q = static_cast<const uint8_t *>(p);
	const uint8_t *base = const_cast<const uint8_t *>(m_base);
	if (q < base) {
		return false;
	}
	uint64_t offset = static_cast<uint64_t>(q - base);
	// Inside the guest-allocable region, and the whole span fits before its end.
	return offset >= m_floor && offset <= m_size && len <= m_size - offset;
}

uint64_t RgfxRegion::offsetOf(const void *p) const
{
	if (!contains(p, 0)) {
		return 0;
	}
	return static_cast<uint64_t>(static_cast<const uint8_t *>(p) -
	                             const_cast<const uint8_t *>(m_base));
}
