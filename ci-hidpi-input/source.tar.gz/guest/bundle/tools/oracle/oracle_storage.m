// oracle_storage: when Managed and Shared resources' CPU and GPU views meet.
//   oracle_storage DEVICE [CASE...]   every case (or the ones named), each in a child process of
//                                     its own, so a Metal abort ends only that case
// Cases:
//   mbuf SIZE     a Managed buffer of SIZE bytes (4096, 67108864, ...): CPU writes with and without
//                 didModifyRange:, GPU writes (blit fills) with and without synchronizeResource:,
//                 a partial didModifyRange: after a GPU write, a didModifyRange: made after the
//                 command buffer that reads the range was made but before its commit
//   mtex          a 256 x 256 RGBA8 Managed texture: replaceRegion:, GPU writes with and without
//                 synchronizeTexture:, a replaceRegion: of a corner after an unsynchronized GPU
//                 write
//   shtex         newTextureWithDescriptor: of storage Shared (2D BGRA8), used as a render target
//                 and read by the CPU (getBytes:)
//   lintex MODE   a linear BGRA8 texture over a Shared (MODE shared) or Managed (managed) buffer:
//                 CPU writes to the buffer seen by the GPU's reads of the texture, and a render
//                 pass's clear of the texture seen in the buffer, and replaceRegion: of the texture
//                 (whole, then a corner after a CPU write to the buffer) seen by the GPU
//   argenc MODE   an argument encoder's setBuffer: and setTexture: into a Shared (MODE shared) or
//                 Managed (managed) argument buffer: the GPU's copy of the bytes against the CPU's,
//                 with and without the app's didModifyRange:
//   nocopy        a no-copy Managed buffer over the app's pages and a linear texture over it: CPU
//                 writes to the pages with and without didModifyRange:, seen by the GPU or not
//   didmodify MODE  a linear texture (the SPI form) over a Managed buffer, of newBufferWithLength:
//                 (MODE length) or no-copy (nocopy): CPU writes seen by the GPU with no call and
//                 after the texture's didModifyData (SPI), as CoreAnimation calls it
//   linalign      the offsets and row pitches a texture over a Shared or Managed buffer takes, by
//                 the public form, the linear SPI and the tiled SPI: made or nil for each
//   linarray MODE a linear 2D array texture over a Shared buffer, by the linear SPI (MODE spi)
//                 or the public form (public): where each slice lies in the buffer, for the CPU's
//                 replaceRegion: and getBytes: and for the GPU's reads
//   lintypes FORM:TYPE  a texture of MTLTextureType TYPE over a Shared buffer by FORM (public,
//                 spi or tiled): made, nil, or where Metal's assertion ends the process
//   spin          a Shared buffer the CPU writes while one GPU thread polls it (atomic and plain
//                 loads), and one the GPU writes step by step while the CPU polls it
//   capture [BYTES]  which of a Managed buffer's CPU bytes (BYTES of them, 4096 by default) a
//                 command buffer's kernel reads where the CPU writes the range again after its
//                 didModifyRange: (A, then B): B written before the commit (the buffer encoded
//                 before A, or after B), B written after the commit while the buffer's first
//                 kernel spins, and B written at once after the commit returns, before the buffer
//                 is scheduled; each of the last two again with a second didModifyRange: right
//                 after B. A alone and B with a second didModifyRange: before the commit are the
//                 controls. A means the GPU's copy took the bytes at didModifyRange: (or at the
//                 commit, where B came after it), B at a later point: the submission, the GPU's
//                 read, or the second didModifyRange: itself
//   mtexcap [full|part]  which texels of a 256 x 256 RGBA8 Managed texture a committed command
//                 buffer's blit (into a Shared buffer) reads where replaceRegion: writes B over
//                 A after the commit: the whole texture (full, the default) or the rect
//                 (64,64)-(192,128) (part). The buffer first waits on a shared event (value 1),
//                 which the CPU signals after B. Steps: A, commit, signal (control: A); A, B,
//                 commit, signal (control: B); A, commit, B at once, signal. Where that last
//                 step leaves the point open (B read, and B written before the GPU started the
//                 buffer), B again after the buffer is scheduled (polled for at most 1 s) and
//                 20 ms more, then, if still open, with a spinning kernel (spin_atomic) in place
//                 of the event wait, B landing while the GPU runs it. A in the third step means
//                 the bytes were taken at the commit; A later, by the scheduling (the
//                 submission) or, with the spin, by the GPU's start. B written after the GPU
//                 started the buffer means at the replaceRegion: call (or the blit's own run);
//                 B written before it leaves the submission, the GPU's run and the call open.
//                 The read prints as A, B (part: B in its rect, A elsewhere) or mixed, with the
//                 rect that bounds B's texels and their count
// A buffer's bytes print as runs, "A[0,4096)" or "B[0,256) A[256,4096)", each letter a byte.
// Build: see README.md.
#import "oracle_common.h"
#import <objc/message.h>
#include <mach/mach.h>
#include <spawn.h>
#include <sys/wait.h>
#include <unistd.h>

extern char **environ;

static id<MTLDevice> D;
// The spin case's bounds: polls before the GPU gives up, and LCG steps between progress stores
// (each run stays near a second on the 5300M; a kernel of ~6 s or more is ended by the GPU's
// watchdog on these Macs). ORACLE_SPIN_POLLS and ORACLE_PROGRESS_SPIN override them.
static uint32_t gSpinPolls = 10000000, gProgressSpin = 50000;
static id<MTLCommandQueue> Q;
static const char *gArgv0;

// The bytes as runs of one value: "A[0,4096)" (letters for A-Z, hex otherwise), at most 6 runs.
static void runs(const uint8_t *p, size_t n, char *out, size_t cap)
{
	size_t o = 0, start = 0, nr = 0;
	out[0] = 0;
	for (size_t i = 1; i <= n; i++) {
		if (i < n && p[i] == p[start])
			continue;
		if (nr < 6) {
			uint8_t b = p[start];
			if (b >= 'A' && b <= 'Z')
				o += snprintf(out + o, cap - o, "%s%c[%zu,%zu)", nr ? " " : "", b, start, i);
			else
				o += snprintf(out + o, cap - o, "%s%02x[%zu,%zu)", nr ? " " : "", b, start, i);
		}
		nr++;
		start = i;
	}
	if (nr > 6)
		snprintf(out + o, cap - o, " ... %zu runs", nr);
}

static void line(const char *step, const char *result, double ms)
{
	printf("  %-58s | %-44s | %7.2f ms\n", step, result, ms);
}

// The GPU's view of `b`'s first `n` bytes: a blit into a Shared buffer.
static void gpu_view(id<MTLBuffer> b, size_t n, char *out, size_t cap)
{
	id<MTLBuffer> rb = [D newBufferWithLength:n options:MTLResourceStorageModeShared];
	id<MTLCommandBuffer> cb = [Q commandBuffer];
	id<MTLBlitCommandEncoder> e = [cb blitCommandEncoder];
	[e copyFromBuffer:b sourceOffset:0 toBuffer:rb destinationOffset:0 size:n];
	[e endEncoding];
	oracle_commit_wait(cb, NULL, NULL);
	runs(rb.contents, n, out, cap);
}

static void gpu_fill(id<MTLBuffer> b, NSRange r, uint8_t v, BOOL sync)
{
	id<MTLCommandBuffer> cb = [Q commandBuffer];
	id<MTLBlitCommandEncoder> e = [cb blitCommandEncoder];
	[e fillBuffer:b range:r value:v];
	if (sync)
		[e synchronizeResource:b];
	[e endEncoding];
	oracle_commit_wait(cb, NULL, NULL);
}

static void sync_buffer(id<MTLBuffer> b)
{
	id<MTLCommandBuffer> cb = [Q commandBuffer];
	id<MTLBlitCommandEncoder> e = [cb blitCommandEncoder];
	[e synchronizeResource:b];
	[e endEncoding];
	oracle_commit_wait(cb, NULL, NULL);
}

static void case_mbuf(size_t n)
{
	char g[200], c[200];
	printf("case mbuf %zu: a Managed buffer\n", n);
	id<MTLBuffer> b = [D newBufferWithLength:n options:MTLResourceStorageModeManaged];
	uint8_t *p = b.contents;
	double t0;

	memset(p, 'A', n);
	[b didModifyRange:NSMakeRange(0, n)];
	gpu_view(b, n, g, sizeof g);
	line("CPU A, didModifyRange all; GPU sees", g, 0);

	memset(p, 'B', n);
	gpu_view(b, n, g, sizeof g);
	line("CPU B, no didModifyRange; GPU sees", g, 0);
	gpu_fill([D newBufferWithLength:256 options:MTLResourceStorageModeShared],
	         NSMakeRange(0, 256), 1, NO);
	gpu_view(b, n, g, sizeof g);
	line("  after another command buffer; GPU sees", g, 0);
	usleep(200000);
	gpu_view(b, n, g, sizeof g);
	line("  200 ms later; GPU sees", g, 0);
	[b didModifyRange:NSMakeRange(0, 256)];
	gpu_view(b, n, g, sizeof g);
	line("  didModifyRange [0,256) only; GPU sees", g, 0);
	[b didModifyRange:NSMakeRange(0, n)];
	gpu_view(b, n, g, sizeof g);
	line("  didModifyRange all; GPU sees", g, 0);

	memset(p, 'C', n);
	[b didModifyRange:NSMakeRange(0, n)];
	gpu_fill(b, NSMakeRange(0, n), 'D', NO);
	runs(p, n, c, sizeof c);
	line("GPU fill D, no synchronizeResource; CPU sees", c, 0);
	usleep(200000);
	runs(p, n, c, sizeof c);
	line("  200 ms later; CPU sees", c, 0);
	t0 = oracle_now_ms();
	sync_buffer(b);
	runs(p, n, c, sizeof c);
	line("  synchronizeResource in a later buffer; CPU sees", c, oracle_now_ms() - t0);
	gpu_fill(b, NSMakeRange(0, n), 'E', YES);
	runs(p, n, c, sizeof c);
	line("GPU fill E + synchronizeResource; CPU sees", c, 0);

	gpu_fill(b, NSMakeRange(0, n), 'F', NO);
	memset(p, 'G', 256);
	[b didModifyRange:NSMakeRange(0, 256)];
	gpu_view(b, n, g, sizeof g);
	line("GPU fill F (no sync), CPU G [0,256) + didModify it; GPU", g, 0);
	sync_buffer(b);
	runs(p, n, c, sizeof c);
	line("  then synchronizeResource; CPU sees", c, 0);

	memset(p, 'H', n);
	[b didModifyRange:NSMakeRange(0, n)];
	id<MTLBuffer> rb = [D newBufferWithLength:n options:MTLResourceStorageModeShared];
	id<MTLCommandBuffer> cb = [Q commandBuffer];
	id<MTLBlitCommandEncoder> e = [cb blitCommandEncoder];
	[e copyFromBuffer:b sourceOffset:0 toBuffer:rb destinationOffset:0 size:n];
	[e endEncoding];
	memset(p, 'I', n);
	[b didModifyRange:NSMakeRange(0, n)];
	oracle_commit_wait(cb, NULL, NULL);
	runs(rb.contents, n, g, sizeof g);
	line("CPU I + didModify after the reading buffer was encoded", g, 0);

	cb = [Q commandBuffer];
	e = [cb blitCommandEncoder];
	[e copyFromBuffer:b sourceOffset:0 toBuffer:rb destinationOffset:0 size:n];
	[e endEncoding];
	[cb commit];
	memset(p, 'J', n);
	[b didModifyRange:NSMakeRange(0, n)];
	[cb waitUntilCompleted];
	runs(rb.contents, n, g, sizeof g);
	line("CPU J + didModify just after the reading buffer's commit", g, 0);

	// Cost: a didModifyRange of all of it, then a read, against a read with nothing modified.
	double tm[3];
	for (int k = 0; k < 3; k++) {
		memset(p, 'K' + k, n);
		[b didModifyRange:NSMakeRange(0, n)];
		t0 = oracle_now_ms();
		gpu_view(b, n, g, sizeof g);
		tm[k] = oracle_now_ms() - t0;
	}
	line("cost: didModify all, then a GPU read (3 runs)", g, (tm[0] + tm[1] + tm[2]) / 3);
	for (int k = 0; k < 3; k++) {
		t0 = oracle_now_ms();
		gpu_view(b, n, g, sizeof g);
		tm[k] = oracle_now_ms() - t0;
	}
	line("cost: a GPU read, nothing modified (3 runs)", g, (tm[0] + tm[1] + tm[2]) / 3);
}

static void tex_view(id<MTLTexture> t, int w, int h, char *out, size_t cap)
{
	id<MTLBuffer> rb = [D newBufferWithLength:(size_t)w * h * 4 options:MTLResourceStorageModeShared];
	id<MTLCommandBuffer> cb = [Q commandBuffer];
	id<MTLBlitCommandEncoder> e = [cb blitCommandEncoder];
	[e copyFromTexture:t
	         sourceSlice:0
	         sourceLevel:0
	        sourceOrigin:MTLOriginMake(0, 0, 0)
	          sourceSize:MTLSizeMake(w, h, 1)
	            toBuffer:rb
	   destinationOffset:0
	destinationBytesPerRow:(NSUInteger)w * 4
	destinationBytesPerImage:(NSUInteger)w * h * 4];
	[e endEncoding];
	oracle_commit_wait(cb, NULL, NULL);
	runs(rb.contents, (size_t)w * h * 4, out, cap);
}

static void tex_cpu(id<MTLTexture> t, int w, int h, char *out, size_t cap)
{
	NSMutableData *d = [NSMutableData dataWithLength:(size_t)w * h * 4];
	[t getBytes:d.mutableBytes
	    bytesPerRow:(NSUInteger)w * 4
	     fromRegion:MTLRegionMake2D(0, 0, w, h)
	    mipmapLevel:0];
	runs(d.bytes, d.length, out, cap);
}

static void tex_gpu_write(id<MTLTexture> t, int w, int h, uint8_t v, BOOL sync)
{
	id<MTLBuffer> src = [D newBufferWithLength:(size_t)w * h * 4 options:MTLResourceStorageModeShared];
	memset(src.contents, v, src.length);
	id<MTLCommandBuffer> cb = [Q commandBuffer];
	id<MTLBlitCommandEncoder> e = [cb blitCommandEncoder];
	[e copyFromBuffer:src
	           sourceOffset:0
	      sourceBytesPerRow:(NSUInteger)w * 4
	    sourceBytesPerImage:(NSUInteger)w * h * 4
	             sourceSize:MTLSizeMake(w, h, 1)
	              toTexture:t
	       destinationSlice:0
	       destinationLevel:0
	      destinationOrigin:MTLOriginMake(0, 0, 0)];
	if (sync)
		[e synchronizeTexture:t slice:0 level:0];
	[e endEncoding];
	oracle_commit_wait(cb, NULL, NULL);
}

static void tex_replace(id<MTLTexture> t, int x, int y, int w, int h, uint8_t v)
{
	NSMutableData *d = [NSMutableData dataWithLength:(size_t)w * h * 4];
	memset(d.mutableBytes, v, d.length);
	[t replaceRegion:MTLRegionMake2D(x, y, w, h)
	     mipmapLevel:0
	       withBytes:d.bytes
	     bytesPerRow:(NSUInteger)w * 4];
}

static void case_mtex(void)
{
	const int w = 256, h = 256;
	char g[200], c[200];
	printf("case mtex: a 256x256 RGBA8 Managed texture (rows of 1024 bytes)\n");
	MTLTextureDescriptor *td =
	    [MTLTextureDescriptor texture2DDescriptorWithPixelFormat:MTLPixelFormatRGBA8Unorm
	                                                       width:w
	                                                      height:h
	                                                   mipmapped:NO];
	td.storageMode = MTLStorageModeManaged;
	td.usage = MTLTextureUsageShaderRead | MTLTextureUsageRenderTarget;
	id<MTLTexture> t = [D newTextureWithDescriptor:td];
	tex_replace(t, 0, 0, w, h, 'A');
	tex_view(t, w, h, g, sizeof g);
	line("replaceRegion all A; GPU sees", g, 0);
	tex_gpu_write(t, w, h, 'B', NO);
	tex_cpu(t, w, h, c, sizeof c);
	line("GPU write B, no synchronizeTexture; getBytes", c, 0);
	usleep(200000);
	tex_cpu(t, w, h, c, sizeof c);
	line("  200 ms later; getBytes", c, 0);
	tex_gpu_write(t, w, h, 'C', YES);
	tex_cpu(t, w, h, c, sizeof c);
	line("GPU write C + synchronizeTexture; getBytes", c, 0);
	tex_gpu_write(t, w, h, 'D', NO);
	tex_replace(t, 0, 0, 16, 1, 'E');
	tex_view(t, w, h, g, sizeof g);
	line("GPU D (no sync), replaceRegion 16x1 at 0,0 E; GPU sees", g, 0);
	tex_cpu(t, w, h, c, sizeof c);
	line("  getBytes", c, 0);
}

static id<MTLRenderPipelineState> gSolid;

static void clear_tex(id<MTLTexture> t, uint8_t v)
{
	double f = v / 255.0;
	MTLRenderPassDescriptor *rp = [MTLRenderPassDescriptor renderPassDescriptor];
	rp.colorAttachments[0].texture = t;
	rp.colorAttachments[0].loadAction = MTLLoadActionClear;
	rp.colorAttachments[0].storeAction = MTLStoreActionStore;
	rp.colorAttachments[0].clearColor = MTLClearColorMake(f, f, f, f);
	id<MTLCommandBuffer> cb = [Q commandBuffer];
	[[cb renderCommandEncoderWithDescriptor:rp] endEncoding];
	oracle_commit_wait(cb, NULL, NULL);
}

static void case_shtex(void)
{
	const int w = 256, h = 256;
	char g[200], c[200];
	printf("case shtex: newTextureWithDescriptor: of storage Shared, 256x256 BGRA8\n");
	MTLTextureDescriptor *td =
	    [MTLTextureDescriptor texture2DDescriptorWithPixelFormat:MTLPixelFormatBGRA8Unorm
	                                                       width:w
	                                                      height:h
	                                                   mipmapped:NO];
	td.storageMode = MTLStorageModeShared;
	td.usage = MTLTextureUsageShaderRead | MTLTextureUsageRenderTarget;
	id<MTLTexture> t = [D newTextureWithDescriptor:td];
	line("made", t ? "texture" : "nil", 0);
	if (!t)
		return;
	printf("  storageMode %lu\n", (unsigned long)t.storageMode);
	tex_replace(t, 0, 0, w, h, 'A');
	tex_view(t, w, h, g, sizeof g);
	line("replaceRegion A; GPU sees", g, 0);
	clear_tex(t, 'B');
	tex_cpu(t, w, h, c, sizeof c);
	line("render clear B; getBytes", c, 0);
	tex_view(t, w, h, g, sizeof g);
	line("  GPU sees", g, 0);
	usleep(200000);
	tex_cpu(t, w, h, c, sizeof c);
	line("  200 ms later; getBytes", c, 0);
	tex_replace(t, 0, 0, 16, 1, 'C');
	tex_cpu(t, w, h, c, sizeof c);
	line("  replaceRegion 16x1 C; getBytes", c, 0);
	tex_view(t, w, h, g, sizeof g);
	line("  GPU sees", g, 0);
	tex_gpu_write(t, w, h, 'D', NO);
	tex_cpu(t, w, h, c, sizeof c);
	line("blit write D; getBytes", c, 0);
}

static void case_lintex(const char *mode)
{
	const int w = 256, h = 256;
	char g[200], c[200];
	MTLResourceOptions opt = !strcmp(mode, "managed") ? MTLResourceStorageModeManaged
	                                                   : MTLResourceStorageModeShared;
	printf("case lintex %s: a linear 256x256 BGRA8 texture over a %s buffer\n", mode, mode);
	size_t align = [D minimumLinearTextureAlignmentForPixelFormat:MTLPixelFormatBGRA8Unorm];
	size_t bpr = ((size_t)w * 4 + align - 1) / align * align;
	printf("  minimumLinearTextureAlignment(BGRA8) %zu, bytesPerRow %zu\n", align, bpr);
	id<MTLBuffer> b = [D newBufferWithLength:bpr * h options:opt];
	MTLTextureDescriptor *td =
	    [MTLTextureDescriptor texture2DDescriptorWithPixelFormat:MTLPixelFormatBGRA8Unorm
	                                                       width:w
	                                                      height:h
	                                                   mipmapped:NO];
	td.storageMode = b.storageMode;
	td.usage = MTLTextureUsageShaderRead | MTLTextureUsageRenderTarget;
	id<MTLTexture> t = [b newTextureWithDescriptor:td offset:0 bytesPerRow:bpr];
	line("made", t ? "texture" : "nil", 0);
	if (!t)
		return;
	memset(b.contents, 'A', b.length);
	if (opt == MTLResourceStorageModeManaged)
		[b didModifyRange:NSMakeRange(0, b.length)];
	tex_view(t, w, h, g, sizeof g);
	line(opt == MTLResourceStorageModeManaged ? "CPU A + didModify; GPU sees texture"
	                                          : "CPU A to the buffer; GPU sees texture",
	     g, 0);
	memset(b.contents, 'B', b.length);
	tex_view(t, w, h, g, sizeof g);
	line("CPU B to the buffer, nothing else; GPU sees texture", g, 0);
	clear_tex(t, 'C');
	runs(b.contents, b.length, c, sizeof c);
	line("render clear C of the texture; CPU sees buffer", c, 0);
	if (opt == MTLResourceStorageModeManaged) {
		sync_buffer(b);
		runs(b.contents, b.length, c, sizeof c);
		line("  synchronizeResource(buffer); CPU sees", c, 0);
	}
	memset(b.contents, 'D', b.length);
	if (opt == MTLResourceStorageModeManaged)
		[b didModifyRange:NSMakeRange(0, b.length)];
	tex_view(t, w, h, g, sizeof g);
	line("CPU D (+didModify if Managed); GPU sees texture", g, 0);
	NSMutableData *e = [NSMutableData dataWithLength:(size_t)w * 4 * h];
	memset(e.mutableBytes, 'E', e.length);
	[t replaceRegion:MTLRegionMake2D(0, 0, w, h)
	     mipmapLevel:0
	       withBytes:e.bytes
	     bytesPerRow:(NSUInteger)w * 4];
	tex_view(t, w, h, g, sizeof g);
	line("replaceRegion E of the texture, nothing else; GPU sees texture", g, 0);
	runs(b.contents, b.length, c, sizeof c);
	line("  CPU sees buffer", c, 0);
	memset(b.contents, 'G', b.length);
	memset(e.mutableBytes, 'F', e.length);
	[t replaceRegion:MTLRegionMake2D(0, 0, 16, 1)
	     mipmapLevel:0
	       withBytes:e.bytes
	     bytesPerRow:(NSUInteger)w * 4];
	tex_view(t, w, h, g, sizeof g);
	line("CPU G to the buffer, then replaceRegion F of a 16x1 corner; GPU sees", g, 0);
}

// A linear 2D array texture over a Shared buffer, of 3 BGRA8 slices of W x 3 at offset 0, rows
// BPR bytes apart: by the linear SPI (MODE spi) with each bytesPerImage of 0, BPR x 3 and 1024,
// or by the public form (MODE public). For each texture made: where replaceRegion: of each whole
// slice (A, B, C) lands in the buffer, what the GPU reads of each slice (a blit of it into a
// Shared buffer), and what getBytes: reads of each after the CPU writes the buffer's bytes at
// slice pitch BPR x 3 (X, Y, Z). Two shapes: W 64 (BPR 256) and W 4 (BPR 16).
static void case_linarray(const char *mode)
{
	printf("case linarray %s: a linear 2D array of 3 BGRA8 slices over a Shared buffer\n", mode);
	SEL lin = NSSelectorFromString(@"newLinearTextureWithDescriptor:offset:bytesPerRow:bytesPerImage:");
	const bool spi = !strcmp(mode, "spi");
	const int h = 3, slices = 3;
	const int widths[] = {64, 4};
	for (int k = 0; k < 2; k++) {
		const int w = widths[k];
		const NSUInteger bpr = (NSUInteger)w * 4;
		const NSUInteger images[] = {0, bpr * h, 1024};
		for (int i = 0; i < (spi ? 3 : 1); i++) {
			id<MTLBuffer> b = [D newBufferWithLength:0x4000 options:MTLResourceStorageModeShared];
			MTLTextureDescriptor *td =
			    [MTLTextureDescriptor texture2DDescriptorWithPixelFormat:MTLPixelFormatBGRA8Unorm
			                                                       width:w
			                                                      height:h
			                                                   mipmapped:NO];
			td.textureType = MTLTextureType2DArray;
			td.arrayLength = slices;
			td.storageMode = MTLStorageModeShared;
			td.usage = MTLTextureUsageShaderRead;
			char step[100];
			snprintf(step, sizeof step, "%s W %d BPR %lu bytesPerImage %lu", mode, w,
			         (unsigned long)bpr, (unsigned long)images[i]);
			id<MTLTexture> t = nil;
			if (!spi)
				t = [b newTextureWithDescriptor:td offset:0 bytesPerRow:bpr];
			else if ([(id)b respondsToSelector:lin])
				t = ((id(*)(id, SEL, id, NSUInteger, NSUInteger, NSUInteger))objc_msgSend)(
				    b, lin, td, 0, bpr, images[i]);
			else {
				line(step, "no linear SPI", 0);
				return;
			}
			char out[200];
			snprintf(out, sizeof out, "%s, type %lu, arrayLength %lu", t ? "made" : "nil",
			         (unsigned long)t.textureType, (unsigned long)t.arrayLength);
			line(step, out, 0);
			if (!t)
				continue;
			memset(b.contents, 0, b.length);
			NSMutableData *d = [NSMutableData dataWithLength:bpr * h];
			for (int s = 0; s < slices; s++) {
				memset(d.mutableBytes, 'A' + s, d.length);
				[t replaceRegion:MTLRegionMake3D(0, 0, 0, w, h, 1)
				     mipmapLevel:0
				           slice:s
				       withBytes:d.bytes
				     bytesPerRow:bpr
				   bytesPerImage:bpr * h];
			}
			runs(b.contents, 0x1000, out, sizeof out);
			line("  replaceRegion slices A B C; CPU sees buffer", out, 0);
			size_t o = 0;
			for (int s = 0; s < slices; s++) {
				id<MTLBuffer> rb = [D newBufferWithLength:bpr * h
				                                  options:MTLResourceStorageModeShared];
				id<MTLCommandBuffer> cb = [Q commandBuffer];
				id<MTLBlitCommandEncoder> e = [cb blitCommandEncoder];
				[e copyFromTexture:t
				             sourceSlice:s
				             sourceLevel:0
				            sourceOrigin:MTLOriginMake(0, 0, 0)
				              sourceSize:MTLSizeMake(w, h, 1)
				                toBuffer:rb
				       destinationOffset:0
				  destinationBytesPerRow:bpr
				destinationBytesPerImage:bpr * h];
				[e endEncoding];
				oracle_commit_wait(cb, NULL, NULL);
				char r[80];
				runs(rb.contents, bpr * h, r, sizeof r);
				o += snprintf(out + o, sizeof out - o, "%s%d:%s", s ? " " : "", s, r);
			}
			line("  GPU reads each slice", out, 0);
			for (int s = 0; s < slices; s++)
				memset((uint8_t *)b.contents + (size_t)s * bpr * h, 'X' + s, bpr * h);
			o = 0;
			for (int s = 0; s < slices; s++) {
				[t getBytes:d.mutableBytes
				      bytesPerRow:bpr
				    bytesPerImage:bpr * h
				       fromRegion:MTLRegionMake3D(0, 0, 0, w, h, 1)
				      mipmapLevel:0
				            slice:s];
				char r[80];
				runs(d.bytes, d.length, r, sizeof r);
				o += snprintf(out + o, sizeof out - o, "%s%d:%s", s ? " " : "", s, r);
			}
			line("  CPU X Y Z at BPR x 3 apart; getBytes of each slice", out, 0);
		}
	}
}

// A texture of type TYPE (an MTLTextureType's number) over a Shared buffer at offset 0, rows 256
// bytes apart, by FORM: public (newTextureWithDescriptor:offset:bytesPerRow:), spi (the linear
// SPI, bytesPerImage the rows' bytes) or tiled (the tiled SPI, from a Managed descriptor). The
// descriptor is 64 x 4 BGRA8 (64 x 1 for a 1D type, 64 x 64 for a cube), 2 deep for 3D, 2 long
// for an array, 4 samples for a multisample type. Made, nil, or the process ends at Metal's
// assertion: ARG is FORM:TYPE.
static void case_lintypes(const char *arg)
{
	char form[16] = "public";
	int type = 3;
	sscanf(arg, "%15[^:]:%d", form, &type);
	printf("case lintypes %s:%d: a texture of type %d over a Shared buffer\n", form, type, type);
	const MTLTextureType t = (MTLTextureType)type;
	const bool oneD = t == MTLTextureType1D || t == MTLTextureType1DArray;
	const bool cube = t == MTLTextureTypeCube || t == MTLTextureTypeCubeArray;
	const bool array = t == MTLTextureType1DArray || t == MTLTextureType2DArray ||
	                   t == MTLTextureTypeCubeArray || t == MTLTextureType2DMultisampleArray;
	const bool ms = t == MTLTextureType2DMultisample || t == MTLTextureType2DMultisampleArray;
	MTLTextureDescriptor *td = [MTLTextureDescriptor new];
	td.textureType = t;
	td.pixelFormat = MTLPixelFormatBGRA8Unorm;
	td.width = 64;
	td.height = oneD ? 1 : cube ? 64 : 4;
	td.depth = t == MTLTextureType3D ? 2 : 1;
	td.arrayLength = array ? 2 : 1;
	td.sampleCount = ms ? 4 : 1;
	td.usage = MTLTextureUsageShaderRead | (ms ? MTLTextureUsageRenderTarget : 0);
	const bool tiled = !strcmp(form, "tiled");
	td.storageMode = tiled ? MTLStorageModeManaged : MTLStorageModeShared;
	id<MTLBuffer> b = [D newBufferWithLength:0x40000 options:MTLResourceStorageModeShared];
	SEL lin = NSSelectorFromString(@"newLinearTextureWithDescriptor:offset:bytesPerRow:bytesPerImage:");
	SEL til = NSSelectorFromString(@"newTiledTextureWithDescriptor:offset:bytesPerRow:");
	id<MTLTexture> tex = nil;
	if (!strcmp(form, "public")) {
		tex = [b newTextureWithDescriptor:td offset:0 bytesPerRow:256];
	} else if (!strcmp(form, "spi") && [(id)b respondsToSelector:lin]) {
		tex = ((id(*)(id, SEL, id, NSUInteger, NSUInteger, NSUInteger))objc_msgSend)(
		    b, lin, td, 0, 256, 256 * td.height);
	} else if (tiled && [(id)b respondsToSelector:til]) {
		tex = ((id(*)(id, SEL, id, NSUInteger, NSUInteger))objc_msgSend)(b, til, td, 0, 256);
	} else {
		line(form, "no such form", 0);
		return;
	}
	char out[120];
	snprintf(out, sizeof out, "%s, type %lu", tex ? "made" : "nil", (unsigned long)tex.textureType);
	line(form, out, 0);
}

// The GPU's copy of `b`'s first `n` bytes against the CPU's: "same as the CPU's" or the GPU's runs.
static void gpu_against_cpu(id<MTLBuffer> b, size_t n, char *out, size_t cap)
{
	id<MTLBuffer> rb = [D newBufferWithLength:n options:MTLResourceStorageModeShared];
	id<MTLCommandBuffer> cb = [Q commandBuffer];
	id<MTLBlitCommandEncoder> e = [cb blitCommandEncoder];
	[e copyFromBuffer:b sourceOffset:0 toBuffer:rb destinationOffset:0 size:n];
	[e endEncoding];
	oracle_commit_wait(cb, NULL, NULL);
	if (!memcmp(rb.contents, b.contents, n)) {
		snprintf(out, cap, "same as the CPU's");
		return;
	}
	char r[160];
	runs(rb.contents, n, r, sizeof r);
	snprintf(out, cap, "differs: %s", r);
}

static void case_argenc(const char *mode)
{
	char g[200];
	MTLResourceOptions opt = !strcmp(mode, "managed") ? MTLResourceStorageModeManaged
	                                                   : MTLResourceStorageModeShared;
	printf("case argenc %s: an argument encoder writing a %s argument buffer\n", mode, mode);
	MTLArgumentDescriptor *p = [MTLArgumentDescriptor argumentDescriptor];
	p.dataType = MTLDataTypePointer;
	p.index = 0;
	MTLArgumentDescriptor *t = [MTLArgumentDescriptor argumentDescriptor];
	t.dataType = MTLDataTypeTexture;
	t.textureType = MTLTextureType2D;
	t.index = 1;
	id<MTLArgumentEncoder> enc = [D newArgumentEncoderWithArguments:@[ p, t ]];
	if (!enc) {
		line("argument encoder", "nil", 0);
		return;
	}
	const size_t n = (enc.encodedLength + 255) / 256 * 256;
	id<MTLBuffer> ab = [D newBufferWithLength:n options:opt];
	memset(ab.contents, 0, n);
	if (opt == MTLResourceStorageModeManaged)
		[ab didModifyRange:NSMakeRange(0, n)];
	gpu_against_cpu(ab, n, g, sizeof g);
	line("zeroed (+didModify if Managed); GPU's bytes", g, 0);
	id<MTLBuffer> x = [D newBufferWithLength:4096 options:MTLResourceStorageModeShared];
	MTLTextureDescriptor *td =
	    [MTLTextureDescriptor texture2DDescriptorWithPixelFormat:MTLPixelFormatBGRA8Unorm
	                                                       width:16
	                                                      height:16
	                                                   mipmapped:NO];
	td.storageMode = MTLStorageModePrivate;
	id<MTLTexture> tex = [D newTextureWithDescriptor:td];
	[enc setArgumentBuffer:ab offset:0];
	[enc setBuffer:x offset:0 atIndex:0];
	[enc setTexture:tex atIndex:1];
	gpu_against_cpu(ab, n, g, sizeof g);
	line("setBuffer: + setTexture:, nothing else; GPU's bytes", g, 0);
	if (opt == MTLResourceStorageModeManaged) {
		[ab didModifyRange:NSMakeRange(0, n)];
		gpu_against_cpu(ab, n, g, sizeof g);
		line("  then didModifyRange: of the buffer; GPU's bytes", g, 0);
	}
}

// A no-copy Managed buffer over the app's pages, and a linear texture over it as WindowServer makes
// one (BGRA8 468 x 36 at offset 0x100, rows 0x780 apart, in 0x11000 bytes): CPU writes to the
// app's memory with no call, seen by the GPU's reads of the buffer and of the texture or not.
static void case_nocopy(void)
{
	char g[200];
	const size_t n = 0x11000, offset = 0x100, bpr = 0x780;
	const int w = 468, h = 36;
	printf("case nocopy: a no-copy Managed buffer of %zu bytes and a linear texture over it\n", n);
	vm_address_t at = 0;
	if (vm_allocate(mach_task_self(), &at, n, VM_FLAGS_ANYWHERE) != KERN_SUCCESS) {
		line("vm_allocate", "failed", 0);
		return;
	}
	uint8_t *p = (uint8_t *)at;
	memset(p, 'A', n);
	id<MTLBuffer> b = [D newBufferWithBytesNoCopy:p
	                                       length:n
	                                      options:MTLResourceStorageModeManaged
	                                  deallocator:nil];
	line("made", !b ? "nil" : b.contents == p ? "buffer, contents the app's pages" : "buffer, contents elsewhere", 0);
	if (!b)
		return;
	printf("  storageMode %lu\n", (unsigned long)b.storageMode);
	MTLTextureDescriptor *td =
	    [MTLTextureDescriptor texture2DDescriptorWithPixelFormat:MTLPixelFormatBGRA8Unorm
	                                                       width:w
	                                                      height:h
	                                                   mipmapped:NO];
	td.storageMode = b.storageMode;
	td.usage = MTLTextureUsageShaderRead;
	id<MTLTexture> t = [b newTextureWithDescriptor:td offset:offset bytesPerRow:bpr];
	line("linear texture", t ? "made" : "nil", 0);
	gpu_view(b, n, g, sizeof g);
	line("CPU A before the make; GPU sees buffer", g, 0);
	if (t) {
		tex_view(t, w, h, g, sizeof g);
		line("  GPU sees texture", g, 0);
	}
	memset(p, 'B', n);
	gpu_view(b, n, g, sizeof g);
	line("CPU B to the pages, no didModifyRange; GPU sees buffer", g, 0);
	if (t) {
		tex_view(t, w, h, g, sizeof g);
		line("  GPU sees texture", g, 0);
	}
	usleep(200000);
	gpu_view(b, n, g, sizeof g);
	line("  200 ms later; GPU sees buffer", g, 0);
	memset(p, 'C', n);
	[b didModifyRange:NSMakeRange(0, n)];
	gpu_view(b, n, g, sizeof g);
	line("CPU C + didModifyRange all; GPU sees buffer", g, 0);
	if (t) {
		tex_view(t, w, h, g, sizeof g);
		line("  GPU sees texture", g, 0);
	}
}

// didModifyData (SPI) of a texture over a buffer, as CoreAnimation calls it on an image texture it
// reuses once the CPU redrew the image's bytes: a linear texture (newLinearTextureWithDescriptor:
// offset:bytesPerRow:bytesPerImage:, SPI) of 468 x 36 BGRA8 at offset 0x100, rows 0x800 apart
// (the AMD's 256-byte alignment), over a Managed buffer of 0x13000 bytes, made by
// newBufferWithLength: (MODE length) or over the app's pages (nocopy); CPU writes seen by the GPU's
// reads of the texture with no call, and after didModifyData.
static void case_didmodify(const char *mode)
{
	char g[200];
	const size_t n = 0x13000, offset = 0x100, bpr = 0x800;
	const int w = 468, h = 36;
	printf("case didmodify %s: a linear texture over a Managed buffer, and didModifyData\n", mode);
	id<MTLBuffer> b;
	if (!strcmp(mode, "nocopy")) {
		vm_address_t at = 0;
		if (vm_allocate(mach_task_self(), &at, n, VM_FLAGS_ANYWHERE) != KERN_SUCCESS)
			return;
		b = [D newBufferWithBytesNoCopy:(void *)at
		                         length:n
		                        options:MTLResourceStorageModeManaged
		                    deallocator:nil];
	} else {
		b = [D newBufferWithLength:n options:MTLResourceStorageModeManaged];
	}
	SEL lin = NSSelectorFromString(@"newLinearTextureWithDescriptor:offset:bytesPerRow:bytesPerImage:");
	if (!b || ![(id)b respondsToSelector:lin]) {
		line("buffer, or its linear texture SPI", "none", 0);
		return;
	}
	MTLTextureDescriptor *td =
	    [MTLTextureDescriptor texture2DDescriptorWithPixelFormat:MTLPixelFormatBGRA8Unorm
	                                                       width:w
	                                                      height:h
	                                                   mipmapped:NO];
	td.storageMode = MTLStorageModeManaged;
	td.usage = MTLTextureUsageShaderRead;
	id<MTLTexture> t = ((id(*)(id, SEL, id, NSUInteger, NSUInteger, NSUInteger))objc_msgSend)(
	    b, lin, td, offset, bpr, bpr * h);
	line("linear texture", t ? "made" : "nil", 0);
	if (!t)
		return;
	SEL dmd = NSSelectorFromString(@"didModifyData");
	printf("  texture storage %lu, answers didModifyData: %s\n", (unsigned long)t.storageMode,
	       [(id)t respondsToSelector:dmd] ? "yes" : "no");
	uint8_t *p = b.contents;
	memset(p, 'A', n);
	[b didModifyRange:NSMakeRange(0, n)];
	tex_view(t, w, h, g, sizeof g);
	line("CPU A + didModifyRange; GPU sees texture", g, 0);
	memset(p, 'B', n);
	tex_view(t, w, h, g, sizeof g);
	line("CPU B, no call; GPU sees texture", g, 0);
	if ([(id)t respondsToSelector:dmd]) {
		((void (*)(id, SEL))objc_msgSend)(t, dmd);
		tex_view(t, w, h, g, sizeof g);
		line("  then didModifyData; GPU sees texture", g, 0);
		gpu_view(b, n, g, sizeof g);
		line("  and the buffer", g, 0);
	}
}

// Which offsets and row pitches a texture over a buffer takes: 468 x 36 BGRA8 over a buffer of
// 0x12000 bytes, by the public form (newTextureWithDescriptor:offset:bytesPerRow:), the linear
// SPI (newLinearTextureWithDescriptor:offset:bytesPerRow:bytesPerImage:) and the tiled SPI
// (newTiledTextureWithDescriptor:offset:bytesPerRow:, a Managed descriptor over a Shared buffer),
// over Shared and Managed buffers: "made" or "nil" for each. Where Metal's validation asserts
// instead (the Intel's), the case ends there.
static void case_linalign(void)
{
	printf("case linalign: the offsets and pitches a texture over a buffer takes\n");
	const int w = 468, h = 36;
	const NSUInteger offsets[] = {0, 0x40, 0x100}, pitches[] = {1872, 1920, 2048};
	SEL lin = NSSelectorFromString(@"newLinearTextureWithDescriptor:offset:bytesPerRow:bytesPerImage:");
	SEL tiled = NSSelectorFromString(@"newTiledTextureWithDescriptor:offset:bytesPerRow:");
	for (int form = 0; form < 3; form++) {
		for (int managed = 0; managed < 2; managed++) {
			if (form == 2 && managed)
				continue; // a tiled texture's buffer is Shared
			id<MTLBuffer> b = [D newBufferWithLength:0x12000
			                                 options:managed ? MTLResourceStorageModeManaged
			                                                 : MTLResourceStorageModeShared];
			MTLTextureDescriptor *td =
			    [MTLTextureDescriptor texture2DDescriptorWithPixelFormat:MTLPixelFormatBGRA8Unorm
			                                                       width:w
			                                                      height:h
			                                                   mipmapped:NO];
			td.storageMode = form == 2 || managed ? MTLStorageModeManaged : MTLStorageModeShared;
			td.usage = MTLTextureUsageShaderRead;
			char out[200];
			size_t o = 0;
			for (int i = 0; i < 3; i++) {
				for (int j = 0; j < 3; j++) {
					id t = nil;
					if (form == 0)
						t = [b newTextureWithDescriptor:td offset:offsets[i] bytesPerRow:pitches[j]];
					else if ([(id)b respondsToSelector:form == 1 ? lin : tiled])
						t = form == 1 ? ((id(*)(id, SEL, id, NSUInteger, NSUInteger, NSUInteger))
						                     objc_msgSend)(b, lin, td, offsets[i], pitches[j],
						                                   pitches[j] * h)
						              : ((id(*)(id, SEL, id, NSUInteger, NSUInteger))objc_msgSend)(
						                    b, tiled, td, offsets[i], pitches[j]);
					o += snprintf(out + o, sizeof out - o, "%s@%lx/%lu:%s", o ? " " : "",
					              (unsigned long)offsets[i], (unsigned long)pitches[j],
					              t ? "made" : "nil");
				}
			}
			char step[80];
			snprintf(step, sizeof step, "%s over %s",
			         form == 0 ? "public" : form == 1 ? "linear SPI" : "tiled SPI",
			         managed ? "Managed" : "Shared");
			printf("  %-22s %s\n", step, out);
		}
	}
}

static id<MTLComputePipelineState> pipeline(id<MTLLibrary> lib, const char *name)
{
	NSError *err = nil;
	id<MTLFunction> f = [lib newFunctionWithName:@(name)];
	id<MTLComputePipelineState> p = [D newComputePipelineStateWithFunction:f error:&err];
	if (!p)
		printf("  ! pipeline %s: %s\n", name, err.description.UTF8String);
	return p;
}

static void case_spin(void)
{
	printf("case spin: a Shared buffer written by one side while the other runs\n");
	id<MTLLibrary> lib = oracle_library(D, gArgv0, "oracle");
	if (!lib)
		return;
	const char *names[2] = {"spin_atomic", "spin_plain"};
	for (int k = 0; k < 2; k++) {
		id<MTLComputePipelineState> p = pipeline(lib, names[k]);
		if (!p)
			continue;
		id<MTLBuffer> flag = [D newBufferWithLength:64 options:MTLResourceStorageModeShared];
		id<MTLBuffer> res = [D newBufferWithLength:64 options:MTLResourceStorageModeShared];
		memset(flag.contents, 0, 64);
		memset(res.contents, 0xff, 64);
		uint32_t max = gSpinPolls;
		id<MTLCommandBuffer> cb = [Q commandBuffer];
		id<MTLComputeCommandEncoder> e = [cb computeCommandEncoder];
		[e setComputePipelineState:p];
		[e setBuffer:flag offset:0 atIndex:0];
		[e setBuffer:res offset:0 atIndex:1];
		[e setBytes:&max length:4 atIndex:2];
		[e dispatchThreads:MTLSizeMake(1, 1, 1) threadsPerThreadgroup:MTLSizeMake(1, 1, 1)];
		[e endEncoding];
		double t0 = oracle_now_ms();
		[cb commit];
		[cb waitUntilScheduled];
		usleep(20000);
		((volatile uint32_t *)flag.contents)[0] = 7;
		double tw = oracle_now_ms() - t0;
		[cb waitUntilCompleted];
		double tc = oracle_now_ms() - t0;
		uint32_t *r = res.contents;
		char out[200];
		snprintf(out, sizeof out, "polls %u of %u, saw %u", r[0], max, r[1]);
		line(k ? "GPU polls (plain), CPU writes 20 ms after scheduled"
		       : "GPU polls (atomic), CPU writes 20 ms after scheduled",
		     out, tc);
		printf("  CPU wrote at %.1f ms, the buffer completed at %.1f ms, GPU time %.1f ms, status %ld%s%s\n",
		       tw, tc, (cb.GPUEndTime - cb.GPUStartTime) * 1e3, (long)cb.status,
		       cb.error ? " error " : "", cb.error ? cb.error.description.UTF8String : "");
	}
	id<MTLComputePipelineState> p = pipeline(lib, "progress");
	if (!p)
		return;
	id<MTLBuffer> ctr = [D newBufferWithLength:64 options:MTLResourceStorageModeShared];
	id<MTLBuffer> sink = [D newBufferWithLength:64 options:MTLResourceStorageModeShared];
	memset(ctr.contents, 0, 64);
	uint32_t steps = 200, spin = gProgressSpin;
	id<MTLCommandBuffer> cb = [Q commandBuffer];
	id<MTLComputeCommandEncoder> e = [cb computeCommandEncoder];
	[e setComputePipelineState:p];
	[e setBuffer:ctr offset:0 atIndex:0];
	[e setBytes:&steps length:4 atIndex:1];
	[e setBytes:&spin length:4 atIndex:2];
	[e setBuffer:sink offset:0 atIndex:3];
	[e dispatchThreads:MTLSizeMake(1, 1, 1) threadsPerThreadgroup:MTLSizeMake(1, 1, 1)];
	[e endEncoding];
	double t0 = oracle_now_ms();
	[cb commit];
	char seen[400];
	size_t o = 0;
	uint32_t last = 0;
	int changes = 0, polls = 0;
	while (cb.status < MTLCommandBufferStatusCompleted && oracle_now_ms() - t0 < 20000) {
		uint32_t v = ((volatile uint32_t *)ctr.contents)[0];
		polls++;
		if (v != last) {
			changes++;
			if (o < sizeof seen - 32)
				o += snprintf(seen + o, sizeof seen - o, "%u@%.0fms ", v, oracle_now_ms() - t0);
			last = v;
		}
		usleep(1000);
	}
	[cb waitUntilCompleted];
	char out[200];
	snprintf(out, sizeof out, "%d changes seen in %d polls before completion", changes, polls);
	line("GPU stores 1..200 while the CPU polls every ms", out, oracle_now_ms() - t0);
	printf("  values seen: %s\n  final %u, GPU time %.1f ms, status %ld%s%s\n", changes ? seen : "(none)",
	       ((uint32_t *)ctr.contents)[0], (cb.GPUEndTime - cb.GPUStartTime) * 1e3, (long)cb.status,
	       cb.error ? " error " : "", cb.error ? cb.error.description.UTF8String : "");
}

// One step of case_capture: `step` of its table, over a fresh Managed buffer of `n` bytes.
static void capture_step(id<MTLComputePipelineState> spin, id<MTLComputePipelineState> copy,
                         NSUInteger n, int step, const char *what)
{
	id<MTLBuffer> m = [D newBufferWithLength:n options:MTLResourceStorageModeManaged];
	id<MTLBuffer> out = [D newBufferWithLength:n options:MTLResourceStorageModeShared];
	id<MTLBuffer> flag = [D newBufferWithLength:64 options:MTLResourceStorageModeShared];
	id<MTLBuffer> res = [D newBufferWithLength:64 options:MTLResourceStorageModeShared];
	// The GPU's copy starts as zeros the CPU never wrote.
	memset(m.contents, 0, n);
	[m didModifyRange:NSMakeRange(0, n)];
	id<MTLCommandBuffer> zero = [Q commandBuffer];
	[zero commit];
	[zero waitUntilCompleted];
	memset(out.contents, 0xee, n);
	memset(res.contents, 0, 64);
	// The spin ends at once unless the step holds it for a write after the commit: during the
	// spin (after), or at once after the commit returns (atonce).
	const bool after = step == 3 || step == 6, atonce = step == 5 || step == 7;
	((volatile uint32_t *)flag.contents)[0] = after || atonce ? 0 : 1;
	__block id<MTLCommandBuffer> cb = nil;
	void (^encode)(void) = ^{
		uint32_t max = gSpinPolls;
		cb = [Q commandBuffer];
		id<MTLComputeCommandEncoder> e = [cb computeCommandEncoder];
		[e setComputePipelineState:spin];
		[e setBuffer:flag offset:0 atIndex:0];
		[e setBuffer:res offset:0 atIndex:1];
		[e setBytes:&max length:4 atIndex:2];
		[e dispatchThreads:MTLSizeMake(1, 1, 1) threadsPerThreadgroup:MTLSizeMake(1, 1, 1)];
		[e endEncoding];
		e = [cb computeCommandEncoder];
		[e setComputePipelineState:copy];
		[e setBuffer:m offset:0 atIndex:0];
		[e setBuffer:out offset:0 atIndex:1];
		[e dispatchThreads:MTLSizeMake(n / 4, 1, 1) threadsPerThreadgroup:MTLSizeMake(64, 1, 1)];
		[e endEncoding];
	};
	// 0: A, didModifyRange:, encode, commit (control: A)
	// 1: encode, A, didModifyRange:, B, commit
	// 2: A, didModifyRange:, B, encode, commit
	// 3: A, didModifyRange:, encode, commit, B while the first kernel spins, then the read
	// 4: A, didModifyRange:, B, didModifyRange:, encode, commit (control: B)
	// 5: A, didModifyRange:, encode, commit, B at once (no wait), then the spin let go as in 3:
	//    A means the bytes were taken by the time the commit returned, B at the submission or
	//    the GPU's read
	// 6: as 3, then a second didModifyRange: of the range before the spin is let go: B means
	//    didModifyRange: reaches a command buffer already running, at the call
	// 7: as 5, then a second didModifyRange: right after B: B means it reaches a command buffer
	//    already committed, before the GPU schedules it
	if (step == 1)
		encode();
	memset(m.contents, 'A', n);
	[m didModifyRange:NSMakeRange(0, n)];
	if (step == 1 || step == 2 || step == 4)
		memset(m.contents, 'B', n);
	if (step == 4)
		[m didModifyRange:NSMakeRange(0, n)];
	if (step != 1)
		encode();
	double t0 = oracle_now_ms();
	__block double ts = -1;
	if (step >= 5)
		[cb addScheduledHandler:^(id<MTLCommandBuffer> _) { ts = oracle_now_ms() - t0; }];
	[cb commit];
	double tr = oracle_now_ms() - t0, tb = -1, tw = -1, tg = -1;
	// B, and its second didModifyRange: in steps 6 and 7, from tb to tw.
	void (^writeB)(void) = ^{
		memset(m.contents, 'B', n);
		if (step == 6 || step == 7)
			[m didModifyRange:NSMakeRange(0, n)];
	};
	if (atonce) {
		tb = oracle_now_ms() - t0;
		writeB();
		tw = oracle_now_ms() - t0;
	}
	if (after || atonce) {
		[cb waitUntilScheduled];
		usleep(20000);
		if (after) {
			tb = oracle_now_ms() - t0;
			writeB();
			tw = oracle_now_ms() - t0;
		}
		tg = oracle_now_ms() - t0;
		((volatile uint32_t *)flag.contents)[0] = 7;
	}
	[cb waitUntilCompleted];
	double tc = oracle_now_ms() - t0;
	char seen[200];
	runs(out.contents, n, seen, sizeof seen);
	line(what, seen, tc);
	uint32_t *r = res.contents;
	printf("    spin polls %u, saw flag %u%s; status %ld%s%s\n", r[0], r[1],
	       tw >= 0 ? "" : " (not held)", (long)cb.status, cb.error ? " error " : "",
	       cb.error ? cb.error.description.UTF8String : "");
	if (step == 3)
		printf("    B written %.1f ms after the commit, the buffer completed at %.1f ms\n", tw, tc);
	else if (step >= 5)
		printf("    B%s written from %.2f to %.2f ms after the commit, which returned at %.2f ms; "
		       "scheduled at %.2f ms, GPU start at %.2f ms, the spin let go at %.1f ms, the "
		       "buffer completed at %.1f ms\n",
		       step == 5 ? "" : " and didModifyRange:", tb, tw, tr, ts,
		       cb.GPUStartTime * 1e3 - t0, tg, tc);
}

static void case_capture(NSUInteger n)
{
	printf("case capture: the CPU bytes a kernel reads of a Managed buffer of %lu bytes written "
	       "again after didModifyRange:\n",
	       (unsigned long)n);
	id<MTLLibrary> lib = oracle_library(D, gArgv0, "oracle");
	if (!lib)
		return;
	id<MTLComputePipelineState> spin = pipeline(lib, "spin_atomic");
	id<MTLComputePipelineState> copy = pipeline(lib, "copy_u32");
	if (!spin || !copy)
		return;
	const char *what[] = {
	    "A, didModifyRange:, encode, commit",
	    "encode, A, didModifyRange:, B, commit",
	    "A, didModifyRange:, B, encode, commit",
	    "A, didModifyRange:, encode, commit, B during the spin",
	    "A, didModifyRange:, B, didModifyRange:, encode, commit",
	    "A, didModifyRange:, encode, commit, B at once",
	    "as 3, then didModifyRange: during the spin",
	    "as 5, then didModifyRange: at once",
	};
	for (int step = 0; step < 8; step++)
		capture_step(spin, copy, n, step, what[step]);
}

// One step of case_mtexcap over a fresh texture: 0 and 1 the controls, 2 B at once after the
// commit, 3 B after the scheduling, 4 as 3 with the spin in place of the event wait. Returns
// whether the step settles the point: A read in a step that wrote B after the commit, or B read
// where B was written after the GPU started the buffer.
static bool mtexcap_step(id<MTLComputePipelineState> spin, bool part, int step, const char *what)
{
	const int w = 256, h = 256;
	const int rx = part ? 64 : 0, ry = part ? 64 : 0, rw = part ? 128 : w, rh = part ? 64 : h;
	MTLTextureDescriptor *td =
	    [MTLTextureDescriptor texture2DDescriptorWithPixelFormat:MTLPixelFormatRGBA8Unorm
	                                                       width:w
	                                                      height:h
	                                                   mipmapped:NO];
	td.storageMode = MTLStorageModeManaged;
	td.usage = MTLTextureUsageShaderRead;
	id<MTLTexture> t = [D newTextureWithDescriptor:td];
	id<MTLBuffer> rb = [D newBufferWithLength:(size_t)w * h * 4 options:MTLResourceStorageModeShared];
	id<MTLBuffer> flag = [D newBufferWithLength:64 options:MTLResourceStorageModeShared];
	id<MTLBuffer> res = [D newBufferWithLength:64 options:MTLResourceStorageModeShared];
	memset(rb.contents, 0xee, rb.length);
	memset(res.contents, 0, 64);
	((volatile uint32_t *)flag.contents)[0] = 0;
	id<MTLSharedEvent> ev = [D newSharedEvent];
	tex_replace(t, 0, 0, w, h, 'A');
	if (step == 1)
		tex_replace(t, rx, ry, rw, rh, 'B');
	id<MTLCommandBuffer> cb = [Q commandBuffer];
	if (step == 4) {
		uint32_t max = gSpinPolls;
		id<MTLComputeCommandEncoder> e = [cb computeCommandEncoder];
		[e setComputePipelineState:spin];
		[e setBuffer:flag offset:0 atIndex:0];
		[e setBuffer:res offset:0 atIndex:1];
		[e setBytes:&max length:4 atIndex:2];
		[e dispatchThreads:MTLSizeMake(1, 1, 1) threadsPerThreadgroup:MTLSizeMake(1, 1, 1)];
		[e endEncoding];
	} else {
		[cb encodeWaitForEvent:ev value:1];
	}
	id<MTLBlitCommandEncoder> e = [cb blitCommandEncoder];
	[e copyFromTexture:t
	         sourceSlice:0
	         sourceLevel:0
	        sourceOrigin:MTLOriginMake(0, 0, 0)
	          sourceSize:MTLSizeMake(w, h, 1)
	            toBuffer:rb
	   destinationOffset:0
	destinationBytesPerRow:(NSUInteger)w * 4
	destinationBytesPerImage:(NSUInteger)w * h * 4];
	[e endEncoding];
	double t0 = oracle_now_ms();
	__block double ts = -1;
	[cb addScheduledHandler:^(id<MTLCommandBuffer> _) { ts = oracle_now_ms() - t0; }];
	[cb commit];
	double tr = oracle_now_ms() - t0, tb = -1, tw = -1;
	bool sched = false;
	if (step == 2) {
		tb = oracle_now_ms() - t0;
		tex_replace(t, rx, ry, rw, rh, 'B');
		tw = oracle_now_ms() - t0;
	} else if (step >= 3) {
		while (cb.status < MTLCommandBufferStatusScheduled && oracle_now_ms() - t0 < 1000)
			usleep(100);
		sched = cb.status >= MTLCommandBufferStatusScheduled;
		usleep(20000);
		tb = oracle_now_ms() - t0;
		tex_replace(t, rx, ry, rw, rh, 'B');
		tw = oracle_now_ms() - t0;
	}
	double tsg = oracle_now_ms() - t0;
	if (step == 4)
		((volatile uint32_t *)flag.contents)[0] = 7;
	else
		ev.signaledValue = 1;
	[cb waitUntilCompleted];
	double tc = oracle_now_ms() - t0, tg = cb.GPUStartTime * 1e3 - t0, te = cb.GPUEndTime * 1e3 - t0;
	// Count the texels: A, B (and the rect bounding B's), anything else.
	const uint8_t *p = rb.contents;
	size_t na = 0, nb = 0, nx = 0;
	int x0 = w, y0 = h, x1 = 0, y1 = 0;
	for (int y = 0; y < h; y++) {
		for (int x = 0; x < w; x++) {
			const uint8_t *q = p + ((size_t)y * w + x) * 4;
			uint8_t v = q[0];
			if ((v != 'A' && v != 'B') || q[1] != v || q[2] != v || q[3] != v) {
				nx++;
				continue;
			}
			if (v == 'A') {
				na++;
				continue;
			}
			nb++;
			x0 = MIN(x0, x);
			y0 = MIN(y0, y);
			x1 = MAX(x1, x + 1);
			y1 = MAX(y1, y + 1);
		}
	}
	const bool whole = nb == (size_t)rw * rh && x0 == rx && y0 == ry && x1 == rx + rw && y1 == ry + rh;
	char seen[200];
	if (nb == 0 && nx == 0)
		snprintf(seen, sizeof seen, "A");
	else if (whole && nx == 0)
		snprintf(seen, sizeof seen, part ? "B (B in its rect, A elsewhere)" : "B");
	else if (nb)
		snprintf(seen, sizeof seen, "mixed: B %zu in (%d,%d)-(%d,%d), other %zu", nb, x0, y0, x1,
		         y1, nx);
	else
		snprintf(seen, sizeof seen, "mixed: A %zu, other %zu", na, nx);
	line(what, seen, tc);
	uint32_t *r = res.contents;
	if (step == 4)
		printf("    spin polls %u, saw flag %u\n", r[0], r[1]);
	printf("    texels A %zu, B %zu, other %zu; status %ld%s%s\n", na, nb, nx, (long)cb.status,
	       cb.error ? " error " : "", cb.error ? cb.error.description.UTF8String : "");
	char tbs[64] = "";
	if (tb >= 0)
		snprintf(tbs, sizeof tbs, "B replaced from %.2f to %.2f ms, ", tb, tw);
	printf("    the commit returned at %.2f ms, %sscheduled at %.2f ms, %s at %.2f ms, GPU from "
	       "%.2f to %.2f ms, completed at %.1f ms\n",
	       tr, tbs, ts, step == 4 ? "the spin let go" : "signalled", tsg, tg, te, tc);
	if (step < 2)
		return true;
	if (step >= 3 && !sched)
		printf("    not scheduled within 1 s of the commit: B landed before the scheduling\n");
	else if (step == 2 && (ts < 0 || ts > tb))
		printf("    B landed before the scheduling\n");
	if (nb == 0 && nx == 0)
		return true;
	if (tg > 0 && tg < tb) {
		printf("    B landed %.2f ms after the GPU started the buffer\n", tb - tg);
		return true;
	}
	printf("    B landed before the GPU started the buffer: open\n");
	return false;
}

static void case_mtexcap(const char *mode)
{
	const bool part = !strcmp(mode, "part");
	printf("case mtexcap %s: a 256x256 RGBA8 Managed texture replaced %s after the commit of a "
	       "command buffer that reads it\n",
	       part ? "part" : "full", part ? "in (64,64)-(192,128)" : "whole");
	const char *what[] = {
	    "A, commit, signal",
	    "A, B, commit, signal",
	    "A, commit, B at once, signal",
	    "A, commit, scheduled + 20 ms, B, signal",
	    "A, commit (spin), scheduled + 20 ms, B, let go",
	};
	mtexcap_step(nil, part, 0, what[0]);
	mtexcap_step(nil, part, 1, what[1]);
	if (mtexcap_step(nil, part, 2, what[2]) || mtexcap_step(nil, part, 3, what[3]))
		return;
	id<MTLLibrary> lib = oracle_library(D, gArgv0, "oracle");
	id<MTLComputePipelineState> spin = lib ? pipeline(lib, "spin_atomic") : nil;
	if (spin)
		mtexcap_step(spin, part, 4, what[4]);
}

static int run_case(int argc, char **argv)
{
	const char *c = argv[0];
	if (!strcmp(c, "mbuf"))
		case_mbuf(argc > 1 ? strtoull(argv[1], NULL, 0) : 4096);
	else if (!strcmp(c, "mtex"))
		case_mtex();
	else if (!strcmp(c, "shtex"))
		case_shtex();
	else if (!strcmp(c, "lintex"))
		case_lintex(argc > 1 ? argv[1] : "shared");
	else if (!strcmp(c, "linalign"))
		case_linalign();
	else if (!strcmp(c, "linarray"))
		case_linarray(argc > 1 ? argv[1] : "spi");
	else if (!strcmp(c, "lintypes"))
		case_lintypes(argc > 1 ? argv[1] : "public:3");
	else if (!strcmp(c, "didmodify"))
		case_didmodify(argc > 1 ? argv[1] : "length");
	else if (!strcmp(c, "nocopy"))
		case_nocopy();
	else if (!strcmp(c, "argenc"))
		case_argenc(argc > 1 ? argv[1] : "shared");
	else if (!strcmp(c, "spin"))
		case_spin();
	else if (!strcmp(c, "capture"))
		case_capture(argc > 1 ? strtoull(argv[1], NULL, 0) : 4096);
	else if (!strcmp(c, "mtexcap"))
		case_mtexcap(argc > 1 ? argv[1] : "full");
	else {
		printf("unknown case %s\n", c);
		return 2;
	}
	return 0;
}

int main(int argc, char **argv)
{
	setvbuf(stdout, NULL, _IOLBF, 0);
	gArgv0 = argv[0];
	if (argc < 2) {
		fprintf(stderr, "usage: %s DEVICE [CASE [ARG]]\n", argv[0]);
		return 2;
	}
	if (getenv("ORACLE_SPIN_POLLS"))
		gSpinPolls = (uint32_t)strtoul(getenv("ORACLE_SPIN_POLLS"), NULL, 0);
	if (getenv("ORACLE_PROGRESS_SPIN"))
		gProgressSpin = (uint32_t)strtoul(getenv("ORACLE_PROGRESS_SPIN"), NULL, 0);
	if (argc > 2 && !strcmp(argv[2], "--case")) {
		D = oracle_device(argv[1]);
		Q = [D newCommandQueue];
		return run_case(argc - 3, argv + 3);
	}
	D = oracle_device(argv[1]);
	oracle_header("oracle_storage", D);
	D = nil;
	static const char *const all[][2] = {
	    {"mbuf", "4096"}, {"mbuf", "67108864"}, {"mtex", NULL}, {"shtex", NULL},
	    {"lintex", "shared"}, {"lintex", "managed"}, {"argenc", "shared"},
	    {"argenc", "managed"}, {"nocopy", NULL}, {"didmodify", "length"},
	    {"didmodify", "nocopy"}, {"linalign", NULL}, {"linarray", "spi"},
	    {"linarray", "public"}, {"lintypes", "public:3"}, {"spin", NULL}, {"capture", NULL},
	    {"mtexcap", "full"},
	};
	size_t n = sizeof all / sizeof all[0];
	for (size_t i = 0; i < n; i++) {
		if (argc > 2 && strcmp(argv[2], all[i][0]))
			continue;
		const char *arg = argc > 3 ? argv[3] : all[i][1];
		char *args[] = {argv[0], argv[1], "--case", (char *)all[i][0], (char *)arg, NULL};
		pid_t pid;
		if (posix_spawn(&pid, argv[0], NULL, NULL, args, environ))
			return 1;
		int st;
		waitpid(pid, &st, 0);
		if (WIFSIGNALED(st))
			printf("  => case %s died on signal %d\n", all[i][0], WTERMSIG(st));
		else if (WEXITSTATUS(st))
			printf("  => case %s exited %d\n", all[i][0], WEXITSTATUS(st));
		if (argc > 3)
			break;
	}
	return 0;
}
